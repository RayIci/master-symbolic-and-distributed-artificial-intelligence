"""The dev UI's window: a pywebview shell in its own OS process.

Run as a script -- `python -m icaros.runtime.web.window <url> [title]` -- and
it opens a native window on that URL, blocking until the user closes it.

## Why a separate process

Importing pywebview's backend re-enables the GIL:

    RuntimeWarning: The global interpreter lock (GIL) has been enabled to
    load module 'gi._gi', which has not declared that it can run safely
    without the GIL.

icaros targets the free-threaded build precisely so agents run in parallel
(see pyproject.toml's requires-python rationale), so importing a webview
backend into the MAS process would quietly undo the reason the project is on
3.14t at all. It is also the convention every other GUI here already follows
-- grid_view.py, blocks_gui.py, auctioneer_gui_view.py and food_chart.py all
run in their own process, for the related reason that a toolkit wants the
process's main thread.

Nothing crosses the boundary but a URL: the window is an HTTP client of the
server running inside the MAS.

## Backends

pywebview is pure Python; its backend is not, and differs per OS:

- macOS: `pyobjc-framework-webkit` -- prebuilt cp314t wheels
- Windows: `pythonnet` (WebView2) -- prebuilt cp314t wheels
- Linux: `PyGObject` + WebKitGTK -- **no wheels**, compiled from source, so
  it needs meson plus the gobject-introspection and cairo development
  headers (`gobject-introspection`/`cairo` on Arch, `libgirepository1.0-dev`
  and `libcairo2-dev` on Debian/Ubuntu), and the WebKitGTK runtime.

All three are declared in the `devui` extra with platform markers. When the
backend is missing the launcher falls back to the default browser rather
than refusing to run -- a MAS must always start.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import webbrowser

logger = logging.getLogger(__name__)

WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 900


def _child_env() -> dict[str, str]:
    """The environment the window process gets.

    Two WebKitGTK workarounds, both measured here, both Linux-only, and both
    skipped if the variable is already set so they can be turned off.

    1. `GDK_BACKEND=x11` on Wayland sessions. Under *native* Wayland the
       window dies on startup with `Gdk-Message: Error 71 (Protocol error)
       dispatching to Wayland display` and exits 1 within a second; through
       XWayland the same build stays up and closes cleanly. XWayland ships
       with every Wayland desktop.

    2. `WEBKIT_DISABLE_DMABUF_RENDERER=1`. Without it the window renders
       **blank white** while the page underneath is perfectly fine -- probed
       from inside the running window, document.readyState was "complete",
       the body was 58 KB, the agent list was populated and the websocket
       was live, and the computed background was the dark theme colour. The
       giveaway was on stderr:

           Failed to create GBM buffer of size 2400x1600: Invalid argument

       i.e. WebKit's DMA-BUF accelerated renderer cannot allocate through
       this GPU/XWayland combination, so nothing gets painted. Disabling it
       falls back to software composition: 2 GBM errors before, 0 after.
    """
    env = dict(os.environ)
    if sys.platform != "linux":
        return env
    if env.get("WAYLAND_DISPLAY") and "GDK_BACKEND" not in env:
        env["GDK_BACKEND"] = "x11"
    env.setdefault("WEBKIT_DISABLE_DMABUF_RENDERER", "1")
    return env


class _Bridge:
    """The one thing the page cannot do for itself.

    ag: the hub needs a *path* on the server's filesystem, and a browser
    <input type="file"> only ever hands back a blob -- no path, by design.
    pywebview's native dialog does return one, and it runs here, in the
    window process, which is also the only process allowed to touch the
    toolkit. The page reaches it through window.pywebview.api; under the
    browser fallback there is no bridge and the hub's path field is the way in.
    """

    def pick_mas2i(self):
        import webview

        window = webview.windows[0] if webview.windows else None
        if window is None:
            return None
        chosen = window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=False,
            file_types=("MAS files (*.mas2i)", "All files (*.*)"))
        if not chosen:
            return None
        return chosen[0] if isinstance(chosen, (list, tuple)) else chosen


def open_window(url: str, title: str = "icaros") -> None:
    """Blocks until the window is closed. Only ever called in the child."""
    import webview

    webview.create_window(title, url, width=WINDOW_WIDTH, height=WINDOW_HEIGHT,
                          js_api=_Bridge())
    webview.start()


def _backend_hint() -> str:
    if sys.platform == "linux":
        return ("install a WebKitGTK backend: the `devui` extra builds PyGObject from "
                "source, which needs meson plus the gobject-introspection and cairo "
                "headers, and WebKitGTK at runtime")
    if sys.platform == "darwin":
        return "install the `devui` extra (pyobjc-framework-webkit)"
    return "install the `devui` extra (pythonnet, for WebView2)"


class WindowShell:
    """Launches the window process and waits for it, falling back to the
    default browser when there is no usable backend."""

    def __init__(self, url: str, title: str = "icaros") -> None:
        self._url = url
        self._title = title
        self._process: subprocess.Popen | None = None
        self._fell_back = False

    @property
    def fell_back(self) -> bool:
        return self._fell_back

    def start(self) -> None:
        # same idiom as grid_environment.py: sys.executable plus a module
        # that stands alone, so nothing but text crosses the boundary
        try:
            self._process = subprocess.Popen(
                [sys.executable, "-m", "icaros.runtime.web.window", self._url, self._title],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=_child_env())
        except OSError as e:
            logger.warning("could not launch the UI window process (%s)", e)
            self._fall_back()
            return
        # a missing backend shows up as an immediate non-zero exit, not as an
        # exception here, so give it a moment and check
        try:
            self._process.wait(timeout=1.5)
        except subprocess.TimeoutExpired:
            return  # still alive: the window is up
        stderr = (self._process.stderr.read() or "").strip().splitlines()
        detail = stderr[-1] if stderr else f"exit code {self._process.returncode}"
        logger.warning("the UI window could not open (%s); %s", detail, _backend_hint())
        self._fall_back()

    def _fall_back(self) -> None:
        self._process = None
        self._fell_back = True
        print(f"icaros dev UI: {self._url} (opening in your browser)", flush=True)
        webbrowser.open(self._url)

    def wait(self) -> None:
        """Blocks until the window is closed. With no window, blocks forever
        -- the caller (cli.run_web) treats Ctrl-C as the way out, exactly as
        run_headless does.

        ag: a window that dies *later* than start()'s 1.5 s liveness check used
        to be indistinguishable from one the user closed -- the MAS shut down
        and the process exited 0, with nothing on the terminal. A WebKit
        segfault five seconds in therefore looked like "icaros just quits".
        Closing a window is exit 0; anything else gets said out loud.
        """
        if self._process is not None:
            code = self._process.wait()
            if code != 0:
                self._report_death(code)
            return
        import time

        while True:
            time.sleep(1.0)

    def _report_death(self, code: int) -> None:
        stderr = ""
        if self._process is not None and self._process.stderr is not None:
            # safe to read only because the child has already exited
            stderr = (self._process.stderr.read() or "").strip()
        how = f"signal {-code}" if code < 0 else f"exit code {code}"
        last = stderr.splitlines()[-1] if stderr else "no output"
        logger.warning("the UI window died (%s): %s", how, last)
        print(f"icaros: the UI window died ({how}); the MAS is shutting down. "
              f"Re-run with --ui none to keep it headless.", flush=True)

    def stop(self) -> None:
        if self._process is not None and self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                self._process.kill()
        self._process = None


def main(argv: list[str] | None = None) -> None:
    args = sys.argv[1:] if argv is None else argv
    if not args:
        print("usage: python -m icaros.runtime.web.window <url> [title]", file=sys.stderr)
        raise SystemExit(2)
    open_window(args[0], args[1] if len(args) > 1 else "icaros")


if __name__ == "__main__":
    main()

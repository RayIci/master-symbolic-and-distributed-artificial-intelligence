from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_semantics.message import Message


class MsgListener:
    """Callback interface to be notified about every message routed through
    a Runner's agents, regardless of sender/receiver -- see
    CircumstanceListener for why this is a plain base class with a no-op
    body rather than Protocol/ABC.

    Runs on the sending agent's own reasoning thread, not the listener's --
    an implementation that mutates its own agent's state must marshal that
    mutation onto its own thread (e.g. via
    TransitionSystem.run_at_begin_of_next_cycle), not touch it directly."""

    def msg_sent(self, message: Message) -> None: ...
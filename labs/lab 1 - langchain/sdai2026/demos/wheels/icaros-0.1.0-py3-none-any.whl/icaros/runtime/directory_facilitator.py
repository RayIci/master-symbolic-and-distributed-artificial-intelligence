from __future__ import annotations

import threading
from typing import TYPE_CHECKING

from icaros.as_semantics.message import Message
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import create_literal
from icaros.as_syntax.string_term import StringTerm

if TYPE_CHECKING:
    from icaros.runtime.runner import Runner


class DirectoryFacilitator:
    """Registry of which agents provide which named services, plus
    subscriptions for future-provider notifications -- backs .df_register/
    .df_deregister/.df_search/.df_subscribe (stdlib/internal_actions/
    directory_facilitator.py).

    ag: Jason implements this as a real, sourceless, lazily-created agent
    ("df") whose belief base IS the registry, and delivers notifications by
    sending a message as if from that agent (BaseLocalMAS.dfRegister/
    dfSubscribe -> sendProvider, jason.infra.local.BaseLocalMAS). Ported here
    as a plain object owned by Runner instead: Runner already is the one
    shared per-MAS object every internal action can reach (ts.ag_arch.runner,
    the same chain .send/.broadcast already use), and AgArch.receive_msg
    doesn't need a real sender architecture -- it only appends to the
    receiver's mailbox and wakes it -- so no fake agent is needed to
    deliver a `tell`.

    `service_type` is accepted by every method (arity compatibility with
    Jason's 2-arg call forms) but never affects matching, faithfully
    matching Jason's own behavior on the local (non-JADE) infrastructure
    this ports -- JADE, where type is a real FIPA service-description
    field, is out of scope here.
    """

    def __init__(self, runner: Runner):
        self._runner = runner
        self._providers: dict[str, set[str]] = {}
        self._subscribers: dict[str, set[str]] = {}
        # guards _providers/_subscribers -- register/subscribe mutate one
        # dict-of-sets while iterating the other to notify, and remove_agent
        # (reachable from Runner.del_ag on a kill_agent Timer thread) walks
        # both entirely, so any of these running concurrently on the old,
        # lock-free version raced with "set/dict changed size during
        # iteration". RLock for consistency with Runner._lock.
        self._lock = threading.RLock()

    def register(self, agent_name: str, service: str, service_type: str | None = None) -> None:
        with self._lock:
            self._providers.setdefault(service, set()).add(agent_name)
            subscribers = list(self._subscribers.get(service, ()))
        # _notify (message delivery) runs outside the lock: short hold time,
        # no coupling between this registry lock and AgArch's own locking
        for subscriber in subscribers:
            self._notify(subscriber, agent_name, service)

    def deregister(self, agent_name: str, service: str, service_type: str | None = None) -> bool:
        """True iff agent_name was actually registered for service (and is
        now removed). ag: Jason's df_deregister always returns true,
        unconditionally -- the real boolean is used here instead, same
        deliberate improvement already made for .set.remove."""
        with self._lock:
            providers = self._providers.get(service)
            if providers is None or agent_name not in providers:
                return False
            providers.discard(agent_name)
            return True

    def search(self, service: str, service_type: str | None = None) -> list[str]:
        with self._lock:
            return sorted(self._providers.get(service, ()))

    def subscribe(self, subscriber_name: str, service: str, service_type: str | None = None) -> None:
        """Registers the subscription, then immediately notifies subscriber_name
        of every current provider of service (Jason's "subscribe now, get
        told about the future" contract -- see BaseLocalMAS.dfSubscribe)."""
        with self._lock:
            self._subscribers.setdefault(service, set()).add(subscriber_name)
            providers = list(self._providers.get(service, ()))
        for provider in providers:
            self._notify(subscriber_name, provider, service)

    def remove_agent(self, agent_name: str) -> None:
        """Drops every registration/subscription belonging to agent_name --
        called by Runner.del_ag, mirroring Jason's BaseLocalMAS.delAg."""
        with self._lock:
            for providers in self._providers.values():
                providers.discard(agent_name)
            for subscribers in self._subscribers.values():
                subscribers.discard(agent_name)

    def _notify(self, subscriber_name: str, provider_name: str, service: str) -> None:
        arch = self._runner.get_ag(subscriber_name)
        if arch is None:
            return
        content = create_literal("provider", Atom(provider_name), StringTerm(service))
        arch.receive_msg(Message("tell", "df", subscriber_name, content))
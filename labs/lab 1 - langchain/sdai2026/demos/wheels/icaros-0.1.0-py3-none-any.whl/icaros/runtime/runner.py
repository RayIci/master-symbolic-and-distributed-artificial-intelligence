from __future__ import annotations

import threading
from pathlib import Path
from typing import TYPE_CHECKING

from icaros.runtime.scheduler import AgentScheduler

if TYPE_CHECKING:
    from icaros.architecture.ag_arch import AgArch
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.message import Message
    from icaros.environment.environment import Environment
    from icaros.runtime.directory_facilitator import DirectoryFacilitator
    from icaros.runtime.msg_listener import MsgListener


class Runner:
    """Registry of the AgArchs running in this process, plus the DF (Directory
    Facilitator). Java splits this across BaseLocalMAS (registry + DF + debug
    console) and RuntimeServices (the public API); this port keeps the registry
    and the DF, but no debug console, no MAS2J project loading. create_agent/
    clone_agent/kill_agent below are a deliberately trimmed stand-in for Java's
    RuntimeServices/LocalRuntimeServices -- no custom agent/belief-base/
    architecture classes here (icaros has one un-chainable AgArch by design);
    that convention does exist, but only for `.mas2i`'s agent_class/
    ag_arch_class/belief_base_class (see mas2i/loader.py's _load_subclass),
    not (yet) for these runtime-facing methods.
    """

    def __init__(self):
        from icaros.runtime.directory_facilitator import DirectoryFacilitator

        self._ags: dict[str, AgArch] = {}
        self._environment: Environment | None = None
        self._df = DirectoryFacilitator(self)
        # set by mas2i/loader.py when the .mas2i specifies `threads: N` --
        # shared by every agent's AgArch.scheduler in this MAS (see ag_arch.py)
        self.scheduler: AgentScheduler | None = None
        # mas2i's `tui:`; False means run_headless even without --headless
        self.ui: str = "web"  # which frontend cli.main opens; see MASConfig.ui
        # (declared name, instance count) per `agent` block in the .mas2i,
        # in declaration order -- lets the runner name a 10,000-instance
        # group as "cell#10000" instead of listing every agent. Kept as the
        # loader's own record rather than inferred from the names, because
        # `cell1..cell10000` (one block, 10,000 instances) and `r1`, `r2`
        # (two blocks of one) are indistinguishable after the fact.
        self.agent_groups: list[tuple[str, int]] = []
        self._msg_listeners: list[MsgListener] = []
        # ag: guards the "check name uniqueness, then insert" sequence for
        # create_agent/clone_agent -- without it, two concurrent calls could
        # compute the same deduplicated name and the second add_ag would
        # silently overwrite the first in _ags (a plain dict assignment,
        # no error). Same reason Java's LocalRuntimeServices has a createLock.
        # RLock (not Lock): create_agent/clone_agent call get_new_agent_name
        # while already holding it.
        self._lock = threading.RLock()

    @property
    def environment(self) -> Environment | None:
        return self._environment

    @environment.setter
    def environment(self, environment: Environment) -> None:
        self._environment = environment
        environment.runner = self
        with self._lock:
            for ag_arch in self._ags.values():
                ag_arch.environment = environment

    def add_ag(self, ag_arch: AgArch) -> None:
        with self._lock:
            self._ags[ag_arch.ag_name] = ag_arch
        ag_arch.runner = self
        if self._environment is not None:
            ag_arch.environment = self._environment

    def add_msg_listener(self, listener: MsgListener) -> None:
        self._msg_listeners.append(listener)

    def remove_msg_listener(self, listener: MsgListener) -> None:
        try:
            self._msg_listeners.remove(listener)
        except ValueError:
            pass

    @property
    def msg_listeners(self) -> list[MsgListener]:
        return self._msg_listeners

    def notify_msg_sent(self, message: Message) -> None:
        for listener in list(self._msg_listeners):
            listener.msg_sent(message)

    @property
    def df(self) -> DirectoryFacilitator:
        return self._df

    def del_ag(self, ag_name: str) -> AgArch | None:
        self._df.remove_agent(ag_name)
        with self._lock:
            return self._ags.pop(ag_name, None)

    def get_ag(self, ag_name: str) -> AgArch | None:
        # ag: not locked -- a single dict.get() is already atomic (no
        # iteration, no compound op), both under the GIL and free-threaded.
        # This runs on every .send/.broadcast/wake, so don't add a lock here.
        return self._ags.get(ag_name)

    @property
    def ags(self) -> dict[str, AgArch]:
        # a snapshot, not the live dict -- callers (broadcast,
        # inform_ags_environment_changed, ...) iterate this, and del_ag can
        # pop from a Timer thread (kill_agent) concurrently
        with self._lock:
            return dict(self._ags)

    def agent_names(self) -> list[str]:
        with self._lock:
            return list(self._ags.keys())

    def ag_list(self) -> list[AgArch]:
        # ag: cheaper than `ags` for the common "iterate every agent" case
        # (wakes, teardown): one list, not a full dict copy -- at 10,000
        # agents `ags` rebuilds a 10,000-entry dict on every step boundary
        with self._lock:
            return list(self._ags.values())

    def stop_all(self, timeout: float | None = None) -> None:
        """Stops every registered agent in two phases -- signal all, then join
        all -- so teardown costs one wake round trip in total instead of one
        per agent (see AgArch.signal_stop)."""
        arches = self.ag_list()
        for arch in arches:
            arch.signal_stop()
        for arch in arches:
            arch.join_stopped(timeout)

    @property
    def nb_agents(self) -> int:
        # ag: not locked, same reasoning as get_ag -- len() on a dict is a
        # single atomic read, not an iteration
        return len(self._ags)

    def get_new_agent_name(self, base: str) -> str:
        """base, base_1, base_2, ... -- first name not already registered.
        Call sites that need the dedup+insert to be atomic (create_agent/
        clone_agent) must do so under self._lock themselves."""
        with self._lock:
            if base not in self._ags:
                return base
            n = 1
            while f"{base}_{n}" in self._ags:
                n += 1
            return f"{base}_{n}"

    def create_agent(self, name: str, source: str | Path,
                      beliefs=None, extra_ia_paths=None) -> AgArch:
        """Boots a new agent from an .asl file and registers it (does not
        start its thread -- same division of responsibility as boot_agent/
        load_mas: starting is always the caller's decision)."""
        from icaros.runtime.boot import boot_agent

        with self._lock:
            deduped = self.get_new_agent_name(name)
            ag_arch = boot_agent(source, name=deduped)
            self.add_ag(ag_arch)

        if beliefs:
            for b in beliefs:
                ag_arch.ts.ag.bb.add(b.copy())
        if extra_ia_paths:
            from icaros.stdlib.registry import load_internal_actions
            ag_arch.ts.ag.register_internal_actions(load_internal_actions(extra_paths=extra_ia_paths))
        return ag_arch

    def clone_agent(self, source_agent: Agent, name: str) -> AgArch:
        """Clones source_agent's beliefs and plans into a freshly registered
        agent (no .asl file involved -- unlike create_agent). Thread not
        started, same convention as create_agent."""
        from icaros.architecture.ag_arch import AgArch
        from icaros.as_semantics.agent import Agent as AgentClass
        from icaros.as_semantics.transition_system import TransitionSystem

        with self._lock:
            deduped = self.get_new_agent_name(name)
            new_agent = AgentClass()
            for b in source_agent.bb:
                new_agent.bb.add(b.copy())
            new_agent.pl.join(source_agent.pl)

            ag_arch = AgArch()
            ag_arch.ag_name = deduped
            TransitionSystem(new_agent, None, ag_arch)  # wires new_agent.ts / ag_arch.ts
            self.add_ag(ag_arch)
        return ag_arch

    def kill_agent(self, name: str, deadline_ms: float = 0) -> bool:
        """Stops and unregisters the named agent asynchronously (fire-and-
        forget, matching Java's killAgent): the actual stop happens on a
        separate timer thread after deadline_ms, so the caller is never
        blocked by AgArch.stop_ag()'s blocking thread-join, even when
        deadline_ms is 0."""
        arch = self.get_ag(name)
        if arch is None:
            return False

        def do_kill() -> None:
            arch.stop_ag()
            self.del_ag(name)

        timer = threading.Timer(max(deadline_ms, 0) / 1000.0, do_kill)
        timer.daemon = True
        timer.start()
        return True
from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.architecture.ag_arch import AgArch

# how long a paused agent naps between rechecks. A missed notify then costs
# this much rather than hanging the agent until something else wakes it.
PAUSE_POLL_SECONDS = 0.2


@dataclass(slots=True)
class BreakpointHit:
    agent: str
    cycle: int
    reason: str  # always "plan": the .asl source's own [breakpoint] annotation
    what: str  # "@[breakpoint]"
    source: str | None = None


@dataclass(slots=True)
class _AgentDebugState:
    paused: bool = False
    steps_left: int = 0
    hit: BreakpointHit | None = None


class DebugController:
    """Pause, step and breakpoints for a running MAS.

    Installed into AgArch._exec_control -- the slot that has been sitting at
    None since the port, waiting for Jason's ExecutionControl. Two entry
    points, because the two scheduling modes need opposite behaviour:

    - `before_cycle(arch)` **blocks**. Used by AgArch.run(), where the agent
      owns its thread and parking it costs nothing.
    - `may_run(arch)` **never blocks**. Used by AgArch._run_batch(), where
      the thread belongs to a shared pool: parking there with `threads: 1`
      would freeze the entire MAS. A paused pooled agent de-schedules itself
      exactly the way a sleeping one does, and resume() wakes it.

    Governing rule: a reasoning cycle is never interrupted half-way. Pause is
    observed only at the top of the loop, so every Circumstance invariant
    holds and "paused" is a state another thread can safely read from.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._condition = threading.Condition(self._lock)
        self._states: dict[str, _AgentDebugState] = {}
        self._on_hit = None  # set by the UI: called on the agent's thread

    # ---- state -------------------------------------------------------

    def _state(self, name: str) -> _AgentDebugState:
        state = self._states.get(name)
        if state is None:
            state = self._states[name] = _AgentDebugState()
        return state

    def status(self, name: str) -> dict:
        with self._lock:
            state = self._state(name)
            return {
                "paused": state.paused,
                "steps_left": state.steps_left,
                "hit": None if state.hit is None else {
                    "reason": state.hit.reason, "what": state.hit.what,
                    "cycle": state.hit.cycle, "source": state.hit.source},
            }

    def set_on_hit(self, callback) -> None:
        """Called on the agent's own thread the moment a breakpoint fires, so
        the UI can wake its websocket immediately instead of waiting for the
        next poll."""
        self._on_hit = callback

    # ---- commands (called from the server thread) ---------------------

    def pause(self, name: str) -> None:
        with self._lock:
            state = self._state(name)
            state.paused = True
            state.steps_left = 0

    def resume(self, name: str, ag_arch: AgArch | None = None) -> None:
        with self._lock:
            state = self._state(name)
            state.paused = False
            state.steps_left = 0
            state.hit = None
            self._condition.notify_all()
        if ag_arch is not None:
            # pooled mode parked by clearing _scheduled; only wake() re-queues it
            ag_arch.wake()

    def step(self, name: str, count: int = 1, ag_arch: AgArch | None = None) -> None:
        with self._lock:
            state = self._state(name)
            state.paused = True
            state.steps_left = max(1, count)
            state.hit = None
            self._condition.notify_all()
        if ag_arch is not None:
            ag_arch.wake()

    def release_all(self) -> None:
        """Lets every paused agent out. Called from AgArch.signal_stop --
        wake() notifies the sleep condition, not this one, so without this a
        paused agent would sit here until the join timed out."""
        with self._lock:
            for state in self._states.values():
                state.paused = False
                state.steps_left = 0
            self._condition.notify_all()

    # ---- hooks (called on the agent's own thread) ---------------------

    def before_cycle(self, ag_arch: AgArch) -> None:
        """Dedicated-thread mode. Blocks while paused."""
        name = ag_arch.ag_name
        with self._condition:
            while True:
                state = self._state(name)
                if not state.paused:
                    return
                if state.steps_left > 0:
                    state.steps_left -= 1
                    if state.steps_left == 0:
                        state.hit = None
                    return
                if not ag_arch.is_running():
                    return
                # timed wait: a missed notify costs 200 ms, never a hang
                self._condition.wait(PAUSE_POLL_SECONDS)

    def may_run(self, ag_arch: AgArch) -> bool:
        """Pooled mode. Never blocks -- the caller de-schedules on False."""
        with self._lock:
            state = self._state(ag_arch.ag_name)
            if not state.paused:
                return True
            if state.steps_left > 0:
                state.steps_left -= 1
                if state.steps_left == 0:
                    state.hit = None
                return True
            return False

    def note_plan_pushed(self, ag_arch: AgArch, plan, trigger) -> None:
        """Called from TransitionSystem when an intended means is pushed --
        the one place that sees both the chosen plan and its trigger.

        The agent parks at the *next* top of loop, so the UI shows "paused
        after the cycle in which +!g fired". Deliberate: stopping mid-cycle
        would mean exposing a half-updated Circumstance.

        The only breakpoint left is the one authored in the .asl source
        itself, via the `[breakpoint]` plan annotation -- the UI-managed
        trigger/regex/label breakpoints this used to also check were removed
        along with the "Breakpoints" card that was their only caller.
        """
        if not plan.has_breakpoint():
            return
        name = ag_arch.ag_name
        info = getattr(plan, "src_info", None)
        with self._lock:
            state = self._state(name)
            state.paused = True
            state.steps_left = 0
            state.hit = BreakpointHit(agent=name, cycle=ag_arch.ts.cycle_count,
                                      reason="plan", what="@[breakpoint]",
                                      source=str(info) if info is not None else None)
            hit = state.hit
        if self._on_hit is not None:
            self._on_hit(hit)

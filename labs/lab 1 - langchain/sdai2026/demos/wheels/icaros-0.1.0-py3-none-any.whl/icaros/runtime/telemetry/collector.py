from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from icaros.runtime.telemetry import inspect as agent_inspect
from icaros.runtime.telemetry.model import AgentState, TraceEvent
from icaros.runtime.telemetry.ring import EventRing

if TYPE_CHECKING:
    from icaros.architecture.ag_arch import AgArch
    from icaros.runtime.telemetry.model import AgentCounters
    from icaros.runtime.session import MasSession


@dataclass(slots=True)
class _StateRequest:
    """One reader's question, waiting for the agent to answer it.

    Its own Event and its own answer slot: that is the whole point. Two
    readers must not be able to consume each other's wakeup or each other's
    state, which is exactly what a shared Event and a shared field allowed.
    """

    kinds: tuple[str, ...]
    answered: threading.Event = field(default_factory=threading.Event)
    state: AgentState | None = None


class AgentCollector:
    """Telemetry for one agent: cheap counters every cycle, deep state only
    when somebody asks.

    ag: the split is the whole point. The TUI's snapshot() stringified the
    entire belief base on every cycle on the agent's own thread, whether or
    not anyone was looking at that agent -- that cost is proportional to
    agents x cycles. Here on_cycle publishes five ints unless a request is
    pending, so a collapsed panel costs one `is None` check per cycle and the
    expensive read happens once per question asked.
    """

    def __init__(self, ag_arch: AgArch, ring: EventRing) -> None:
        self._ag_arch = ag_arch
        self._ring = ring
        self._counters: AgentCounters | None = None
        self._beliefs: list[str] | None = None
        self._lock = threading.Lock()
        # ag: one ticket per question, not one shared slot. _state/_answered
        # used to be single fields, so two overlapping readers (the mind
        # pane's 1 Hz poll overlapping itself while an agent is slow, a second
        # browser window) clobbered each other: B's Event.clear() could eat the
        # wakeup A was waiting for, and A could return the state built for B.
        # A ticket is answered exactly once, by the cycle that served it.
        self._pending: list[_StateRequest] = []
        self._previous_on_cycle = None
        self._previous_on_print = None
        self._previous_on_call = None
        self._previous_on_call_started = None
        self._previous_on_chunk = None
        self._on_llm_call = None  # set by MasCollector, which owns the transcript store

    @property
    def ag_arch(self) -> AgArch:
        return self._ag_arch

    @property
    def counters(self) -> AgentCounters | None:
        """Latest published counters, or None before the first cycle."""
        return self._counters

    @property
    def beliefs(self) -> list[str] | None:
        """Latest published belief texts, or None before the first cycle.

        Refreshed here rather than mirrored from BB_DELTA journal entries: a
        belief base does its own add/remove/merge bookkeeping (BeliefBase.add
        can merge annotations onto an existing belief instead of appending
        one, abolish() can drop a whole predicate at once), and reimplementing
        that bookkeeping in a second place, from a diff of texts, is a second
        place for it to drift out of sync. One `str()` pass over the real
        thing every cycle, on the thread that owns it, has no such duplicate
        logic to keep honest.

        A plain reference swap, like `_counters` above: readers on another
        thread get either the whole old list or the whole new one, never a
        half-built one, without a lock -- the atomicity a lock would buy here
        is already free.
        """
        return self._beliefs

    def on_cycle(self, ag_arch: AgArch) -> None:
        """Runs on the agent's own thread, synchronously after each reasoning
        cycle -- so this is a consistent read, and it blocks that agent's
        loop for exactly as long as it takes."""
        self._counters = agent_inspect.counters(ag_arch)
        # ag: cheap relative to what request_state() can cost (intentions,
        # mailbox, deliberation), and unlike those, safe to publish
        # unconditionally: a browser watching the beliefs card should not have
        # to wait out an LLM round trip, or the busy-skip built for the
        # EXPENSIVE deep read (see app.js's refreshDetail), just to see a
        # belief that changed a cycle ago.
        self._beliefs = [v.text for v in agent_inspect.beliefs(ag_arch)]
        # fast path, no lock: a request that lands right after this check is
        # simply served one cycle later, which is the same staleness the
        # design already accepts
        if not self._pending:
            return
        with self._lock:
            waiting, self._pending = self._pending, []
        # ag: one read for the union of what everybody asked, then the same
        # AgentState handed to each -- it is a snapshot of one cycle, so two
        # readers sharing it are not sharing staleness, they are sharing the
        # answer. The alternative (one agent_state() per waiter) would multiply
        # the one genuinely expensive thing this class does.
        kinds = tuple(k for k in agent_inspect.KINDS
                      if any(k in request.kinds for request in waiting))
        state = agent_inspect.agent_state(ag_arch, kinds)
        for request in waiting:
            request.state = state
            request.answered.set()

    def request_state(self, kinds: tuple[str, ...] = agent_inspect.KINDS,
                       timeout: float = 2.0) -> AgentState | None:
        """Asks the agent to publish a deep read of itself at the end of its
        next cycle, and waits for it. Returns None on timeout -- an agent
        blocked in a long act(), or one that has stopped, never answers, and
        a UI must show "not responding" rather than hang.

        A paused agent runs no cycle either, and this will time out on one:
        read_state_directly() is the right call there, and the debug
        controller is what says which case you are in.
        """
        request = _StateRequest(kinds=tuple(kinds))
        with self._lock:
            self._pending.append(request)
        if not request.answered.wait(timeout):
            # ag: withdraw it. Left in the queue, an abandoned request makes
            # the agent pay a full agent_state() on some later cycle for
            # nobody -- and that used to be every timed-out poll of a paused
            # agent, i.e. all of them.
            with self._lock:
                if request in self._pending:
                    self._pending.remove(request)
                    return None
            # served between the timeout and the withdrawal: the answer is
            # here and it is this request's own, so it is worth having
            return request.state
        return request.state

    def read_state_directly(self, kinds: tuple[str, ...] = agent_inspect.KINDS) -> AgentState:
        """Deep read from the caller's thread, without waiting for a cycle.

        Only safe when the agent is known not to be running -- parked on a
        debugger pause, or stopped. Reading a live Circumstance from another
        thread is a data race: under free-threading, iterating a deque while
        the owner mutates it can raise or tear, not merely go stale.
        """
        return agent_inspect.agent_state(self._ag_arch, kinds)

    def _mirror_journal(self, entry) -> None:
        """One journal entry, onto the MAS-wide ring.

        ag: this is why deliberations and belief deltas need no listener of
        their own here. The agent records them for itself whether or not
        anyone is collecting; a UI is just a second reader of the same entry,
        and the ring stays the single ordered timeline it already was.
        """
        self._ring.append(TraceEvent(
            seq=-1, kind=entry.kind.value, agent=self._ag_arch.ag_name,
            cycle=entry.cycle, at=time.time(), detail=dict(entry.detail)))

    def attach(self, capture_console: bool = False) -> None:
        """`capture_console` means "this collector is now the agent's
        console": .print output is routed here and stops going to the
        terminal. False (the default) leaves the terminal alone, which is
        what a headless run collecting only LLM traces wants."""
        ts = self._ag_arch.ts
        # ag: telemetry registers NO listener of its own -- not on the
        # Circumstance, not on goals, not on the plan library. Those interfaces
        # are an extension mechanism built on the assumption that nobody is
        # listening (Circumstance guards six notification sites with
        # `if self._listeners:`), so a UI that used them would make every agent
        # in the MAS pay the slow path for as long as a browser stayed open.
        # Everything the timeline shows now comes from mirroring the agent's
        # own journal, which the interpreter writes regardless.
        ts.ag.journal.add_observer(self._mirror_journal)
        # on_cycle/on_print are single slots, not fan-out lists: chain onto
        # whatever was there so attaching never silently unhooks another
        # consumer, and detach() can put it back
        self._previous_on_cycle = self._ag_arch.on_cycle
        self._previous_on_print = self._ag_arch.on_print
        self._ag_arch.on_cycle = self._fire_on_cycle
        if capture_console:
            self._ag_arch.on_print = self._fire_on_print
        if ts.agentic is not None:
            # ag: getattr, not attribute access -- `agentic` is duck-typed
            # (every test fake is a bare object with a _round()), and a fake
            # that never heard of this hook must not make attach() explode.
            self._previous_on_call = getattr(ts.agentic, "on_call_finished", None)
            ts.agentic.on_call_finished = self._fire_on_call
            self._previous_on_call_started = getattr(ts.agentic, "on_call_started", None)
            ts.agentic.on_call_started = self._fire_on_call_started
            self._previous_on_chunk = getattr(ts.agentic, "on_call_chunk", None)
            ts.agentic.on_call_chunk = self._fire_on_call_chunk

    def _fire_on_cycle(self, ag_arch: AgArch) -> None:
        if self._previous_on_cycle is not None:
            self._previous_on_cycle(ag_arch)
        self.on_cycle(ag_arch)

    def _fire_on_print(self, text: str) -> None:
        # ag: setting on_print at all is what takes the console off the
        # terminal (see AgArch.print) -- that is this hook's whole remaining
        # job. The line itself reaches the ring through the journal mirror,
        # so emitting here too would double every printed line.
        if self._previous_on_print is not None:
            self._previous_on_print(text)

    def _fire_on_call_started(self, call) -> None:
        if self._previous_on_call_started is not None:
            self._previous_on_call_started(call)
        # ag: a plain field write, not under self._lock -- on_cycle's own
        # counters publish is unsynchronized the same way (a busy MAS builds
        # thousands of these; a reader seeing last cycle's counters for one
        # more tick is the staleness this whole class already accepts).
        if self._counters is not None:
            self._counters.busy = True

    def _fire_on_call_chunk(self, call, text: str) -> None:
        """A piece of a chat answer, on its way to whoever is watching.

        ag: straight to the ring, NOT through the journal -- the one place
        this class does that for something the agent produced, and on purpose.
        The journal is the agent's own memory (see .say's own reasoning in
        stdlib/internal_actions/chat.py): an agent should remember that it
        said something, not that it had said half of it. The finished sentence
        arrives as a SAY entry moments later, through the mirror, and that is
        the one that is remembered and the one the chat keeps.
        """
        if self._previous_on_chunk is not None:
            self._previous_on_chunk(call, text)
        self._ring.append(TraceEvent(
            seq=-1, kind="llm_chunk", agent=call.agent, cycle=call.cycle,
            at=time.time(), detail={"session": str(call.session), "text": text}))

    def _fire_on_call(self, call) -> None:
        if self._counters is not None:
            self._counters.busy = False
        if self._previous_on_call is not None:
            self._previous_on_call(call)
        if self._on_llm_call is not None:
            self._on_llm_call(call)

    def detach(self) -> None:
        ts = self._ag_arch.ts
        ts.ag.journal.remove_observer(self._mirror_journal)
        self._ag_arch.on_cycle = self._previous_on_cycle
        self._ag_arch.on_print = self._previous_on_print
        if ts.agentic is not None:
            ts.agentic.on_call_finished = self._previous_on_call
            ts.agentic.on_call_started = self._previous_on_call_started
            ts.agentic.on_call_chunk = self._previous_on_chunk


class MasCollector:
    """Telemetry for a whole MAS: one ring shared by every agent, one
    collector per agent, plus the MAS-wide message stream."""

    def __init__(self, agents: list[AgArch], capacity: int | None = None,
                 transcripts: int = 256) -> None:
        self._ring = EventRing() if capacity is None else EventRing(capacity)
        self._agents = {a.ag_name: AgentCollector(a, self._ring) for a in agents}
        self._runner = agents[0].runner if agents else None
        self._attached = False
        # ag: an LlmCall carries a whole prompt plus the model's reasoning --
        # kilobytes each. The ring gets a one-line summary so the timeline
        # stays cheap and ordered; the full transcript is kept here, keyed by
        # the summary's seq, and pulled only when someone opens that row.
        self._lock = threading.Lock()
        self._transcripts: dict[int, object] = {}
        self._transcript_order: deque[int] = deque(maxlen=transcripts)
        self._llm_sinks: list = []
        self._log_handler: logging.Handler | None = None
        self._log_propagated = True

    @property
    def ring(self) -> EventRing:
        return self._ring

    def add_llm_sink(self, sink) -> None:
        """Every LlmCall also goes to `sink` -- used by the .jsonl writer, so
        a `--ui none` run still gets its trace."""
        self._llm_sinks.append(sink)

    def transcript(self, seq: int):
        """The full LlmCall behind a timeline row, or None once evicted."""
        with self._lock:
            return self._transcripts.get(seq)

    def _record_llm_call(self, call) -> None:
        seq = self._ring.append(TraceEvent(
            seq=-1, kind="llm_call", agent=call.agent, cycle=call.cycle, at=call.started_at,
            detail={"purpose": call.purpose, "model": str(call.model),
                    "duration_ms": f"{call.duration_ms:.0f}",
                    "choice": str(call.choice), "error": str(call.error),
                    "thinking": "yes" if call.thinking else "no",
                    "options": str(len(call.options)), "tools": str(len(call.tool_specs)),
                    # a generation round: which session, at which level, and
                    # what it reached for. Empty for the select_* calls, which
                    # belong to no session and call nothing.
                    "level": str(call.level), "session": str(call.session),
                    "called": ", ".join(c["name"] for c in call.tool_calls)},
        ))
        with self._lock:
            if len(self._transcript_order) == self._transcript_order.maxlen:
                self._transcripts.pop(self._transcript_order[0], None)
            self._transcript_order.append(seq)
            self._transcripts[seq] = call
        for sink in self._llm_sinks:
            sink(call)

    @property
    def agents(self) -> dict[str, AgentCollector]:
        return self._agents

    def __getitem__(self, name: str) -> AgentCollector:
        return self._agents[name]

    def counters(self) -> dict[str, AgentCounters]:
        """The overview grid: whatever each agent published last cycle."""
        return {name: c.counters for name, c in self._agents.items() if c.counters is not None}

    def log(self, kind: str, **detail) -> None:
        """MAS-level events with no owning agent (environment log lines,
        interpreter warnings)."""
        self._ring.append(TraceEvent(seq=-1, kind=kind, agent="", cycle=-1, at=time.time(),
                                     detail={k: str(v) for k, v in detail.items()}))

    def attach(self, session: MasSession | None = None,
               capture_console: bool = False) -> None:
        """`capture_console` means a UI is showing this MAS, so everything
        the runtime would have printed -- .print output, environment log
        lines, interpreter logging -- comes here instead of to the terminal.
        A headless run collecting only LLM traces leaves it False and keeps
        its terminal output."""
        if self._attached:
            return
        self._attached = True
        for collector in self._agents.values():
            collector._on_llm_call = self._record_llm_call
            collector.attach(capture_console)
        if not capture_console:
            return
        environment = session.environment if session is not None else None
        if environment is not None:
            environment.log_sink = lambda line: self.log("environment", line=line)
        self._capture_logging()

    def _capture_logging(self) -> None:
        """Routes the interpreter's own logging into the ring, and stops it
        reaching the terminal.

        ag: two halves, and the second is the one that is easy to miss. The
        handler makes warnings and internal-action failures visible in the
        UI; `propagate = False` stops the same records ALSO going to the root
        handler cli.main installs, which would print them to stderr behind
        the UI's back -- the duplication the old TUI suffered from and never
        fixed. Both are undone in detach(), so a library embedder gets its
        logging setup back exactly as it was.
        """
        collector = self

        class _RingHandler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                try:
                    collector.log("log", level=record.levelname,
                                  logger=record.name, line=record.getMessage())
                except Exception:
                    self.handleError(record)

        logger = logging.getLogger("icaros")
        self._log_handler = _RingHandler(level=logging.INFO)
        self._log_propagated = logger.propagate
        logger.addHandler(self._log_handler)
        logger.propagate = False

    def detach(self) -> None:
        if not self._attached:
            return
        self._attached = False
        for collector in self._agents.values():
            collector.detach()
        if self._log_handler is not None:
            logger = logging.getLogger("icaros")
            logger.removeHandler(self._log_handler)
            logger.propagate = self._log_propagated
            self._log_handler = None

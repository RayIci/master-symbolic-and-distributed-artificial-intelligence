from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.journal.deliberation import is_generated_label
from icaros.llm import call_id_of
from icaros.runtime.telemetry.model import (
    AgentCounters,
    AgentState,
    BeliefView,
    DeliberationView,
    ForkView,
    IntendedMeansView,
    IntentionView,
    OptionView,
)
from icaros.stdlib.internal_actions.fork import ForkIntention

if TYPE_CHECKING:
    from icaros.architecture.ag_arch import AgArch
    from icaros.as_semantics.intention import Intention
    from icaros.as_semantics.option import Option
    from icaros.as_semantics.unifier import Unifier

# what a caller may ask AgentState to include, beyond the always-present counters
KINDS = ("beliefs", "intentions", "deliberation", "mailbox")


# ag: every function here reads live interpreter state, so all of them must
# run on the owning agent's thread -- from AgArch.on_cycle, or against an
# agent that is parked. Reading a Circumstance deque from another thread is a
# data race, and under free-threading iteration over a mutating deque can
# raise or tear rather than merely return something stale.


def counters(ag_arch: AgArch) -> AgentCounters:
    """The per-cycle read. No collection is walked: `len()` on a deque is
    O(1), and this runs after every single reasoning cycle."""
    ts = ag_arch.ts
    circumstance = ts.circumstance
    return AgentCounters(
        cycle=ts.cycle_count,
        sleeping=ag_arch.is_sleeping,
        pending_events=len(circumstance.events),
        mailbox=len(circumstance.mailbox),
        running_intentions=circumstance.nb_running_intentions,
    )


def _source(term) -> str | None:
    info = getattr(term, "src_info", None)
    return str(info) if info is not None else None


def _bindings(unifier: Unifier | None) -> dict[str, str]:
    if unifier is None:
        return {}
    return {str(var): str(unifier.get(var)) for var in unifier}


def beliefs(ag_arch: AgArch) -> list[BeliefView]:
    out = []
    for belief in ag_arch.ts.ag.bb:
        # ag: same namespace drop as Agent._journal_beliefs -- kqml holds four
        # static rules from pl/kqml_plans.asl and nothing else, so this is
        # exactly the interpreter's own plumbing, not agent state worth a row.
        if belief.ns.functor == "kqml":
            continue
        out.append(BeliefView(text=str(belief),
                              functor=belief.functor,
                              arity=belief.get_arity()))
    return out


def _intended_means(im) -> IntendedMeansView:
    plan = im.plan
    label = plan.label
    step = im.current_step
    return IntendedMeansView(
        # a generated p__N says nothing next to the trigger already shown
        plan_label=str(label) if label is not None and not is_generated_label(label) else None,
        trigger=str(im.trigger),
        source=_source(plan),
        current_step=str(step) if step is not None else None,
        llm_call_id=call_id_of(im.trigger),
    )


def _fork_view(intention: Intention) -> ForkView | None:
    if not isinstance(intention, ForkIntention):
        return None
    fork_data = intention.fork_data
    # ForkIntention.fork_point is parent.size() at fork time, INCLUDING the
    # one frame that was running .fork itself -- that frame gets cloned, not
    # shared (fork.py's Fork.execute), so it counts as this branch's own, and
    # only the fork_point - 1 frames below it are truly shared ancestry.
    return ForkView(
        group_id=str(id(fork_data)),
        shared_frames=max(intention.fork_point - 1, 0),
        is_and=fork_data.is_and,
        to_finish=fork_data.to_finish,
        sibling_ids=[str(i.id) for i in fork_data.intentions if i is not intention],
    )


def _intention(intention: Intention) -> IntentionView:
    stack = [_intended_means(im) for im in intention]
    return IntentionView(
        id=str(intention.id),
        depth=len(stack),
        suspended=intention.suspended,
        tool_call=any(im.llm_call_id is not None for im in stack),
        stack=stack,
        fork=_fork_view(intention),
    )


def intentions(ag_arch: AgArch) -> list[IntentionView]:
    """Every intention the agent is holding, not just the runnable queue.

    ag: Circumstance.running_intentions is only the deque of intentions
    waiting for a turn -- the one actually being executed has been moved to
    `selected_intention` and a suspended one lives in `_pending_intentions`,
    so a debugger reading `running_intentions` right after a cycle sees an
    empty list while the agent is visibly busy. all_intentions() is the
    interpreter's own complete, de-duplicated snapshot (and it snapshots, so
    it is safe to iterate while the owner mutates).
    """
    return [_intention(i) for i in ag_arch.ts.circumstance.all_intentions()]


def _option(option: Option, *, applicable: bool) -> OptionView:
    plan = option.plan
    label = plan.label
    context = plan.context
    return OptionView(
        plan_label=str(label) if label is not None else None,
        trigger=str(plan.trigger),
        context=str(context) if context is not None else None,
        source=_source(plan),
        bindings=_bindings(option.unifier),
        applicable=applicable,
        breakpoint=plan.has_breakpoint(),
    )


def deliberation(ag_arch: AgArch) -> DeliberationView:
    """The plan-selection state of the cycle that just ran: which plans
    matched the trigger, which of those had their context hold, and which one
    won. Circumstance.reset_deliberate() clears all of it at the top of the
    next cycle, so this is only meaningful right after a cycle.

    ag: `relevant_plans`/`applicable_plans` on the Circumstance are usually
    None even after a perfectly normal cycle -- _select_applicable_plan
    (transition_system.py, the "fast track of _find_option") walks the plan
    library and picks a winner in one pass, so the deliberate loop goes
    SEL_EV -> SEL_APPL and the two intermediate lists are only filled on the
    JasonER scope path. Reporting them raw would show a debugger nothing on
    the main path, so when they are absent this recomputes them from the
    selected event, through the very same Agent.relevant_plans /
    Agent.applicable_plans the interpreter uses. `recomputed` says which
    happened: recomputed answers "what applies now", the recorded lists
    answer "what applied then", and for a paused agent they are the same.
    """
    circumstance = ag_arch.ts.circumstance
    relevant_options = circumstance.relevant_plans
    applicable_options = circumstance.applicable_plans
    event = circumstance.selected_event
    recomputed = False
    if relevant_options is None and event is not None:
        recomputed = True
        agent = ag_arch.ts.ag
        relevant_options = agent.relevant_plans(event.trigger, event)
        applicable_options = agent.applicable_plans(relevant_options)
    relevant_options = relevant_options or []
    applicable_options = applicable_options or []
    # identity, not equality: Option has no __eq__, and two options for the
    # same plan with different unifiers are genuinely different rows
    applicable_ids = {id(o) for o in applicable_options}

    selected = circumstance.selected_option
    selected_intention = circumstance.selected_intention
    deed = circumstance.last_deed
    return DeliberationView(
        selected_event=str(event.trigger) if event is not None else None,
        relevant=[_option(o, applicable=id(o) in applicable_ids) for o in relevant_options],
        applicable=[_option(o, applicable=True) for o in applicable_options],
        selected_option=_option(selected, applicable=True) if selected is not None else None,
        selected_intention=str(selected_intention.id) if selected_intention is not None else None,
        last_deed=str(deed) if deed is not None else None,
        recomputed=recomputed,
    )


def mailbox(ag_arch: AgArch) -> list[str]:
    return [str(m) for m in ag_arch.ts.circumstance.mailbox]


_COLLECTORS = {
    "beliefs": beliefs,
    "intentions": intentions,
    "deliberation": deliberation,
    "mailbox": mailbox,
}


def agent_state(ag_arch: AgArch, kinds: tuple[str, ...] = KINDS) -> AgentState:
    """A deep read of the requested parts. An unrequested part stays None --
    "not collected", never "empty"."""
    unknown = set(kinds) - set(_COLLECTORS)
    if unknown:
        raise ValueError(f"unknown inspection kind(s): {', '.join(sorted(unknown))}")
    numbers = counters(ag_arch)
    state = AgentState(name=ag_arch.ag_name, at_cycle=numbers.cycle, counters=numbers)
    for kind in kinds:
        setattr(state, kind, _COLLECTORS[kind](ag_arch))
    return state

from __future__ import annotations

import asyncio
from collections import Counter
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import uuid4

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from icaros.as_semantics.message import Message
from icaros.as_syntax.factory import create_literal, create_string
from icaros.llm import IcarosState
from icaros.runtime.telemetry import inspect as agent_inspect
from icaros.runtime.telemetry.model import to_json

if TYPE_CHECKING:
    from icaros.runtime.telemetry.collector import MasCollector

STATIC_DIR = Path(__file__).resolve().parent / "static"

# how often a websocket drains the ring -- same cadence the TUI polls at
PUSH_SECONDS = 0.1


def message_graph(collector: MasCollector) -> dict:
    """The message-flow graph, built here rather than in JavaScript.

    ag: aggregation lives on the Python side on purpose -- it is the part
    with real logic in it, and the browser is the one place in this project
    with no test harness at all.
    """
    edges: Counter[tuple[str, str]] = Counter()
    performatives: dict[tuple[str, str], Counter[str]] = {}
    known = set(collector.agents)
    for event in collector.ring.since(0).events:
        # ag: built from the senders' journals, not from a MsgListener on the
        # Runner. Telemetry registers no listeners at all any more, and a
        # msg_out entry already carries everything an edge needs -- the ring
        # stamps the sending agent, the entry carries the receiver.
        if event.kind != "msg_out":
            continue
        sender = event.agent or "?"
        receiver = event.detail.get("receiver", "?")
        # a broadcast is one journal entry, because the agent did one thing.
        # The graph is the one place that wants it fanned back out.
        receivers = sorted(known - {sender}) if receiver == "everyone" else [receiver]
        for target in receivers:
            pair = (sender, target)
            edges[pair] += 1
            performatives.setdefault(pair, Counter())[event.detail.get("performative", "?")] += 1

    nodes = sorted({name for pair in edges for name in pair} | set(collector.agents))
    return {
        "nodes": [{"id": n, "known": n in collector.agents} for n in nodes],
        "edges": [{"source": s, "target": t, "count": c,
                   "performatives": dict(performatives[(s, t)])}
                  for (s, t), c in sorted(edges.items(), key=lambda kv: -kv[1])],
    }


def _chat_ineligible_reason(ag_arch) -> str | None:
    """None if the agent can open a .talk session right now; otherwise the
    reason it cannot, in words the dropdown/tooltip can show as-is.

    ag: mirrors the two checks generation.py's `_open()` makes before opening
    a session -- ts.agentic is None or ts.agentic.provider is None (not agentic, or
    the provider never came up), and ts.gen_limit < the level asked for. Kept
    as its own function, not inlined, because both the eligibility reported
    by /api/mas and the /talk endpoint need exactly the same answer -- if
    they drift, the dropdown would offer an agent the send call then refuses.
    """
    ts = ag_arch.ts
    if ts.agentic is None or ts.agentic.provider is None:
        return "not agentic, or its model provider is unavailable"
    if ts.gen_limit < IcarosState.TALK:
        return f"gen_limit is '{ts.gen_limit}' (chat needs at least 'talk')"
    return None


def build_app(host, mas_name: str = "mas") -> FastAPI:
    """`host` is a MasHost -- the MAS may not be loaded yet (hub mode), or may
    be swapped for another one while the window stays open."""
    app = FastAPI(title="icaros dev UI", docs_url=None, redoc_url=None)

    def _collector() -> MasCollector:
        collector = host.collector
        if collector is None:
            raise HTTPException(status_code=409, detail="no MAS is running")
        return collector

    def _agent(name: str):
        collector = _collector()
        if name not in collector.agents:
            raise HTTPException(status_code=404, detail=f"no agent named '{name}'")
        return collector[name].ag_arch

    def _controller():
        if host.controller is None:
            raise HTTPException(status_code=503, detail="debug control is not enabled")
        return host.controller

    def _is_parked(name: str) -> bool:
        """Whether `name` is sitting still and will run no further cycle until
        somebody says so.

        ag: this is what decides between the two deep-read paths, and getting
        it wrong in the unsafe direction is a data race. A paused agent with
        steps queued is NOT parked -- step() already released it and it is on
        its way through a cycle right now.
        """
        controller = host.controller
        if controller is None:
            return False
        status = controller.status(name)
        return bool(status["paused"]) and not status["steps_left"]

    # ---- hub and boot lifecycle ---------------------------------------

    @app.get("/api/status")
    def status():
        return host.state.as_json()

    @app.get("/api/recents")
    def recents():
        from icaros.runtime.web.host import load_recents

        return {"recents": load_recents()}

    @app.post("/api/boot")
    def boot(path: str):
        target = Path(path).expanduser()
        if not target.is_file():
            raise HTTPException(status_code=404, detail=f"no such file: {target}")
        if target.suffix != ".mas2i":
            raise HTTPException(status_code=400,
                                detail=f"icaros runs .mas2i files; got '{target.name}'")
        try:
            host.boot_async(target)
        except RuntimeError as e:
            raise HTTPException(status_code=409, detail=str(e)) from e
        return host.state.as_json()

    @app.post("/api/shutdown")
    def shutdown_mas():
        """Stops the running MAS and returns to the hub, leaving the window
        open -- the point of having a hub at all."""
        host.close()
        return host.state.as_json()

    @app.get("/api/mas")
    def mas():
        state = host.state
        collector = host.collector
        names = sorted(collector.agents) if collector else []
        chat = {}
        for n in names:
            reason = _chat_ineligible_reason(collector[n].ag_arch)
            chat[n] = {"eligible": reason is None, "reason": reason}
        return {"name": state.mas_name or mas_name,
                "agents": names,
                "chat": chat,
                "kinds": list(agent_inspect.KINDS),
                "state": state.state}

    @app.get("/api/agents")
    def agents():
        return {name: to_json(c) for name, c in _collector().counters().items()}

    @app.get("/api/agents/{name}")
    def agent(name: str, kinds: str = ",".join(agent_inspect.KINDS), timeout: float = 2.0):
        collector = _collector()
        if name not in collector.agents:
            raise HTTPException(status_code=404, detail=f"no agent named '{name}'")
        wanted = tuple(k for k in kinds.split(",") if k)
        unknown = set(wanted) - set(agent_inspect.KINDS)
        if unknown:
            raise HTTPException(status_code=400,
                                detail=f"unknown kind(s): {', '.join(sorted(unknown))}")
        # ag: a parked agent runs no cycle, so request_state() can only ever
        # time out on it -- which is how "pause the agent to study it" used to
        # blank the whole mind pane and blame act(). read_state_directly is
        # exactly the documented path for an agent that is not running.
        if _is_parked(name):
            return to_json(collector[name].read_state_directly(wanted))
        state = collector[name].request_state(wanted, timeout=timeout)
        if state is None:
            # an agent blocked in a long act(), or already stopped, never
            # answers -- say so rather than hang the pane
            return JSONResponse(status_code=503, content={
                "detail": "agent is not responding", "agent": name,
                "last_counters": to_json(collector[name].counters)})
        return to_json(state)

    @app.get("/api/agents/{name}/beliefs_diff")
    def beliefs_diff(name: str, at: int, since: int | None = None):
        """What this agent's beliefs did between two cycles.

        ag: read off the agent's journal by folding its deltas, not by asking
        the agent anything -- so it works on a stopped agent, and on a cycle
        long past. `null` for either side means that far back can no longer be
        reconstructed, and the pane has to say so: a diff drawn against a
        belief base that was quietly wrong is worse than no diff.
        """
        collector = _collector()
        if name not in collector.agents:
            raise HTTPException(status_code=404, detail=f"no agent named '{name}'")
        journal = collector[name].ag_arch.ts.ag.journal
        before_cycle = at - 1 if since is None else since
        before, after = journal.beliefs_at(before_cycle), journal.beliefs_at(at)
        if before is None or after is None:
            return {"agent": name, "at": at, "since": before_cycle, "known": False}
        return {"agent": name, "at": at, "since": before_cycle, "known": True,
                "added": sorted(set(after) - set(before)),
                "removed": sorted(set(before) - set(after)),
                "unchanged": len(set(after) & set(before))}

    @app.get("/api/agents/{name}/beliefs")
    def beliefs(name: str):
        """This agent's current beliefs, as of the last cycle it finished.

        ag: not the `beliefs` kind of /api/agents/{name} -- that one waits on
        request_state()'s cycle-gated handshake and is skipped outright while
        the agent is busy in an LLM call, exactly the case where this card
        matters most. This reads AgentCollector.beliefs instead, published
        unconditionally by on_cycle on the agent's own thread, so it answers
        instantly regardless of what the agent is doing right now.
        """
        collector = _collector()
        if name not in collector.agents:
            raise HTTPException(status_code=404, detail=f"no agent named '{name}'")
        return {"beliefs": collector[name].beliefs or []}

    @app.get("/api/agents/{name}/reasoning")
    def reasoning(name: str, limit: int = 12):
        """The last few cycles this agent did something in, oldest first --
        the road each one took, as the agent recorded it while taking it.

        ag: read off the journal, like beliefs_diff above and for the same
        reason -- it needs no cycle to happen, so it answers for an agent that
        is paused on a breakpoint or has stopped altogether. That is the whole
        difference from the deliberation view in /api/agents/{name}, which can
        only ever say what applies *now*.
        """
        from icaros.runtime.telemetry.reasoning import reasoning_stream

        ag_arch = _agent(name)
        if not 1 <= limit <= 200:
            raise HTTPException(status_code=400, detail="limit must be 1..200")
        return to_json(reasoning_stream(ag_arch.ts.ag.journal, name, limit))

    @app.get("/api/transcript/{seq}")
    def transcript(seq: int):
        call = _collector().transcript(seq)
        if call is None:
            raise HTTPException(status_code=404,
                                detail="transcript evicted or never existed")
        return to_json_llm_call(call)

    @app.get("/api/messages")
    def messages():
        return message_graph(_collector())

    @app.get("/api/plans/{name}")
    def plans(name: str, infrastructure: bool = False):
        """Static analysis of the plan library -- no run needed, so this is
        safe to read from the server thread: PlanLibrary is not mutated by a
        reasoning cycle the way Circumstance is."""
        from icaros.runtime.telemetry.plan_graph import plan_graph

        ag_arch = _agent(name)
        return plan_graph(ag_arch.ts.ag.pl, include_infrastructure=infrastructure)

    # ---- debug control ------------------------------------------------
    # ag: every mutation goes through TransitionSystem.run_at_begin_of_next_cycle,
    # the channel the interpreter already documents (msg_listener.py) as the
    # way to touch a Circumstance from a foreign thread. Nothing here reaches
    # into agent state directly, and nothing here blocks on a join.

    @app.get("/api/debug/{name}")
    def debug_status(name: str):
        _agent(name)
        return _controller().status(name)

    @app.post("/api/debug/{name}/pause")
    def pause(name: str):
        _agent(name)
        _controller().pause(name)
        return _controller().status(name)

    @app.post("/api/debug/{name}/resume")
    def resume(name: str):
        ag_arch = _agent(name)
        _controller().resume(name, ag_arch)
        return _controller().status(name)

    @app.post("/api/debug/{name}/step")
    def step(name: str, count: int = 1):
        ag_arch = _agent(name)
        _controller().step(name, count, ag_arch)
        return _controller().status(name)

    @app.post("/api/debug/{name}/chat")
    def chat(name: str, message: str):
        """Hands a person's chat message to `name` as a KQML message.

        ag: a message, not a hand-built goal, because that is what it is --
        somebody outside the agent addressing it. From there nothing is
        special-cased: the mailbox turns it into +!kqml_received(user, chat,
        msg("..."), Id) like any other performative, and pl/kqml_plans.asl
        answers it with .talk. AgArch.receive_msg is the same door the
        Directory Facilitator knocks on from outside the agent world, so
        this needs no run_at_begin_of_next_cycle: it appends to the mailbox
        and wakes the agent, which is safe from this thread by design.
        """
        ag_arch = _agent(name)
        if not message.strip():
            raise HTTPException(status_code=400, detail="message must not be empty")
        reason = _chat_ineligible_reason(ag_arch)
        if reason is not None:
            raise HTTPException(status_code=409, detail=f"'{name}' cannot chat: {reason}")

        # ag: hex, no dashes -- the id becomes Atom(msg.id), the fourth term of
        # the kqml_received trigger, and that trigger is what the browser reads
        # back to match an answer to the message it came from.
        chat_id = f"chat{uuid4().hex[:8]}"
        # ag: msg(StringTerm), never a bare str -- _message_content parses
        # anything that is not already a Term, and a line typed by a person is
        # exactly what must not reach the parser.
        content = create_literal("msg", create_string(message))
        ag_arch.receive_msg(Message("chat", "user", name, content, id=chat_id))
        return {"chat": chat_id, "agent": name}

    @app.get("/api/events")
    def events(since: int = 0):
        drain = _collector().ring.since(since)
        return {"events": [to_json(e) for e in drain.events],
                "next_seq": drain.next_seq, "gap": drain.gap}

    @app.websocket("/ws")
    async def stream(websocket: WebSocket):
        """Pull-from-the-loop, not push-from-the-agent.

        ag: agents never touch this event loop. call_soon_threadsafe per
        trace event would mean thousands of loop wakeups a second; instead
        the agents write to a plain-locked ring and this coroutine drains it
        on a timer. That is what makes the cost independent of how many
        browsers are watching.
        """
        await websocket.accept()
        cursor = 0
        seen = None  # the run this cursor belongs to
        try:
            while True:
                # ag: one snapshot, not two property reads -- a boot landing
                # between them would ship this MAS's status with that MAS's
                # events, which is exactly the mix-up `run` exists to end
                state, collector = host.snapshot()
                # a different run means a different ring: restart the cursor
                # rather than silently reading someone else's sequence numbers
                if state.run != seen:
                    seen, cursor = state.run, 0
                frame = {"run": state.run, "status": state.as_json(), "counters": {},
                         "events": [], "gap": 0, "next_seq": 0}
                if collector is not None:
                    drain = collector.ring.since(cursor)
                    cursor = drain.next_seq
                    frame["counters"] = {n: to_json(c)
                                         for n, c in collector.counters().items()}
                    frame["events"] = [to_json(e) for e in drain.events]
                    frame["gap"] = drain.gap
                    frame["next_seq"] = cursor
                await websocket.send_json(frame)
                await asyncio.sleep(PUSH_SECONDS)
        except (WebSocketDisconnect, RuntimeError):
            return  # the browser closed the tab, or the server is shutting down

    if STATIC_DIR.is_dir():
        app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

        @app.get("/")
        def index():
            return FileResponse(STATIC_DIR / "index.html")

    return app


def to_json_llm_call(call) -> dict:
    """LlmCall lives in icaros/llm/trace.py and holds provider-shaped tool specs
    (arbitrary nested JSON from to_specs), so it does not go through the
    strict to_json() the telemetry views use."""
    from dataclasses import asdict

    return asdict(call)

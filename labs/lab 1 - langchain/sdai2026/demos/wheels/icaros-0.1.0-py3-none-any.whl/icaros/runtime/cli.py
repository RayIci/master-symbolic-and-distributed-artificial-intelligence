from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING

from icaros.as_syntax.parser.errors import ASParseError
from icaros.mas2i.loader import load_mas
from icaros.mas2i.parser.parser import MAS2IParseError, parse_mas
from icaros.runtime.session import MasSession

if TYPE_CHECKING:
    from icaros.architecture.ag_arch import AgArch


def describe_agents(agents: list[AgArch],
                     groups: list[tuple[str, int]] | None = None) -> str:
    """One line naming what is running. A group of many instances collapses
    to `cell#10000` rather than listing every name -- at that size the list
    is longer than everything else the run will ever print. `groups` is the
    loader's own record (see Runner.agent_groups); without it, fall back to
    the names themselves."""
    if not groups:
        return ", ".join(a.ag_name for a in agents)
    return ", ".join(name if count == 1 else f"{name}#{count}" for name, count in groups)


def run_headless(agents: list[AgArch],
                  groups: list[tuple[str, int]] | None = None) -> None:
    with MasSession(agents) as session:
        # flush: redirected to a file or a pipe, stdout is block-buffered, so a
        # quiet MAS would otherwise show this only once ~8KB has piled up
        print(f"agents running: {describe_agents(agents, groups)} (Ctrl-C to stop)", flush=True)
        while session.any_running():
            time.sleep(1.0)


def run_headless_traced(agents: list[AgArch], groups: list[tuple[str, int]] | None,
                         llm_trace: str) -> None:
    """Headless, but still collecting LLM round trips to a .jsonl file --
    debugging an LLM-driven MAS without a UI at all."""
    from icaros.runtime.telemetry.collector import MasCollector
    from icaros.runtime.telemetry.trace_file import LlmTraceWriter

    collector = MasCollector(agents)
    collector.attach()
    writer = LlmTraceWriter(llm_trace).attach(collector)
    try:
        run_headless(agents, groups)
    finally:
        writer.close()
        collector.detach()
        print(f"llm trace written to {writer.path} ({writer.written} calls)", flush=True)


def run_web(source: Path | None = None, port: int = 0,
             llm_trace: str | None = None) -> None:
    """The developer UI: a server on a daemon thread in this process, and a
    window in its own. Blocks until the window is closed or Ctrl-C.

    `source` is the .mas2i to boot straight away; None opens the hub, where
    the MAS is chosen from the window. Either way the window comes up first
    and the MAS loads behind a progress screen -- a single Agentic warm-up was
    measured at 15 s, and staring at nothing for that long is the problem
    this ordering solves.
    """
    try:
        from icaros.runtime.web.host import MasHost
        from icaros.runtime.web.server import UiServer
        from icaros.runtime.web.window import WindowShell
    except ImportError as e:
        raise SystemExit(
            f"the dev UI needs the 'devui' extra ({e}); install it with "
            "`uv sync` or `pip install 'icaros[devui]'`, or run with --ui none") from e
    from icaros.runtime.telemetry.trace_file import LlmTraceWriter

    host = MasHost()
    writer = LlmTraceWriter(llm_trace).open() if llm_trace else None
    if writer is not None:
        host.set_llm_sink(writer.write)

    mas_name = source.stem if source is not None else "hub"
    server = UiServer(host, mas_name, port=port)
    url = server.start()
    shell = WindowShell(url, f"icaros · {mas_name}")
    try:
        print(f"icaros dev UI at {url}", flush=True)
        if source is not None:
            host.boot_async(source)
        shell.start()
        shell.wait()  # the window owns the run, the way the TUI's app.run() did
    except KeyboardInterrupt:
        pass
    finally:
        shell.stop()
        server.stop()
        host.close()
        if writer is not None:
            writer.close()
            print(f"llm trace written to {writer.path} ({writer.written} calls)", flush=True)


def _load(path: Path) -> tuple[list[AgArch], str, list[tuple[str, int]]]:
    """The agents to run, the frontend the .mas2i asked for (`ui:`), and the
    declared (name, instances) groups for the summary line.

    ag: .mas2i only. Booting a bare .asl used to be accepted here, but a lone
    agent with no MAS around it has no environment, no directory facilitator
    and nobody to talk to -- and every knob that shapes a run (provider/model,
    instances, initial beliefs, threads) lives in the .mas2i. Write a two-line
    .mas2i instead; `agent <name>` alone already defaults its source to
    <name>.asl."""
    if path.suffix != ".mas2i":
        raise ValueError(f"icaros runs .mas2i files; got '{path.name}'")
    runner = load_mas(path)
    return list(runner.ags.values()), runner.ui, runner.agent_groups


def _declared(path: Path) -> tuple[str, int]:
    """The .mas2i's `ui:` and its declared agent count, from a parse alone.

    ag: parsing is milliseconds; booting is seconds (one Agentic warm-up measured
    at 15 s). main() has to know which frontend to open BEFORE paying that,
    or the window cannot come up first and show a progress bar for it."""
    if path.suffix != ".mas2i":
        raise ValueError(f"icaros runs .mas2i files; got '{path.name}'")
    config = parse_mas(path.read_text(), source=str(path))
    return config.ui, sum(spec.instances for spec in config.agents)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        description="Run a multi-agent system (.mas2i)")
    parser.add_argument("source", nargs="?",
                        help="path to a .mas2i system file; omit it to open the hub "
                             "and pick one there")
    parser.add_argument("--ui", choices=("web", "none"), default=None,
                        help="which frontend to run: the dev UI in its own window (web) "
                             "or terminal logs only (none). Overrides the .mas2i's `ui:`.")
    parser.add_argument("--headless", action="store_true",
                        help="alias for --ui none")
    parser.add_argument("--ui-port", type=int, default=0, metavar="N",
                        help="port for the dev UI server (default: let the OS pick one)")
    parser.add_argument("--llm-trace", metavar="FILE",
                        help="write every LLM round trip to FILE as JSON lines (FILE is "
                             "replaced); works with any --ui, including none")
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO)
    # ag: the ollama client speaks through httpx, which logs one INFO line per
    # request ("HTTP Request: POST .../api/chat ..."). At INFO root level that
    # lands in the middle of the agents' own output -- once per LLM-delegated
    # select_* call, so an agent with llm_selections is mostly HTTP noise. The
    # levels are set here, not in Agentic: configuring logging is the CLI's job,
    # and a library embedder gets to keep its own setup.
    for noisy in ("httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    if args.source is None:
        # no file named: open the hub and let the window choose one
        if args.ui == "none" or args.headless:
            print("error: --ui none needs a .mas2i to run", file=sys.stderr)
            raise SystemExit(2)
        run_web(None, port=args.ui_port, llm_trace=args.llm_trace)
        return

    source = Path(args.source)
    try:
        declared_ui, nb_agents = _declared(source)
    except (MAS2IParseError, ASParseError, FileNotFoundError, ValueError, OSError) as e:
        print(f"error: {e}", file=sys.stderr)
        raise SystemExit(1) from None
    # explicit --ui wins, then --headless, then the .mas2i's own `ui:`
    ui = args.ui or ("none" if args.headless else declared_ui)
    if ui != "none" and nb_agents > 200:
        # a MAS that declared `ui: none` did so because a per-agent UI cannot
        # cope with its agent count. Honour the override -- it is a dev tool
        # and the developer asked -- but say what they are in for.
        print(f"warning: {nb_agents} agents; the dev UI targets tens", file=sys.stderr)

    if ui != "none":
        run_web(source, port=args.ui_port, llm_trace=args.llm_trace)
        return

    try:
        agents, _, groups = _load(source)
    except (MAS2IParseError, ASParseError, FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        raise SystemExit(1) from None
    if args.llm_trace:
        run_headless_traced(agents, groups, args.llm_trace)
    else:
        run_headless(agents, groups)


if __name__ == "__main__":
    main()
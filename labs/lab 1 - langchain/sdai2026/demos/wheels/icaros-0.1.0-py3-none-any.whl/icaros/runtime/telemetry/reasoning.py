from __future__ import annotations

import json
from typing import TYPE_CHECKING

from icaros.journal import JournalKind
from icaros.llm import CALL_ANNOT, SOURCE_LLM
from icaros.runtime.telemetry.model import (
    Annotation,
    ChainLink,
    CycleTrace,
    ReasoningStream,
)

if TYPE_CHECKING:
    from icaros.journal.entry import JournalEntry
    from icaros.journal.journal import Journal

# ag: read from the journal, NOT from the live Circumstance, and that is the
# whole design. A Circumstance read has to happen on the agent's own thread
# (telemetry.inspect says so at the top), which means waiting for a cycle --
# so a paused agent, the one moment somebody actually wants to study a
# deliberation, could never answer. The journal is a snapshot-under-lock any
# thread may read, it works on a stopped agent, and what it holds was written
# while the cycle was running rather than reconstructed afterwards.

# the kinds that are part of the road a cycle took. Belief deltas, prints and
# messages happen in the same cycle but are already rows of their own on the
# timeline, and putting them here would drown the shape.
_LINKED = (JournalKind.SENSE, JournalKind.LLM_GENERATE, JournalKind.LLM_CHOICE,
           JournalKind.DELIBERATE, JournalKind.ACT, JournalKind.GOAL_FAILED)


def _split(text: str) -> tuple[str, str]:
    """`source(bob)` -> ("source", "bob"). A term's own rendering, taken apart
    at the first bracket -- not a parse of the whole annotation list, which is
    what _bare exists to avoid."""
    functor, _, rest = text.partition("(")
    return functor, rest[:-1] if rest.endswith(")") else rest


def _model_tag(session: str | None) -> str:
    """What the model's tag reads: `llm·3f9a2b1c`, or `llm` for a call that
    belongs to no session (the select_* ones open none).

    ag: `icaros-` is stripped because every session in the process carries it
    and it therefore distinguishes none of them; the hex is the whole
    identity. `llm` stays in front so the tag says what it is without being
    hovered -- a bare hex blob next to a trigger is a puzzle.
    """
    short = (session or "").removeprefix("icaros-")
    return f"llm·{short}" if short else "llm"


def _annot_texts(raw: str | None) -> list[str]:
    """The annotation terms as the journal stored them, in order."""
    try:
        return [str(t) for t in (json.loads(raw) if raw else [])]
    except ValueError:  # a journal older than this field, or a truncated line
        return []


def _annots(texts: list[str], session: str | None = None) -> list[Annotation]:
    """A trigger's annotations, classified so the UI can draw them.

    ag: the roles are the palette's own question -- did this come from inside
    the agent or from the world -- asked of an annotation instead of an event
    kind. `source(self)` is the agent's own doing, `source(percept)` and
    `source(bob)` are the world arriving, an error annotation is a failure
    carrying its reason. Everything else stays whole and neutral rather than
    being guessed at.
    """
    # ag: the model stamps TWO annotations on everything it posts --
    # source(llm) for provenance, llm_call(id, session) for correlation (see
    # llm/result.py). Side by side those were two tags saying "the model asked
    # for this" twice, and source(llm) read as a third thing again: an agent
    # named "llm". One tag says it, and what it says is the SESSION -- which
    # conversation this belongs to is the part that distinguishes one of these
    # events from another, and the part that ties events a dozen cycles apart
    # together. The call id and the raw annotations stay on its title.
    from_model = [t for t in texts
                  if _split(t) == ("source", SOURCE_LLM) or _split(t)[0] == CALL_ANNOT]

    out = []
    for text in texts:
        functor, inner = _split(text)
        if text in from_model:
            if any(a.role == "model" for a in out):
                continue  # its other half already spoke for it
            out.append(Annotation(role="model", text=_model_tag(session),
                                  label=" · ".join(from_model)))
        elif functor == "source":
            role = {"self": "self", "percept": "percept"}.get(inner, "agent")
            out.append(Annotation(role=role, text=inner or "?", label=text))
        elif functor.startswith("error"):
            out.append(Annotation(role="error", text=inner or functor, label=text))
        else:
            out.append(Annotation(role="other", text=text, label=text))
    return out


def _bare(text: str, texts: list[str]) -> str:
    """`text` without its annotation suffix.

    ag: not a parse, and anchored to the RAW terms rather than to the tags
    built from them -- the tags merge (the model's pair becomes one) and would
    no longer rebuild the string. The suffix is exactly how Structure.__str__
    appended it, and it is only removed if the string really does end in it.
    Scanning back from the last `]` would be the parse, and `+!say("a]b")` is
    why that is wrong.
    """
    if not texts:
        return text
    suffix = "[" + ",".join(texts) + "]"
    return text[:-len(suffix)] if text.endswith(suffix) else text


def _linked(kind: str, label: str, text: str, raw: str | None,
            session: str | None = None, **kw) -> ChainLink:
    """A link whose text is a trigger: annotations out of the line, into
    their own field."""
    texts = _annot_texts(raw)
    return ChainLink(kind=kind, label=label, text=_bare(text, texts),
                     notes=kw.pop("notes", []), annots=_annots(texts, session), **kw)


def _deliberate_links(detail: dict[str, str]) -> list[ChainLink]:
    """The middle of the cycle, opened up: the event taken up, and what won
    or why nothing did."""
    trigger = detail.get("trigger", "?")
    outcome = detail.get("outcome", "")
    links = [_linked("event", "event", trigger, detail.get("annots"),
                     detail.get("session"))]

    if outcome == "selected":
        bindings = detail.get("bindings")
        source = detail.get("source")
        links.append(ChainLink(
            kind="plan", label="plan", tone="chosen", source=source,
            notes=[bindings] if bindings and bindings != "{}" else [],
            text=detail.get("plan_label") or "(unlabelled)"))
        return links

    # ag: a belief update that nothing reacts to is the ordinary case, not a
    # dead end. Most beliefs an agent revises have no +b plan at all, and
    # _handle_no_plan treats it as exactly that -- it fails and logs a goal
    # with no plan, and shrugs at a belief. Marking it in red here would paint
    # a belief-heavy MAS as one long failure. The event link still shows the
    # event arrived; nothing following it is the whole story.
    if detail.get("trigger_kind") == "belief" and outcome in ("no_relevant", "no_applicable"):
        return links

    # three different dead ends, and the wording of each is load-bearing.
    # "no_option" is NOT a missing plan -- one was applicable and select_option
    # turned it down. And none of the three has anything to do with `path`,
    # which only names the road the interpreter took to find out; putting it in
    # front of the outcome read as if taking the shortcut were the reason
    # nothing was chosen.
    why = {
        "no_relevant": "no plan matches this trigger",
        "no_applicable": "plans match, none of their contexts hold",
        "no_option": "a plan applied and select_option turned it down",
    }.get(outcome, outcome or "nothing was chosen")
    links.append(ChainLink(kind="dead-end", label="—", text=why, notes=[], tone="dead-end"))
    return links


# ag: .icaros_step/.icaros_consider_results (generation.py) are spliced into
# a plan body, never written by hand -- their one argument is an
# ObjectTerm(IcarosSession), and even with IcarosSession.__str__ trimmed down
# (session.py) the raw "ran .icaros_step(session ...)" line is still noise:
# the SAME cycle already writes a much better JournalKind.LLM_GENERATE entry
# for a .icaros_step round (_generate_links below), and .icaros_consider_results
# never calls the model at all, so there is nothing behind it worth spelling
# out here either. Both get a short, human line instead of the raw term.
_ICAROS_STEP_TEXT = {
    ".icaros_step": "thinking",
    ".icaros_consider_results": "considering the results",
}


def _act_links(detail: dict[str, str]) -> list[ChainLink]:
    """What ran, and which intention it belonged to.

    `where` and `step` are only there when the line was built from the
    intention's own state; an internal action that spoke for itself (.print,
    .send) journals a summary and nothing to split.
    """
    where, step = detail.get("where"), detail.get("step")
    if not step:
        return [ChainLink(kind="run", label="ran", text=detail.get("summary", ""), notes=[])]
    links = []
    if where:
        # ag: where_root is only set (transition_system.py's _journal_detail)
        # when the intention is more than one frame deep -- a !subgoal call, a
        # goal the model asked for, root() does not care which. Folded into
        # ONE line, "+!start/+!brew", rather than a second link: this is the
        # line that already says which intention a step belongs to, and a
        # reader should not have to scroll back to the cycle the nested goal
        # was taken up in just to remember what it is nested IN. Only the
        # current frame's own annotations become the chip -- the root's are
        # stripped for readability, same as everywhere else, but not shown.
        top_texts = _annot_texts(detail.get("where_annots"))
        text = _bare(where, top_texts)
        root_raw = detail.get("where_root")
        if root_raw:
            root_texts = _annot_texts(detail.get("where_root_annots"))
            text = f"{_bare(root_raw, root_texts)}/{text}"
        links.append(ChainLink(kind="intention", label="intention", text=text, notes=[],
                               annots=_annots(top_texts, detail.get("where_session"))))
    icaros_text = _ICAROS_STEP_TEXT.get(detail.get("functor"))
    if icaros_text is not None:
        links.append(ChainLink(kind="run", label="ran", text=icaros_text, notes=[],
                               clickable=True))
    else:
        links.append(ChainLink(kind="run", label="ran", text=step, notes=[]))
    return links


def _generate_links(detail: dict[str, str]) -> list[ChainLink]:
    """One round of an Icaros session, or the round that closed it."""
    level = detail.get("level") or detail.get("faculty") or "generate"
    round_no = detail.get("round")
    notes = [f"{k} {detail[k]}" for k in ("about", "asked", "concluded", "goal", "error")
             if detail.get(k)]
    # the same tag the events this round posts will wear, so "the model asked
    # for that, in this conversation" is one thing seen twice and not two
    session = detail.get("session")
    tag = [Annotation(role="model", text=_model_tag(session),
                      label=f"session {session}")] if session else []
    return [ChainLink(kind="model", label="model", notes=notes, annots=tag, clickable=True,
                      text=f"{level} round {round_no}" if round_no else str(level))]


def _links_of(entry: JournalEntry) -> list[ChainLink]:
    detail = entry.detail
    match entry.kind:
        case JournalKind.SENSE:
            return [ChainLink(kind="sense", label="sense",
                              text=detail.get("summary", ""), notes=[])]
        case JournalKind.LLM_GENERATE:
            return _generate_links(detail)
        case JournalKind.LLM_CHOICE:
            return [ChainLink(kind="chose", label="model chose", notes=[],
                              text=f"{detail.get('purpose', 'select')}: "
                                   f"{detail.get('choice', '—')}")]
        case JournalKind.DELIBERATE:
            return _deliberate_links(detail)
        case JournalKind.ACT:
            return _act_links(detail)
        case JournalKind.GOAL_FAILED:
            return [ChainLink(kind="failed", label="failed", tone="dead-end", notes=[],
                              text=f"{detail.get('goal', '?')} — "
                                   f"{detail.get('reason', '?')}")]
    return []


def _active_cycles(entries: list[JournalEntry]) -> list[int]:
    """Every cycle the agent did something in, oldest first.

    ag: "did something" and not "ran" -- a cycle that decides nothing journals
    nothing, deliberately (an idle agent must leave no trace, or a MAS waiting
    on a slow environment fills the buffer with lines saying it is still
    waiting). So the numbers here have gaps, and the gaps are true.

    A folded CYCLE entry counts: it says that cycle had detail once, and
    reporting it as known=False with its one-line summary is a better answer
    than leaving it out as though nothing had happened.
    """
    seen: list[int] = []
    for entry in entries:
        if entry.kind not in _LINKED and entry.kind is not JournalKind.CYCLE:
            continue
        if not seen or seen[-1] != entry.cycle:
            seen.append(entry.cycle)
    return seen


def cycle_trace(journal: Journal, agent: str, cycle: int | None = None) -> CycleTrace:
    """The road one reasoning cycle took, in order.

    `cycle` defaults to the last cycle the agent actually did something in --
    NOT the one it is on. ag: those are the same thing far less often than it
    sounds. A cycle that decides nothing journals nothing (the stage
    describers return None, deliberately: an idle agent must leave no trace,
    or a MAS waiting on a slow environment fills the buffer with lines saying
    it is still waiting). So an agent that has settled, or one parked inside a
    long model round trip while its cycle counter keeps climbing, is on a
    silent cycle essentially always -- and defaulting to it showed an empty
    card forever, which reads as broken rather than as quiet.

    An empty `chain` with `known=True` is still a real answer, for a journal
    with nothing in it at all. It is not the same as `known=False`, which
    means the detail existed and has since been folded away.
    """
    entries = journal.window()
    if cycle is None:
        active = _active_cycles(entries)
        cycle = active[-1] if active else journal.cycle()
    return _trace(entries, agent, cycle)


def _trace(entries: list[JournalEntry], agent: str, at: int) -> CycleTrace:
    mine = [e for e in entries if e.cycle == at]

    folded = next((e for e in mine if e.kind is JournalKind.CYCLE), None)
    if folded is not None:
        return CycleTrace(agent=agent, cycle=at, known=False, chain=[],
                          folded=folded.detail.get("summary") or None)
    # nothing for this cycle and nothing this old still kept: it was evicted
    # outright rather than folded, so there is no honest line to show either
    if not mine and entries and entries[0].cycle > at:
        return CycleTrace(agent=agent, cycle=at, known=False, chain=[])

    chain: list[ChainLink] = []
    for entry in mine:
        for link in _links_of(entry):
            # ag: act journals twice for one deed when the internal action
            # also speaks for itself -- once as "this intention ran this step",
            # once in the action's own words. Two journal lines is right (they
            # are two different statements); two identical links in a row is
            # just the chain stuttering.
            if chain and chain[-1].kind == link.kind and chain[-1].text == link.text:
                continue
            chain.append(link)
    return CycleTrace(agent=agent, cycle=at, known=True, chain=chain)

def reasoning_stream(journal: Journal, agent: str, limit: int = 12) -> ReasoningStream:
    """The last `limit` cycles this agent did something in, oldest first.

    ag: what the Reasoning card renders. Replacing the card with one cycle
    every poll made the interesting part -- how one cycle led to the next --
    the one thing you could never see: the answer to "which step is it on"
    only means something next to the steps before it. Read whole from the
    journal each time rather than accumulated in the browser, so it cannot
    drift, cannot double a cycle, and survives a reload; the journal is the
    window, and how far back it goes is `limit`.
    """
    entries = journal.window()
    active = _active_cycles(entries)
    return ReasoningStream(agent=agent,
                           cycles=[_trace(entries, agent, at) for at in active[-limit:]])

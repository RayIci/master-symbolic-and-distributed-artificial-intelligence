from __future__ import annotations

import json
import threading
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.llm import LlmCall
    from icaros.runtime.telemetry.collector import MasCollector


class LlmTraceWriter:
    """Appends every LLM round trip to a .jsonl file, one JSON object per line.

    ag: the point is that an LLM-driven MAS is debuggable without a UI at
    all. `icaros --ui none --llm-trace run.jsonl` leaves a file you can grep,
    diff between runs, or replay -- and it is the same data the web UI shows,
    so the two can never disagree.

    Writes are serialised under a lock because on_call fires on each agent's
    own thread, and under free-threading those are genuinely parallel.
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()
        self._file = None
        self._written = 0

    @property
    def path(self) -> Path:
        return self._path

    @property
    def written(self) -> int:
        return self._written

    def open(self) -> LlmTraceWriter:
        # ag: "w", so one run is one file. Appending would interleave two runs
        # in a format that has no run marker to tell them apart -- and the
        # question this file answers is always "what did the model do in THIS
        # run". The --llm-trace help says the file is replaced.
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._file = self._path.open("w", encoding="utf-8")
        return self

    def write(self, call: LlmCall) -> None:
        if self._file is None:
            return
        line = json.dumps(asdict(call), ensure_ascii=False, default=str)
        with self._lock:
            # flush per line: a run that is Ctrl-C'd (the normal way a MAS
            # ends) must still leave a complete trace behind
            self._file.write(line + "\n")
            self._file.flush()
            self._written += 1

    def close(self) -> None:
        with self._lock:
            if self._file is not None:
                self._file.close()
                self._file = None

    def attach(self, collector: MasCollector) -> LlmTraceWriter:
        self.open()
        collector.add_llm_sink(self.write)
        return self

    def __enter__(self) -> LlmTraceWriter:
        return self.open()

    def __exit__(self, *exc_info) -> None:
        self.close()

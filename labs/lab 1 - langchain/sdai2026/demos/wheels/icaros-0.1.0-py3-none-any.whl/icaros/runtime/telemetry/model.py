from __future__ import annotations

from dataclasses import dataclass, field, fields, is_dataclass

# ag: plain dataclasses, no pydantic. The data layer has to import and be
# testable without the `devui` extra installed -- only runtime/web/ may know
# what pydantic is. slots=True because a busy MAS builds thousands of these.


@dataclass(slots=True)
class AgentCounters:
    """The cheap per-cycle read: ints and a bool, nothing that walks a
    collection. Published on every reasoning cycle, which is why it may not
    grow -- everything expensive lives in AgentState instead."""

    cycle: int
    sleeping: bool
    pending_events: int
    mailbox: int
    running_intentions: int
    # ag: set the instant a round trip starts, cleared the instant it ends --
    # unlike every other field here, published outside of on_cycle, because an
    # agent blocked in a slow act() publishes no cycle at all for as long as
    # that call takes. See AgentCollector._fire_on_call_started.
    busy: bool = False


@dataclass(slots=True)
class BeliefView:
    text: str
    functor: str
    arity: int


@dataclass(slots=True)
class IntendedMeansView:
    plan_label: str | None
    trigger: str
    source: str | None  # "file.asl:12", from the plan's SourceInfo
    current_step: str | None
    # ag: the llm_call(...) id this ONE frame carries, or None. A frame the
    # model asked for directly (a goal written by goal_step, an action pushed
    # by add_tool_call -- icaros.py) rather than one the agent's own plan
    # chose. Per-frame, not per-intention: since icaros sessions push what the
    # model asks for as a real child frame of whichever intention opened the
    # session (generation.py), one intention can hold both its own work and,
    # for as long as a session is open, a frame or two that were not its own
    # decision -- and a reader needs to tell exactly which.
    llm_call_id: str | None = None


@dataclass(slots=True)
class ForkView:
    """Where a .fork branch stands relative to its siblings (fork.py). Only
    present on an intention that IS a live branch -- the intention that
    called .fork is abandoned (fork.py's own docstring), so there is nothing
    to annotate on its side once the branches exist.
    """

    # ag: a correlation key for this one inspection, not a stored id --
    # ForkData has no identity of its own, so this is str(id(fork_data)),
    # stable only for as long as the branches that share it are alive. Lets a
    # reader (the UI, mainly) group rows without also being handed every
    # sibling's full state.
    group_id: str
    # ag: NOT ForkIntention.fork_point (a stack-depth threshold, "at or above
    # this size we are in our own work") -- this is a count of frames, from
    # the ROOT end, that are byte-identical across every sibling. Since
    # IntentionView.stack is innermost-first (stack[0] is the top), that is
    # stack[-shared_frames:] if shared_frames else []; a branch's own work is
    # everything else, stack[:len(stack) - shared_frames]. Frame for frame
    # identical because Intention.copy_to (fork.py) shares those
    # IntendedMeans objects by reference across every branch and the
    # (abandoned) caller -- the ONE frame that was running .fork itself is
    # cloned, not shared, and diverges per branch immediately (a different
    # current_step), so it is always counted as "own", never shared, even at
    # the moment right after the fork when its trigger still reads the same.
    shared_frames: int
    is_and: bool
    to_finish: int
    # the OTHER branches currently alive in the same ForkData, this one
    # excluded -- empty once every sibling but this one has joined or died.
    sibling_ids: list[str]


@dataclass(slots=True)
class IntentionView:
    id: str
    depth: int
    suspended: bool
    # ag: at least one frame in the stack carries an llm_call id (see
    # IntendedMeansView.llm_call_id) -- true for as long as work the model
    # asked for is still on this intention's stack, false again once it is
    # popped. Not "this intention IS a tool call": under the bubble design
    # (generation.py) an intention mixes its own frames with the model's, and
    # the per-frame field above is the one that says which is which; this is
    # the cheap "does this row need a second look" scan across the whole
    # stack, the same job it did before, answered a different way.
    tool_call: bool
    stack: list[IntendedMeansView]  # innermost first, the way Intention iterates
    fork: ForkView | None = None


@dataclass(slots=True)
class OptionView:
    """One plan the agent considered for the selected event. `applicable` is
    what separates the two lists the interpreter builds: a relevant plan
    matched the trigger, an applicable one also had its context hold."""

    plan_label: str | None
    trigger: str
    context: str | None
    source: str | None
    bindings: dict[str, str]
    applicable: bool
    breakpoint: bool


@dataclass(slots=True)
class DeliberationView:
    """Why the agent is about to do what it is about to do. All of it already
    lives on Circumstance and none of it ever reached a UI before."""

    selected_event: str | None
    relevant: list[OptionView]
    applicable: list[OptionView]
    selected_option: OptionView | None
    selected_intention: str | None
    last_deed: str | None
    # whether the two lists were rebuilt at inspection time rather than read
    # off the Circumstance -- see telemetry.inspect.deliberation()
    recomputed: bool = False


@dataclass(slots=True)
class AgentState:
    """A deep read of one agent, built on that agent's own thread. The
    optional fields are the ones the requester didn't ask for -- None means
    "not collected", never "empty"."""

    name: str
    at_cycle: int
    counters: AgentCounters
    beliefs: list[BeliefView] | None = None
    intentions: list[IntentionView] | None = None
    deliberation: DeliberationView | None = None
    mailbox: list[str] | None = None


@dataclass(slots=True)
class Annotation:
    """One annotation on a trigger, classified so it can be drawn.

    `role` is what the renderer paints: "self" and "percept" and an agent's
    name are three different provenances and the palette already has a rule
    for that ("did this come from inside the agent or from the world"). `text`
    is the short form to show -- `bob`, not `source(bob)`; `label` the full
    one, for the title.
    """

    role: str    # self | percept | agent | model | error | other
    text: str
    label: str


@dataclass(slots=True)
class ChainLink:
    """One step of one reasoning cycle, in the order the cycle took it.

    ag: a chain rather than four fat stage blocks, because the question this
    answers is a sequence -- what came in, which event was taken up, what was
    chosen, which intention it went onto, what ran. Folding "an event was
    selected" and "this plan won" into a single deliberate row hid the middle
    of that, which is the interesting part.

    `label` is the gutter word, `text` the line, `notes` the dimmer lines
    under it. `tone` is for the renderer: "chosen" and "dead-end" are the two
    outcomes a reader scans for, and neither should have to be read to be
    seen.
    """

    kind: str    # sense | model | chose | event | plan | dead-end
                 # | intention | run | failed
    label: str
    text: str
    notes: list[str]
    tone: str | None = None  # None | chosen | dead-end
    # ag: the trigger's annotations, split off the text rather than left
    # inside it. `source(percept)` versus `source(bob)` versus `source(self)`
    # is half of why the agent is doing this, and inline it is six words of
    # brackets in the middle of the line that a reader has to step over every
    # time. Out here the renderer can draw them, and colour them by the same
    # provenance rule the rest of the UI uses.
    annots: list[Annotation] = field(default_factory=list)
    # where in the .asl this came from, as an absolute path. Its own field
    # rather than a note because it is three times the width of the plan it
    # annotates and the UI shows only the file name, with the rest on a title.
    source: str | None = None
    # ag: is there more behind this one line worth a click -- a full LlmCall
    # (prompt/thinking/answer/transcript) for a "model" link or the icaros
    # step that triggered it, correlated client-side by (agent, cycle) since
    # at most one LlmCall happens per agent per cycle (app.js, no id plumbing
    # needed here). False for the links that are already the whole story
    # (an event, a belief delta, a chosen plan).
    clickable: bool = False


@dataclass(slots=True)
class CycleTrace:
    """What one agent did in one reasoning cycle: the road the cycle took.

    ag: the counterpart of DeliberationView, and the difference is the whole
    point of it existing. DeliberationView answers "what applies NOW" -- on
    the fast path the interpreter never fills relevant/applicable plans, so
    inspect.deliberation() has to re-derive them against the belief base as it
    stands at inspection time. This answers "what happened THEN", because it
    is folded from journal entries written during the cycle itself.

    `known` is False when the cycle is too old to still have its detail: the
    journal folds a cycle into one CYCLE line once `detail_cycles` have passed
    (Journal._compact). `folded` is that one line. Saying so is the same
    contract as beliefs_at() returning None -- an empty trace presented as
    "nothing happened" would be a lie.
    """

    agent: str
    cycle: int
    known: bool
    chain: list[ChainLink]
    folded: str | None = None


@dataclass(slots=True)
class ReasoningStream:
    """The last few cycles an agent actually did something in, oldest first.

    ag: a stream and not a single cycle, because one cycle out of context
    answers "what is it doing" and not "what has it been doing" -- and the
    second question is the one a reader of a BDI trace is really asking. The
    cycles are the ones with something in them, so the numbers can jump: an
    agent doing thousands of cycles a second is sampled, not followed, and the
    gaps between the numbers are what says so.
    """

    agent: str
    cycles: list[CycleTrace]


@dataclass(slots=True)
class TraceEvent:
    """One thing that happened, captured as text at the moment it happened.

    ag: `detail` holds strings, not live objects, and that is not laziness --
    an Event's Intention and a Circumstance's plan lists keep mutating after
    the callback returns, so holding a reference would mean rendering
    whatever the agent had done by the time a browser asked. The cost is one
    str() per event rather than per cycle.
    """

    seq: int
    kind: str
    agent: str
    cycle: int
    at: float
    detail: dict[str, str]


class WireError(TypeError):
    """Something that isn't JSON reached the wire layer."""


_SCALARS = (str, int, float, bool, type(None))


def to_json(value):
    """Recursively turns the views above into json.dumps-able data.

    Deliberately strict: anything that isn't a dataclass, list, tuple, dict
    or scalar raises instead of being coerced. A Term or an Intention that
    leaks into a view field is the most likely way this layer breaks, and a
    silent repr() would hide it until a browser rendered nonsense.
    """
    if isinstance(value, _SCALARS):
        return value
    if is_dataclass(value) and not isinstance(value, type):
        return {f.name: to_json(getattr(value, f.name)) for f in fields(value)}
    if isinstance(value, (list, tuple)):
        return [to_json(v) for v in value]
    if isinstance(value, dict):
        for key in value:
            if not isinstance(key, str):
                raise WireError(f"non-string dict key {key!r} ({type(key).__name__})")
        return {k: to_json(v) for k, v in value.items()}
    raise WireError(
        f"{type(value).__name__} is not wire data -- capture it as a string at collection time")

"""Round-robin scheduler over the runnable agents of one MAS -- the
purpose-built replacement for the shared ThreadPoolExecutor that `.mas2i`'s
`threads: N` used to create (ported from Jason's RunLocalMAS.createThreadPool
/ `infrastructure: Local(pool,N)`). A ThreadPoolExecutor allocates a Future
(with its own Condition/RLock) per submitted slice that nobody ever reads --
at thousands of agents that is tens of thousands of throwaway objects per
simulation round, and a discarded Future silently swallows any exception
raised inside it. AgentScheduler is just a FIFO of runnable agents drained by
N daemon workers blocked in SimpleQueue.get(): an idle MAS costs exactly zero
CPU, a slice costs one queue put/get, and a worker that hits an exception
logs it and keeps serving instead of disappearing.

No import from `icaros` here on purpose: `ag_arch.py` imports `runner.py`,
and `runner.py` owns the scheduler -- a concrete AgArch import would close
that circle. `Slice` is a structural Protocol instead.
"""
from __future__ import annotations

import logging
import queue
import threading
from typing import Protocol

logger = logging.getLogger(__name__)

_STOP = object()  # one per worker -- unblocks a worker parked in get()


class Slice(Protocol):
    ag_name: str

    def run_slice(self) -> None: ...


class AgentScheduler:
    """Callers must keep "at most one pending slice per agent" themselves --
    this scheduler does not deduplicate. AgArch enforces it with `_scheduled`
    under `_batch_lock`; that invariant is the only thing keeping two workers
    out of the same agent's Circumstance at once.
    """

    def __init__(self, num_threads: int, name_prefix: str = "icaros-ag") -> None:
        if num_threads < 1:
            raise ValueError(f"num_threads must be >= 1, got {num_threads}")
        self._runnable: queue.SimpleQueue = queue.SimpleQueue()
        self._threads = tuple(
            threading.Thread(target=self._worker, name=f"{name_prefix}-{i}", daemon=True)
            for i in range(num_threads))
        self._lock = threading.Lock()  # guards _started/_shutdown vs submit()/shutdown()
        self._started = False
        self._shutdown = False

    @property
    def num_threads(self) -> int:
        return len(self._threads)

    @property
    def queue_size(self) -> int:
        return self._runnable.qsize()

    @property
    def is_shutdown(self) -> bool:
        return self._shutdown

    def start(self) -> None:
        # idempotent; submit() calls it on first use, so callers rarely need to
        with self._lock:
            self._start_locked()

    def _start_locked(self) -> None:
        if self._started or self._shutdown:
            return
        self._started = True
        for t in self._threads:
            t.start()

    def submit(self, item: Slice) -> bool:
        """Queues one slice. Returns False -- a silent no-op, not an
        exception -- once shutdown() has been called, so a caller like
        Environment._wake_agent (no try/except around it, unlike
        Environment.act) can't blow up on a wake that arrives during
        teardown."""
        with self._lock:
            if self._shutdown:
                return False
            self._start_locked()
            self._runnable.put(item)
            return True

    def shutdown(self, wait: bool = False, timeout: float | None = None) -> None:
        """Refuses new work and stops the workers once already-queued slices
        have run -- same semantics as ThreadPoolExecutor.shutdown(wait=False).
        Idempotent. Don't call with wait=True from a worker thread (it would
        join itself)."""
        with self._lock:
            if self._shutdown:
                return
            self._shutdown = True
            started = self._started
        if not started:
            return
        for _ in self._threads:
            self._runnable.put(_STOP)
        if wait:
            for t in self._threads:
                t.join(timeout)

    def _worker(self) -> None:
        while True:
            item = self._runnable.get()  # blocks: an idle MAS burns zero CPU
            if item is _STOP:
                return
            try:
                item.run_slice()
            except BaseException:
                # a worker must never die: at num_threads == 1 that would
                # freeze the whole MAS with no visible error
                logger.exception("agent '%s' aborted a reasoning slice",
                                  getattr(item, "ag_name", item))
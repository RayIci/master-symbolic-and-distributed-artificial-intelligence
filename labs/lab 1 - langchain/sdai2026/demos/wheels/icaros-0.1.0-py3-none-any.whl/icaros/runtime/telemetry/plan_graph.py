from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.plan_body import BodyType
from icaros.journal.deliberation import is_generated_label

if TYPE_CHECKING:
    from icaros.pl.plan_library import PlanLibrary

# body steps that raise a goal, i.e. that can hand control to another plan
_GOAL_STEPS = {BodyType.ACHIEVE, BodyType.ACHIEVE_NF, BodyType.TEST}

# the plans every agent gets from boot_agent -- the KQML protocol ones and the
# journal tool wrappers -- are infrastructure, not the developer's own program,
# and they swamp the graph of a small agent. They are tagged on the way in
# (boot.py passes origin=PlanLibrary.KQML_PLANS_FILE / JOURNAL_PLANS_FILE,
# which lands as a url(...) annotation on the plan label).
_INFRASTRUCTURE_FILES = ("kqmlPlans.asl", "journalPlans.asl")


def _indicator(literal) -> str:
    """`greet/1` -- what a `!greet(X)` step and a `+!greet(Who)` trigger have
    in common. Matching on name and arity rather than through the unifier is
    the point: this is static analysis of the plan library, not a run."""
    try:
        return f"{literal.functor}/{literal.get_arity()}"
    except AttributeError:
        return str(literal)


def _label_name(plan) -> str | None:
    """The bare label -- `p`, not `p[breakpoint]`, which is what str() gives."""
    label = plan.label
    return None if label is None else label.functor


def _is_infrastructure(plan) -> bool:
    return plan.source_file in _INFRASTRUCTURE_FILES


# PlanBody.__str__ renders the whole remaining chain ("!a; !b; !c"), so a
# step has to be rendered from its own term to name just itself
_STEP_PREFIX = {BodyType.ACHIEVE: "!", BodyType.ACHIEVE_NF: "!!", BodyType.TEST: "?"}


def _goal_steps(plan) -> list[tuple[str, str]]:
    """(indicator, rendered step) for every goal this plan's body raises."""
    out = []
    body = plan.get_body()
    if body is None:
        return out
    for step in body:
        if step.body_type in _GOAL_STEPS and step.body_term is not None:
            rendered = f"{_STEP_PREFIX[step.body_type]}{step.body_term}"
            out.append((_indicator(step.body_term), rendered))
    return out


def plan_graph(plan_library: PlanLibrary, *, include_infrastructure: bool = False) -> dict:
    """Which plan can hand control to which, derived from the plan library
    alone -- no run required.

    An edge goes from a plan whose body contains `!g` to every plan whose
    trigger is `+!g`, matched by name and arity. Purely static, so it is the
    map you read *before* stepping through anything: it shows the routes that
    exist, not the one that was taken.

    `orphans` are the goals raised by some body with no plan to handle them
    -- a runtime failure waiting to happen, and the single most useful thing
    this view surfaces.
    """
    plans = [p for p in plan_library.plans
             if include_infrastructure or not _is_infrastructure(p)]

    handlers: dict[str, list[str]] = {}
    nodes = []
    for i, plan in enumerate(plans):
        node_id = _label_name(plan) or f"plan#{i}"
        trigger = plan.trigger
        info = getattr(plan, "src_info", None)
        nodes.append({
            "id": node_id,
            # what the card shows: the author's label, none for a generated p__N
            "label": None if is_generated_label(plan.label) else _label_name(plan),
            "trigger": str(trigger),
            "context": str(plan.context) if plan.context is not None else None,
            "source": str(info) if info is not None else None,
            "breakpoint": plan.has_breakpoint(),
            "is_goal_plan": trigger.is_achv_goal() and trigger.is_addition(),
        })
        if trigger.is_achv_goal() and trigger.is_addition():
            handlers.setdefault(_indicator(trigger.literal), []).append(node_id)

    edges = []
    orphans = []
    for node, plan in zip(nodes, plans):
        for indicator, rendered in _goal_steps(plan):
            targets = handlers.get(indicator)
            if not targets:
                orphans.append({"from": node["id"], "goal": rendered,
                                "indicator": indicator})
                continue
            for target in targets:
                edges.append({"source": node["id"], "target": target,
                              "goal": rendered, "indicator": indicator})

    # a plan nothing routes to and that raises nothing is an entry point --
    # where reading the graph starts
    reachable = {e["target"] for e in edges}
    for node in nodes:
        node["entry"] = node["id"] not in reachable

    return {"nodes": nodes, "edges": edges, "orphans": orphans}

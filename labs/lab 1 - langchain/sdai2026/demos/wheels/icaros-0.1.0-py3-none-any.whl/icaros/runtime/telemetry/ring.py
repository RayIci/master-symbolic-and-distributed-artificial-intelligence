from __future__ import annotations

import threading
from collections import deque
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.runtime.telemetry.model import TraceEvent

DEFAULT_CAPACITY = 4096


@dataclass(slots=True)
class Drain:
    """What one reader got out of a ring: the events it hadn't seen, where to
    resume from, and how many it will never see."""

    events: list[TraceEvent]
    next_seq: int
    gap: int  # evicted before this reader asked for them


class EventRing:
    """A bounded, monotonically numbered event log with many readers.

    ag: deliberately NOT the fan-out that the TUI's _LogChannel does (a
    queue.Queue per client, appended to from the producer thread). That queue
    is unbounded, so one stalled websocket client grows without limit, and
    the fan-out cost lands on the agent's own thread. Here the producer does
    one bounded append and readers poll by sequence number: agent-thread cost
    is independent of how many browsers are watching, and a reader that falls
    behind loses events -- and is told it lost them -- instead of eating
    memory.
    """

    def __init__(self, capacity: int = DEFAULT_CAPACITY) -> None:
        self._lock = threading.Lock()
        self._events: deque[TraceEvent] = deque(maxlen=capacity)
        self._next_seq = 0
        self._dropped = 0

    @property
    def capacity(self) -> int:
        return self._events.maxlen

    @property
    def dropped(self) -> int:
        """How many events have been evicted since the ring was created."""
        with self._lock:
            return self._dropped

    def append(self, event: TraceEvent) -> int:
        """Stamps `event` with the next sequence number and stores it.
        Called from agent threads; must stay short."""
        with self._lock:
            event.seq = self._next_seq
            self._next_seq += 1
            if len(self._events) == self._events.maxlen:
                self._dropped += 1
            self._events.append(event)
            return event.seq

    def since(self, seq: int) -> Drain:
        """Everything from `seq` onward. A reader starts at 0 and then feeds
        back the `next_seq` it was given."""
        with self._lock:
            if not self._events:
                return Drain(events=[], next_seq=self._next_seq, gap=0)
            oldest = self._events[0].seq
            # a reader that asked for events already evicted must be told, not
            # silently handed the surviving tail as if it were complete
            gap = oldest - seq if seq < oldest else 0
            start = max(seq, oldest)
            events = [e for e in self._events if e.seq >= start]
            return Drain(events=events, next_seq=self._next_seq, gap=gap)

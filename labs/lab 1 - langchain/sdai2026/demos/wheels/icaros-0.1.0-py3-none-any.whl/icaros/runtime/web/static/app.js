// icaros dev UI.
//
// ag: a deliberately dumb renderer. Everything with logic in it -- filtering,
// aggregation, the message graph's edges -- is computed in Python, where it
// has tests. This file turns already-shaped JSON into DOM and does nothing
// clever, because it is the one part of the project with no test harness.

const state = {
  agents: {},        // name -> counters
  selected: null,
  timeline: [],      // newest last, capped
  llmCalls: [],      // {seq, agent, cycle, purpose, ...} newest last
  selectedCall: null,
  onlySelected: false,
  beliefFilter: "",
  debug: null,       // pause/step/breakpoint status of the selected agent
  bootState: null,   // idle | loading | ready | failed, from /api/status
  // ag: which MAS the rest of this object belongs to. Every boot gets a new
  // number from the server (BootState.run) and the numbers only go up, so
  // this answers both questions a browser has: "is this a different MAS?"
  // (reset) and "did this frame arrive after the one that replaced it?"
  // (drop). Without it a second MAS inherited the first one's timeline, and
  // the frame already in flight when a MAS was stopped bounced the hub
  // straight back into the dead MAS's screen.
  run: null,
  // the highest ring seq already folded in. A reconnecting websocket is
  // handed the whole retained ring from 0 again (the server's cursor is
  // per-connection), so without this every reload duplicated the timeline,
  // the console and -- most visibly -- the chat.
  lastSeq: -1,
  reasoning: null,   // the selected agent's last cycle, from /api/agents/{n}/reasoning
  busy: false,       // the deep read timed out: the mind cards are a moment old
  log: [],           // print/environment/log events, newest last, capped
  chat: {
    eligible: {},        // name -> {eligible, reason}, from /api/mas
    // ag: a stream, not question/answer pairs -- an agent says things on its
    // own initiative too (.say), and those belong in the same conversation as
    // the ones it was asked for.
    messages: [],        // {who: "you"|"agent", agent, text, error}
    pending: new Map(),  // chatId -> {agent}: what is still unanswered
    // ag: agent -> the answer so far, while it is still being written. Held
    // apart from `messages` because it is not one yet: it is provisional
    // text, replaced wholesale by the real message the moment .say lands.
    // That is also what makes a dropped llm_chunk harmless -- the authoritative
    // sentence always arrives by another route.
    streaming: new Map(),
  },
};

const TIMELINE_MAX = 400;
const LLM_MAX = 100;
const LOG_MAX = 400;
const CHAT_MAX = 200;

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
};

// ag: a row on the cycle rail. The gutter carries the agent and its
// reasoning-cycle number, printed only when the pair changes, so a run of
// events inside one cycle reads as a block rather than as the same number six
// times over. Both the timeline and the LLM list are built from this, which is
// what makes them read as two views of one ruler.
//
// The agent belongs in the gutter and not inline because the cycle counter is
// *per agent*: an unfiltered timeline interleaves several of them, so 26, 25,
// 63, 24 is not a broken ruler, it is four agents' clocks. Printing whose
// clock it is next to the number is what makes that legible.
function railRow(agent, cycle, cls) {
  const li = el("li", "ev" + (cls ? " " + cls : ""));
  const rail = el("div", "ev-rail");
  if (agent) rail.append(el("span", "ev-agent", agent));
  if (cycle !== null && cycle !== undefined) rail.append(el("span", "ev-num", String(cycle)));
  li.append(rail, el("div", "ev-body"));
  return li;
}
const railBody = (li) => li.lastChild;

// ag: src_info stringifies to an absolute path, which in the plans pane is
// three times the width of the plan it annotates. The file name and line are
// the part anyone reads; the whole path stays on the element's title, so
// nothing is actually lost.
function sourceTag(source) {
  const span = el("span", "src", source.split("/").pop());
  span.title = source;
  return span;
}

// ag: swapping screens is a change of place, not of content, so it wants a
// crossfade -- but *not* through document.startViewTransition. WebKitGTK 4.1
// exposes that API and then segfaults the whole window process the first time
// it runs, taking the MAS down with it:
//
//     Stack trace of thread 212917:
//     #0 libwebkit2gtk-4.1.so.0 + 0x1cec04e
//     ...
//     #7 libjavascriptcoregtk-4.1.so.0 + 0x22e591f
//
// and because the window only dies a few seconds in, WindowShell's 1.5 s
// liveness check has already passed: no warning, no browser fallback, the app
// just quietly exits. Feature-detecting the API is not enough, since the crash
// is in the implementation behind it. The fade lives in CSS instead, where the
// worst case is that it does not play.
function transition(mutate) {
  mutate();
}

// ------------------------------------------------------------------- theme

// Lucide (MIT): sun and moon. The button offers the theme you would switch
// *to*, which is the one people reach for -- so a dark page shows a sun.
const ICON_SUN = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4'
               + 'M17.7 17.7l1.4 1.4M2 12h2M20 12h2M6.3 17.7l-1.4 1.4M19.1 4.9l-1.4 1.4"/>';
const ICON_MOON = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z"/>';

// the <head> script has already stamped data-theme; this only keeps the button
// in step and remembers a deliberate choice
function renderTheme() {
  const light = document.documentElement.dataset.theme === "light";
  const btn = $("btn-theme");
  btn.querySelector("svg").innerHTML = light ? ICON_MOON : ICON_SUN;
  btn.title = light ? "Switch to the dark theme" : "Switch to the light theme";
  btn.setAttribute("aria-label", btn.title);
}

function setTheme(name) {
  document.documentElement.dataset.theme = name;
  try { localStorage.setItem("icaros-theme", name); } catch (e) { /* private mode */ }
  renderTheme();
}

// ------------------------------------------------------------------ toasts

// ag: the vanilla stand-in for a toast library. Errors used to land in inline
// text that is easy to miss once a run is underway -- a failed boot, a
// rejected injection. Say what happened and what to do about it.
function toast(message, { title = "", tone = "bad", ms = 7000 } = {}) {
  const host = $("toasts");
  const node = el("div", `toast is-${tone}`);
  if (title) node.append(el("div", "toast-title", title));
  node.append(el("div", null, message));
  node.onclick = () => node.remove();
  host.append(node);
  setTimeout(() => node.remove(), ms);
}

// -------------------------------------------------------- hub and loading

// which of the three screens is up. Driven entirely by /api/status, so the
// window can outlive any single MAS: stop one, land back on the hub, run
// another, all without restarting the process.
function showScreen(name) {
  const screens = [["screen-hub", "hub"], ["screen-loading", "loading"],
                   ["screen-mas", "mas"]];
  if (screens.every(([id, wanted]) => $(id).hidden === (name !== wanted))) return;
  transition(() => {
    for (const [id, wanted] of screens) $(id).hidden = name !== wanted;
    $("btn-hub").hidden = name !== "mas";
  });
}

function applyStatus(status) {
  if (!status) return;
  // ag: runs only ever go up, so a lower one is a frame that was already on
  // the wire when the MAS it describes was replaced. Acting on it would undo
  // the reset that replaced it -- which is exactly how "back to hub" used to
  // flash the dead MAS's screen back up for a tenth of a second.
  if (state.run !== null && status.run < state.run) return;

  const fresh = status.run !== state.run;
  const previous = state.bootState;
  state.run = status.run;
  state.bootState = status.state;
  // ag: keyed on the run, not on the state transition. The old test
  // ("previous === 'ready'") missed every path that does not pass through the
  // hub -- a boot issued while a MAS was running, and a websocket that
  // reconnected across a swap and so never saw the states in between.
  if (fresh) resetMasState();

  if (status.state === "loading") {
    showScreen("loading");
    renderLoading(status);
    return;
  }
  if (status.state === "ready") {
    // only on the transition: onMasReady refetches and repaints the panes
    if (fresh || previous !== "ready") onMasReady(status);
    return;
  }
  // idle or failed
  showScreen("hub");
  // only on the transition: every websocket status frame carries "failed"
  // again for as long as the hub sits there, and this used to re-toast on
  // every one of them
  if (status.state === "failed" && status.error && (fresh || previous !== status.state)) {
    showOpenError(status.error);
  }
  if (fresh || previous !== status.state) refreshRecents();
}

function renderLoading(status) {
  $("loading-name").textContent = status.mas_name
    ? `Starting ${status.mas_name}…` : "Starting…";
  const p = status.progress;
  const fill = $("progress-fill");
  if (!p || p.fraction === null) {
    // the total is unknown until the .mas2i has been parsed; sweeping is
    // honest, a 0% bar that sits there is not
    fill.classList.add("is-indeterminate");
    fill.style.width = "";
  } else {
    fill.classList.remove("is-indeterminate");
    fill.style.width = `${Math.round(p.fraction * 100)}%`;
  }
  $("loading-phase").textContent = p ? PHASES[p.phase] || p.phase : "preparing";
  $("loading-detail").textContent = p ? p.detail : "";
}

const PHASES = {
  parse: "Reading the MAS file",
  environment: "Loading the environment",
  asl: "Parsing agent sources",
  // named separately because it is the slow one: the provider loads the model
  llm: "Waiting for the language model",
  agent: "Booting agents",
  ready: "Ready",
};

async function onMasReady(status) {
  const run = state.run;
  const mas = await fetch("/api/mas").then((r) => r.json());
  if (state.run !== run) return;  // a third MAS arrived while this awaited
  $("mas-name").textContent = mas.name;
  document.title = `icaros · ${mas.name}`;
  // ag: seed the names that are missing rather than reassigning. This runs
  // after an await, and frames delivering real counters have been landing all
  // through it -- `state.agents = {}` here threw those away and made the
  // agent list say "no data yet" for a MAS that had already been thinking.
  for (const name of mas.agents) {
    if (!(name in state.agents)) state.agents[name] = null;
  }
  state.chat.eligible = mas.chat || {};
  showScreen("mas");
  if (mas.agents.length) select(mas.agents[0]);
  renderAgents();
  renderChatAgentOptions();
  // the two panes that are pulled on demand rather than pushed: whichever one
  // is open is still showing the previous MAS until something asks again
  if (activePane() === "plans") refreshPlans();
  if (activePane() === "messages") refreshMessages();
}

function resetMasState() {
  state.agents = {};
  agentRows.clear();   // the next MAS gets fresh rows, not the last one's
  state.selected = null;
  state.timeline = [];
  state.llmCalls = [];
  // ring seqs restart at 0 with every MAS, so a selection kept across a swap
  // would name a transcript that now belongs to somebody else entirely
  state.selectedCall = null;
  state.lastSeq = -1;
  state.debug = null;
  state.reasoning = null;
  state.busy = false;
  state.log = [];
  state.chat = { eligible: {}, messages: [], pending: new Map(), streaming: new Map() };
  $("mas-name").textContent = "—";
  document.title = "icaros";
  clearPanes();
}

// ag: clearing `state` is not clearing the screen. Every render* below paints
// from scratch, but most of them only ever run when an event of their own
// kind arrives -- so a MAS that had not yet printed, called a model or spoken
// left the previous MAS's console, LLM list and chat sitting there, sometimes
// for good. The fix is to say so out loud once, here, rather than to make
// each render defensive.
function clearPanes() {
  renderAgents();
  renderTimeline();
  renderLlmList();
  renderLog();
  renderChat();
  renderDebug();
  renderChatAgentOptions();
  renderReasoning();
  for (const id of ["beliefs", "mailbox", "intentions"]) {
    renderList($(id), [], "empty");
  }
  for (const [id, text] of [["plan-graph", "—"], ["message-graph", "No messages yet."],
                            ["llm-detail", "Select a call to see its prompt, "
                                         + "reasoning and answer."]]) {
    const host = $(id);
    host.className = id === "llm-detail" ? "llm-detail empty" : "empty";
    host.textContent = text;
  }
  $("detail-name").textContent = "Select an agent";
  count($("mailbox-count"), 0);
  count($("intentions-count"), 0);
  // a drop warning belongs to the run that dropped them
  $("gap-warning").hidden = true;
}

const activePane = () =>
  (document.querySelector(".pane.is-active") || {}).id?.replace("pane-", "") || null;

// ag: the raw string is "ExceptionClassName: file:line:col: message", or
// "ExceptionClassName: message" with no location at all, or (a syntax error)
// the same plus the source line and a "^" caret on the lines after. None of
// that reads well run together in one paragraph -- so pull the location out
// into its own small badge (full path in the tooltip, since the .mas2i tree
// can nest a few levels deep) and drop the Python class name, which never
// added anything a MAS author could act on.
function showOpenError(rawText) {
  const box = $("open-error");
  const loc = $("open-error-loc");
  const body = $("open-error-text");
  box.hidden = false;
  box.dataset.raw = rawText;  // Copy still hands over the untouched original

  const text = rawText.replace(/^[A-Za-z_]\w*(?:Error|Exception): /, "");
  const m = /^(.+?):(\d+):(\d+): ([\s\S]*)$/.exec(text);
  if (m) {
    const [, path, line, col, rest] = m;
    loc.hidden = false;
    loc.textContent = `${path.split("/").pop()}:${line}:${col}`;
    loc.title = path;
    body.textContent = rest;
  } else {
    loc.hidden = true;
    body.textContent = text;
  }
  toast("Could not start — see the error below", { title: "Could not start" });
}

async function refreshRecents() {
  const { recents } = await fetch("/api/recents").then((r) => r.json());
  const host = $("recents");
  host.replaceChildren();
  if (!recents.length) {
    host.append(el("li", "empty", "Nothing yet."));
    return;
  }
  for (const entry of recents) {
    const li = el("li", "entry");
    li.append(el("span", "r-name", entry.name),
              el("span", "r-path", entry.path),
              el("span", "r-when", ago(entry.at)));
    li.onclick = () => bootMas(entry.path);
    host.append(li);
  }
}

function ago(seconds) {
  if (!seconds) return "";
  const mins = Math.max(0, (Date.now() / 1000 - seconds) / 60);
  if (mins < 1) return "just now";
  if (mins < 60) return `${Math.round(mins)}m ago`;
  const hours = mins / 60;
  if (hours < 24) return `${Math.round(hours)}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

async function bootMas(path) {
  $("open-error").hidden = true;
  const res = await fetch(`/api/boot?path=${encodeURIComponent(path)}`, { method: "POST" });
  const body = await res.json();
  if (!res.ok) { showOpenError(body.detail); return; }
  applyStatus(body);
}

// ---------------------------------------------------------------- bootstrap

async function boot() {
  renderTheme();
  await refreshRecents();
  applyStatus(await fetch("/api/status").then((r) => r.json()));
  // pywebview injects its bridge asynchronously; the browser fallback never
  // gets one, and there the path field is the only way in
  setTimeout(() => {
    if (window.pywebview && window.pywebview.api) $("btn-browse").hidden = false;
  }, 400);
  connect();
}

function connect() {
  const ws = new WebSocket(`ws://${location.host}/ws`);
  const link = $("link");
  ws.onopen = () => { link.textContent = "live"; link.className = "link is-live"; };
  ws.onclose = () => {
    link.textContent = "disconnected"; link.className = "link is-down";
    setTimeout(connect, 1000);
  };
  ws.onmessage = (ev) => onFrame(JSON.parse(ev.data));
}

function onFrame(frame) {
  if (frame.status) applyStatus(frame.status);
  if (state.bootState !== "ready") return;
  // the run the events belong to, checked after applyStatus has had its say:
  // a frame from a MAS that is no longer the current one carries counters and
  // events that would be read as this one's
  if (frame.run !== state.run) return;
  state.agents = frame.counters;
  if (frame.gap > 0) {
    const w = $("gap-warning");
    w.hidden = false;
    w.textContent = `${frame.gap} events dropped (UI fell behind)`;
  }
  let applied = 0;
  for (const event of frame.events) {
    // ag: the server's cursor lives on the connection, so a websocket that
    // reconnects is replayed the whole retained ring from seq 0. Everything
    // below appends blindly, so without this every reload doubled the
    // timeline and re-said every line an agent had ever said in the chat.
    if (event.seq <= state.lastSeq) continue;
    state.lastSeq = event.seq;
    applied += 1;
    state.timeline.push(event);
    if (event.kind === "llm_call") {
      state.llmCalls.push(event);
      if (state.llmCalls.length > LLM_MAX) state.llmCalls.shift();
    }
    // the console: what an agent printed, what the environment said, what the
    // interpreter warned about -- three kinds, one thing to read
    if (event.kind === "print" || event.kind === "environment" || event.kind === "log") {
      state.log.push(event);
      if (state.log.length > LOG_MAX) state.log.shift();
    }
    if (event.kind === "llm_chunk") agentIsWriting(event);
    if (event.kind === "say") agentSaid(event);
    if (event.kind === "llm_generate") noteChatFailure(event);
  }
  if (state.timeline.length > TIMELINE_MAX) {
    state.timeline.splice(0, state.timeline.length - TIMELINE_MAX);
  }
  renderAgents();
  renderReasoningHead();  // the live cycle, next to the one the trace is on
  if (applied) { renderTimeline(); renderLlmList(); renderLog(); renderChat(); }
}

// ag: the agent spoke. This is the ONLY way an agent message enters the chat,
// whether it was answering something typed here or decided to say it by
// itself -- which is why nothing needs to correlate the two. Answering closes
// the oldest thing still outstanding with that agent; a message nobody asked
// for closes nothing and simply appears.
// ag: a piece of an answer still being written. Deltas, not the whole text
// each time -- which is what every provider streams and what keeps these
// events small, the ring being bounded and shared with everything else on the
// timeline. Losing one leaves a hole for as long as the answer takes and no
// longer: agentSaid below throws the accumulated text away and puts the real
// sentence in its place.
function agentIsWriting(event) {
  const so_far = state.chat.streaming.get(event.agent) || "";
  state.chat.streaming.set(event.agent, so_far + (event.detail.text || ""));
}

function agentSaid(event) {
  state.chat.streaming.delete(event.agent);
  state.chat.messages.push({ who: "agent", agent: event.agent, text: event.detail.text || "" });
  for (const [chatId, waiting] of state.chat.pending) {
    if (waiting.agent === event.agent) { state.chat.pending.delete(chatId); break; }
  }
  if (state.chat.messages.length > CHAT_MAX) state.chat.messages.shift();
}

// A session that never finished leaves somebody waiting for an answer that is
// not coming, so the one llm_generate this panel still reads is the failed
// one: the entry names the goal it was serving, and a chat message's goal
// carries the id this panel was handed when it sent it. Journal.record()
// drops None-valued kwargs, so "error" in detail is what marks a failure --
// not a string comparison.
function noteChatFailure(event) {
  if (!("error" in event.detail)) return;
  const goal = event.detail.goal || "";
  const chatId = [...state.chat.pending.keys()].find((id) => goal.includes(id));
  if (!chatId) return;
  const { agent } = state.chat.pending.get(chatId);
  state.chat.pending.delete(chatId);
  state.chat.messages.push({ who: "agent", agent, error: true,
                             text: event.detail.error });
}

// ------------------------------------------------------------------ agents

// ag: this list is redrawn on *every* websocket frame, because the counters
// change on every reasoning cycle -- so it is the one place where rebuilding
// the DOM is not free. replaceChildren() here threw the row out from under the
// pointer dozens of times a second: :hover was lost and reapplied on each
// rebuild, which reads as a fast flicker under the mouse. So the rows are
// built once and patched in place afterwards, and only rebuilt when the set of
// agents actually changes (a MAS is stopped and another one started).
const agentRows = new Map();  // name -> {li, dot, cycle, stats}

function buildAgentRow(name) {
  const li = el("li", "agent");
  li.onclick = () => select(name);
  const dot = el("span", "dot");
  const nameEl = el("span", "name");
  nameEl.append(dot, name);
  const cycle = el("span", "cycle");
  const stats = el("span", "stats");
  li.append(nameEl, cycle, stats);
  agentRows.set(name, { li, dot, cycle, stats });
  return li;
}

function renderAgents() {
  const list = $("agent-list");
  const names = Object.keys(state.agents).sort();
  if (names.length !== agentRows.size || names.some((n) => !agentRows.has(n))) {
    agentRows.clear();
    list.replaceChildren(...names.map(buildAgentRow));
  }
  for (const name of names) {
    const row = agentRows.get(name);
    const c = state.agents[name];
    row.li.classList.toggle("is-selected", name === state.selected);
    row.dot.className = "dot " + (c && c.busy ? "thinking" : c && c.sleeping ? "sleeping" : "running");
    row.cycle.textContent = c ? `#${c.cycle}` : "—";
    row.stats.textContent = c
      ? c.busy ? "thinking…" : `ev ${c.pending_events} · int ${c.running_intentions} · mail ${c.mailbox}`
      : "no data yet";
  }
}

function select(name) {
  state.selected = name;
  state.reasoning = null;
  state.busy = false;
  $("detail-name").textContent = name;
  renderAgents();
  renderReasoning();
  refreshDetail();
  refreshDebug();
  refreshReasoning();
  refreshBeliefs();
  renderTimeline();
}

// ag: every pull below is `for` an agent, and the agent can change while the
// request is out -- the mind pane polls once a second and a slow agent takes
// up to two to answer, so an answer about the agent you just left would land
// on top of the one you just picked. Two rules, applied at every call site:
// never have two of the same request in flight, and drop an answer that is no
// longer about the selected agent.
const inFlight = new Set();

async function forSelected(key, path, apply) {
  const agent = state.selected;
  if (!agent || inFlight.has(key)) return;
  inFlight.add(key);
  try {
    const res = await fetch(path(agent));
    if (state.selected !== agent) return;  // answered about somebody else
    await apply(res, agent);
  } finally {
    inFlight.delete(key);
  }
}

// ------------------------------------------------------------ debug control

function refreshDebug() {
  return forSelected("debug", (a) => `/api/debug/${encodeURIComponent(a)}`,
    async (res) => {
      state.debug = res.ok ? await res.json() : null;
      renderDebug();
      renderReasoningHead();
    });
}

// Lucide (MIT), inline so the window needs no network and no icon package
const ICON_PAUSE = '<rect x="14" y="4" width="4" height="16" rx="1"/>'
                 + '<rect x="6" y="4" width="4" height="16" rx="1"/>';
const ICON_PLAY = '<path d="M6 4l12 8-12 8V4z"/>';

function renderDebug() {
  const d = state.debug;
  const label = $("debug-state");
  const pause = $("btn-pause");
  const resuming = !!(d && d.paused);
  pause.querySelector("svg").innerHTML = resuming ? ICON_PLAY : ICON_PAUSE;
  pause.title = resuming ? "Resume" : "Pause";
  pause.setAttribute("aria-label", pause.title);
  pause.disabled = !d;
  $("btn-step").disabled = !d;
  if (!d) { label.textContent = ""; label.className = "debug-state"; }
  else if (d.hit) {
    label.textContent = `paused at ${d.hit.what} (cycle ${d.hit.cycle})`;
    label.className = "debug-state is-hit";
  } else {
    label.textContent = d.paused ? "paused" : "";
    label.className = "debug-state" + (d.paused ? " is-paused" : "");
  }
}

async function debugCall(method, path) {
  const res = await fetch(path, { method });
  if (res.ok) {
    state.debug = await res.json();
    renderDebug();
    // don't make the reader wait up to a second to see what Step did
    refreshReasoning();
    refreshBeliefs();
    refreshDetail();
  }
  return res;
}

// ------------------------------------------------------------------- mind

// ag: deliberation is NOT asked for any more. It is the one kind that costs a
// re-derivation of the relevant/applicable plan lists on the agent's own
// thread, and the Reasoning card answers the question it was there for from
// the journal instead -- exactly, and without waiting for a cycle. beliefs
// left in the same way, for the same reason: see refreshBeliefs below.
const MIND_KINDS = "intentions,mailbox";

function refreshDetail() {
  // ag: the counters already say "in a round trip" the instant it starts --
  // asking request_state() anyway would just wait out its own timeout for a
  // cycle that provably has not happened. Skipping the request entirely (not
  // just accepting its answer sooner) is what stops a slow local model from
  // turning the Mind pane into a fetch-then-503 loop for its whole duration.
  const counters = state.agents[state.selected];
  if (counters && counters.busy) {
    state.busy = true;
    renderReasoningHead();
    return Promise.resolve();
  }
  return forSelected("mind",
    (a) => `/api/agents/${encodeURIComponent(a)}?kinds=${MIND_KINDS}`,
    async (res) => {
      // ag: a deep read has to be built on the agent's own thread, so an
      // agent that is inside something long -- an act(), a model round trip,
      // which for an agentic agent is most of the time -- cannot answer and
      // times out. That is a fact about the agent, not an error, and it must
      // NOT blank the cards: what they were showing a second ago is still the
      // last true thing known about it. The chip says the read is stale;
      // meanwhile the Reasoning card keeps working, because it reads the
      // journal and needs no cycle at all.
      state.busy = res.status === 503;
      if (!res.ok) { renderReasoningHead(); return; }
      renderMind(await res.json());
      renderReasoningHead();
    });
}

// the cycle the agent went through, read off its own journal
function refreshReasoning() {
  return forSelected("reasoning",
    (a) => `/api/agents/${encodeURIComponent(a)}/reasoning`,
    async (res) => {
      if (!res.ok) return;
      state.reasoning = await res.json();
      renderReasoning();
    });
}

// ag: no busy check, on purpose -- this is the beliefs-panel counterpart of
// refreshReasoning above. AgentCollector publishes it unconditionally once
// per cycle, on the agent's own thread, so it is never waiting for the
// request_state() handshake refreshDetail's other cards use, and never
// blanked out by a round trip in flight: exactly the case where a stale
// beliefs card used to sit frozen for the whole duration of a session.
function refreshBeliefs() {
  return forSelected("beliefs",
    (a) => `/api/agents/${encodeURIComponent(a)}/beliefs`,
    async (res) => {
      if (!res.ok) return;
      const { beliefs } = await res.json();
      renderBeliefs(beliefs.map((text) => ({ text })));
    });
}

const count = (host, n) => { host.textContent = n ? `· ${n}` : ""; };

function renderMind(s) {
  renderIntentions(s.intentions);
  renderList($("mailbox"), (s.mailbox || []).map((m) => el("li", null, m)), "empty");
  // ag: these two cards stay folded -- they matter in specific moments, not
  // every moment -- so the count on the summary is what says whether there is
  // anything worth unfolding.
  count($("mailbox-count"), (s.mailbox || []).length);
  count($("intentions-count"), (s.intentions || []).length);
}

function renderList(host, children, emptyText) {
  host.replaceChildren();
  if (!children.length) {
    host.className = "empty";
    host.textContent = emptyText === "empty" ? "—" : emptyText;
    return;
  }
  host.className = "";
  const ul = el("ul", "rows");
  ul.append(...children);
  host.append(ul);
}

// ---------------------------------------------------------------- reasoning

// ag: this card used to answer a different question. It showed the plans that
// were relevant and applicable to the selected event -- but the interpreter
// only fills those two lists on the JasonER path, so on the ordinary one the
// card was re-deriving them at read time, against the belief base as it stood
// AFTER the cycle. It answered "what applies now" while reading as "what the
// agent decided". What it is now is the road the cycle actually took, folded
// in Python from the agent's own journal (runtime/telemetry/reasoning.py),
// which is written while the cycle is in progress and can be read while the
// agent is paused.
function renderReasoning() {
  renderReasoningHead();
  const stream = state.reasoning;
  const host = $("reasoning");
  if (!stream || !stream.cycles.length) return renderList(host, [], "—");
  // ag: stick to the newest only if the reader was already there. This is a
  // stream that keeps arriving, and yanking somebody back down while they are
  // reading a cycle three screens up is the one thing that would make it
  // useless to read.
  const atBottom = host.scrollHeight - host.scrollTop - host.clientHeight < 24;

  host.className = "";
  const ul = el("ul", "chain");
  for (const trace of stream.cycles) {
    ul.append(cycleMark(trace.cycle));
    if (!trace.known) {
      ul.append(trace.folded ? foldedLine(trace.cycle, trace.folded)
        : chainLine("folded", "the journal no longer keeps this cycle's detail"));
      continue;
    }
    if (!trace.chain.length) {
      ul.append(chainLine("folded", "nothing happened"));
      continue;
    }
    for (const link of trace.chain) ul.append(chainLink(link, stream.agent, trace.cycle));
  }
  host.replaceChildren(ul);
  if (atBottom) host.scrollTop = host.scrollHeight;
}

// the rule between two cycles. Numbered, because the numbers jump: an agent
// doing thousands of cycles a second is sampled, not followed, and 1482
// straight after 1204 is what says so.
function cycleMark(cycle) {
  const li = el("li", "cycle-mark");
  // the spine passes straight through the rule: one execution seen in
  // stretches, not a stack of unrelated cards
  li.append(el("span", "cycle-mark-n", `cycle ${cycle}`),
            el("span", "link-rail is-plain"),
            el("span", "cycle-mark-rule"));
  return li;
}

function chainLine(cls, text) {
  const li = el("li", "link");
  li.append(el("span", "link-label"), el("span", "link-rail"));
  li.append(el("div", `link-body ${cls}`, text));
  return li;
}

// ag: a compacted cycle (Journal._compact, journal.py) -- `trace.folded` is
// every narrative line that cycle had, glued together with "; ", which is
// exactly the wall of text this replaces inline with a short label. Nothing
// is lost: the glued line is still one click away, in the same popup a
// reasoning step opens (openStepDetail/fallbackDetail below).
function foldedLine(cycle, summary) {
  const li = el("li", "link is-clickable");
  li.append(el("span", "link-label"), el("span", "link-rail"));
  li.append(el("div", "link-body folded", "folded — click to see what survived"));
  li.onclick = () => openModal(fallbackDetail(
    { label: `Cycle ${cycle} (compacted)`, text: summary, notes: [] }));
  return li;
}

function chainLink(link, agent, cycle) {
  const clickable = link.clickable && agent != null && cycle != null;
  const li = el("li", `link kind-${link.kind}` + (link.tone ? ` is-${link.tone}` : "")
    + (clickable ? " is-clickable" : ""));
  li.append(el("span", "link-label", link.label), el("span", "link-rail"));
  const body = el("div", "link-body");
  const head = el("div", "link-head");
  head.append(el("span", "link-text", link.text));
  // ag: drawn, not printed. `+!confirm("Lisbon")[source(self)]` spends half
  // its width on a bracket the reader has to step over every line, and the
  // part that matters -- who this came from -- is the part the palette can
  // say without words. Python classified them; this only paints.
  for (const a of link.annots) head.append(annotChip(a));
  if (link.source) head.append(sourceTag(link.source));
  body.append(head);
  for (const note of link.notes) body.append(el("div", "link-note", note));
  li.append(body);
  if (clickable) li.onclick = () => openStepDetail(link, agent, cycle);
  return li;
}

// ag: at most one LlmCall happens per agent per reasoning cycle (one EXEC_INT
// step per reasoning_cycle()), so (agent, cycle) already picks out the right
// one in state.llmCalls -- no id needs to travel from the journal to here for
// this to work. Falls back to the link's own text/notes when there is none
// (.icaros_consider_results never calls the model at all; a "model" link's
// call can also simply have aged out of the transcript ring).
async function openStepDetail(link, agent, cycle) {
  const call = state.llmCalls.find((c) => c.agent === agent && c.cycle === cycle);
  if (!call) return openModal(fallbackDetail(link));
  const res = await fetch(`/api/transcript/${call.seq}`);
  if (!res.ok) return openModal(fallbackDetail(link));
  openModal(renderCallDetail(await res.json()));
}

function fallbackDetail(link) {
  const box = [el("h3", null, link.label)];
  box.push(el("p", null, link.text));
  if (link.notes.length) box.push(block("Notes", link.notes.join("\n")));
  return box;
}

function annotChip(a) {
  const chip = el("span", `annot is-${a.role}`, a.text);
  chip.title = a.label;   // the annotation as written, for when the short form is not enough
  return chip;
}

// The head is the honest part. This card shows the last cycle the agent did
// something in, and the agent's counter has usually moved on since -- naming
// both numbers is what stops the gap reading as a bug. "busy" is the third
// state and the one worth having: it says the beliefs and intentions beside
// this card are a moment old because the agent is not answering, which for an
// agent in a model round trip is normal and lasts seconds.
function renderReasoningHead() {
  const chip = $("reasoning-status");
  const label = $("reasoning-cycle");
  const counters = state.selected ? state.agents[state.selected] : null;
  if (!state.selected) {
    chip.replaceChildren();
    chip.hidden = true;
    label.replaceChildren();
    return;
  }
  const paused = !!(state.debug && state.debug.paused);
  const what = paused ? "paused"
    : state.busy ? "busy"
    : counters && counters.sleeping ? "sleeping"
    : "running";
  chip.hidden = false;
  chip.replaceChildren(el("span", `dot ${what}`), what);
  chip.title = what === "busy"
    ? "The agent is inside something long and cannot publish its state; "
      + "beliefs, intentions and mailbox are from its last answer."
    : "";

  // the head answers "how current is what I am reading": the newest cycle in
  // the stream, and the one the agent has already reached
  label.replaceChildren();
  const cycles = state.reasoning ? state.reasoning.cycles : [];
  if (!cycles.length) return;
  const at = cycles[cycles.length - 1].cycle;
  // a paused agent runs no further cycle, so there is nothing to be behind of
  if (!paused && counters && counters.cycle > at) {
    label.append(el("span", "behind", `agent at #${counters.cycle}`));
  }
}

function renderIntentions(list) {
  if (!list) return renderList($("intentions"), [], "empty");

  // ag: the only grouping done here -- correlate rows the server already
  // tagged with the same fork.group_id, so two branches of one .fork read as
  // one thing instead of two unrelated intentions. Everything each row shows
  // (llm_call_id, fork_point, sibling_ids) was already computed in Python
  // (runtime/telemetry/inspect.py); this only buckets and slices arrays.
  const groups = new Map();
  const standalone = [];
  for (const i of list) {
    if (!i.fork) { standalone.push(i); continue; }
    const bucket = groups.get(i.fork.group_id) || [];
    bucket.push(i);
    groups.set(i.fork.group_id, bucket);
  }

  const rows = standalone.map(intentionRow);
  for (const branches of groups.values()) rows.push(forkGroupRow(branches));
  renderList($("intentions"), rows, "no intentions");
}

function intentionHeader(i) {
  const marks = `${i.tool_call ? " · llm" : ""}${i.suspended ? " · suspended" : ""}`;
  return el("div", null, `${i.id.slice(0, 8)} · depth ${i.depth}${marks}`);
}

function stackFrame(im) {
  const frame = el("div", "stack");
  if (im.plan_label) frame.append(el("span", "label", im.plan_label + " "));
  frame.append(im.trigger);
  if (im.llm_call_id) {
    frame.append(annotChip({ role: "model", text: "model", label: `llm_call(${im.llm_call_id})` }));
  }
  if (im.current_step) {
    frame.append(el("div", "step", `→ ${im.current_step}`));
  }
  if (im.source) frame.append(sourceTag(im.source));
  return frame;
}

function intentionRow(i) {
  const li = el("li");
  li.append(intentionHeader(i));
  for (const im of i.stack) li.append(stackFrame(im));
  return li;
}

// ag: the ancestry every branch shares -- the LAST fork.shared_frames
// entries of .stack, since .stack is innermost-first -- is drawn ONCE, under
// a head naming the fork; each branch then shows only what is its own (the
// front of its own .stack, past that count). The alternative, one full
// stack per branch, would repeat the shared frames once per branch and bury
// the one thing worth seeing at a glance: that they forked from the same
// place. shared_frames is often 0 (a fork one level deep, the common icaros
// shape) -- the frame that called .fork diverges per branch immediately, so
// there is nothing to lift out, and every branch just shows its own full
// stack below its own header.
function forkGroupRow(branches) {
  const fork = branches[0].fork;
  const li = el("li", "fork-group");
  const count = branches.length;
  const left = fork.to_finish ? ` · ${fork.to_finish} still running` : "";
  li.append(el("div", "fork-head",
    `forked (${fork.is_and ? "and" : "or"}) into ${count} branch${count === 1 ? "" : "es"}${left}`));
  if (fork.shared_frames) {
    for (const im of branches[0].stack.slice(-fork.shared_frames)) li.append(stackFrame(im));
  }

  const ul = el("ul", "fork-branches");
  for (const i of branches) {
    const branch = el("li", "fork-branch");
    branch.append(intentionHeader(i));
    const own = fork.shared_frames ? i.stack.slice(0, i.stack.length - fork.shared_frames) : i.stack;
    for (const im of own) branch.append(stackFrame(im));
    ul.append(branch);
  }
  li.append(ul);
  return li;
}

function renderBeliefs(list) {
  if (!list) return renderList($("beliefs"), [], "empty");
  const q = state.beliefFilter.toLowerCase();
  const rows = list
    .filter((b) => !q || b.text.toLowerCase().includes(q))
    .map((b) => el("li", null, b.text));
  renderList($("beliefs"), rows, q ? "nothing matches" : "no beliefs");
}

// -------------------------------------------------------------------- llm

function renderLlmList() {
  const host = $("llm-list");
  host.replaceChildren();
  let previous;
  for (const c of [...state.llmCalls].reverse()) {
    const failed = c.detail.error && c.detail.error !== "None";
    const key = `${c.agent}#${c.cycle}`;
    const fresh = key !== previous;
    previous = key;
    const li = railRow(fresh ? c.agent : null, fresh ? c.cycle : null,
      "kind-llm_call is-clickable" + (failed ? " is-failed" : "")
      + (c.seq === state.selectedCall ? " is-selected" : ""));
    const body = railBody(li);
    body.append(el("div", "purpose", c.detail.purpose));
    const choice = c.detail.choice && c.detail.choice !== "None" ? c.detail.choice : "—";
    const meta = el("div", "meta", `${c.detail.duration_ms} ms · ${choice}`);
    meta.title = choice;
    body.append(meta);
    li.onclick = () => showCall(c.seq);
    host.append(li);
  }
}

async function showCall(seq) {
  state.selectedCall = seq;
  renderLlmList();
  const host = $("llm-detail");
  // the fetch is the only genuinely pending thing in this pane -- llm_call
  // events arrive already finished, so there is no in-flight call to animate
  host.className = "llm-detail is-waiting";
  const res = await fetch(`/api/transcript/${seq}`);
  if (!res.ok) {
    host.className = "llm-detail empty";
    host.textContent = "This transcript has been evicted. Only the last 100 calls are kept.";
    return;
  }
  host.className = "llm-detail";
  host.replaceChildren(...renderCallDetail(await res.json()));
}

// ag: the content half of showCall, factored out so the popup a reasoning
// step opens (openStepDetail) shows exactly the same thing as the LLM pane
// does for the same call, rather than a second, drifting rendering of it.
function renderCallDetail(call) {
  const out = [];
  const head = el("section");
  head.append(el("h3", null, `${call.purpose} · ${call.agent} · cycle ${call.cycle}`));
  // ag: "conversation N msgs" used to be the whole story of what the model
  // had seen. A selection is stateless now and carries its history as the
  // journal preamble inside Prompt below, so that number is 0 and saying
  // "conversation 0" would read as if the model had been sent nothing.
  const carried = call.messages_len ? `conversation ${call.messages_len} msgs` : "stateless";
  // ag: "available", not "used": nothing is passed as tools= to the provider
  // yet, so this is what the model could have reached for, not what it was
  // handed. Naming it plainly is cheaper than a reader concluding the tools
  // were sent and wondering why none was ever called.
  head.append(el("div", "meta",
    `${call.model || "?"} · ${call.duration_ms.toFixed(0)} ms · ${carried} · `
    + `${call.tool_specs.length} tools available`));
  out.push(head);

  out.push(block("Prompt", call.prompt));
  if (call.thinking) out.push(block("Reasoning", call.thinking, "thinking"));
  // ag: what it actually reached for, not just what it said -- a round that
  // calls tools and says nothing (or says something separate from the call
  // itself, see icaros.py's prose_only_nudge) would otherwise show as an
  // empty round even though it is the one that did something.
  if (call.tool_calls.length) {
    const text = call.tool_calls
      .map((c) => `${c.name}(${JSON.stringify(c.arguments)})`)
      .join("\n");
    out.push(block(`Tool calls (${call.tool_calls.length})`, text));
  }
  if (call.content) out.push(block("Answer", call.content));
  if (call.choice) out.push(block("Chose", call.choice));
  if (call.error) out.push(block("Error", call.error, "error"));
  return out;
}

// --------------------------------------------------- beliefs, cycle by cycle

// ag: the interesting question about a decision is not what the agent
// believed, it is what had just changed. Folding the journal's deltas gives
// that for any past cycle, on a stopped agent too -- and gives "I no longer
// know", which is rendered as such rather than as an empty diff.
async function showBeliefsDiff(agent, cycle) {
  showPane("llm");
  const host = $("llm-detail");
  host.className = "llm-detail is-waiting";
  const res = await fetch(
    `/api/agents/${encodeURIComponent(agent)}/beliefs_diff?at=${cycle}`);
  if (!res.ok) {
    host.className = "llm-detail empty";
    host.textContent = "Could not read that agent's journal.";
    return;
  }
  const d = await res.json();
  host.className = "llm-detail";
  host.replaceChildren();
  host.append(el("h3", null, `${agent} · what changed entering cycle ${cycle}`));
  if (!d.known) {
    host.className = "llm-detail empty";
    host.append(el("p", null,
      `Cycle ${cycle} is too far back: the journal can no longer reconstruct it.`));
    return;
  }
  if (!d.added.length && !d.removed.length) {
    host.append(el("p", "meta", `Nothing changed. ${d.unchanged} beliefs held.`));
    return;
  }
  if (d.added.length) host.append(block("Gained", d.added.join("\n")));
  if (d.removed.length) host.append(block("Lost", d.removed.join("\n")));
  host.append(el("div", "meta", `${d.unchanged} unchanged`));
}

function block(title, text, cls) {
  const s = el("section");
  s.append(el("h3", null, title));
  s.append(el("pre", cls, text));
  return s;
}

// ---------------------------------------------------------------- modal
//
// ag: one overlay, reused -- openModal() does not know or care who called
// it, it just replaces #modal-box's children and shows the overlay. A
// reasoning step is the first caller (chainLink/openStepDetail above); the
// component itself is not about that feature.

function openModal(children) {
  const box = $("modal-box");
  box.replaceChildren();
  const close = el("button", "close", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  close.onclick = closeModal;
  box.append(close, ...children);
  $("modal-overlay").hidden = false;
}

function closeModal() {
  $("modal-overlay").hidden = true;
  $("modal-box").replaceChildren();
}

// ------------------------------------------------------------------ plans

async function refreshPlans() {
  if (!state.selected) return;
  const g = await fetch(`/api/plans/${encodeURIComponent(state.selected)}`).then((r) => r.json());
  const host = $("plan-graph");
  host.replaceChildren();
  if (!g.nodes.length) { host.className = "empty"; host.textContent = "No plans."; return; }
  host.className = "";

  if (g.orphans.length) {
    const box = el("article", "card");
    box.append(el("h3", null, "Goals with no plan"));
    const ul = el("ul", "rows");
    for (const o of g.orphans) {
      const li = el("li");
      li.append(el("span", "label", o.from), ` raises `, el("span", "unhandled", o.goal),
                ` — nothing handles ${o.indicator}`);
      ul.append(li);
    }
    box.append(ul);
    host.append(box);
  }

  const out = new Map();
  for (const e of g.edges) {
    if (!out.has(e.source)) out.set(e.source, []);
    out.get(e.source).push(e);
  }
  const box = el("article", "card");
  box.append(el("h3", null, "Plans"));
  const ul = el("ul", "rows");
  for (const n of g.nodes) {
    const li = el("li");
    const head = el("div", "opt" + (n.entry ? " is-selected" : ""));
    if (n.label) head.append(el("span", "label", n.label));
    head.append(el("span", null, n.trigger));
    if (n.context) head.append(el("span", "ctx", `: ${n.context}`));
    if (n.breakpoint) head.append(el("span", "badge", "breakpoint"));
    if (n.source) head.append(sourceTag(n.source));
    li.append(head);
    for (const e of out.get(n.id) || []) {
      li.append(el("div", "stack", `${e.goal} → ${e.target}`));
    }
    ul.append(li);
  }
  box.append(ul);
  host.append(box);
}

// --------------------------------------------------------------- messages

async function refreshMessages() {
  const g = await fetch("/api/messages").then((r) => r.json());
  const host = $("message-graph");
  if (!g.edges.length) {
    host.className = "empty";
    host.textContent = "No messages yet.";
    return;
  }
  host.className = "";
  host.replaceChildren();
  // same card as the plans pane, so the two graph panes are one family
  const box = el("article", "card");
  box.append(el("h3", null, "Who talks to whom"));
  host.append(box);
  const max = g.edges[0].count;
  for (const e of g.edges) {
    const row = el("div");
    const line = el("div", "edge");
    line.append(el("span", "from", e.source), el("span", null, "→"),
                el("span", "to", e.target),
                el("span", "perf", Object.keys(e.performatives).join(", ")),
                el("span", "count", String(e.count)));
    const bar = el("div", "edge-bar");
    bar.style.width = `${Math.max(2, (e.count / max) * 100)}%`;
    row.append(line, bar);
    box.append(row);
  }
}

// -------------------------------------------------------------- log & chat

// ag: a stable hue per agent name -- the same name is the same colour across
// runs and across reloads, which is what makes the gutter worth scanning. The
// hue is all that is decided here; how bright and how strong it may be is the
// stylesheet's business, once per theme (see --agent-sat / --agent-lum).
const agentHue = (name) => [...name].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 360, 7);

// which gutter label a console line gets, and in which role colour
function logLabel(e) {
  if (e.kind === "environment") return { text: "[env]", cls: "is-env" };
  if (e.kind === "log") {
    const level = (e.detail.level || "log").toLowerCase();
    const cls = level === "error" || level === "critical" ? "is-bad"
      : level === "warning" ? "is-warn" : "is-quiet";
    return { text: `[${level}]`, cls };
  }
  return { text: `[${e.agent}]`, cls: "is-agent", hue: agentHue(e.agent) };
}

// Lucide (MIT), matching the header's icon buttons.
const LOG_COPY_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="13" height="13" x="9" y="9" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
const LOG_COPIED_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>';

// ag: copies one line, not the whole (possibly huge) log -- a button that
// dumped everything was worse than the selectable text it replaced. Feedback
// is the icon itself flipping to a check for a beat, not a toast: firing one
// per click here would spam the corner if someone copies a few lines in a row.
async function copyLogLine(btn, text) {
  try {
    await navigator.clipboard.writeText(text);
    btn.innerHTML = LOG_COPIED_ICON;
    btn.classList.add("is-copied");
    setTimeout(() => { btn.innerHTML = LOG_COPY_ICON; btn.classList.remove("is-copied"); }, 1000);
  } catch (err) {
    toast("Couldn't copy the line", { tone: "bad" });
  }
}

function buildLogRow(e) {
  const { text, cls, hue } = logLabel(e);
  const li = el("li");
  const who = el("span", `log-who ${cls}`, text);
  if (hue !== undefined) who.style.setProperty("--agent-hue", hue);
  const line = e.detail.line || "";
  const copyBtn = el("button", "log-copy-btn");
  copyBtn.type = "button";
  copyBtn.title = "Copy this line";
  copyBtn.setAttribute("aria-label", "Copy this line");
  copyBtn.innerHTML = LOG_COPY_ICON;
  copyBtn.onclick = () => copyLogLine(copyBtn, `${text} ${line}`);
  li.append(who, el("span", "log-line", line), copyBtn);
  return li;
}

// event -> <li>, and the same events in the order they are on screen. Kept
// so renderLog() can patch instead of rebuild (see agentRows above for the
// same fix on the same bug): every print/environment/log line re-renders the
// whole card, and a full replaceChildren() there threw the hovered row out
// from under the pointer just like it did for the agent list -- except here
// it was the copy button, shown on :hover, that read as blinking on every
// timeline tick.
const logRows = new Map();
let logQueue = [];

function renderLog() {
  const host = $("log-list");
  const empty = state.log.length === 0;
  host.classList.toggle("empty", empty);
  if (empty) {
    logRows.clear();
    logQueue = [];
    host.replaceChildren("—");
    return;
  }
  if (logQueue.length === 0) host.replaceChildren();  // drop the "—" placeholder

  // LOG_MAX eviction: the oldest rendered rows fell off the front of state.log
  while (logQueue.length && logQueue[0] !== state.log[0]) {
    const old = logQueue.shift();
    logRows.get(old)?.remove();
    logRows.delete(old);
  }
  // only the events appended since the last render are actually new
  for (let i = logQueue.length; i < state.log.length; i++) {
    const e = state.log[i];
    const li = buildLogRow(e);
    logRows.set(e, li);
    host.append(li);
    logQueue.push(e);
  }
  host.scrollTop = host.scrollHeight;
}

function renderChatAgentOptions() {
  const select = $("chat-agent");
  const names = Object.keys(state.agents).sort();
  const previous = select.value;
  select.replaceChildren(...names.map((name) => {
    const info = state.chat.eligible[name];
    const opt = el("option", null, name);
    opt.value = name;
    if (info && !info.eligible) {
      // ag: the reason belongs on the tooltip, not in the option's text --
      // spelling "gen_limit is 'still' (chat needs at least 'talk')" inside a
      // dropdown entry is how the selector became unreadable the first time.
      opt.disabled = true;
      opt.title = info.reason;
    }
    return opt;
  }));
  if (names.includes(previous)) select.value = previous;
  renderChatDot();
}

function renderChatDot() {
  const info = state.chat.eligible[$("chat-agent").value];
  const eligible = !info || info.eligible;
  const dot = $("chat-dot");
  dot.className = "dot " + (eligible ? "eligible" : "blocked");
  dot.title = eligible ? "" : info.reason;
}

function renderChat() {
  const host = $("chat-list");
  const empty = !state.chat.messages.length && !state.chat.pending.size;
  host.classList.toggle("empty", empty);
  host.replaceChildren();
  if (empty) { host.textContent = "Ask an agent something."; return; }
  for (const m of state.chat.messages) {
    if (m.who === "you") {
      const you = el("li", "chat-msg is-user");
      you.append(el("div", "bubble", m.text));
      host.append(you);
      continue;
    }
    const said = el("li", "chat-msg " + (m.error ? "is-error" : "is-agent"));
    said.append(el("div", "who", m.agent), el("div", "bubble", m.text));
    host.append(said);
  }
  // whoever has been asked something and has not spoken yet -- showing the
  // answer as it is written when there is one, and the bare "…" before the
  // first words arrive or when this agent is not streaming at all
  for (const { agent } of state.chat.pending.values()) {
    const partial = state.chat.streaming.get(agent);
    const waiting = el("li", "chat-msg is-pending");
    waiting.append(el("div", "who", agent),
                   partial ? el("div", "bubble is-writing", partial)
                           : el("div", "bubble is-waiting", "…"));
    host.append(waiting);
  }
  host.scrollTop = host.scrollHeight;
}

// --------------------------------------------------------------- timeline

function renderTimeline() {
  const host = $("timeline-list");
  host.replaceChildren();
  const events = state.timeline.filter(
    (e) => !state.onlySelected || e.agent === state.selected);
  let previous;
  for (const e of events.slice(-TIMELINE_MAX).reverse()) {
    const failed = (e.kind === "llm_call" && e.detail.error && e.detail.error !== "None")
      || e.kind === "goal_failed";
    const clickable = e.kind === "llm_call" || e.kind === "deliberate";
    const key = `${e.agent}#${e.cycle}`;
    const fresh = key !== previous;
    previous = key;
    // with the filter on there is only one clock, so the name would be the
    // same word on every row -- drop it and let the number carry the gutter
    const agent = fresh && !state.onlySelected ? e.agent : null;
    const li = railRow(agent, fresh ? e.cycle : null, `kind-${e.kind}`
      + (failed ? " is-failed" : "") + (clickable ? " is-clickable" : ""));
    const body = railBody(li);
    body.append(el("span", "k", e.kind), " ");
    body.append(summarise(e));
    if (e.kind === "llm_call") li.onclick = () => { showPane("llm"); showCall(e.seq); };
    else if (clickable) li.onclick = () => showBeliefsDiff(e.agent, e.cycle);
    host.append(li);
  }
}

function summarise(e) {
  const d = e.detail;
  // the reasoning cycle, mirrored from the agent's own journal
  if (e.kind === "deliberate") return deliberation(d);
  if (e.kind === "sense" || e.kind === "act" || e.kind === "cycle") return d.summary;
  if (e.kind === "bb_delta") return beliefDelta(d);
  if (e.kind === "bb_checkpoint") return `${d.beliefs} beliefs`;
  if (e.kind === "goal_failed") return `${d.goal} — ${d.reason}`;
  if (e.kind === "msg_out") return `→${d.receiver} ${d.performative} ${d.content || ""}`;
  if (e.kind === "msg_in") return `←${d.sender} ${d.performative} ${d.content || ""}`;
  if (e.kind === "llm_choice") return `${d.purpose}: ${d.choice}`;
  if (e.kind === "llm_generate") return `${d.level} ${d.concluded || d.error || ""}`;
  if (e.kind === "say") return d.text;
  // MAS-level and transcript rows, which do not come from a journal
  if (e.kind === "llm_call") return `${d.purpose} ${d.duration_ms}ms`;
  if (e.kind === "print") return d.line;
  if (e.kind === "log") return `${d.level} ${d.line}`;
  if (e.kind === "breakpoint") return `${d.agent} hit ${d.what}`;
  return d.trigger || d.goal || d.top || d.plan || d.line || "";
}

function beliefDelta(d) {
  const added = JSON.parse(d.added || "[]").map((b) => `+${b}`);
  const deleted = JSON.parse(d.deleted || "[]").map((b) => `-${b}`);
  return added.concat(deleted).join(" ");
}

// A deliberation is the one row worth spelling out. Plans whose context was
// evaluated and failed are NOT the same as plans the shortcut never reached,
// and a UI that merged them into "3 candidates" would show a deliberation
// that did not happen -- weighing three options rather than taking the first
// that applied.
function deliberation(d) {
  if (d.outcome !== "selected") {
    return `${d.trigger} — no ${(d.outcome || "").replace("no_", "")} plan`;
  }
  const bits = [`${d.trigger} → ${d.plan_label || d.source || "unlabelled"}`];
  if (d.bindings && d.bindings !== "{}") bits.push(d.bindings);
  const failed = Number(d.context_failed || 0);
  const unexamined = Number(d.unexamined || 0);
  const notes = [];
  if (failed) notes.push(`${failed} context failed`);
  if (unexamined) notes.push(`${unexamined} not examined`);
  if (notes.length) bits.push(`(${notes.join(", ")})`);
  return bits.join(" ");
}

// ------------------------------------------------------------------- wiring

function showPane(name) {
  for (const tab of document.querySelectorAll(".tab")) {
    tab.classList.toggle("is-active", tab.dataset.pane === name);
  }
  for (const pane of document.querySelectorAll(".pane")) {
    pane.classList.toggle("is-active", pane.id === `pane-${name}`);
  }
  if (name === "messages") refreshMessages();
  if (name === "plans") refreshPlans();
}

for (const tab of document.querySelectorAll(".tab")) {
  tab.onclick = () => showPane(tab.dataset.pane);
}
$("only-selected").onchange = (e) => { state.onlySelected = e.target.checked; renderTimeline(); };
$("timeline-clear").onclick = () => {
  state.timeline = [];
  $("gap-warning").hidden = true;
  renderTimeline();
};
$("belief-filter").oninput = (e) => { state.beliefFilter = e.target.value; refreshBeliefs(); };

// clicking the backdrop (not the box itself) or Esc closes the modal
$("modal-overlay").onclick = (e) => { if (e.target === e.currentTarget) closeModal(); };
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !$("modal-overlay").hidden) closeModal();
});

$("open-form").onsubmit = (e) => {
  e.preventDefault();
  const path = $("open-path").value.trim();
  if (path) bootMas(path);
};

$("open-error-copy").onclick = async () => {
  try {
    await navigator.clipboard.writeText($("open-error").dataset.raw || "");
    toast("Copied to clipboard", { tone: "" });
  } catch (err) {
    toast("Couldn't copy", { tone: "bad" });
  }
};

$("btn-browse").onclick = async () => {
  // pywebview's own file dialog, run in the window process -- a browser
  // <input type="file"> would hand back a blob, and the server needs a path
  const picked = await window.pywebview.api.pick_mas2i();
  if (picked) { $("open-path").value = picked; bootMas(picked); }
};

$("btn-theme").onclick = () =>
  setTheme(document.documentElement.dataset.theme === "light" ? "dark" : "light");

// until the user picks a side, keep following the system
matchMedia("(prefers-color-scheme: light)").addEventListener("change", (e) => {
  let chosen = null;
  try { chosen = localStorage.getItem("icaros-theme"); } catch (err) { /* ignore */ }
  if (chosen) return;
  document.documentElement.dataset.theme = e.matches ? "light" : "dark";
  renderTheme();
});

$("btn-hub").onclick = () =>
  fetch("/api/shutdown", { method: "POST" })
    .then((r) => r.json())
    .then(applyStatus);

$("btn-cancel").onclick = () =>
  fetch("/api/shutdown", { method: "POST" })
    .then((r) => r.json())
    .then(applyStatus);

$("btn-pause").onclick = () => {
  const action = state.debug && state.debug.paused ? "resume" : "pause";
  debugCall("POST", `/api/debug/${encodeURIComponent(state.selected)}/${action}`);
};
$("btn-step").onclick = () =>
  debugCall("POST", `/api/debug/${encodeURIComponent(state.selected)}/step?count=1`);

$("log-clear").onclick = () => {
  state.log = [];
  renderLog();
};

$("chat-agent").onchange = renderChatDot;

$("chat-form").onsubmit = async (e) => {
  e.preventDefault();
  const agent = $("chat-agent").value;
  const message = $("chat-message").value.trim();
  if (!agent || !message) return;
  const res = await fetch(
    `/api/debug/${encodeURIComponent(agent)}/chat?message=${encodeURIComponent(message)}`,
    { method: "POST" });
  const body = await res.json();
  if (!res.ok) { toast(body.detail, { title: `Cannot chat with ${agent}` }); return; }
  state.chat.messages.push({ who: "you", agent, text: message });
  if (state.chat.messages.length > CHAT_MAX) state.chat.messages.shift();
  state.chat.pending.set(body.chat, { agent });
  $("chat-message").value = "";
  renderChat();
};

// the mind pane is a pull, not a push: it asks the agent for a deep read.
// forSelected() keeps each of these to one request at a time, so a tick that
// lands while the previous one is still out is dropped rather than queued.
setInterval(() => {
  if (state.bootState !== "ready" || !state.selected) return;
  if (activePane() !== "mind") return;
  refreshDetail();
  refreshDebug();
  refreshReasoning();
  refreshBeliefs();
}, 1000);

boot();

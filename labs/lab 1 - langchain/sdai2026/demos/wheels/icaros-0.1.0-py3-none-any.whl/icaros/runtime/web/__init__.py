"""The developer UI: an HTTP+websocket server inside the MAS process, and a
window in its own process pointed at it.

Split that way for one measured reason -- importing a webview backend
re-enables the GIL (see window.py), which would undo the free-threaded
parallelism the whole project is built on. The server stays in-process
because the debugger's command channel has to reach live agent objects.

Requires the `devui` extra; everything under runtime/telemetry/ works without
it, and that is where the data lives.
"""

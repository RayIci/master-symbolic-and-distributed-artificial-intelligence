from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import TracebackType

    from icaros.architecture.ag_arch import AgArch
    from icaros.environment.environment import Environment
    from icaros.runtime.runner import Runner


class MasSession:
    """Owns a booted MAS's start/stop lifecycle, so every frontend shares one
    teardown sequence instead of keeping its own copy of it.

    ag: the sequence used to be duplicated almost verbatim in cli.run_headless
    and in the old Textual TUI, which is how they drifted -- the order matters
    (environment before scheduler, signal-all before join-all) and a third
    copy for the dev UI would have been one copy too many. A frontend now
    wraps whatever blocks its main thread in `with MasSession(agents):`.
    """

    def __init__(self, agents: list[AgArch]) -> None:
        self._agents = agents
        self._started = False
        self._torn_down = False

    @property
    def agents(self) -> list[AgArch]:
        return self._agents

    @property
    def environment(self) -> Environment | None:
        """The one environment this MAS shares, if it declared one."""
        return next((a.environment for a in self._agents if a.environment is not None), None)

    @property
    def runner(self) -> Runner | None:
        return self._agents[0].runner if self._agents else None

    def start(self) -> None:
        for ag in self._agents:
            ag.start_thread()
        self._started = True

    def any_running(self) -> bool:
        # is_running() (not .thread.is_alive()) -- a pooled agent's .thread
        # (see ag_arch.py's scheduler mode) is created but never started, so
        # is_alive() would be False immediately and this would think every
        # agent had already finished.
        return any(a.is_running() for a in self._agents)

    def shutdown(self) -> None:
        """Stops everything, in the one order that works. Idempotent: an
        Environment subclass's stop() hook is user code with no reentrancy
        promise, so it must not be run twice."""
        if self._torn_down:
            return
        self._torn_down = True
        # two phases: signal every agent, then join -- one wake round trip in
        # total instead of one per agent (10,000 in examples/game-of-life)
        for a in self._agents:
            a.signal_stop()
        for a in self._agents:
            a.join_stopped()
        environment = self.environment
        if environment is not None:
            environment.shutdown()
        # last: a pooled agent's final slice may still be draining on a worker
        runner = self.runner
        if runner is not None and runner.scheduler is not None:
            runner.scheduler.shutdown()

    def __enter__(self) -> MasSession:
        self.start()
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None,
                 tb: TracebackType | None) -> bool:
        self.shutdown()
        # a Ctrl-C out of the frontend is how a MAS normally ends, not a crash
        return exc_type is KeyboardInterrupt

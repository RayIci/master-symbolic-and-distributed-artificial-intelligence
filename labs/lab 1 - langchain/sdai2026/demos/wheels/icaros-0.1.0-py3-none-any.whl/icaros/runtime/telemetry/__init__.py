"""Toolkit-agnostic runtime telemetry: what a UI needs to show about a
running MAS, with no UI in it.

Two shapes of datum, deliberately kept apart:

- **History pushes.** Events, intentions, goals, plan-library changes,
  messages, console lines -- they arrive at the interpreter's existing
  listener interfaces and are naturally a stream. They go into one bounded
  `EventRing` per MAS, which readers drain by sequence number.
- **State pulls.** The belief base, the intention stack, the plan-selection
  outcome of the last cycle. These are what a debugger asks about the *one*
  agent someone is looking at, so they are collected on request rather than
  on every cycle -- see `AgentCollector`.

Everything here is plain dataclasses and threading primitives: it imports and
tests without a server, a browser or the `devui` extra.
"""

from icaros.runtime.telemetry.collector import AgentCollector, MasCollector
from icaros.runtime.telemetry.model import (
    AgentCounters,
    AgentState,
    Annotation,
    BeliefView,
    ChainLink,
    CycleTrace,
    DeliberationView,
    IntendedMeansView,
    IntentionView,
    OptionView,
    ReasoningStream,
    TraceEvent,
    WireError,
    to_json,
)
from icaros.runtime.telemetry.reasoning import cycle_trace, reasoning_stream
from icaros.runtime.telemetry.ring import Drain, EventRing

__all__ = [
    "AgentCollector", "AgentCounters", "AgentState", "Annotation", "BeliefView",
    "ChainLink", "CycleTrace", "DeliberationView", "Drain", "EventRing",
    "IntendedMeansView", "IntentionView", "MasCollector", "OptionView",
    "ReasoningStream", "TraceEvent", "WireError", "cycle_trace", "reasoning_stream",
    "to_json",
]

from __future__ import annotations

from pathlib import Path
from threading import Thread
from typing import TYPE_CHECKING

from icaros.architecture.ag_arch import AgArch
from icaros.as_semantics.agent import Agent
from icaros.as_semantics.event import Event
from icaros.as_semantics.icaros import Icaros
from icaros.as_semantics.transition_system import TransitionSystem
from icaros.llm import MAX_ROUNDS, IcarosState
from icaros.pl.plan_library import PlanLibrary

if TYPE_CHECKING:
    from icaros.as_syntax.factory import AgentSource

_KQML_PLANS_PATH = Path(__file__).resolve().parent.parent / "pl" / "kqml_plans.asl"
_kqml_plans_parsed = None  # lazily parsed once, reused by every booted agent -- see _get_kqml_plans_parsed()

_JOURNAL_PLANS_PATH = Path(__file__).resolve().parent.parent / "pl" / "journal_plans.asl"
_journal_plans_parsed = None  # same, for the journal tool wrappers

_RAG_PLANS_PATH = Path(__file__).resolve().parent.parent / "pl" / "rag_plans.asl"
_rag_plans_parsed = None  # same, for the rag tool wrapper


def _get_kqml_plans_parsed():
    # ag: boot_agent() loads the exact same kqml_plans.asl text into every
    # agent it boots -- fine at the agent counts every example used before
    # examples/game-of-life (thousands of agents), where re-parsing this
    # ~dozens-of-plans file from scratch per agent was ~75% of total boot
    # time. Parsed once, on first use; Agent.load_parsed_asl then clones
    # each Plan/belief per agent rather than sharing the parsed objects
    # (see its docstring) -- still far cheaper than re-parsing, since a
    # clone is a structural copy with no lexing/parsing involved.
    global _kqml_plans_parsed
    if _kqml_plans_parsed is None:
        from icaros.as_syntax.factory import parse_agent
        _kqml_plans_parsed = parse_agent(_KQML_PLANS_PATH.read_text(),
                                         base_dir=_KQML_PLANS_PATH.parent,
                                         source_name=str(_KQML_PLANS_PATH))
    return _kqml_plans_parsed


def _get_journal_plans_parsed():
    # ag: same parse-once-clone-per-agent deal as the KQML plans above, and
    # loaded into every agent for the same reason: whether a model will ever
    # ask for one is not known at boot, and five plans are cheaper than a
    # second boot path that has to know about llm_tools.
    global _journal_plans_parsed
    if _journal_plans_parsed is None:
        from icaros.as_syntax.factory import parse_agent
        _journal_plans_parsed = parse_agent(_JOURNAL_PLANS_PATH.read_text(),
                                            base_dir=_JOURNAL_PLANS_PATH.parent,
                                            source_name=str(_JOURNAL_PLANS_PATH))
    return _journal_plans_parsed


def _get_rag_plans_parsed():
    # ag: same parse-once-clone-per-agent deal as the KQML/journal plans
    # above, and loaded into every agent for the same reason: whether a model
    # will ever ask for one is not known at boot.
    global _rag_plans_parsed
    if _rag_plans_parsed is None:
        from icaros.as_syntax.factory import parse_agent
        _rag_plans_parsed = parse_agent(_RAG_PLANS_PATH.read_text(),
                                        base_dir=_RAG_PLANS_PATH.parent,
                                        source_name=str(_RAG_PLANS_PATH))
    return _rag_plans_parsed


# ag: Python analog of Java's Agent.create() -- builds the Agent/AgArch/
# TransitionSystem triple, loads the .asl file into belief base + plan
# library, and seeds the circumstance with the initial-goal events (Java's
# Agent.addInitialGoalsInTS). Wires a thread but does not start it: whether
# to run it (and how) is the caller's decision.
def boot_agent(asl_path: str | Path, ag_arch: AgArch | None = None,
               agent: Agent | None = None, agentic: Icaros | None = None,
               name: str | None = None,
               parsed: AgentSource | None = None,
               gen_limit: str | IcarosState = IcarosState.STILL,
               gen_path: Path | None = None,
               gen_max_rounds: int = MAX_ROUNDS) -> AgArch:
    ag_arch = ag_arch if ag_arch is not None else AgArch()
    path = Path(asl_path)
    ag_arch.ag_name = name or path.stem

    agent = agent if agent is not None else Agent()
    # wires agent.ts / ag_arch.ts
    TransitionSystem(agent, agentic, ag_arch, gen_limit=gen_limit, gen_path=gen_path,
                     gen_max_rounds=gen_max_rounds)

    # `parsed`, when given, is a source already parsed once by a caller
    # booting many instances from the same .asl (mas2i/loader.py's
    # `instances: N`) -- load_parsed_asl clones it per agent, same as the
    # KQML plans below, so this is only ever a boot-time optimization, never
    # a sharing hazard.
    if parsed is not None:
        initial_goals = agent.load_parsed_asl(parsed)
    else:
        initial_goals = agent.load_asl(path.read_text(), base_dir=path.parent, source_name=str(path))
    for trigger in initial_goals:
        ag_arch.ts.circumstance.add_event(Event(trigger, None))

    # loaded last, like Java's Agent.loadInitialAS (loadAS then
    # loadKqmlPlans): plan selection tries options in insertion order, so a
    # user-defined +kqml_received plan added above is found before this one.
    agent.load_parsed_asl(_get_kqml_plans_parsed(), origin=PlanLibrary.KQML_PLANS_FILE)
    # the wrappers a model's journal tool calls land on: an LLM tool call is an
    # event, so it needs a plan to be relevant to (see pl/journal_plans.asl)
    agent.load_parsed_asl(_get_journal_plans_parsed(), origin=PlanLibrary.JOURNAL_PLANS_FILE)
    # same deal for the rag tool (see pl/rag_plans.asl)
    agent.load_parsed_asl(_get_rag_plans_parsed(), origin=PlanLibrary.RAG_PLANS_FILE)

    # daemon: a caller that forgets to stop_ag()/stopMAS a spawned agent (or
    # a test that only joins with a timeout) must not hang process exit
    # waiting to join a thread nobody told to stop -- a graceful stop_ag()
    # is still the normal way to end an agent; this is only the fallback
    # for when the whole process is going down anyway.
    ag_arch.thread = Thread(target=ag_arch.run, daemon=True)
    return ag_arch

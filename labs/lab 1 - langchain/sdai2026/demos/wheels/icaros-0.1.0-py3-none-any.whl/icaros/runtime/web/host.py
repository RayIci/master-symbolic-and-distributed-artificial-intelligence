from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from icaros.mas2i.loader import load_mas
from icaros.mas2i.progress import BootStep
from icaros.runtime.debug_control import DebugController
from icaros.runtime.session import MasSession
from icaros.runtime.telemetry.collector import MasCollector

logger = logging.getLogger(__name__)

MAX_RECENTS = 12


def recents_path() -> Path:
    """Where the hub remembers what you last ran. XDG on Linux/macOS,
    %APPDATA% on Windows -- no new dependency for one small file."""
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "icaros" / "recents.json"


def load_recents() -> list[dict]:
    """Most recent first. Entries whose file has since been moved or deleted
    are dropped on read rather than shown as dead links."""
    path = recents_path()
    try:
        entries = json.loads(path.read_text())
    except (OSError, ValueError):
        return []
    if not isinstance(entries, list):
        return []
    alive = []
    for entry in entries:
        if not isinstance(entry, dict) or "path" not in entry:
            continue
        if Path(entry["path"]).is_file():
            alive.append(entry)
    return alive[:MAX_RECENTS]


def remember(path: Path) -> None:
    resolved = str(Path(path).resolve())
    entries = [e for e in load_recents() if e.get("path") != resolved]
    entries.insert(0, {"path": resolved, "name": Path(resolved).stem, "at": time.time()})
    target = recents_path()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(entries[:MAX_RECENTS], indent=1))
    except OSError as e:  # a read-only home must not stop a MAS from running
        logger.warning("could not save recent MAS list to %s: %s", target, e)


@dataclass
class BootState:
    """What the hub and the loading screen render from."""

    state: str = "idle"  # idle | loading | ready | failed
    path: str | None = None
    mas_name: str | None = None
    step: BootStep | None = None
    error: str | None = None
    agents: list[str] = field(default_factory=list)
    # ag: which MAS this is, counted rather than named. Two boots of the same
    # .mas2i are two different runs with two different rings whose sequence
    # numbers both start at 0, so `path` cannot tell them apart -- and a
    # browser that cannot tell them apart shows the dead one's timeline under
    # the live one's name. Strictly increasing across EVERY transition, going
    # idle included (see MasHost.close), so "lower than what I have" is a
    # sound test for a frame that arrived late. 0 is a host that never booted.
    run: int = 0

    def as_json(self) -> dict:
        step = self.step
        return {
            "run": self.run,
            "state": self.state,
            "path": self.path,
            "mas_name": self.mas_name,
            "error": self.error,
            "agents": self.agents,
            "progress": None if step is None else {
                "done": step.done, "total": step.total, "phase": step.phase,
                "detail": step.detail, "fraction": step.fraction},
        }


class MasHost:
    """Owns whichever MAS is currently loaded, so the UI can outlive it.

    ag: everything used to be built around an agent list that existed before
    the server did. With a hub, the window opens first and the MAS arrives
    later (or never), so the collector, session and debug controller have to
    be created per-boot and thrown away on shutdown. Keeping that in one
    object is also what makes "stop this MAS and open another one" a method
    rather than a restart.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._boot = BootState()
        self._collector: MasCollector | None = None
        self._session: MasSession | None = None
        self._controller: DebugController | None = None
        self._llm_sink = None
        self._runs = 0

    # ---- what the API reads -------------------------------------------

    @property
    def collector(self) -> MasCollector | None:
        return self._collector

    @property
    def controller(self) -> DebugController | None:
        return self._controller

    @property
    def state(self) -> BootState:
        with self._lock:
            return self._boot

    def snapshot(self) -> tuple[BootState, MasCollector | None]:
        """The boot state and the collector it belongs to, read together.

        ag: the websocket needs both in one frame, and reading them through
        the two properties above is two separate acquisitions -- a boot
        landing between them ships MAS A's status with MAS B's events, which
        is precisely the confusion `run` exists to end.
        """
        with self._lock:
            return self._boot, self._collector

    def set_llm_sink(self, sink) -> None:
        """A trace writer to re-attach to every MAS this host boots."""
        self._llm_sink = sink

    # ---- booting -------------------------------------------------------

    def adopt(self, collector: MasCollector, session: MasSession | None = None,
              controller: DebugController | None = None,
              mas_name: str | None = None) -> MasHost:
        """Takes over a MAS somebody else already built and started.

        The counterpart to boot_async for the case where the agents exist
        before the host does -- an embedder wiring the UI onto a MAS it
        assembled itself, and every test in tests/runtime/web. Returns self
        so it reads as a constructor.
        """
        with self._lock:
            self._runs += 1
            self._collector = collector
            self._session = session
            self._controller = controller
            self._boot = BootState(state="ready", mas_name=mas_name,
                                   agents=sorted(collector.agents), run=self._runs)
        return self

    def boot_async(self, path: str | Path) -> None:
        """Starts a MAS on a worker thread. Returns immediately: loading takes
        seconds (a single Agentic warm-up measured 15 s), and the caller is an
        HTTP handler on the event loop that must not block for that."""
        with self._lock:
            if self._boot.state == "loading":
                raise RuntimeError("a MAS is already loading")
            # the run is stamped here, not when the boot succeeds: the loading
            # screen is already part of the new run, and a browser watching it
            # must clear the old MAS then rather than seconds later
            self._runs += 1
            self._boot = BootState(state="loading", path=str(path),
                                   mas_name=Path(path).stem, run=self._runs)
        threading.Thread(target=self._boot_now, args=(Path(path),),
                         name="icaros-boot", daemon=True).start()

    def _on_step(self, step: BootStep) -> None:
        with self._lock:
            self._boot.step = step

    def _boot_now(self, path: Path) -> None:
        try:
            self.shutdown()  # a previous MAS, if any, goes first
            runner = load_mas(path, progress=self._on_step)
            agents = list(runner.ags.values())
            collector = MasCollector(agents)
            session = MasSession(agents)
            controller = DebugController()
            controller.set_on_hit(lambda hit: collector.log(
                "breakpoint", agent=hit.agent, cycle=hit.cycle, reason=hit.reason,
                what=hit.what, source=hit.source))
            for ag in agents:
                ag.exec_control = controller
            collector.attach(session, capture_console=True)
            if self._llm_sink is not None:
                collector.add_llm_sink(self._llm_sink)
            session.start()
        except Exception as e:
            logger.exception("could not start %s", path)
            with self._lock:
                self._boot.state = "failed"
                self._boot.error = f"{type(e).__name__}: {e}"
            return
        with self._lock:
            self._collector = collector
            self._session = session
            self._controller = controller
            self._boot.state = "ready"
            self._boot.agents = [a.ag_name for a in agents]
            self._boot.mas_name = path.stem
        remember(path)

    def shutdown(self) -> None:
        with self._lock:
            session, collector = self._session, self._collector
            self._session = self._collector = self._controller = None
        if session is not None:
            session.shutdown()
        if collector is not None:
            collector.detach()

    def close(self) -> None:
        """Teardown for process exit: stop the MAS and mark the host idle."""
        self.shutdown()
        with self._lock:
            # ag: going idle bumps the run too, so `run` only ever increases.
            # That is what lets a client say "anything numbered below what I
            # have is stale" and drop the websocket frame that was already in
            # flight when the MAS was stopped -- the one that used to bounce
            # the hub straight back into the dead MAS's screen.
            self._runs += 1
            self._boot = BootState(run=self._runs)

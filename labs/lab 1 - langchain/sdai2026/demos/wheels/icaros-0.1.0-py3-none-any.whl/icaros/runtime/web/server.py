from __future__ import annotations

import logging
import threading
import time
logger = logging.getLogger(__name__)

STARTUP_TIMEOUT = 10.0
SHUTDOWN_TIMEOUT = 2.0


class UiServer:
    """The dev UI's HTTP+websocket server, on a daemon thread inside the MAS
    process.

    ag: in-process, not a subprocess, because the debugger's command channel
    has to reach live agent objects -- injecting a goal is one call on a
    Circumstance, versus an RPC protocol plus a term serialiser across a pipe.
    The precedent is examples/iterated-prisoners-dilemma/my/plot.py, which
    already runs a web server on a daemon thread in the MAS process. What
    does NOT go in-process is the window: see window.py.

    Binds 127.0.0.1 only. This server can mutate a running MAS, so it has no
    business listening on anything routable.
    """

    def __init__(self, mas_host, mas_name: str = "mas",
                 port: int = 0, host: str = "127.0.0.1") -> None:
        self._mas_host = mas_host
        self._mas_name = mas_name
        self._requested_port = port
        self._host = host
        self._server = None
        self._thread: threading.Thread | None = None
        self._port: int | None = None

    @property
    def port(self) -> int | None:
        """The port actually bound -- with the default port=0 the OS picks
        one, because two MAS processes on one machine is normal."""
        return self._port

    @property
    def url(self) -> str:
        return f"http://{self._host}:{self._port}"

    def start(self) -> str:
        import uvicorn

        from icaros.runtime.web.api import build_app

        config = uvicorn.Config(
            build_app(self._mas_host, self._mas_name),
            host=self._host, port=self._requested_port,
            log_level="warning",  # the MAS's own output is the point, not access logs
            lifespan="off",
        )
        self._server = uvicorn.Server(config)
        self._thread = threading.Thread(target=self._serve, name="icaros-ui", daemon=True)
        self._thread.start()

        deadline = time.monotonic() + STARTUP_TIMEOUT
        while time.monotonic() < deadline:
            if self._server.started:
                break
            if not self._thread.is_alive():
                raise RuntimeError("the dev UI server thread died during startup")
            time.sleep(0.01)
        else:
            raise RuntimeError(f"the dev UI server did not start within {STARTUP_TIMEOUT}s")

        self._port = self._server.servers[0].sockets[0].getsockname()[1]
        return self.url

    def _serve(self) -> None:
        try:
            self._server.run()
        except BaseException:
            # a UI bug must not take the MAS down with it -- that is the price
            # of running in-process, and this is how it is paid
            logger.exception("the dev UI server stopped unexpectedly; the MAS keeps running")

    def stop(self) -> None:
        """Asks uvicorn to wind down from another thread. Never loop.stop():
        that is not thread-safe and leaves sockets open."""
        if self._server is not None:
            self._server.should_exit = True
        if self._thread is not None:
            self._thread.join(SHUTDOWN_TIMEOUT)

    def __enter__(self) -> UiServer:
        self.start()
        return self

    def __exit__(self, *exc_info) -> None:
        self.stop()

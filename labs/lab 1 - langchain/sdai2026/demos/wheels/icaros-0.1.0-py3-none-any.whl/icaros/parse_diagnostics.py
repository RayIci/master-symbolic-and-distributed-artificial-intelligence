from __future__ import annotations

from lark import Lark
from lark.exceptions import UnexpectedCharacters, UnexpectedInput

def _literal_names(parser: Lark) -> dict[str, str]:
    """terminal name -> its fixed spelling, for every string-literal terminal
    (keywords, punctuation) -- derived from the grammar itself so it can
    never drift out of sync with it. Regex terminals (NAME, NUMBER, VAR...)
    aren't literals; format_syntax_error() falls back to `overrides` or the
    bare terminal name for those."""
    return {t.name: t.pattern.value for t in parser.terminals if t.pattern.type == "str"}


def _found(e: UnexpectedInput) -> str:
    """The actual text the parser choked on -- always something literally
    present in the user's file, never a terminal name."""
    if isinstance(e, UnexpectedCharacters):
        return e.char
    # $END is how LALR spells end-of-input; <EOF> is UnexpectedEOF's stand-in
    return "end of input" if e.token.type in ("$END", "<EOF>") else str(e.token)


def _expected_names(e: UnexpectedInput) -> set[str]:
    """The terminals the parser would have accepted instead. Each exception
    type spells this differently: UnexpectedToken has `accepts`,
    UnexpectedCharacters has `allowed`, and UnexpectedEOF has `expected`
    holding terminal objects rather than plain names."""
    for attr in ("accepts", "allowed", "expected"):
        names = getattr(e, attr, None)
        if names:
            return {getattr(n, "name", None) or getattr(n, "type", None) or str(n) for n in names}
    return set()


def _position(e: UnexpectedInput, text: str) -> tuple[int, int]:
    if getattr(e, "line", None) and e.line > 0:
        return e.line, e.column
    # UnexpectedEOF carries no position at all (lark hardcodes -1), so point
    # at the very end of the input -- which is exactly where it ran out
    lines = text.split("\n")
    return len(lines), len(lines[-1]) + 1


def _context(e: UnexpectedInput, text: str, line: int, column: int) -> str:
    """The offending source line with a '^' under the exact column."""
    pos = getattr(e, "pos_in_stream", None)
    if pos is not None and pos >= 0:
        return e.get_context(text).rstrip("\n")
    src_line = text.split("\n")[line - 1]
    return src_line + "\n" + " " * (column - 1) + "^"


def _readability(entry: str) -> tuple[int, str]:
    """Sort key for the "expected one of ..." list: plain-language entries
    ("an atom") first, then keywords ("'if'"), then punctuation ("'<-'").
    Plain alphabetical order would lead with the punctuation -- the least
    self-explanatory end of the list -- since "'" sorts before any letter."""
    word = entry[1:] if entry.startswith("'") else entry
    return (0 if not entry.startswith("'") else 1 if word[:1].isalpha() else 2, entry)


def describe_syntax_error(e: UnexpectedInput, parser: Lark, *,
                          overrides: dict[str, str] | None = None) -> str:
    """The "expected X but found Y" half of the message on its own, with no
    position and no source context -- for callers that embed it in a message
    of their own (see mas2i's belief lines)."""
    names = _literal_names(parser)
    overrides = overrides or {}

    def friendly(name: str) -> str:
        if name in ("$END", "<EOF>"):
            return "end of input"
        if name in names:
            return f"'{names[name]}'"
        return overrides.get(name, name)

    expected = sorted((friendly(n) for n in _expected_names(e)), key=_readability)
    found = _found(e)
    found_display = found if found == "end of input" else f"'{found}'"

    if not expected:
        return f"unexpected {found_display}"
    if len(expected) == 1:
        return f"expected {expected[0]} but found {found_display}"
    return f"expected one of {', '.join(expected)} -- but found {found_display}"


def format_syntax_error(e: UnexpectedInput, text: str, parser: Lark, *,
                        source: str | None = None,
                        overrides: dict[str, str] | None = None) -> str:
    """Turns a raw Lark UnexpectedInput into a message aimed at the person
    who wrote the source file, not at icaros's own maintainers: where
    (file:line:col if `source` is known, else "line L, column C"), what was
    expected there in plain terms, what was actually found, and the source
    line itself with a '^' caret under the exact column -- instead of Lark's
    own terminal-name-heavy default `str(e)`."""
    line, column = _position(e, text)
    where = f"{source}:{line}:{column}" if source else f"line {line}, column {column}"
    return "\n".join([f"{where}: {describe_syntax_error(e, parser, overrides=overrides)}",
                      _context(e, text, line, column)])
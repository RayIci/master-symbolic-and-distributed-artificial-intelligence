from __future__ import annotations

import itertools
import logging
import re
from collections import deque
from collections.abc import Iterator
from typing import TYPE_CHECKING

from enum import Enum

from icaros.as_syntax.string_term import StringTerm
from icaros.as_syntax.trigger import TEOperator, TEType, Trigger

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from icaros.architecture.ag_arch import AgArch
    from icaros.as_semantics.option import Option
    from icaros.as_semantics.icaros import Icaros

from icaros.as_semantics.action_exec import ActionExec
from icaros.as_semantics.agent import Agent
from icaros.as_semantics.circumstance import Circumstance
from icaros.as_semantics.circumstance_listener import CircumstanceListener
from icaros.journal import (DeliberationRecord, JournalKind, annots_text, kind_of,
                            record_for, trigger_text)
from icaros.as_semantics.event import Event
from icaros.as_semantics.goal_listener import GoalListener, GoalStates
from icaros.as_semantics.intended_means import IntendedMeans
from icaros.as_semantics.intention import Intention
from icaros.llm import (MAX_ROUNDS, IcarosState, LlmToolResult, call_id_of, session_of, tool_name_of)
from icaros.as_semantics.message import Message
from icaros.as_semantics.unifier import Unifier
from icaros.as_semantics.option import Option
from icaros.as_syntax.factory import parse_plan, parse_term, create_atom, create_structure
from icaros.as_syntax.binary_structure import BinaryStructure
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.term import Term
from icaros.as_syntax.structure import Structure
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.plan import Plan
from icaros.as_syntax.plan_body import BodyType, PlanBody
from icaros.as_syntax.var_term import VarTerm
from icaros.as_syntax.literal_impl import LiteralImpl
from icaros.as_syntax.object_term import ObjectTerm
from icaros.as_syntax.parser.errors import ASParseError
from icaros.bb.belief_base import BeliefBase
from icaros.pl.plan_library import PlanLibrary
from icaros.stdlib.internal_actions import add_nested_source


# This is used cause typically when something fails it is annotated with reason and a message
# So that you can think to catch all the different errors in -! plans
def error_annots(error_id: str, msg: str) -> ListTerm:
    return ListTerm([create_structure("error", Atom(error_id)),
                     create_structure("error_msg", StringTerm(msg))])


def _explained(fail_annots: ListTerm | None, reason: Term | None) -> Term | None:
    """`reason`, or the error_msg next to it when there is one.

    ag: for an agent the reason atom is enough -- a -!g plan matches on
    `ia_failed`, not on prose. For a model it is not: "ia_failed" says an
    action went wrong and nothing about what to do differently, while the
    error_msg the same failure already carries ("expected 3 arguments, got 2")
    is the whole answer. Only the LLM deposit path uses this; the annotations
    on the failure event are untouched, so nothing an .asl can match on
    changes.
    """
    if fail_annots is None:
        return reason
    for annot in fail_annots:
        if getattr(annot, "functor", None) == "error_msg":
            message = str(annot.get_term(0)).strip('"')
            if message:
                return StringTerm(f"{reason}: {message}" if reason is not None else message)
    return reason


def _answer_name(var: Term) -> str:
    """The name an output variable is shown to the model under.

    ag: `Entries`, not `_20_12Entries`. Every renaming on the way -- goal_step
    making the step's variables its own, Rule Achieve making the event's --
    prefixes `_<n>` and keeps the rest (UnnamedVar.create), so peeling the
    prefixes off gives back the name the tool declared. A name that is
    nothing but prefixes stays as it is: better an odd name than none.
    """
    name = str(var)
    return re.sub(r"^(?:_\d+)+", "", name) or name


class _GoalListenerAdapter(CircumstanceListener):
    """Bridges a GoalListener onto Circumstance's intention-level
    notifications, translating intention events into goal events -- mirrors
    the anonymous CircumstanceListener Java's TransitionSystem.addGoalListener
    builds and registers on C for exactly this purpose."""

    def __init__(self, goal_listener: GoalListener) -> None:
        self._gl = goal_listener

    def event_added(self, event: Event) -> None:
        if event.trigger.is_addition() and event.trigger.is_goal():
            self._gl.goal_started(event)

    def intention_dropped(self, intention: Intention) -> None:
        for im in intention:
            if im.trigger.is_addition() and im.trigger.is_goal():
                self._gl.goal_finished(im.trigger, GoalStates.DROPPED)

    def intention_suspended(self, trigger: Trigger | None, intention: Intention | None,
                             reason: Term | None) -> None:
        if trigger is not None and trigger.is_addition() and trigger.is_goal():
            self._gl.goal_suspended(trigger, reason)

    def intention_waiting(self, intention: Intention, reason: Term | None) -> None:
        im = intention.peek()
        if im is not None and im.trigger.is_addition() and im.trigger.is_goal():
            self._gl.goal_waiting(im.trigger, reason)

    def intention_resumed(self, intention: Intention, reason: Term | None) -> None:
        im = intention.peek()
        if im is not None and im.trigger.is_addition() and im.trigger.is_goal():
            self._gl.goal_resumed(im.trigger, reason)

    def intention_executing(self, intention: Intention, reason: Term | None) -> None:
        im = intention.peek()
        if im is not None and im.trigger.is_addition() and im.trigger.is_goal():
            self._gl.goal_executing(im.trigger, reason)


class TransitionSystem:

    _logger: logging.Logger = logging.getLogger(__name__)

    class State(Enum):
        START_RC = 0    # SENSE         Start of the reasoning cycle
        SEL_EV = 1      # DELIBERATE    Selecting event
        REL_PL = 2      # DELIBERATE    Finding Relevant Plans
        APPL_PL = 3     # DELIBERATE    Finding Applicable Plans
        SEL_APPL = 4    # DELIBERATE    Select One Applicable Plan
        FIND_OP = 5     # DELIBERATE    Find Options for the Plan
        ADD_IM = 6      # DELIBERATE    Add Intended Means
        PROC_ACT = 7    # ACT           Process Action
        SEL_INT = 8     # ACT           Selected Intention
        EXEC_INT = 9    # ACT           Execute Intention
        CLR_INT = 10    # ACT           Clear Intention

    def __init__(self, agent: Agent, agentic: Icaros | None, ag_arch: AgArch, circumstance: Circumstance | None = None,
                 gen_limit: str | IcarosState = IcarosState.STILL,
                 gen_path: Path | None = None,
                 gen_max_rounds: int = MAX_ROUNDS) -> None:
        self._agent = agent                             # Agent
        self._ag_arch = ag_arch                         # Agent Architecture
        self._agentic = agentic                         # the agentic faculty
        self._gen_limit = IcarosState.parse(gen_limit)
        self._gen_path = gen_path
        self._gen_max_rounds = gen_max_rounds
        if circumstance is not None:                    # Circumstance
            self._circumstance = circumstance
        else:
            self._circumstance = Circumstance()
        # Give self as ts to agent and ag_arch
        self._agent.ts = self
        self._ag_arch.ts = self
        # ag: agentic is optional -- boot_agent() defaults it to None, which is
        # how tests (and Runner.clone_agent) build an agent with no LLM at all.
        # The .mas2i path never hits this because loader.py always constructs an
        # Agentic, even when provider and model are both unset.
        if self._agentic is not None:
            self._agentic.ts = self

        # SENSE STATE
        self._step_sense = TransitionSystem.State.START_RC      # it goes just from START_RC to SEL_EV
        # DELIBERATE STATE
        self._step_deliberate = TransitionSystem.State.SEL_EV
        # ACT STATE
        self._step_act = TransitionSystem.State.PROC_ACT

        self._sleeping_event: bool = False
        self._tasks_for_begin_of_cycle: deque[Callable[[], None]] = deque()
        self._cycle_count: int = 0
        self._plan_base_for_e_plans: Plan | None = None

        self._goal_listeners: list[GoalListener] = []
        self._goal_listener_adapters: dict[GoalListener, CircumstanceListener] = {}

        # ag: what _find_option learned on its way to a decision, parked for
        # _journal_state to pick up at the end of the step. The counters exist
        # only inside that loop -- once it returns, which candidates had a
        # false context and which were never looked at is unrecoverable -- and
        # this is what lets the journal have one write per state instead of a
        # record() call scattered at each of the loop's exits.
        self._deliberation: DeliberationRecord | None = None
        self._sensed: str | None = None   # what sense() took in, for its line
        self._acted: str | None = None    # what act() did, for its line
        self._last_act: str | None = None  # to not say the same thing twice,
        # within one cycle -- act() clears it at its top

    ### Journal #######################
    # ag: the journal is written from here, by direct calls, and NOT by
    # registering a CircumstanceListener/GoalListener of its own. Those are an
    # extension mechanism built on the assumption that nobody is listening --
    # Circumstance guards six notification sites with `if self._listeners:` and
    # this class guards its own with `if self._goal_listeners:`. A listener
    # registered for every agent by default turns all of those fast paths into
    # slow ones, permanently, to obtain something the interpreter can simply
    # say itself.

    def _journal_state(self, kind: JournalKind) -> None:
        """One line per reasoning-cycle state, written after the state ran.

        A single describer rather than a record() at each interesting site: a
        state added tomorrow is journalled by construction instead of by
        somebody remembering. States with nothing to say write nothing -- an
        idle agent should leave no trace, or a MAS waiting on a slow
        environment fills the buffer with lines saying it is still waiting and
        pushes the real history out.
        """
        detail = self._journal_detail(kind)
        if detail is not None:
            self._agent.journal.record(kind, **detail)

    def _journal_detail(self, kind: JournalKind) -> dict | None:
        match kind:
            case JournalKind.SENSE:
                summary, self._sensed = self._sensed, None
                return None if summary is None else {"summary": summary}
            case JournalKind.DELIBERATE:
                record, self._deliberation = self._deliberation, None
                return None if record is None else record.as_detail()
            case JournalKind.ACT:
                summary, self._acted = self._acted, None
                step = self._circumstance.last_deed
                if summary is None and step is None:
                    return None
                # ag: `where` and `step` are the same two facts the summary
                # already spells out, kept apart as well as together. A reader
                # that wants to lay them out -- the UI's reasoning chain shows
                # the intention this belonged to on one line and what it ran on
                # the next -- would otherwise have to split the sentence back
                # up, i.e. guess. The summary stays because render() and every
                # model preamble read prose, not fields.
                where = step_text = where_annots = where_session = functor = None
                where_root = where_root_annots = None
                if summary is None:
                    intention = self._circumstance.selected_intention
                    top = intention.peek() if intention is not None else None
                    root = intention.root() if intention is not None else None
                    where = str(top.trigger) if top is not None else None
                    where_annots = annots_text(top.trigger) if top is not None else None
                    where_session = session_of(top.trigger) if top is not None else None
                    # ag: only when the intention is more than one frame deep --
                    # root() and peek() are the same object otherwise, and a
                    # reader does not need "+!g/+!g" to know an intention it has
                    # not left. When they differ, this is what lets the UI's
                    # "intention" line keep saying where a nested goal (a
                    # !subgoal call, a goal the model asked for -- root() does
                    # not care which) came from on every cycle it is the top
                    # frame, not only the one where it was taken up.
                    if root is not None and top is not None and root is not top:
                        where_root = str(root.trigger)
                        where_root_annots = annots_text(root.trigger)
                    # ag: the step's own term, not str(step) -- PlanBody.__str__
                    # renders the whole remaining chain ("!a; !b; !c"), so the
                    # line would repeat the rest of the plan on every step
                    # (same trap plan_graph._goal_steps documents). The body
                    # type carries the prefix, and it is not decoration: it is
                    # what separates +cleaning(R) from -cleaning(R).
                    term = getattr(step, "body_term", None)
                    step_text = str(step) if term is None else f"{step.body_type}{term}"
                    summary = f"{where} step {step_text}" if where else f"step {step_text}"
                    # ag: which internal action this was, plainly -- a generic
                    # interpreter fact (not an opinion about icaros or any
                    # other family of actions), left for a reader (the UI's
                    # reasoning chain, reasoning.py) to decide what a specific
                    # functor is worth showing.
                    functor = getattr(term, "functor", None)
                # act runs through PROC_ACT/SEL_INT/EXEC_INT/CLR_INT and only
                # some of those change anything, so the same line would be
                # written several times per cycle. Suppressed here rather than
                # folded away at render time: a journal that records the same
                # thing twice is wrong, not merely verbose.
                if summary == self._last_act:
                    return None
                self._last_act = summary
                # record() drops None values, so a summary that came from
                # _acted (an internal action's own words) simply has no
                # where/step -- there is no half-filled shape here
                return {"summary": summary, "where": where, "step": step_text,
                        "where_annots": where_annots, "where_session": where_session,
                        "where_root": where_root, "where_root_annots": where_root_annots,
                        "functor": functor}
            case _:
                return None

    ### Goal listeners ################
    def add_goal_listener(self, goal_listener: GoalListener) -> None:
        if goal_listener in self._goal_listeners:
            return
        adapter = _GoalListenerAdapter(goal_listener)
        self._circumstance.add_event_listener(adapter)
        self._goal_listener_adapters[goal_listener] = adapter
        self._goal_listeners.append(goal_listener)

    def remove_goal_listener(self, goal_listener: GoalListener) -> bool:
        adapter = self._goal_listener_adapters.pop(goal_listener, None)
        if adapter is not None:
            self._circumstance.remove_event_listener(adapter)
        try:
            self._goal_listeners.remove(goal_listener)
            return True
        except ValueError:
            return False

    def has_goal_listener(self) -> bool:
        return bool(self._goal_listeners)

    @property
    def goal_listeners(self) -> list[GoalListener]:
        return self._goal_listeners

    # PROPERTIES
    @property
    def cycle_count(self) -> int:
        return self._cycle_count

    @property
    def circumstance(self) -> Circumstance:
        return self._circumstance

    @property
    def ag(self):
        return self._agent

    @ag.setter
    def ag(self, ag) -> None:
        self._agent = ag

    @property
    def ag_arch(self):
        return self._ag_arch

    @ag_arch.setter
    def ag_arch(self, ag_arch) -> None:
        self._ag_arch = ag_arch

    @property
    def agentic(self):
        return self._agentic

    @agentic.setter
    def agentic(self, agentic) -> None:
        self._agentic = agentic

    @property
    def gen_limit(self) -> IcarosState:
        """How far up the generation scale this agent may go. Ordered, so the
        runtime question is `ts.gen_limit >= IcarosState.FLY`, not equality."""
        return self._gen_limit

    @gen_limit.setter
    def gen_limit(self, gen_limit: str | IcarosState) -> None:
        self._gen_limit = IcarosState.parse(gen_limit)

    @property
    def gen_path(self) -> Path | None:
        """Where a burn-rung agent's generated internal actions are written,
        or None to keep them in memory only.

        ag: the companion of gen_limit, and the pair is deliberate -- one says
        how high the model may go, the other whether what it writes up there
        survives the run. None is not "a default directory": it is the refusal
        to touch the filesystem at all, which is why the .mas2i has to name a
        directory before anything is saved."""
        return self._gen_path

    @gen_path.setter
    def gen_path(self, gen_path: Path | None) -> None:
        self._gen_path = gen_path

    @property
    def gen_max_rounds(self) -> int:
        """Per-agent override of icaros.llm.session.MAX_ROUNDS -- the ceiling
        on round trips a single .talk/.run/.fly/.burn session may take before
        it gives up and fails the goal that opened it. Read once per session,
        at open (generation.py's _open), and carried on the session itself
        from there -- the same "captured once" treatment session.level gets."""
        return self._gen_max_rounds

    @gen_max_rounds.setter
    def gen_max_rounds(self, gen_max_rounds: int) -> None:
        self._gen_max_rounds = gen_max_rounds

    # ==== SENSE STATE =================================================================================================
    # Advance method
    def _advance_sense(self):
        if self._step_sense == TransitionSystem.State.START_RC:
            self._process_messages()

    # Processes incoming messages
    def _process_messages(self) -> None:
        # updates the sense step
        self._step_sense = TransitionSystem.State.SEL_EV
        # if empty mailbox, exit
        if not self._circumstance.mailbox:
            return
        # call the agent select_message with the mailbox
        msg: Message | None = self._agent.select_message(self._circumstance.mailbox)
        # if message is empty, exit
        if msg is None:
            return
        # get the content (it forces it to be a term)
        content = self._message_content(msg)
        # parked for the sense line rather than written here: one message is
        # what this stage did, not a separate thing that happened
        self._sensed = f"{msg.il_force} from {msg.sender}: {content}"

        # the message is in reply to an intention, it was an ask I made
        # get the intention from the pending ones (with the message id)
        # sync asks are intentions suspended waiting for the answer.
        intention: Intention | None = None
        if msg.in_reply_to is not None:
            intention = self._circumstance.pending_intentions.get(msg.in_reply_to)

        # if the intention is not none, then process the reply
        if intention is not None:
            self._process_ask_reply(msg, content, intention)
        # otherwise, simply process the message
        elif self._agent.soc_acc(msg) and not msg.is_reply_to_sync_ask():
            self._process_new_message(msg, content)

    @staticmethod
    def _message_content(msg: Message) -> Term:
        # the content can be any term (literal, list, number, ...; see ask)
        if isinstance(msg.content, Term):
            return msg.content
        try:
            return parse_term(str(msg.content))
        except ASParseError:
            return ObjectTerm(msg.content)

    def _process_ask_reply(self, msg: Message, content: Term, intention: Intention) -> None:
        """
        This method is called when a message containing an answer to a previous ask is received
        """
        # get the send structure from the intention of the ask message
        send: Structure = intention.peek().current_step.body_term
        # get the answer with sources (they can be nested!)
        answer = self._answer_with_sources(msg, str(send.get_term(1)), content)
        # get the answer variable
        answer_var = send.get_term(3)
        # get the receiver from the first arg of send
        un: Unifier = intention.peek().unifier
        receiver: Term = send.get_term(0).resolve(un)
        # if the receiver is just one, then I will have only one answer, I can resume the intention
        if not receiver.is_list():
            self.resume_sync_ask_intention(msg.in_reply_to, answer_var, answer)
            return

        # if I asked multiple agents, I will have a list of answers
        answers_var = VarTerm("AnsList___" + msg.in_reply_to)
        answers = un.get(answers_var)
        if answers is None:
            answers = ListTerm()
            un.unifies(answers_var, answers)
        # add the received answer to the answers
        answers.append(answer)
        # if I received all the answers, resume the intention
        if len(answers) == len(receiver):
            self.resume_sync_ask_intention(msg.in_reply_to, answer_var, answers)

    def _answer_with_sources(self, msg: Message, performative: str, content: Term) -> Term:
        # get the source sender
        source = Atom(msg.sender)
        # if the message is untell and I asked one return False
        if msg.is_untell() and performative == "askOne":
            return Literal.l_false
        # if the content is a literal, add the sender to the sources
        # this way, if I ask bob p and bob knows p[source(alice)], I will receive p[source[bob][source(alice)]]
        if content.is_literal():
            return add_nested_source.add_annot_to_list(content, source)
        # if the performative is an ask-all and the content is a list then I create a new ListTerm with all the answers
        if performative == "askAll" and content.is_list():
            return ListTerm([add_nested_source.add_annot_to_list(t, source) for t in content])
        # if the performative is ask-how and the content is a list, then return a list containing all the plans casted
        if performative == "askHow" and content.is_list():
            plans = []
            for t in content:
                if isinstance(t, Plan):
                    p = Plan(t)
                    p.add_source(source)
                    plans.append(p)
            return ListTerm(plans)

        return content

    def _process_new_message(self, msg: Message, content: Term) -> None:
        # sender is self if I was the sender of the message, name of the agent otherwise
        sender = "self" if msg.sender == self.ag_arch.ag_name else msg.sender

        # ag: recorded here, before the shortcut below, because a `tell` that
        # never becomes an event is still something the agent was told -- and a
        # journal that only remembered the messages that needed a plan would
        # answer "has anyone spoken to me?" with the wrong half. It is
        # MSG_OUT's twin and reads as one: what came in, from whom, as what.
        self._agent.journal.record(JournalKind.MSG_IN, sender=sender,
                                   performative=msg.il_force, content=str(content))

        # handling tell/achieve/signal directly, skipping the kqmlReceived plans,
        # is only possible when the user has not customized them
        shortcut = (not self._agent.pl.has_user_kqml_received_plans
                    and content.is_literal() and not content.is_list()
                    and msg.il_force in ("achieve", "tell", "signal"))
        if shortcut:
            # add the nested sources
            content = add_nested_source.add_annot_to_list(content, Atom(sender))
            # if it is an achieve we can add an event +!content[nested_sources]
            if msg.il_force == "achieve":
                self._circumstance.add_event(Event(Trigger(TEOperator.ADD, TEType.ACHIEVE, content)))
            # if it is a tell add the belief
            elif msg.il_force == "tell":
                self._agent.add_bel(content)
            else:  # signal, as for achieve but with signal type
                content.add_annot(Atom("signal"))
                self._circumstance.add_event(Event(Trigger(TEOperator.ADD, TEType.SIGNAL, content)))
            return

        # if we defined custom kqml_received, create a
        # kqml_received(sender,il_force,content,msg_id) literal
        # add that trigger to the events
        received = LiteralImpl(Message.kqml_received_functor).add_terms(
            Atom(sender), create_atom(msg.il_force), content, Atom(msg.id))
        self.update_events(Event(Trigger(TEOperator.ADD, TEType.ACHIEVE, received)))

    def resume_sync_ask_intention(self, msg_id: str, answer_var: Term, answer_value: Term):
        # try to get the pending intention with msg_id received in the answer message
        intention: Intention | None = self._circumstance.remove_pending_intention(msg_id)
        # if it is none exit
        if intention is None:
            return
        # remove the current step in the msg_id pending intention
        intention.peek().remove_current_step()
        # if the answer unifies the variable, resume the intention with reason ask_answer(msg_id)
        if intention.peek().unifier.unifies(answer_var, answer_value):
            self._circumstance.resume_intention(intention, create_structure("ask_answer", StringTerm(msg_id)))
        else:
            # otherwise, ask_failed() with this error message
            self._generate_goal_deletion(
                intention,
                error_annots("ask_failed", f"reply of an ask message ('{answer_value}') does not "
                                           f"unify with fourth argument of .send ('{answer_var}')"),
                Atom("ask_failed"))

    # ==== DELIBERATE STATE ============================================================================================
    # Advance method
    def _advance_deliberate(self):
        match self._step_deliberate:
            case TransitionSystem.State.SEL_EV:
                self._select_event()
                return
            case TransitionSystem.State.REL_PL:
                self._find_relevant_plans()
                return
            case TransitionSystem.State.APPL_PL:
                self._filter_applicable_plans()
                return
            case TransitionSystem.State.SEL_APPL:
                self._select_applicable_plan()
                return
            case TransitionSystem.State.FIND_OP:
                self._find_option()
                return
            case TransitionSystem.State.ADD_IM:
                self._push_intended_means()
                return

    def _select_event(self) -> None:
        # ATOMIC HANDLING
        # 1. if there is an atomic intention parked -> execute it
        if self._circumstance.atomic_intention is not None:
            self._step_deliberate = TransitionSystem.State.PROC_ACT
            return
        # 2. the atomic intention generated an event?
        #    if it has, go for it, always considering the FIND_OP shortcut
        self._circumstance.selected_event = self._circumstance.remove_atomic_event()
        if self._circumstance.selected_event is not None:
            self._step_deliberate = TransitionSystem.State.FIND_OP
            if self._has_custom_select_option():
                self._step_deliberate = TransitionSystem.State.REL_PL
            return

        # Check if there are events to consider in the circumstance
        if not self._circumstance.has_event():
            # no event to handle, directly to ProcAct
            self._step_deliberate = TransitionSystem.State.PROC_ACT
            return

        # select one event to consider from the events
        self._circumstance.selected_event = self._agent.select_event(self._circumstance.events)
        if self._circumstance.selected_event is None:
            # no event to handle, directly to ProcAct
            self._step_deliberate = TransitionSystem.State.PROC_ACT
            return

        # if the selected event is external, and it is an update (+something), check if there are ims in the intentions
        # that need this update (for example a wait)
        if self._circumstance.selected_event.is_external() and self._circumstance.selected_event.trigger.is_update():
            self._branch_intentions_for_update_event(self._circumstance.selected_event)

        # if the agent has a custom select_option method, then:
        # REL_PL -> APPL_PL -> SEL_APPL
        if self._has_custom_select_option():
            self._step_deliberate = TransitionSystem.State.REL_PL
        # Otherwise, bypass with the shortcut FIND_OP
        else:
            self._step_deliberate = TransitionSystem.State.FIND_OP

    def _branch_intentions_for_update_event(self, event: Event) -> None:
        # iterate over all actual intentions
        for intention in self._circumstance.all_intentions():
            if not intention.has_interest_in_update_events():
                continue
            # if it has interest in update events, look if there is an option available given the event
            option = self._option_for_update_event(intention, event)
            if option is None:
                continue
            try:
                # e-plans are the nested with {...}
                # I never used them, and we do not have examples that use them, so this is not proven to work!
                if self._plan_base_for_e_plans is None:
                    # TODO(present already in Jason): do not use .drop_intention, but a new internal action
                    #   that drops only this intention (important if the user decides to
                    #   use .drop_intention to stop the g-plan)
                    self._plan_base_for_e_plans = parse_plan(
                        "+artificial_plan <- .print(dropwhenreturntohere); .drop_intention.")

                join_im = IntendedMeans(
                    Option(self._plan_base_for_e_plans.clone_ns(Literal.default_ns),
                           intention.peek().unifier, event),
                    event.trigger)
                new_intention = Intention()
                new_intention.g_intention = intention  # to avoid succeed_goal to resume it
                intention.copy_to(new_intention)
                new_intention.set_no_interest_in_update_events()
                new_intention.push(join_im)

                extra_event = Event(event.trigger, new_intention)
                extra_event.option = option
                self._circumstance.add_event(extra_event)
            except Exception:
                self._logger.exception("Error branching intention for update event %s", event.trigger)

    def _option_for_update_event(self, intention: Intention, event: Event) -> Option | None:
        # iterate of intended means of an intention
        for im in intention:
            # get the plan
            plan = im.plan
            if not plan.has_sub_plans():
                continue
            # get the list of subplans of the plan that have same trigger as the event
            candidates = plan.sub_plans.get_candidate_plans(event.trigger)
            if candidates is None:
                continue
            # for each subplan, check if there is an option available given the event
            for sub_plan in candidates:
                option = self._option_for(event, sub_plan, im.unifier.clone())
                # if there is an option return it
                if option is not None:
                    return option
        return None

    def _option_for(self, event: Event, plan: Plan, unifier: Unifier | None = None) -> Option | None:
        # check if the plan is relevant for the trigger event
        unifier = plan.is_relevant(event.trigger, unifier)
        if unifier is None:
            return None
        # in this case, check the context
        context = plan.context
        # no context = true, return the option
        if context is None:
            return Option(plan, unifier, event)
        # get the first logical consequence of the context given the agent beliefs
        # if it is none, it is false, otherwise return the option with the first found unifier for the context
        # if for example the context is : .my_name(Me), this method would unify Me=bob
        consequences = context.logical_consequence(self._agent, unifier)
        first = next(consequences, None) if consequences is not None else None
        if first is not None:
            return Option(plan, first, event)
        return None

    def _has_custom_select_option(self) -> bool:
        # check if the method is overwritten
        return type(self._agent).select_option is not Agent.select_option or self._agent.so_llm

    def _find_relevant_plans(self) -> None:
        # get the selected event
        event = self._circumstance.selected_event
        # an option was already computed (by _select_event)
        if event.option is not None:  
            self._step_deliberate = TransitionSystem.State.APPL_PL
            return
        # call the agent relevant plans method
        self._circumstance.relevant_plans = self._agent.relevant_plans(event.trigger, event)
        # if the agent found relevant plans, retrieve applicable ones
        if self._circumstance.relevant_plans is not None:
            self._step_deliberate = TransitionSystem.State.APPL_PL
        else: # otherwise handle the no plan, maybe it is not an error, maybe is just a belief update!
            self._handle_no_plan("relevant")

    def _filter_applicable_plans(self) -> None:
        # get the selected event
        event = self._circumstance.selected_event
        # an option was already computed (by _select_event)
        if event.option is not None:  
            self._step_deliberate = TransitionSystem.State.SEL_APPL
            return
        # call the agent applicable plans method
        self._circumstance.applicable_plans = self._agent.applicable_plans(self._circumstance.relevant_plans)
        # if there are applicable plans, we can select one out of them
        if self._circumstance.applicable_plans is not None:
            self._step_deliberate = TransitionSystem.State.SEL_APPL
        else: # otherwise handle the no plan, maybe it is not an error, maybe is just a belief update with a relevant plan not applicable!
            self._handle_no_plan("applicable")

    def _note_deliberation(self, path: str, option: Option | None, **counts) -> None:
        """Parks what this step decided; _journal_state writes it."""
        event = self._circumstance.selected_event
        if event is not None:
            self._deliberation = record_for(path, event.trigger, option,
                                            session=session_of(event.trigger), **counts)

    def _handle_no_plan(self, kind: str, *, path: str = "full", context_failed: int = 0) -> None:
        # there is no relevant/applicable plan for the selected event
        self._step_deliberate = TransitionSystem.State.PROC_ACT  # default next step
        # get the selected event
        event = self._circumstance.selected_event
        # ag: noted because "why did nothing happen" is a question the
        # interpreter could not answer at all before -- an event with no plan
        # simply vanished, whether that was a bug or the intended shrug at a
        # belief update nobody reacts to
        self._deliberation = DeliberationRecord(
            path=path, trigger=trigger_text(event.trigger), trigger_kind=kind_of(event.trigger),
            annots=annots_text(event.trigger), session=session_of(event.trigger),
            outcome=f"no_{kind}",
            candidates=context_failed, context_failed=context_failed)
        # if the event was a goal or a meta event, we should give an error message and fail the goal
        if event.trigger.is_goal() and not event.trigger.is_meta_event():
            # can't carry on: generate the goal deletion event
            msg = f"Found a goal for which there is no {kind} plan: {event.trigger}"
            if not self._generate_goal_deletion_from_event(error_annots(f"no_{kind}", msg),
                                                           Atom(f"no_{kind}_plan")):
                self._logger.warning(msg)
        # if instead it was an internal event (e.g. a belief addition), then there is no real error
        elif event.is_internal():
            intention = event.intention
            # ag: the originating intention may already be finished by the time
            # this internal event is processed (its last body step was itself
            # the belief update that raised this very event, with no reactive
            # plan for it) -- intention.peek() is then None, same condition
            # clear_intention() already checks before touching the top frame.
            # Found via a real crash (`'NoneType' object has no attribute
            # 'unifier'`) in a long-running, belief-heavy multi-agent example
            # (examples/gold-miners-II): common there, apparently never
            # exercised by an existing test/example before.
            top = intention.peek()
            if top is not None:
                self._join_renamed_vars(top, top.unifier)
            self._continue_intention(intention)  # already a no-op (logged) when finished
        else:
            # external and irrelevant: discard the event and select another one
            self._step_deliberate = TransitionSystem.State.SEL_EV

    def _find_option(self) -> None:
        # replaces RelPl -> ApplPl -> SelAppl when select_option is not customised:
        # searches for the first option and selects it, without building the
        # relevant/applicable lists
        self._step_deliberate = TransitionSystem.State.ADD_IM  # default next step

        # get the selected event and its option
        event = self._circumstance.selected_event
        # TODO (JasonER) Implement Scope for RelPl ApplPl SelAppl (besides the fast track of _find_option)
        self._circumstance.selected_option = event.option
        # if the option is already there, exit
        if self._circumstance.selected_option is not None:
            self._note_deliberation("preattached", event.option)
            return

        # TODO(already present in Jason, JasonER): scope/sub-plans libraries not considered here (see Agent.relevant_plans)
        kind = "relevant"
        plan_lib = self._agent.pl
        # ag: `rejected` counts the candidates whose context was evaluated and
        # did not hold. It is not interchangeable with the ones left unread
        # after the winner -- see DeliberationRecord.
        rejected = 0
        while plan_lib is not None:
            # get candidates for the trigger
            candidates = plan_lib.get_candidate_plans(event.trigger)
            if candidates is not None:
                # if there are candidates, look for an applicable one
                kind = "applicable"
                for index, plan in enumerate(candidates):
                    # look for an option for the event
                    option = self._option_for(event, plan)
                    if option is not None:
                        # set the option
                        self._circumstance.selected_option = option
                        unexamined = len(candidates) - index - 1
                        self._note_deliberation(
                            "fast", option,
                            candidates=rejected + 1 + unexamined, chosen_index=rejected,
                            context_failed=rejected, unexamined=unexamined)
                        return
                    rejected += 1
            plan_lib = plan_lib.father

        # if we arrive here, there was not an option, handle this case
        self._handle_no_plan(kind, path="fast", context_failed=rejected)

    def _select_applicable_plan(self) -> None:
        # get the event selected
        event = self._circumstance.selected_event
        # if the option is already in the event, take it
        if event.option is not None:
            self._circumstance.selected_option = event.option
            path = "preattached"
            applicable = 1
        else: # otherwise select with the select_option method
            applicable = len(self._circumstance.applicable_plans or ())
            self._circumstance.selected_option = self._agent.select_option(self._circumstance.applicable_plans)
            path = "full"

        # if there is a selected option go to add intended means step
        if self._circumstance.selected_option is not None:
            # on this path every applicable plan was built before choosing, so
            # there is nothing left unexamined -- the agent (or its model) had
            # the whole list in front of it
            self._note_deliberation(path, self._circumstance.selected_option,
                                    candidates=applicable)
            self._step_deliberate = TransitionSystem.State.ADD_IM
        else:
            # there is no applicable plan, here we go for an error
            self._deliberation = DeliberationRecord(
                path=path, trigger=trigger_text(event.trigger), trigger_kind=kind_of(event.trigger),
                annots=annots_text(event.trigger), session=session_of(event.trigger),
                outcome="no_option",
                candidates=applicable, context_failed=applicable)
            self._generate_goal_deletion_from_event(
                error_annots("no_option", "select_option returned None"), Atom("no_option"))
            # next state: go to the ACT phase
            self._step_deliberate = TransitionSystem.State.PROC_ACT

    def _push_intended_means(self) -> None:
        # get the selected event
        event = self._circumstance.selected_event
        # ag: the one place that sees both the chosen plan and the trigger it
        # was chosen for, so it is where breakpoints are matched -- including
        # @[breakpoint], which as_syntax has parsed since the port
        # (plan.py's has_breakpoint) with nothing ever reading it.
        exec_control = self._ag_arch._exec_control
        if exec_control is not None:
            exec_control.note_plan_pushed(
                self._ag_arch, self._circumstance.selected_option.plan, event.trigger)
        # create a new intended means with option and trigger
        im = IntendedMeans(self._circumstance.selected_option, event.trigger)
        if self._goal_listeners and event.trigger.is_achv_goal() and event.trigger.is_addition():
            for gl in self._goal_listeners:
                gl.goal_executing(event.trigger, None)
        # if the event is external, create a new intention and add it to the running intention
        if event.is_external():
            intention = Intention()
            intention.push(im)
            self._circumstance.add_running_intention(intention)
        else:
            # Tail-recursion optimization: an Intention is a stack of IntendedMeans (IM) frames.
            # Without this, a plan that calls itself as its last step (e.g. "+!p <- ...; !p.")
            # would push a new IM frame on top of the completed one at every iteration,
            # making the stack grow without bound instead of staying at constant depth.
            # So when the top frame's last step is a self-recursive call to the same goal,
            # we pop the completed frame first (carrying over its variable bindings)
            # before pushing the new one, keeping the stack depth constant.

            # peek the inteded means
            top: IntendedMeans = event.intention.peek()
            # if the top im is +! and the current is +! and they share the same predicate indicator
            if top is not None and (top.trigger.is_addition() and im.trigger.is_addition() and
                                    top.trigger.is_goal() and im.trigger.is_goal() and
                                    top.current_step.body_next is None and
                                    top.trigger.literal.get_predicate_indicator() == im.trigger.literal.get_predicate_indicator()):
                if self._goal_listeners:
                    for gl in self._goal_listeners:
                        gl.goal_finished(top.trigger, GoalStates.ACHIEVED)
                # pop the intended means from the intention
                event.intention.pop()
                # peek the intended means
                im_base = event.intention.peek()
                # if the intended means are not None and they have renamed vars
                # top is discarded without going through clear_intention/_join_renamed_vars,
                # so we manually hand back to im_base whatever top would have "returned" to it
                if im_base is not None and im_base.renamed_vars is not None:
                    # v: a var im_base renamed for its call to top
                    for v in im_base.renamed_vars:
                        # vvl: that renamed var's name inside top's scope
                        vvl: VarTerm = im_base.renamed_vars.function.get(v)
                        # did top's execution bind vvl to a value?
                        t = top.unifier.get(vvl)
                        if t is not None:
                            if isinstance(t, Literal):
                                # fully ground the value against top's unifier
                                t = t.resolve(top.unifier)
                                # re-anonymise its free vars, reusing top's map
                                t.make_vars_annon(top.renamed_vars)
                            # stash it on im under the same key, for the eventual real join
                            im.unifier.function[vvl] = t
                        else:
                            # vvl is still unbound: it must be one of top's own renamed vars for its tail call into im
                            # v0: that var's name inside im's scope
                            v0 = top.renamed_vars.function.get(vvl)
                            if v0 is not None:
                                # re-point im_base at im directly, skipping top
                                im_base.renamed_vars.function[v] = v0

            # push the intended means in the intention
            event.intention.push(im)
            # add the intention to the running intentions
            self._circumstance.add_running_intention(event.intention)
        # go to the ACT phase
        self._step_deliberate = TransitionSystem.State.PROC_ACT

    # ==== ACT =========================================================================================================
    # Advance method
    def _advance_act(self):
        match self._step_act:
            case TransitionSystem.State.PROC_ACT:
                self._process_action_feedback()
                return
            case TransitionSystem.State.SEL_INT:
                self._select_intention()
                return
            case TransitionSystem.State.EXEC_INT:
                self._execute_intention_step()
                return
            case TransitionSystem.State.CLR_INT:
                self._clear_selected_intention()
                return

    def _process_action_feedback(self) -> None:
        # TODO(JasonER): clearing of satisfied goal-condition intentions not ported
        # advance to select intention state
        self._step_act = TransitionSystem.State.SEL_INT
        # while there are feedback actions (as answering an ask message)
        while self._circumstance.has_feedback_action():
            # take the lock for selecting the action between the feedback actions
            with self._circumstance.feedback_actions_lock:
                action = self._agent.select_action(self._circumstance.feedback_actions)
            # no action, exit
            if action is None:
                return
            # the intention is the one inside the action
            intention = action.intention
            # PA holds every pending action; if the intention is not there anymore
            # it was dropped and must not return to I (then consider the next feedback)
            if self._circumstance.remove_pending_action(intention.id) is None:
                continue
            # noted before the branch, so a failed action reaches the journal
            # with its reason -- the failures are the ones worth explaining
            outcome = "ok" if action.result else f"FAILED ({action.failure_msg or '?'})"
            self._acted = f"{action.action_term} -> {outcome}"
            # if the action has a result continue with the intention
            if action.result:
                self._continue_intention(intention)
                self.clear_intention(intention)
                if self._goal_listeners:
                    for gl in self._goal_listeners:
                        for im in intention:
                            gl.goal_executing(im.trigger, create_structure("action_executed", action.action_term))
            else:
                # otherwise, we failed the action
                annots = error_annots("action_failed", action.failure_msg or "")
                if action.failure_reason is not None:
                    annots.append(Atom(action.failure_reason))
                self._generate_goal_deletion(intention, annots, Atom("action_failed"))
                # if the (potentially) atomic intention is not removed, it would be
                # selected again in SelInt/SelEv and run again
                self._circumstance.remove_atomic_intention()
            return

    def _select_intention(self) -> None:
        self._step_act = TransitionSystem.State.EXEC_INT  # default next step

        # rule for atomic intentions
        self._circumstance.selected_intention = self._circumstance.remove_atomic_intention()
        if self._circumstance.selected_intention is not None:
            return

        # Rule SelInt1 (the atomic intention, if any, may be suspended: then even if
        # remove_atomic_intention returned None, no other intention can be selected)
        if not self._circumstance.is_atomic_intention_suspended() and self._circumstance.has_running_intentions():
            self._circumstance.selected_intention = self._agent.select_intention(
                self._circumstance.running_intentions)
            if self._circumstance.selected_intention is not None:
                return

        self._step_act = TransitionSystem.State.START_RC

    def _execute_intention_step(self) -> None:
        self._step_act = TransitionSystem.State.CLR_INT  # default next step

        intention = self._circumstance.selected_intention
        if intention is None or intention.is_finished():
            return

        # get the next formula in the body of the intended means
        # on the top of the selected intention
        im = intention.peek()
        if im.is_finished():
            # for empty plans! may need unif, etc
            self._continue_intention(intention)
            return
        u = im.unifier
        h = im.current_step
        self._circumstance.last_deed = h

        bterm = h.body_term

        if isinstance(bterm, VarTerm):  # de-var bterm
            bterm = bterm.resolve(u)
            if bterm.is_var():  # the case of !A with A not ground
                msg = f"{h.src_info}: Variable '{bterm}' must be ground."
                if not self._generate_goal_deletion(
                        intention, error_annots("body_var_without_value", msg), None):
                    self._logger.error(msg)
                return
            if bterm.is_plan_body() and h.body_type != BodyType.ACTION:
                # the case of ...; A = { !g }; +g; ...
                msg = (f"{h.src_info}: The operator '{h.body_type}' is lost with the "
                       f"variable '{bterm}' unified with a plan body.")
                if not self._generate_goal_deletion(
                        intention, error_annots("body_var_with_op", msg), None):
                    self._logger.error(msg)
                return
            if bterm.is_internal_action():  # translate var into appropriate body
                h = PlanBody(BodyType.INTERNAL_ACTION, bterm)
            if not isinstance(bterm, Literal) and h.body_type not in (BodyType.CONSTRAINT, BodyType.TEST):
                # var is not a literal, so it cannot be used for most of the deeds
                msg = (f"{h.src_info}: Variable '{h.body_term}' must be a Literal and "
                       f"not '{bterm}' to be used in '{h}'.")
                if not self._generate_goal_deletion(
                        intention, error_annots("body_var_not_literal", msg), None):
                    self._logger.error(msg)
                return

        if bterm.is_plan_body():
            h = bterm
            if h.get_plan_size() > 1:  # the case of a var unified with a whole plan body
                h = bterm.clone()
                h.add(im.current_step.body_next)
                im.insert_as_next_step(h.body_next)
            bterm = h.body_term

        body = bterm if isinstance(bterm, Literal) else None

        match h.body_type:
            case BodyType.NONE:
                pass

            # Rule Action
            case BodyType.ACTION:
                body = body.resolve(u)
                self._circumstance.action = ActionExec(body, intention)

            case BodyType.INTERNAL_ACTION:
                # a missing IA (or any failure inside it) degrades into an
                # ia_failed goal deletion, as in Java
                ok = False
                annots = None
                try:
                    ia = bterm.get_ia(self._agent)
                    terms = ia.prepare_arguments(body, u)
                    result = ia.execute(self, u, terms)
                    if result is not None:
                        ok = result is True
                        if not ok and isinstance(result, Iterator):
                            first = next(result, None)
                            if first is not None:
                                # use the first unifier returned by the IA
                                im.unifier = first
                                ok = True
                        if not ok:
                            annots = error_annots("ia_failed", "")
                    if ok and not ia.suspend_intention():
                        self._continue_intention(intention)
                except Exception as e:
                    self._logger.exception("internal action '%s' raised", bterm.functor)
                    ok = False
                    annots = error_annots("ia_failed", str(e))
                if not ok:
                    self._generate_goal_deletion(intention, annots, Atom("ia_failed"))

            case BodyType.CONSTRAINT:
                consequences = bterm.logical_consequence(self._agent, u)
                first = next(consequences, None) if consequences is not None else None
                if first is not None:
                    im.unifier = first
                    self._continue_intention(intention)
                else:
                    msg = f"Constraint {h} was not satisfied ({h.src_info}) un={u}"
                    self._generate_goal_deletion(
                        intention, error_annots("constraint_failed", msg), Atom("constraint_failed"))
                    self._logger.debug(msg)

            # if/for/while -- language constructs, not internal actions (see
            # _exec_if/_exec_while/_exec_for): they splice the chosen branch
            # / loop body into the intention's plan-body chain in place of
            # this step, then let the normal step-by-step execution run it.
            case BodyType.IF:
                self._exec_if(bterm, im)
                self._continue_intention(intention)

            case BodyType.WHILE:
                self._exec_while(bterm, im)
                self._continue_intention(intention)

            case BodyType.FOR:
                self._exec_for(bterm, im)
                self._continue_intention(intention)

            # Rule Achieve
            case BodyType.ACHIEVE:
                body = self._prepare_body_for_event(body, u, intention.peek())
                self._circumstance.add_achieve_goal(body, intention)
                self._step_act = TransitionSystem.State.START_RC
                # TODO: check_hard_deadline not ported (needs a scheduler)

            # Rule Achieve as a New Focus (the !! operator)
            case BodyType.ACHIEVE_NF:
                body = self._prepare_body_for_event(body, u, None)
                self._circumstance.add_achieve_goal(body, None)
                self._continue_intention(intention)

            # Rule Test
            case BodyType.TEST:
                if self._agent.believes(bterm, u):
                    self._continue_intention(intention)
                else:
                    failed = True
                    # generate an event when testing a literal (no events for logical
                    # expressions like ?(a & b))
                    if bterm.is_literal() and not isinstance(bterm, BinaryStructure):
                        body = self._prepare_body_for_event(body, u, intention.peek())
                        if body.is_literal():
                            te = Trigger(TEOperator.ADD, TEType.TEST, body)
                            if self._agent.pl.has_candidate_plan(te):
                                self._circumstance.add_event(Event(te, intention))
                                self._step_act = TransitionSystem.State.START_RC
                                failed = False
                    if failed:
                        self._generate_goal_deletion(
                            intention, error_annots("test_goal_failed", f"Failed to test '{bterm}'"),
                            Atom("test_goal_failed"))

            case BodyType.DEL_ADD_BEL:
                # -+a(1,X) ===> remove a(_,_), add a(1,X)
                to_del = self._prepare_body_for_event(body, u, intention.peek())
                to_del.make_terms_annon()  # change all vars to anon vars to remove it
                result = self._agent.revise(None, to_del, intention)
                if result is not None:  # really deleted something: generate events
                    self.update_belief_events(result, None)
                self._add_belief(h, body, u, intention)  # Java falls through to addBel

            # Rule AddBel
            case BodyType.ADD_BEL | BodyType.ADD_BEL_BEGIN | BodyType.ADD_BEL_END | BodyType.ADD_BEL_NEW_FOCUS:
                self._add_belief(h, body, u, intention)

            case BodyType.DEL_BEL | BodyType.DEL_BEL_NEW_FOCUS:
                self._del_belief(h, body, u, intention)

    def _add_belief(self, h: PlanBody, body: Literal, u: Unifier, intention: Intention) -> None:
        # without Settings, sameFocus is the (Jason default) behaviour, except for ++
        new_focus = intention if h.body_type != BodyType.ADD_BEL_NEW_FOCUS else None
        body = self._prepare_body_for_event(body, u, intention.peek() if new_focus is not None else None)
        result = self._agent.revise(body, None, intention, add_end=(h.body_type == BodyType.ADD_BEL_END))
        if result is None or not self.update_belief_events(result, new_focus) or new_focus is None:
            self._continue_intention(intention)

    def _del_belief(self, h: PlanBody, body: Literal, u: Unifier, intention: Intention) -> None:
        new_focus = intention if h.body_type != BodyType.DEL_BEL_NEW_FOCUS else None
        body = self._prepare_body_for_event(body, u, intention.peek() if new_focus is not None else None)
        result = self._agent.revise(None, body, intention)
        if result is None or not self.update_belief_events(result, new_focus) or new_focus is None:
            self._continue_intention(intention)

    def _prepare_body_for_event(self, body: Literal, u: Unifier, im: IntendedMeans | None) -> Literal:
        body = body.resolve(u)
        renamed_vars = Unifier()
        # free variables in an event cannot conflict with those in the plan
        body.make_vars_annon(renamed_vars)
        if im is not None:
            im.renamed_vars = renamed_vars
        body = body.force_full_literal_impl()
        if not body.has_source():  # do not add source(self) if the programmer set one
            body.add_annot(BeliefBase.self_source_term)
        return body

    def clear_intention(self, intention: Intention | None) -> None:
        while True:
            # Rule ClrInt
            if intention is None:
                return
            if intention.is_finished():
                self._circumstance.drop_running_intention(intention)
                return
            im = intention.peek()
            if not im.is_finished():
                return  # nothing to do
            # TODO(JasonER): goal-condition plans (move to pending intentions) not ported

            # remove the finished IM from the top of the intention
            top_im = intention.pop()
            top_literal = top_im.trigger.literal
            if self._goal_listeners and top_im.trigger.is_goal():
                for gl in self._goal_listeners:
                    gl.goal_finished(top_im.trigger, GoalStates.ACHIEVED)
            llm_call_id = call_id_of(top_im.trigger)
            if llm_call_id is not None:
                self._deposit_llm_result(llm_call_id, top_im.trigger, top_im,
                                         GoalStates.ACHIEVED)

            # if a failure-handling IM (-!g) has just finished, get rid of the IMs
            # until the goal that has failure handling; e.g. the stack
            # [-!b, +!c, +!d, +!b, +!s: !b; !z] must become [+!s: !z]
            if top_im.trigger.is_goal() and not top_im.trigger.is_addition() and not intention.is_finished():
                im = intention.peek()
                if (im.is_finished()
                        or not (im.unifier.unifies(im.current_step.body_term, top_literal)
                                and im.current_step.body_type == BodyType.ACHIEVE)
                        or isinstance(im.current_step.body_term, VarTerm)):
                    im = intention.pop()  # the +!c above
                while (not intention.is_finished()
                       and not (im.unifier.unifies(im.trigger.literal, top_literal)
                                and im.trigger.is_goal())
                       and not (im.unifier.unifies(im.current_step.body_term, top_literal)
                                and im.current_step.body_type == BodyType.ACHIEVE)):
                    im = intention.pop()

            if not intention.is_finished():
                im = intention.peek()  # the +!s or +?s that called the finished goal
                if not im.is_finished():
                    # "returning" from the finished IM: unify the final event with
                    # the body term that called it (via the renamed vars)
                    self._join_renamed_vars(im, top_im.unifier)
                    im.remove_current_step()

    def _clear_selected_intention(self) -> None:
        self._step_act = TransitionSystem.State.START_RC
        self.clear_intention(self._circumstance.selected_intention)

    def _join_renamed_vars(self, im: IntendedMeans, values: Unifier) -> None:
        # get the vars renamed by make_vars_annon (stored in renamed_vars) and join
        # their values from `values` (the finished IM's unifier) into im's unifier
        if im.renamed_vars is None:
            return
        for outer_var, renamed_var in list(im.renamed_vars.function.items()):
            im.unifier.unifies_no_undo(outer_var, renamed_var)  # introduce the renaming
            value = values.function.get(renamed_var)
            if value is not None:  # the renamed var got a "return" value: bind it
                value = value.resolve(values)
                if value.is_literal():
                    value.make_vars_annon()
                im.unifier.bind(renamed_var, value)

    def _exec_if(self, structure: Term, im: IntendedMeans) -> None:
        u = im.unifier
        cond, then_body = structure.get_term(0), structure.get_term(1)
        consequences = cond.logical_consequence(self._agent, u)
        first = next(consequences, None)
        branch = None
        if first is not None:
            branch = then_body.clone()
            u.compose(first)
        elif structure.get_arity() == 3:
            branch = structure.get_term(2).clone()
        if branch is not None:
            branch.add(im.current_step.body_next)
            branch.is_body_term = False
            im.insert_as_next_step(branch)

    def _exec_while(self, structure: Term, im: IntendedMeans) -> None:
        # ag: re-evaluates cond on every call (no saved iterator, unlike
        # _exec_for); only a pre-loop backup unifier is threaded through
        # re-entries via an extra ObjectTerm arg on the cloned structure.
        u = im.unifier
        current_step = im.current_step
        if structure.get_arity() == 2:
            new_structure = structure.clone()
            reentrant = PlanBody(BodyType.WHILE, new_structure)
            reentrant.add(current_step.body_next)
            new_structure.add_terms(ObjectTerm(u.clone()))
        else:  # arity == 3: re-entrant call, restore the pre-loop backup unifier
            u.clear()
            u.compose(structure.get_term(2).value)
            reentrant = current_step

        cond, body = structure.get_term(0), structure.get_term(1)
        consequences = cond.logical_consequence(self._agent, u)
        first = next(consequences, None)
        if first is not None:
            u.compose(first)
            whattoadd = body.clone()
            whattoadd.add(reentrant)
            whattoadd.is_body_term = False
            im.insert_as_next_step(whattoadd)

    def _exec_for(self, structure: Term, im: IntendedMeans) -> None:
        # ag: solves cond once, lazily (a "forall" pattern -- never
        # enumerates every solution up front); the Iterator[Unifier] itself
        # and the pre-loop backup unifier are threaded through re-entries
        # via two extra ObjectTerm args on the cloned structure.
        u = im.unifier
        current_step = im.current_step
        if structure.get_arity() == 2:
            cond = structure.get_term(0)
            consequences = cond.logical_consequence(self._agent, u.clone())
            first = next(consequences, None)
            if first is None:
                return  # no solutions at all: nothing to splice
            iterator = itertools.chain([first], consequences)
            new_structure = structure.clone()
            reentrant = PlanBody(BodyType.FOR, new_structure)
            reentrant.add(current_step.body_next)
            new_structure.add_terms(ObjectTerm(iterator), ObjectTerm(u.clone()))
        else:  # arity == 4: re-entrant call
            iterator = structure.get_term(2).value
            reentrant = current_step

        u.clear()
        body = structure.get_term(1)
        nxt = next(iterator, None)
        if nxt is not None:
            u.compose(nxt)
            whattoadd = body.clone()
            whattoadd.add(reentrant)
            whattoadd.is_body_term = False
            im.insert_as_next_step(whattoadd)
        else:
            u.compose(structure.get_term(3).value)  # exhausted: restore pre-loop unifier

    def _continue_intention(self, intention: Intention) -> None:
        # remove the executed step and requeue the intention as running
        if not intention.is_finished():
            intention.peek().remove_current_step()
            self._circumstance.add_running_intention(intention)
        else:
            self._logger.debug("trying to update a finished intention!")

    ### events and failure #############################################

    def update_events(self, event: Event) -> None:
        # events are added even when not relevant, to let a custom select_option
        # provide an "unknown" plan and to let the failure event be created later
        self._circumstance.add_event(event)

    def update_belief_events(self, result: tuple[list[Literal], list[Literal]],
                              focus: Intention | None) -> bool:
        added, deleted = result
        event_added = False
        for op, literals in ((TEOperator.ADD, added), (TEOperator.DEL, deleted)):
            for lit in literals:
                if lit.is_rule():
                    continue
                self.update_events(Event(Trigger(op, TEType.BELIEF, lit), focus))
                event_added = True
                focus = None  # only the first event keeps the focus intention
        return event_added

    def _generate_goal_deletion(self, intention: Intention, fail_annots: ListTerm | None,
                                reason: Term | None) -> bool:
        # generate a failure event (-!g) for the intention
        im = intention.peek()
        # ag: the single funnel every goal failure passes through -- action
        # failures, .fail, a failed test goal, an internal action that raised.
        # Journalled here rather than at each of those sites, and kept as its
        # own entry rather than folded into a state line because a failure is
        # the question a reader arrives with.
        self._agent.journal.record(JournalKind.GOAL_FAILED, goal=trigger_text(im.trigger),
                                   reason=reason, detail=fail_annots)
        # ag: a goal the model asked for is a wall failures do not cross. A
        # -!g plan at or above it still handles the failure as usual; one
        # below it -- the plan that opened the session, or anything under
        # that -- is not consulted, because the mistake is the model's and the
        # answer to it is a tool result, not the end of the caller's plan.
        boundary = self._llm_boundary(intention)
        if boundary is not None:
            _, pos_in_stack = Intention.find_event_for_failure(
                intention, im.trigger, self._agent.pl, self._circumstance)
            # a handler found at the frame k down from the top comes back as
            # pos_in_stack = size - k - 1 (or size, when the failing top
            # frame's own trigger has one): below the boundary means k > boundary
            if pos_in_stack < intention.size() - boundary - 1:
                self._contain_llm_failure(intention, boundary, _explained(fail_annots, reason),
                                          reason)
                return True
        fail_event = self._find_event_for_failure(intention, im.trigger)
        fail_event_is_relevant = fail_event is not None
        if not fail_event_is_relevant:
            fail_event = Event(im.trigger.clone(), intention)
        if im.current_step is not None and im.current_step.body_term is not None:
            body_part = im.current_step.body_term.resolve(im.unifier)
            self._add_default_failure_annots(fail_event, body_part, fail_annots)

        if fail_event.trigger.is_goal():
            if self._goal_listeners:
                for gl in self._goal_listeners:
                    gl.goal_failed(im.trigger, reason)
                    if fail_event_is_relevant:
                        gl.goal_executing(im.trigger, create_atom("has_failure_plan"))
                    else:
                        gl.goal_finished(im.trigger, None)
                        for oim in intention:
                            if oim is not im:
                                gl.goal_finished(oim.trigger, GoalStates.FAILED)
            if fail_event_is_relevant:
                self._circumstance.add_event(fail_event)
            else:
                # ag: no failure plan, so this is where the goal ends -- with a
                # -!g plan it would still have somewhere to go, and reporting a
                # failure the agent is in the middle of handling would be a lie
                told = _explained(fail_annots, reason)
                for oim in intention:
                    llm_call_id = call_id_of(oim.trigger)
                    if llm_call_id is not None:
                        self._deposit_llm_result(llm_call_id, oim.trigger, oim,
                                                 GoalStates.FAILED, told)
                self._logger.warning("No failure event was generated for %s", fail_event.trigger)
                intention.fail(self._circumstance)
                self._circumstance.drop_intention(intention)
        else:
            self._logger.warning("Could not finish intention: %s (trigger: %s)",
                                 intention, fail_event.trigger)
        return fail_event_is_relevant

    @staticmethod
    def _llm_boundary(intention: Intention) -> int | None:
        """Where, counting from the top of the stack, the nearest frame a
        model asked for is -- or None when nothing in it came from a model.

        Both roads a tool call takes leave such a frame: a `!goal` step's plan
        (Icaros.goal_step) and an internal action's synthetic llm_tool_call
        plan (Icaros.add_tool_call). Each carries llm_call(...) on its trigger.
        """
        for index, im in enumerate(intention):
            if call_id_of(im.trigger) is not None:
                return index
        return None

    def _contain_llm_failure(self, intention: Intention, boundary: int, told: Term | None,
                             reason: Term | None) -> None:
        """Ends a failure at the goal the model asked for, instead of letting
        it go on down to the plan that opened the session.

        The frames from the top down to the boundary are popped -- each one
        the model asked for answered FAILED -- and the frame underneath
        "returns" from its call exactly as clear_intention would after a
        success: the `!goal` (or the suspended .icaros_step) is done with, and
        the next step is .icaros_consider_results, which hands the failure
        back to the model as the answer to its call.
        """
        for _ in range(boundary + 1):
            popped = intention.pop()
            llm_call_id = call_id_of(popped.trigger)
            if llm_call_id is not None:
                self._deposit_llm_result(llm_call_id, popped.trigger, popped,
                                         GoalStates.FAILED, told)
            if self._goal_listeners and popped.trigger.is_goal():
                for gl in self._goal_listeners:
                    gl.goal_failed(popped.trigger, reason)
                    gl.goal_finished(popped.trigger, GoalStates.FAILED)
        self._resume_after_llm_failure(intention)

    def _resume_after_llm_failure(self, intention: Intention) -> None:
        """The caller of a failed model goal moves past the call and runs on."""
        if intention.is_finished():
            return
        intention.peek().remove_current_step()
        if not self._circumstance.has_running_intention(intention):
            self._circumstance.add_running_intention(intention)

    def _generate_goal_deletion_from_event(self, fail_annots: ListTerm | None,
                                           reason: Term | None) -> bool:
        # as _generate_goal_deletion, but for the selected event rather than an intention
        event = self._circumstance.selected_event
        if event is None:
            self._logger.warning("Could not generate a goal deletion event: SE is None")
            return False

        trigger = event.trigger
        fail_event_generated = False
        if (trigger.is_addition() and trigger.is_goal() and call_id_of(trigger) is not None
                and event.intention is not None
                and not self._agent.pl.has_candidate_plan(
                    Trigger(TEOperator.DEL, trigger.type, trigger.literal))):
            # ag: a goal the model asked for that nobody has a plan for -- the
            # same wall as in _generate_goal_deletion: the model hears about
            # it, the intention that carries the session goes on.
            self._deposit_llm_result(call_id_of(trigger), trigger, None, GoalStates.FAILED,
                                     _explained(fail_annots, reason))
            if self._goal_listeners:
                for gl in self._goal_listeners:
                    gl.goal_failed(trigger, reason)
                    gl.goal_finished(trigger, GoalStates.FAILED)
            self._resume_after_llm_failure(event.intention)
            return True
        if trigger.is_addition() and trigger.is_goal():
            fail_event = self._find_event_for_failure(event.intention, trigger)
            if fail_event is not None:
                self._add_default_failure_annots(fail_event, trigger.literal, fail_annots)
                self._circumstance.add_event(fail_event)
                fail_event_generated = True
            else:
                self._logger.warning("No fail event was generated for %s", trigger)
                if event.intention is not None:
                    event.intention.fail(self._circumstance)
                    self._circumstance.drop_intention(event.intention)
            if self._goal_listeners:
                for gl in self._goal_listeners:
                    gl.goal_failed(trigger, reason)
                    if fail_event_generated:
                        gl.goal_executing(trigger, create_atom("has_failure_plan"))
                    else:
                        gl.goal_finished(trigger, None)
                        if event.intention is not None:
                            for im in event.intention:
                                gl.goal_finished(im.trigger, GoalStates.FAILED)
            if not fail_event_generated:
                # ag: no failure plan, so this is where the goal ends. There is
                # no intended means -- the deletion was raised from the event --
                # so there are no bindings to report either: a goal nobody had a
                # plan for arrives here, and saying so is the whole point.
                llm_call_id = call_id_of(trigger)
                if llm_call_id is not None:
                    self._deposit_llm_result(llm_call_id, trigger, None,
                                             GoalStates.FAILED, reason)
        elif event.is_internal():
            self._logger.warning("Could not finish intention: %s", event.intention)
        else:
            self._logger.warning("Discarding external event: %s", event)
        return fail_event_generated

    def _find_event_for_failure(self, intention: Intention | None, trigger: Trigger) -> Event | None:
        if intention is not None:
            # TODO(JasonER): should use the plan library scoped to intention.peek()
            return intention.find_event_for_failure(trigger, self._agent.pl, self._circumstance)[0]
        if trigger.is_goal() and trigger.is_addition():
            fail_trigger = Trigger(TEOperator.DEL, trigger.type, trigger.literal)
            if self._agent.pl.has_candidate_plan(fail_trigger):
                return Event(fail_trigger.clone(), intention)
        return None

    @staticmethod
    def _add_default_failure_annots(fail_event: Event, body: Term | None,
                                    fail_annots: ListTerm | None) -> None:
        # default error annots (error, error_msg, code, code_src, code_line)
        if fail_annots is None:
            fail_annots = error_annots("unknown_error", "")

        event_literal = fail_event.trigger.literal.force_full_literal_impl()
        fail_event.trigger.literal = event_literal  # force_full may have copied
        event_literal.add_annots(*fail_annots)

        # failure annots related to the source of the code that failed
        if body is not None and body.is_literal():
            event_literal.add_source_info_as_annots(body.src_info)
            code_body = body
        else:
            code_body = Atom("no_code")
        if event_literal.get_annot("code") is None:
            event_literal.add_annot(create_structure("code", code_body.copy().make_vars_annon()))

    ### main loop ######################################################

    def reasoning_cycle(self) -> None:
        self._cycle_count += 1
        self.sense()
        self.deliberate()
        self.act()

    def sense(self) -> None:
        self._circumstance.reset_sense()

        # Jason's sense(): the architecture hands over the current perception
        # (None if nothing changed) and the agent's BUF reconciles its
        # [source(percept)] beliefs with it
        self._agent.buf(self._ag_arch.perceive())
        self._ag_arch.check_mail()

        # produce sleep/awake events for the jag_* plans
        if self._agent.pl.has_jag_plans:
            if self.can_sleep():
                if not self._sleeping_event:
                    self._sleeping_event = True
                    self._circumstance.add_external_event(PlanLibrary.TE_JAG_SLEEPING)
            elif self._sleeping_event:
                self._sleeping_event = False
                self._circumstance.add_external_event(PlanLibrary.TE_JAG_AWAKING)

        self._step_sense = TransitionSystem.State.START_RC
        while True:
            self._advance_sense()
            self._journal_state(JournalKind.SENSE)
            if self._step_sense == TransitionSystem.State.SEL_EV or not self._ag_arch.is_running():
                return

    def deliberate(self) -> None:
        self._circumstance.reset_deliberate()

        # run the tasks scheduled for the beginning of the cycle (e.g. by .wait).
        # ag: only a snapshot of what's queued *now* -- a task that reschedules
        # itself (e.g. .wait's per-cycle condition recheck) must wait for the
        # NEXT cycle, not busy-loop forever right here draining its own re-adds.
        for _ in range(len(self._tasks_for_begin_of_cycle)):
            self._tasks_for_begin_of_cycle.popleft()()

        # ag: GENERATE is dead (kept below, unreachable, until stage 3's
        # cleanup pass) -- an open icaros session is now a .icaros_step call
        # spliced into its own intention's body (generation.py's _open), so
        # it is served by ordinary SEL_INT/EXEC_INT like any other running
        # intention, not by a dedicated state entered here.
        self._step_deliberate = TransitionSystem.State.SEL_EV
        while True:
            self._advance_deliberate()
            self._journal_state(JournalKind.DELIBERATE)
            if self._step_deliberate == TransitionSystem.State.PROC_ACT or not self._ag_arch.is_running():
                return

    def act(self) -> None:
        self._circumstance.reset_act()

        # ag: the act-line dedup below is scoped to ONE cycle. Without this
        # reset a plan that runs the same step twice in a row (a !tick
        # self-loop, anything polling) journals it only the first time, and a
        # reader -- the Reasoning card, a model reading its own past -- sees a
        # cycle in which the agent apparently did nothing.
        self._last_act = None
        self._step_act = TransitionSystem.State.PROC_ACT
        while True:
            self._advance_act()
            self._journal_state(JournalKind.ACT)
            if self._step_act == TransitionSystem.State.START_RC or not self._ag_arch.is_running():
                break

        action = self._circumstance.action
        if action is not None:
            self._circumstance.add_pending_action(action)
            self._ag_arch.act(action)

    def can_sleep(self) -> bool:
        c = self._circumstance
        # ag: has_feedback_action() walks the FA deque under a lock -- compute
        # it once rather than twice per call.
        has_feedback = c.has_feedback_action()
        # ag: no _needs_generate() check any more -- an open icaros session's
        # intention is an ordinary running intention (generation.py's _open),
        # so has_running_intentions() alone already keeps the agent awake for
        # it, the same way it does for any other goal in progress.
        return ((c.is_atomic_intention_suspended() and not has_feedback and not c.mailbox)
                or (not c.has_event() and not c.has_running_intentions()
                    and not has_feedback and not c.mailbox
                    and not self._tasks_for_begin_of_cycle and self._ag_arch.can_sleep_on_mailbox()))

    def can_sleep_sense(self) -> bool:
        return not self._circumstance.mailbox and self._ag_arch.can_sleep_on_mailbox()

    def can_sleep_deliberate(self) -> bool:
        return (not self._circumstance.has_event() and not self._tasks_for_begin_of_cycle
                and self._circumstance.selected_event is None
                and self._ag_arch.can_sleep_on_mailbox())

    def can_sleep_act(self) -> bool:
        return (not self._circumstance.has_running_intentions()
                and not self._circumstance.has_feedback_action()
                and self._circumstance.selected_intention is None and self._ag_arch.can_sleep_on_mailbox())

    def _deposit_llm_result(self, call_id: str, trigger: Trigger, im: IntendedMeans | None,
                            outcome: GoalStates, reason: Term | None = None) -> None:
        """Leaves the result of a goal the model asked for in the Circumstance.

        `call_id` comes from the caller, which has already established that
        this goal is one the model asked for -- see call_id_of.

        ag: here, and not in a listener, because here the intended means is
        already in hand -- im.unifier is the only place the answer exists and
        it dies with the frame a line later.

        Deposited and nothing more: nobody is notified, nothing is woken. The
        model finds the answer waiting when its own turn in the reasoning
        cycle comes round.
        """
        # ag: a failed goal is reported from more than one place on its way
        # down; the first report is the answer, the rest are echoes of it
        if any(r.call_id == call_id for r in self._circumstance.llm_results):
            return
        values: dict[str, str] = {}
        # ag: annotations stripped before this is shown to anyone -- source(llm)
        # and llm_call(...) are the interpreter's own bookkeeping, stamped on
        # by Icaros._stamp for correlation, and no more meant for a model to
        # read than a database's own internal row id is. tool_name_of below
        # reads the same annotation before it is gone.
        goal = str(trigger.literal.copy().set_annots(None))
        if im is not None:
            # the variables still free in im.trigger ARE the outputs: the
            # trigger was resolved when the intended means was built, so
            # whatever is still a variable there is what was left to come back
            try:
                for term in trigger.literal.get_terms() or ():
                    if term.is_var():
                        # the term itself, not str(term): a renamed variable
                        # is an UnnamedVar, and a VarTerm of the same name is
                        # not the same key in the unifier
                        bound = im.unifier.get(term)
                        if bound is not None:
                            values[_answer_name(term)] = str(bound.resolve(im.unifier))
                goal = str(trigger.literal.resolve(im.unifier).copy().set_annots(None))
            except Exception:  # an answer that cannot be read must not take the cycle down
                self._logger.warning("Could not read the answer of %s", trigger)
        # ag: taken here and not above the duplicate guard -- an echo of a
        # failure must not walk off with the belief changes the first report
        # is about to carry.
        self._circumstance.add_llm_result(LlmToolResult(
            call_id=call_id, session=session_of(trigger), goal=goal, outcome=outcome,
            values=values, beliefs=self._circumstance.take_llm_belief_changes(call_id),
            reason=None if reason is None else str(reason), cycle=self._cycle_count,
            tool_name=tool_name_of(trigger)))

    def run_at_begin_of_next_cycle(self, task: Callable[[], None]) -> None:
        # schedule a task for the beginning of the next reasoning cycle; used mostly
        # to change the Circumstance only from the TS thread (e.g. by .wait)
        self._tasks_for_begin_of_cycle.append(task)
        self._ag_arch.wake()

from __future__ import annotations

import uuid


class Message:

    _id_prefix = "mid"
    _id_synk_ask_prefix = "samid"
    kqml_received_functor = "kqml_received"
    kqml_default_plans = "asl/kqml_plans.asl"

    def __init__(self, ilf, sender, receiver, content, id = None):
        self._il_force = ilf
        self._sender = sender
        self._receiver = receiver
        self._content = content
        if id is not None:
            self._id = id
        else:
            self._id = self._id_prefix + str(uuid.uuid4())
        self._in_reply_to = None

        self.known_performatives = ["tell", "untell", "achieve", "unachieve", "askOne", "askAll", "tellHow", "untellHow", "askHow"]

    def set_sync_ask_msg_id(self):
        self._id = self._id_synk_ask_prefix + str(uuid.uuid4())

    @property
    def il_force(self):
        return self._il_force

    @il_force.setter
    def il_force(self, value):
        if value == "ask-one":
            self._il_force = "askOne"
            return
        if value == "ask-all":
            self._il_force = "askAll"
            return
        if value == "tellHow":
            self._il_force = "tellHow"
            return
        if value == "untellHow":
            self._il_force = "untellHow"
            return
        if value == "ask-how":
            self._il_force = "askHow"
            return
        self._il_force = value

    def is_ask(self):
        return self._il_force.startswith("ask")

    def is_tell(self):
        return self._il_force.startswith("tell")

    def is_untell(self):
        return self._il_force.startswith("untell")

    def is_reply_to_sync_ask(self):
        return self._in_reply_to is not None and self._in_reply_to.startswith(self._id_synk_ask_prefix)

    def is_known_performative(self):
        return self._il_force in self.known_performatives

    @property
    def content(self):
        return self._content

    @content.setter
    def content(self, value):
        self._content = value

    @property
    def receiver(self):
        return self._receiver

    @receiver.setter
    def receiver(self, value):
        self._receiver = value

    @property
    def sender(self):
        return self._sender

    @sender.setter
    def sender(self, value):
        self._sender = value

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, value):
        self._id = value

    @property
    def in_reply_to(self):
        return self._in_reply_to

    @in_reply_to.setter
    def in_reply_to(self, value):
        self._in_reply_to = value

    def __str__(self):
        irt : str = "" if not self.in_reply_to else "->" + self.in_reply_to
        return f"<{self.id}{irt},{self.sender},{self.il_force},{self.receiver},{self.content}"

    def __repr__(self) -> str:
        return str(self)
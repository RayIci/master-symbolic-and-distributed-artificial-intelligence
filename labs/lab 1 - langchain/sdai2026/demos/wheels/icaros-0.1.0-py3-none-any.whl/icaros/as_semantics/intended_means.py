from __future__ import annotations

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.logical_formula import LogicalFormula
from icaros.as_syntax.plan_body import PlanBody
from icaros.as_syntax.plan import Plan
from icaros.as_semantics.option import Option
from icaros.as_syntax.trigger import Trigger
from icaros.as_syntax.term import Term
from icaros.as_semantics.unifier import Unifier


class IntendedMeans:

    def __init__(self, option: Option | object = _unset, trigger: Trigger | None | object = _unset):
        # ag: Java's IntendedMeans(Option,Trigger) / private IntendedMeans()
        # [used by clone] overloads collapsed here, same sentinel pattern as
        # Plan.__init__. The no-arg form leaves every field empty and is only
        # for clone() below, which assigns them all itself -- going through the
        # normal constructor would re-resolve the trigger against the unifier.
        self._plan: Plan | None = None
        self._plan_body: PlanBody | None = None
        self._unifier: Unifier | None = None
        self._trigger: Trigger | None = None
        self._trigger_unifier: Unifier | None = None
        self._renamed_vars: Unifier | None = None
        if option is _unset:
            return

        self._plan = option.plan
        self._plan_body = option.plan.get_body()
        self._unifier = option.unifier

        if trigger is None or trigger is _unset:
            self._trigger = self._plan.trigger.resolve(self._unifier)
        else:
            self._trigger = trigger.resolve(self._unifier)
        self._trigger_unifier = self._unifier.clone()

    def clone(self) -> IntendedMeans:
        """A copy that shares nothing mutable with this one except the plan
        itself (Java's IntendedMeans.clone). Used by .fork to give each branch
        its own continuation of the frame that called it."""
        c = IntendedMeans()
        c._plan = self._plan
        c._plan_body = self._plan_body.clone_pb() if self._plan_body is not None else None
        c._unifier = self._unifier.clone()
        c._trigger = self._trigger.clone()
        if self._trigger_unifier is not None:
            c._trigger_unifier = self._trigger_unifier.clone()
        c._renamed_vars = self._renamed_vars
        return c

    def remove_current_step(self) -> Term | None:
        if self.is_finished():
            return None
        body_term = self._plan_body.body_term
        self._plan_body = self._plan_body.body_next
        return body_term

    @property
    def current_step(self) -> PlanBody:
        return self._plan_body

    def insert_as_next_step(self, new_step: PlanBody) -> PlanBody:
        self._plan_body = PlanBody(self._plan_body.body_type, self._plan_body.body_term)
        self._plan_body.body_next = new_step
        return self._plan_body

    @property
    def plan(self) -> Plan:
        return self._plan

    @property
    def trigger_unifier(self) -> Unifier:
        return self._trigger_unifier

    @property
    def renamed_vars(self) -> Unifier | None:
        # ag: bookkeeping set by TransitionSystem._prepare_body_for_event -- tracks vars
        # anonymised for an outgoing event, so a later ClrInt can join back any binding
        # the sub-goal produced for them.
        return self._renamed_vars

    @renamed_vars.setter
    def renamed_vars(self, renamed_vars: Unifier | None) -> None:
        self._renamed_vars = renamed_vars

    @property
    def unifier(self) -> Unifier:
        return self._unifier

    @unifier.setter
    def unifier(self, unifier: Unifier):
        self._unifier = unifier

    @property
    def trigger(self) -> Trigger:
        return self._trigger

    @trigger.setter
    def trigger(self, trigger: Trigger):
        self._trigger = trigger

    def is_atomic(self) -> bool:
        return self._plan is not None and self._plan.is_atomic()

    def is_finished(self) -> bool:
        return self._plan_body is None or self._plan_body.is_empty_body()

    def is_satisfied(self, agent: Agent) -> bool:
        goal_condition: LogicalFormula = self.plan.goal_condition
        if goal_condition is None:
            return False
        unif_iterator = goal_condition.logical_consequence(agent, self._trigger_unifier)
        return unif_iterator is not None and next(unif_iterator) is not None

    def __str__(self) -> str:
        string = str(self._trigger)
        if self._plan_body is None:
            string += "."
        else:
            string += "... " + str(self._plan_body)
        string += " / " + str(self._unifier)
        return string

class IMCondition:
    """Matches an IntendedMeans whose trigger unifies with `trigger`. Concrete,
    not abstract: unlike Java (which needs a fresh anonymous subclass per
    condition shape), the one shape actually needed here doesn't need
    polymorphism at all -- if a future action needs a different kind of
    condition (e.g. testing an IntendedMeans' own goal-condition rather than
    its trigger), that's a reason to add a parameter/branch here, not to grow
    a subclass hierarchy for it."""

    def __init__(self, trigger: Trigger):
        self._trigger = trigger

    def test(self, im: IntendedMeans, unifier: Unifier) -> bool:
        return unifier.unifies(self._trigger, im.trigger)

    @property
    def trigger(self) -> Trigger:
        return self._trigger
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_semantics.event import Event
    from icaros.as_semantics.intention import Intention
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.trigger import Trigger


class CircumstanceListener:
    """Callback interface to be notified about changes to a Circumstance
    (events, intentions). Mirrors Jason's CircumstanceListener, whose
    methods are all `default` no-ops so an implementation overrides only
    the callbacks it cares about -- reproduced here as a plain base class
    with no-op bodies rather than typing.Protocol (structural, so a
    partial override would AttributeError inside the notify loop) or an
    ABC (nothing here needs to be enforced)."""

    def event_added(self, event: Event) -> None: ...

    def intention_added(self, intention: Intention) -> None: ...

    def intention_dropped(self, intention: Intention) -> None: ...

    def intention_suspended(self, trigger: Trigger | None, intention: Intention | None,
                             reason: Term | None) -> None: ...

    def intention_waiting(self, intention: Intention, reason: Term | None) -> None: ...

    def intention_resumed(self, intention: Intention, reason: Term | None) -> None: ...

    def intention_executing(self, intention: Intention, reason: Term | None) -> None: ...
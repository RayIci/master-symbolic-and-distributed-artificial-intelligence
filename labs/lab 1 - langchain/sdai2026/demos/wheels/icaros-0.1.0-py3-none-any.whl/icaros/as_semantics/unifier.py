from __future__ import annotations

import logging
from collections.abc import Iterator
from typing import TYPE_CHECKING

from icaros.as_syntax.cyclic_term import CyclicTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.literal_impl import LiteralImpl
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.plan_body import BodyType, PlanBody
from icaros.as_syntax.pred import Pred
from icaros.as_syntax.trigger import Trigger
from icaros.as_syntax.unnamed_var import UnnamedVar
from icaros.as_syntax.var_term import VarTerm

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term

# ag: jason.asSyntax.directives.NameSpace.LOCAL_PREFIX -- directives/ is out of scope
# for this port, so only the constant value is carried over here.
LOCAL_NS_PREFIX = "#"

class Unifier:

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self):
        self._function: dict[VarTerm, Term] = {}

    # ag: Java's get(String)/get(VarTerm) merged
    def get(self, v: str | VarTerm) -> Term | None:
        if isinstance(v, str):
            v = VarTerm(v)
        vl = self._function.get(v)
        if vl is not None and vl.is_var():  # optimised deref
            return self.get(vl)
        return vl

    # ag: Java exposes the raw map as the public field `function`; needed where the
    # deref-ing get() is wrong (e.g. renamed-vars maps whose values are unbound vars)
    @property
    def function(self) -> dict[VarTerm, Term]:
        return self._function

    def remove(self, v: VarTerm) -> Term | None:
        return self._function.pop(v, None)

    def __iter__(self) -> Iterator[VarTerm]:
        return iter(self._function)

    # ----- Unify for Triggers
    # ag: Java overloads unifies/unifiesNoUndo by (Trigger,Trigger) vs (Term,Term);
    # Python can't overload, and unlike bind()'s merge, the runtime type here doesn't
    # reliably distinguish "wants Trigger semantics" (same_type check first) from
    # "wants generic Term semantics" since Trigger is itself a Term/Structure -- kept
    # as distinctly-named methods instead of merging via isinstance.

    def unifies_trigger(self, te1: Trigger, te2: Trigger) -> bool:
        return te1.same_type(te2) and self.unifies(te1.literal, te2.literal)

    def unifies_no_undo_trigger(self, te1: Trigger, te2: Trigger) -> bool:
        return te1.same_type(te2) and self.unifies_no_undo(te1.literal, te2.literal)

    # ----- Unify for Predicates/Literals

    # this version of unifies undoes the variables' mapping if the unification fails.
    # E.g. u.unifies(a(X,10), a(1,1)) does not change u, i.e. u = {}
    def unifies(self, t1: Term, t2: Term) -> bool:
        cfunction = dict(self._function)
        if self.unifies_no_undo(t1, t2):
            return True
        else:
            self._function = cfunction
            return False

    # this version does not undo the variables' mapping in case of failure. It is
    # however faster than the version with undo.
    # E.g. u.unifies_no_undo(a(X,10), a(1,1)) fails, but changes u to {X = 10}
    def unifies_no_undo(self, t1g: Term | None, t2g: Term | None) -> bool:
        if t1g is None and t2g is None:
            return True
        if t1g is None and t2g is not None:
            return False
        if t1g is not None and t2g is None:
            return False

        np1: Pred | None = None
        np2: Pred | None = None

        if isinstance(t1g, Pred) and isinstance(t2g, Pred):
            np1 = t1g
            np2 = t2g

            # tests when np1 or np2 are vars with annots
            if (np1.is_var() and np1.has_annot()) or (np2.is_var() and np2.has_annot()):
                if not np1.has_subset_annot(np2, self):
                    return False

        if t1g.is_cyclic_term() and t2g.is_cyclic_term():  # both are cyclic terms
            # unification of cyclic terms: remove the vars (to avoid loops) and test
            # just the structure, then reintroduce the vars
            v1 = t1g.cyclic_var
            v2 = t2g.cyclic_var
            self.remove(v1)
            self.remove(v2)
            try:
                return self.unifies_no_undo(LiteralImpl(t1g), LiteralImpl(t2g))
            finally:
                # ag: Java's restore here puts t1g back for BOTH v1 and v2 -- a
                # copy-paste bug (v2 should map back to t2g). Fixed here.
                self._function[v1] = t1g
                self._function[v2] = t2g
        else:
            if t1g.is_cyclic_term() and self.get(t1g.cyclic_var) is None:  # reintroduce cycles
                self._function[t1g.cyclic_var] = t1g
            if t2g.is_cyclic_term() and self.get(t2g.cyclic_var) is None:
                self._function[t2g.cyclic_var] = t2g

        # unify as Term
        ok = self._unify_terms(t1g, t2g)

        # if np1 is a var that was unified, clear its annots, as in
        #     X[An] = p(1)[a,b]
        # X is mapped to p(1) and not p(1)[a,b] (if the user wants the "remaining"
        # annots, they should write X[An|R] = p(1)[a,b]; X = p(1), An = a, R = [b])
        if ok and np1 is not None:  # they are predicates
            if np1.is_var() and np1.has_annot():
                np1 = self.deref(np1)
                np1vl = self._function.get(np1)
                if np1vl is not None and np1vl.is_pred():
                    pvl = np1vl.clone()
                    pvl.clear_annots()
                    self.bind(np1, pvl)
            if np2.is_var() and np2.has_annot():
                np2 = self.deref(np2)
                np2vl = self._function.get(np2)
                if np2vl is not None and np2vl.is_pred():
                    pvl = np2vl.clone()
                    pvl.clear_annots()
                    self.bind(np2, pvl)

        return ok

    # ----- Unify for Terms

    def _unify_terms(self, t1g: Term, t2g: Term) -> bool:
        # if args are expressions, resolve them and use their values
        if t1g.is_arith_expr():
            t1g = t1g.resolve(self)
        if t2g.is_arith_expr():
            t2g = t2g.resolve(self)

        t1gisvar = t1g.is_var()
        t2gisvar = t2g.is_var()

        # one of the args is a var
        if t1gisvar or t2gisvar:
            t1gv = t1g if t1gisvar else None
            t2gv = t2g if t2gisvar else None

            # get their values
            t1vl = self.get(t1gv) if t1gisvar else t1g
            t2vl = self.get(t2gv) if t2gisvar else t2g

            if t1vl is not None and t2vl is not None:  # unifies the two values of the vars
                return self.unifies_no_undo(t1vl, t2vl)
            elif t1vl is not None:  # unifies var with value
                return self.bind(t2gv, t1vl)
            elif t2vl is not None:
                return self.bind(t1gv, t2vl)
            else:  # unify two vars
                if not self._unify_terms(t1gv.ns, t2gv.ns):
                    return False
                if t1gv.negated() != t2gv.negated():
                    return False
                self.bind(t1gv, t2gv)
                return True

        # both terms are not vars

        # if any of the terms is not a literal (is a number or a string), they must
        # be equal (for unification, lists are literals)
        if (not t1g.is_literal() and not t1g.is_list()) or (not t2g.is_literal() and not t2g.is_list()):
            return t1g == t2g

        # case of plan body
        if t1g.is_plan_body() and t2g.is_plan_body():
            pb1 = t1g
            pb2 = t2g

            if pb1.body_term is None and pb2.body_term is None:
                return True
            if pb1.body_term is None and pb2.body_term is not None:
                return False
            if pb2.body_term is None and pb1.body_term is not None:
                return False

            if pb1.body_term.is_var() and pb2.body_term.is_var():
                if self.unifies_no_undo(pb1.body_term, pb2.body_term):
                    return self.unifies_no_undo(pb1.body_next, pb2.body_next)
                else:
                    return False

            if pb1.body_term.is_var():
                # single vars (as in "B") are considered as type action
                if pb1.body_type != BodyType.ACTION and pb1.body_type != pb2.body_type:
                    return False  # if not action, must have the same type
                if pb1.body_type == BodyType.ACTION and pb1.body_next is None:
                    # last var (unifies the remaining plan body): {A} = {!a,b,c} ==> A = {!a,b,c}
                    return self.unifies_no_undo(pb1.body_term, pb2)
                if pb2.body_term is None:
                    return False

                if ((pb1.body_type == BodyType.ACTION and self.unifies_no_undo(pb1.body_term, pb2.get_head()))
                        or (pb1.body_type != BodyType.ACTION and self.unifies_no_undo(pb1.body_term, pb2.body_term))):
                    if (pb1.body_next is not None and pb2.body_next is None
                            and pb1.body_next.body_term.is_var()
                            and pb1.body_next.body_next is None):
                        # case of {A;T} = {a}, A => a, T => {}
                        return self.unifies_no_undo(pb1.body_next.body_term, PlanBody())
                    else:
                        # keep testing the remaining of the plan body
                        return self.unifies_no_undo(pb1.body_next, pb2.body_next)
                # ag: falls through to generic literal comparison below if the
                # condition above is False (matches Java's fall-through here)

            elif pb2.body_term.is_var():
                return self.unifies(pb2, pb1)
            # ag: falls through to generic literal comparison below if neither
            # side's body term is a var

        # both terms are literal

        t1s: Literal = t1g
        t2s: Literal = t2g

        # different functor
        if t1s.functor != t2s.functor:
            return False

        # the special case of [|T]=[a,b,c] and [|T]=[]
        if t1s.is_list() and t1s.get_term(0) is None and t1s.is_tail():
            return self.unifies_no_undo(t1s.get_term(1), t2s)
        if t2s.is_list() and t2s.get_term(0) is None and t2s.is_tail():
            return self.unifies_no_undo(t1s, t2s.get_term(1))

        # different arities
        ts = t1s.get_arity()
        if ts != t2s.get_arity():
            return False

        # if both are literal, they must have the same negation
        if t1s.negated() != t2s.negated():
            return False

        # different name space
        if not self._unifies_namespace(t1s, t2s):
            return False

        # unify inner terms
        for i in range(ts):
            if not self.unifies_no_undo(t1s.get_term(i), t2s.get_term(i)):
                return False

        # the first's annots must be a subset of the second's annots
        if not t1s.has_subset_annot(t2s, self):
            return False

        return True

    def _unifies_namespace(self, t1s: Literal, t2s: Literal) -> bool:
        if t1s is Literal.default_ns and t2s is Literal.default_ns:  # if both are the default NS
            return True

        # compares the name spaces of t1s and t2s
        t1s = t1s.ns
        t2s = t2s.ns
        if t1s == t2s:  # just to speed up and avoid all the details of unifies_no_undo
            return True
        return self.unifies_no_undo(t1s, t2s)

    def deref(self, v: VarTerm) -> VarTerm:
        vl = self._function.get(v)

        first = v
        while vl is not None and vl.is_var():
            v = vl
            vl = self._function.get(v)
        if first != v:
            self._function[first] = v  # optimise map
        return v

    # ag: Java's bind(VarTerm,VarTerm) [returns void, picks canonical direction via
    # compareTo] / bind(VarTerm,Term) [returns bool, the real bind] merged here,
    # dispatching on isinstance(vt2_or_vl, VarTerm). Verified every call site (in this
    # file and in as_syntax) passes a value whose runtime type already matches what
    # Java's static overload resolution would pick, so this is safe.
    def bind(self, vt: VarTerm, vt2_or_vl: VarTerm | Term) -> bool | None:
        if isinstance(vt2_or_vl, VarTerm):
            vt1 = self._get_var_for_unifier(vt)
            vt2 = self._get_var_for_unifier(vt2_or_vl)
            if vt1 < vt2:
                self._function[vt1] = vt2
            elif vt2 < vt1:
                self._function[vt2] = vt1
            # if they are the same, do not bind
            return None
        else:
            vl = vt2_or_vl
            if vt.negated():  # negated vars unify only with negated literals
                if not vl.is_literal() or not vl.negated():
                    return False
                vl = vl.clone()
                vl.set_negated(Literal.l_pos)

            # namespace
            if vl.is_literal():
                lvl = vl
                if not self._unifies_namespace(vt, lvl):
                    return False
                if lvl.functor.startswith(LOCAL_NS_PREFIX):  # cannot unify a var with a local namespace
                    return False
                if lvl.ns is not Literal.default_ns:
                    vl = lvl.clone_ns(Literal.default_ns)

            if not vl.is_cyclic_term() and vl.has_var(vt, self):
                vl = CyclicTerm(vl, vt.clone())

            if vl.is_var():
                self.bind(vt, vl)
            else:
                self._function[self._get_var_for_unifier(vt)] = vl
            return True

    def _get_var_for_unifier(self, v: VarTerm) -> VarTerm:
        v = self.deref(v).clone_ns(Literal.default_ns)
        v.set_negated(Literal.l_pos)
        return v

    def clear(self):
        self._function.clear()

    def __str__(self) -> str:
        return str(self._function)

    def get_as_term(self) -> Term:
        from icaros.as_syntax.factory import create_structure
        lf = ListTerm()
        for k, v in self._function.items():
            vl = v.clone()
            if isinstance(vl, Literal):
                vl.make_vars_annon()
            # the var must be changed to avoid cyclic references later
            pair = create_structure("map", UnnamedVar.create(str(k)), vl)
            lf.append(pair)
        return lf

    def size(self) -> int:
        return len(self._function)

    # add all unifications from u
    def compose(self, u: Unifier):
        for k, k_value in u._function.items():
            current = self.get(k)
            if current is not None and (current.is_var() or k_value.is_var()):  # current unifier has the new var
                self.unifies(k_value, current)
            else:
                self._function[k.clone()] = k_value.clone()

    def clone(self) -> Unifier:
        new_un = Unifier()
        new_un._function = dict(self._function)
        return new_un

    def __hash__(self) -> int:
        s = 0
        for v in self._function:
            s += hash(v)
        return s * 31

    def __eq__(self, o: object) -> bool:
        if o is None: return False
        if o is self: return True
        if isinstance(o, Unifier):
            return self._function == o._function
        return False

    # changes the implementation of the var/value mapping -- should be used carefully
    def set_map(self, new_func: dict[VarTerm, Term]):
        self._function = new_func

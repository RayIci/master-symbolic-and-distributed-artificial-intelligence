from __future__ import annotations

import time
from uuid import uuid4
from typing import Callable, TYPE_CHECKING

from icaros.as_semantics.intended_means import IntendedMeans
from icaros.as_semantics.intention import Intention
from icaros.as_semantics.option import Option
from icaros.as_semantics.unifier import Unifier
from icaros.as_syntax.factory import (create_atom, create_literal, create_string,
                                      create_structure, parse_plan)
from icaros.as_syntax.internal_action_literal import InternalActionLiteral
from icaros.as_syntax.plan import Plan
from icaros.as_syntax.plan_body import BodyType, PlanBody
from icaros.as_syntax.trigger import TEOperator, TEType, Trigger
from icaros.bb.rag.rag_belief_base import RagBeliefBase
from icaros.journal import CONVERSATION_KINDS, NARRATIVE_KINDS, JournalKind
from icaros.llm import (ADD_ACTION_TOOL, ADD_PLAN_TOOL, CALL_ANNOT, DONE_TOOL,
                        FACULTY_TOOLS, SOURCE_LLM, TOOL_CALL_FUNCTOR, IcarosState,
                        LlmCall, LlmClient, ToolKind, is_achieve_goal, json2literal,
                        json2terms, prompts, to_specs, tool_call_of)
from icaros.llm.decode import InvalidArguments, field_of
from icaros.llm.providers import ARGUMENTS_ERROR
from icaros.llm.prompts import DEFAULT_PROMPT, PromptConfig

if TYPE_CHECKING:
    from icaros.llm import IcarosSession
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_syntax.literal import Literal


class Icaros:

    def __init__(self, provider, model, params=None, prompt: PromptConfig | None = None,
                 chat_stream: bool = True, *, chat=None, client_factory=None):
        # LLM Client. `client_factory`, when given, replaces LlmClient itself
        # -- the seam mas2i/loader.py's load_mas needs, since it builds an
        # Icaros without holding the client (see load_mas's own
        # llm_client_factory parameter); everyone else keeps using `chat=`.
        #
        # `params` is the .mas2i's `params { }`, sent to the provider under its
        # own parameter names -- this class never reads it, it only carries it
        # to the client (see providers.py for where each key lands).
        self._client = (client_factory or LlmClient)(provider, model, params, chat=chat)
        # Transition System
        self._ts = None
        # which sections of a session's system message get built, and how big
        # -- the .mas2i's `prompt:` block. These were three constructor numbers
        # (journal_window/journal_chars/rag_k) that nothing could reach; the
        # ones that are still parameters live on PromptConfig now, with the
        # reasoning for each default written next to it.
        self._prompt = prompt or DEFAULT_PROMPT
        # whether a CHAT round trip streams its answer -- the .mas2i's
        # `agentic { chat_stream: ... }`. Named for what it affects: the
        # provider's own `stream` is a reserved params key precisely because
        # icaros has to be able to read back what it asked for, so this is a
        # decision of ours and not a parameter passed on.
        self._chat_stream = chat_stream
        # With this we can set a method to call once a LLM Call finishes
        self.on_call_finished: Callable[[LlmCall], None] | None = None
        # ...and one to call right before the round trip is made -- the only
        # signal a UI has that this agent is now blocked in a (possibly slow,
        # local-model) network call, well before the call returns and the
        # cycle it belongs to completes.
        self.on_call_started: Callable[[LlmCall], None] | None = None
        # ...and one for each piece of a streamed chat answer, as it arrives.
        # Only ever fired for a conversation session (see _round): a .run
        # working through a plan has nobody reading it live, and filling the
        # telemetry ring on its behalf would evict the events that do get read.
        self.on_call_chunk: Callable[[LlmCall, str], None] | None = None

    @property
    def ts(self) -> TransitionSystem:
        return self._ts

    @ts.setter
    def ts(self, ts):
        self._ts = ts

    @property
    def provider(self):
        return self._client.provider

    @property
    def model(self):
        return self._client.model

    def _tool_specs(self, level=None, session: IcarosSession | None = None,
                    tools: list | None = None) -> list[dict]:
        """What this agent offers the model at `level`, rendered in its dialect.

        Rendered from callable_tools(), NOT from the whole llm_tools()
        declaration: those two differ (the declaration can name families the
        level or the runtime will not hand over), and a trace that showed the
        wider list would be answering a question nobody asked -- the useful one
        is "what could this model have called", not "what did the .mas2i
        mention".

        ag: `level` is None for the select_* calls, which offer nothing: they
        ask the model to pick from a list, not to reach for anything. The
        specs are still recorded there, because it is the one place a reader
        can see what an agent's llm_tools: config actually produces.
        """
        if self._ts is None:
            return []
        try:
            if tools is None:
                tools = self.callable_tools(level, session)
            return to_specs(tools, self._client.provider or "openai")
        except Exception:  # never let introspection break a real call
            return []

    def callable_tools(self, level=None, session: IcarosSession | None = None) -> list:
        """The tools this agent will actually offer the model at `level`.

        When `session` was opened with a tool list (the third argument of
        .talk/.run/.fly/.burn), only the tools named there are kept -- a
        narrowing of what the level and llm_tools: allow, never a widening.
        The faculties and DONE_TOOL are not part of that list: a session must
        always be able to say it is done.

        ag: which families a level allows is IcarosState's business
        (allowed_kinds); what this adds is the filter that is about
        reachability rather than permission. A goal tool whose trigger is not
        `+!` is dropped: goal_step writes a `!goal` step and nothing else,
        so offering `on_add_battery_low` would be offering something that
        cannot be pursued.

        With no level -- a trace of a select_* call -- the question is not "what may this session ask for"
        but "what could this agent's model call at all", so the widest
        reachable set answers it. Nothing is bypassed by that: what a session
        may reach for is decided where the tools are OFFERED, one round trip
        earlier, and a model can only name what it was given. DONE_TOOL is
        appended only for a real session, and then unconditionally even if
        everything above it failed -- a session with no way to say "done" is a
        suspended intention that never resumes.

        ag: the rung's faculties are appended alongside it, and they are the
        one thing here that is NOT a filter of what the agent has -- nothing in
        llm_tools() could produce "write a plan you do not have". A rung with
        none of them (everything below fly) adds nothing, which is why this
        line costs those sessions a single empty tuple.
        """
        if self._ts is None:
            return []
        widest = IcarosState.FLY
        try:
            tools = [t for t in self._ts.ag.llm_tools(kinds=(level or widest).allowed_kinds())
                     if t.kind is not ToolKind.GOAL or is_achieve_goal(t.origin)]
        except Exception:  # never let tool introspection break a round
            tools = []
        if session is not None and session.allowed_tools is not None:
            if not session.allowed_tools_checked:
                session.allowed_tools_checked = True
                unknown = session.allowed_tools - {t.name for t in tools}
                if unknown:
                    self._ts.ag.logger.warning(
                        "Icaros session %s: no tool named %s can be offered at %s "
                        "(not in llm_tools:, or not allowed at this level); ignored",
                        session.id, ", ".join(sorted(unknown)), session.level)
            tools = [t for t in tools if t.name in session.allowed_tools]
        if level is None:
            return tools
        return [*tools, *level.faculties(), DONE_TOOL]

    def _tool_named(self, name: str, session: IcarosSession | None):
        """The tool `session` was offered under `name`, or None if it was
        offered none.

        ag: one expression, two callers -- .icaros_step (generation.py), which
        resolves every name the model gave before choosing its road, and
        add_tool_call, which resolves again rather than being handed the tool
        .icaros_step already found: that is what makes it impossible to reach
        an internal action through a tool the session was never offered.

        ag: deliberately NOT cached, not even for the length of one round.
        _run_control can execute icaros_add_plan in the middle of _round()'s
        own tool loop, so the offer changes under a round -- and a memoised list
        would be stale in exactly the case the fly rung exists to serve.
        """
        return next((t for t in self.callable_tools(None if session is None else session.level, session)
                     if t.name == name), None)

    @staticmethod
    def _action_behind(tool):
        """The internal action a tool is backed by, or None when nothing is.

        ag: one probe, because there is one fact. The InternalAction protocol
        declares both `name` and `execute` (stdlib/registry.py), so the two
        places that used to ask -- one for `execute`, one for `name` -- happened
        to agree. A goal tool's origin is a Trigger and has neither. Asking once
        is what keeps that agreement from being luck.
        """
        origin = getattr(tool, "origin", None)
        return origin if getattr(origin, "execute", None) is not None else None

    @staticmethod
    def _stamp(literal: Literal, call_id: str, session: IcarosSession | None,
              tool_name: str | None = None) -> Literal:
        """A copy of `literal` carrying the model's fingerprints: source(llm)
        and llm_call(call_id, session, tool_name).

        The provenance a reader sees in the journal, the key the result comes
        back under, the conversation it goes back to, and the name the model
        itself used -- tool_name_of reads that third term back to tag the
        role:"tool" reply this call eventually gets (IcarosConsiderResults,
        generation.py), so the model reads its answer back framed as exactly
        what it is. Factored out because every way a tool call reaches the
        agent needs it identically -- as a !goal step (goal_step), as an
        intended means (add_tool_call) -- and the
        annotations are what they have in common, not an implementation
        detail of any one of them.
        """
        lit = literal.copy().force_full_literal_impl()
        lit.add_annot(create_structure("source", create_atom(SOURCE_LLM)))
        session_term = create_string("" if session is None else session.id)
        tool_term = create_string(tool_name or "")
        lit.add_annot(create_structure(CALL_ANNOT, create_string(call_id), session_term, tool_term))
        return lit

    @staticmethod
    def _link_provider_call(session: IcarosSession | None, call_id: str,
                            provider_call_id: str | None) -> None:
        """Records, on `session`, which provider-assigned id answers to this
        call_id -- so a later remember_tool_result can tag the reply with the
        id OpenAI's tool_call_id / Anthropic's tool_use_id needs. None (no
        session, or a provider -- Ollama -- that assigns no id of its own)
        leaves nothing to record; remember_tool_result's own lookup already
        treats "not found" as "nothing to add"."""
        if session is not None and provider_call_id is not None:
            session.provider_call_ids[call_id] = provider_call_id

    def refuse_tool_call(self, session: IcarosSession, name: str,
                         provider_call_id: str | None = None,
                         reason: str | None = None) -> None:
        """Answers a call to a tool `session` was not offered, or one whose
        arguments cannot be built.

        ag: an answer rather than silence -- a dispatch that posts nothing
        leaves the calling intention waiting for a result that never comes,
        and OpenAI/Anthropic reject a turn whose tool calls are not all
        answered. A reason makes the refusal about the call instead of the
        tool: the model did send arguments, it sent the wrong ones, and the
        message says what was wrong with them (argument_problem) so it can
        retry with the right ones.
        """
        call_id = uuid4().hex
        self._link_provider_call(session, call_id, provider_call_id)
        session.remember_tool_result(
            name,
            reason if reason is not None else
            f"'{name}' is not available in this session. Use one of the tools you were offered.",
            call_id=call_id)

    def goal_step(self, tool, arguments: dict, session: IcarosSession | None,
                  provider_call_id: str | None = None) -> PlanBody | None:
        """One tool call as a `!goal` step: a single ACHIEVE node wrapping the
        stamped literal -- handed back rather than posted, because the model
        does not add events: it can only say which goal it would now like to
        achieve. .icaros_step
        (generation.py) writes it into the session's own intention, as the
        next step (one call) or as a .fork branch (several), and the reasoning
        cycle decides when it runs: SelInt picks the intention, ExecInt's Rule
        Achieve posts the goal with that intention, exactly like a written
        !goal. Once its plan finishes, clear_intention reads call_id_of() off
        the trigger and _deposit_llm_result hands the answer back.

        Every kind that takes the goal road: GOAL, and JOURNAL/RAG, which
        resolve through their wrapper plans (pl/journal_plans.asl,
        pl/rag_plans.asl). CONTROL never gets here -- _round runs it on the
        spot.

        ag: INTERNAL_ACTION-kind is refused, and deliberately so. A bare
        INTERNAL_ACTION PlanBody node has no Trigger for clear_intention to
        read call_id_of() off once it finishes, so nothing would ever call
        _deposit_llm_result for it and its answer would vanish; the one-call
        road gives it a hand-built one-step Plan/Trigger/IM instead (see
        add_tool_call / _tool_call_intention). Mixing one into a multi-call
        round is IcarosStep's job to refuse outright, not this one's to paper
        over with a half-working branch.
        """
        if tool.kind is ToolKind.INTERNAL_ACTION:
            return None
        # ag: unique per call, or the result of a second .timeline would be
        # taken for the answer to the first. uuid4 for the same reason
        # Intention uses one; .hex because this ends up inside a term.
        call_id = uuid4().hex
        self._link_provider_call(session, call_id, provider_call_id)
        # ag: the step's variables made its own before it goes anywhere. It
        # is spliced into the body of the plan that called .run, and Rule
        # Achieve resolves a step against that plan's unifier: an `Entries`
        # of the plan's own would otherwise fill in the model's `Entries`.
        # The names survive the renaming (UnnamedVar.create keeps them after
        # the `_<n>` prefix), which is what the answer is read back under.
        literal = json2literal(tool, arguments).make_vars_annon()
        literal = self._stamp(literal, call_id, session, tool.name)
        return PlanBody(BodyType.ACHIEVE, literal)

    ### the rung's faculties ##########

    def _run_control(self, tool, arguments: dict, session: IcarosSession | None) -> bool:
        """Carries out one faculty the rung granted, here and now.

        Returns whether it worked, and either way says so in the session's
        inbox -- which is the whole reason these do not go through the cycle.
        The model reads that line at its next round, so a plan that does not
        parse comes back while the model is still holding the thought that
        produced it. `session.inbox` is already how _round() answers a model
        that only wrote prose; this is the same channel, used for the same
        reason.
        """
        if not self._may_use(tool, session):
            return False
        handler = self._FACULTY_HANDLERS.get(tool.name)
        if handler is None:  # a faculty declared and never wired: a bug, not a refusal
            self._say(session, f"{tool.name} is not available in this build.")
            return False
        try:
            message = handler(self, arguments)
        except Exception as e:
            # ag: the message, not the class name alone -- for these two the
            # exception text IS the answer (a parser's complaint, a Python
            # traceback's last line), and it is what the model needs to write
            # the next attempt. A bare "it failed" costs a whole round.
            self._say(session, f"{tool.name} failed: {e}")
            self._journal_control(tool, error=str(e))
            return False
        self._say(session, message)
        self._journal_control(tool, error=None)
        return True

    def _may_use(self, tool, session: IcarosSession | None) -> bool:
        """Both gates, and it says no out loud.

        ag: the session's rung AND the .mas2i's ceiling, checked against the
        same faculties() table. The second is redundant while
        generation.py::_open refuses to open a session above gen_limit, and it
        is here anyway: the rung is the live authority, the ceiling is what the
        file said, and a session that somehow got opened too high still must
        not act too high.
        """
        if session is None or self._ts is None:
            return False
        needed = next((lvl for lvl in IcarosState if tool in lvl.faculties()), None)
        if needed is None:
            return False
        if tool not in session.level.faculties():
            self._say(session, f"You cannot use {tool.name} in this session: it is a "
                               f"{needed} faculty and this session is {session.level}.")
            return False
        if tool not in self._ts.gen_limit.faculties():
            self._say(session, f"You cannot use {tool.name}: this agent is not allowed "
                               f"above {self._ts.gen_limit}.")
            return False
        return True

    @staticmethod
    def _say(session: IcarosSession | None, line: str) -> None:
        if session is not None:
            session.inbox.append(line)

    def _journal_control(self, tool, *, error: str | None) -> None:
        """A faculty used is a thing the agent did to itself, so it goes on the
        journal -- otherwise a plan that appeared mid-run has no origin any
        reader can find."""
        if self._ts is None:
            return
        self._ts.ag.journal.record(JournalKind.LLM_GENERATE, faculty=tool.name, error=error)

    def _add_plan(self, arguments: dict) -> str:
        """icaros_add_plan: one AgentSpeak plan into the library, marked as the
        model's.

        ag: parse_plan rather than belief_plan.py's _to_plan -- that one also
        accepts a plan TERM and strips backslashes, a Java quirk for plans
        written inside AgentSpeak string literals. What arrives here came out
        of JSON already decoded, so the quirk would only corrupt it.

        The source atom is what marks it generated: PlanLibrary.add turns it
        into source(llm) on the label, which is where .relevant_plans, the dev
        UI and a later .save_agent all read provenance from. Nothing new had to
        be invented for "annotated as generated" -- it is how plans have always
        recorded where they came from.
        """
        source = str(arguments.get("source") or "").strip()
        if not source:
            raise ValueError("no plan given")
        plan = parse_plan(source)
        added = self._ts.ag.pl.add(plan, create_atom(SOURCE_LLM))
        return f"Added the plan {added.label} : {added.trigger}. You can ask for it now."

    def _add_action(self, arguments: dict) -> str:
        """icaros_add_action: one Python module into this agent's own action
        registry.

        Per-agent, not process-wide: register_internal_actions writes into the
        Agent's map, which get_ia consults before the stdlib. One agent burning
        an action does not hand it to every other agent in the MAS, which would
        be a surprising way for a capability to spread.
        """
        from icaros.stdlib.registry import actions_from_source

        name = str(arguments.get("name") or "").strip()
        code = str(arguments.get("code") or "")
        if not code.strip():
            raise ValueError("no code given")
        found = actions_from_source(code, name, directory=self._ts.gen_path)
        self._ts.ag.register_internal_actions(found)
        where = "" if self._ts.gen_path is None else f" (written to {self._ts.gen_path})"
        return f"Added the internal action {', '.join(sorted(found))}{where}. " \
               f"A plan body can call it now."

    # ag: name -> handler, next to the handlers. The table on IcarosState says
    # which rung grants what; this one says what the grant does, and the two are
    # different questions asked by different code.
    _FACULTY_HANDLERS = {
        ADD_PLAN_TOOL.name: _add_plan,
        ADD_ACTION_TOOL.name: _add_action,
    }

    def add_tool_call(self, name: str, arguments: dict,
                      session: IcarosSession,
                      provider_call_id: str | None = None) -> Intention | None:
        """Runs one tool call from the model on the session's own intention,
        with no plan of the agent's standing between the two.

        goal_step's twin, and the pair is the whole point: the same question
        -- the model asked for X, what makes X happen -- with two answers.
        That one writes a `!goal` step and lets the cycle find a plan for it,
        which is the only way a GOAL can be reached. This one is for an
        INTERNAL ACTION, which needs no plan to mean something: the call is
        already the thing to do, and going looking for a wrapper plan to say
        it (pl/journal_plans.asl) is a detour that only exists because the
        detour was the only road.

        Returns the intention, or None if the session has no intention to run
        it on, if the model named a tool this session was not offered, or one
        no internal action backs.

        ag: resolved through _tool_named, so the same two gates that decide
        what the model was OFFERED decide what it can reach -- the .mas2i's
        `llm_tools:` and the session's rung, intersected. Nothing may be run
        here that was not offered a round trip earlier; a model can only name
        what it was given, and this is the check that keeps that true even if
        one day it names something else.

        The journal family passes _action_behind too, since those are internal
        actions like any other. That is deliberate and costs nothing: which
        road a call actually takes is .icaros_step's decision (generation.py),
        and it sends the journal family down the wrapper plans that already
        exist for it, as a !goal step.

        ag: there is no fallback to a fresh Intention. A tool call belongs to
        the intention that opened the session, or it does not run: a model
        starting intentions of its own would be the model deciding what the
        agent pursues, which is the reasoning cycle's job.
        """
        if self._ts is None or session.intention is None:
            return None
        tool = self._tool_named(name, session)
        if tool is None or self._action_behind(tool) is None:
            return None
        im = self._tool_call_intention(tool, arguments, session, provider_call_id)
        if im is None:
            return None
        # ag: pushed onto session.intention -- a real child frame, as the
        # plan a `!goal` step reaches ends up being.
        intention = session.intention
        intention.push(im)
        self._ts.circumstance.add_running_intention(intention)
        return intention

    def _tool_call_intention(self, tool, arguments: dict, session: IcarosSession | None,
                             provider_call_id: str | None = None) -> IntendedMeans | None:
        """One tool call as an intended means: a synthetic one-step plan,
        ready to be pushed onto whichever intention will run it.

        ag: an intention cannot exist without a Plan -- Intention.push reads
        the plan's update-event interest and goal condition, IntendedMeans
        reads its body and trigger -- so "no plan" can only ever mean "no plan
        in the plan library". This builds one that lives nowhere else, the
        same move TransitionSystem makes for e-plans with
        _plan_base_for_e_plans; the difference is that that plan is fixed and
        cached, and this one's body is a different call every time.

        The trigger is where the care is. Its literal mirrors the call --
        llm_tool_call(".timeline", 1, 5, Entries) -- with the OUTPUT
        parameters left as free variables, because that is exactly the shape
        TransitionSystem._deposit_llm_result reads an answer out of: whatever
        is still a variable in the trigger when the intended means finishes is
        what the call was for. So the answer finds its way back to the session
        through the path a wrapper plan's goal already uses, and this adds not
        one line to it.

        ag: returns the IntendedMeans rather than an Intention wrapping it --
        add_tool_call pushes it onto session.intention.
        """
        action = self._action_behind(tool)
        if action is None:  # not an internal-action tool: there is nothing to call
            return None
        ia_name = action.name
        terms = json2terms(tool, arguments)
        # ag: unique per call, same reason as goal_step above
        call_id = uuid4().hex
        self._link_provider_call(session, call_id, provider_call_id)
        trigger_literal = self._stamp(
            create_literal(TOOL_CALL_FUNCTOR, create_string(ia_name), *terms),
            call_id, session, tool.name)
        try:
            # InternalActionLiteral(Structure, Agent) resolves the action
            # through Agent.get_ia, which raises for a name the agent has
            # none of -- reachable if the tool list and the registry disagree
            body = PlanBody(BodyType.INTERNAL_ACTION,
                            InternalActionLiteral(create_structure(ia_name, *terms), self._ts.ag))
        except Exception:
            self._ts.ag.logger.exception("no internal action behind the tool '%s'", tool.name)
            return None
        plan = Plan(create_atom(TOOL_CALL_FUNCTOR),
                    Trigger(TEOperator.ADD, TEType.ACHIEVE, trigger_literal), None, body)
        return IntendedMeans(Option(plan, Unifier()), None)

    def _record(self, purpose: str, prompt: str, options: list[str] | None, level=None,
                session: IcarosSession | None = None, tools: list | None = None) -> LlmCall:
        """The trace entry for one round trip.

        `tools`, when given, is a tool list the caller has ALREADY built, used
        instead of asking for it again. _round needs the same list twice -- the
        rung's capabilities sentence is composed from it, and it is what goes on
        the trace -- and building it walks the whole plan library, so this is
        what keeps "what was offered", "what was recorded as offered" and "what
        the prompt claims was offered" one list by construction rather than
        three that happen to agree.
        """
        ag_name, cycle = "", -1
        if self._ts is not None:
            ag_name = self._ts.ag_arch.ag_name
            cycle = self._ts.cycle_count
        return LlmCall(
            agent=ag_name, cycle=cycle, purpose=purpose,
            provider=self._client.provider, model=self._client.model, prompt=prompt,
            messages_len=self._client.conversation_len,
            started_at=time.time(), duration_ms=0.0,
            options=list(options) if options else [],
            tool_specs=self._tool_specs(level, session, tools=tools),
            level=None if level is None else str(level),
        )

    def _preamble(self, session: IcarosSession | None = None, *, beliefs: bool = True) -> str:
        """The agent's own journal, rendered for the top of a prompt.

        `beliefs` controls the trailing "## What I believe now" full dump
        (Journal.render's own `beliefs=` param) -- on by default, matching
        render()'s own default. `_round` turns it off for a RagBeliefBase
        agent, where `_rag_context` takes over that job with the subset
        actually relevant to the round's question instead of everything.
        `_select` never passes it, deliberately: a selection has no question
        to retrieve against, so there is nothing to replace the full dump
        with, and dropping it there would be a pure loss.

        ag: this is the difference between a model that picks and a model that
        decides -- without it every selection prompt arrives with no past at
        all, so "why did you do that?" has no answer even in principle. The
        budget is not a nicety: the journal grows for the whole run and a
        prompt cannot, and render() declares what it had to cut rather than
        quietly handing over a shortened history that reads complete.

        What it leaves out is the rounds of the conversations the agent has
        OPEN right now, its own included. An agent can hold several at once --
        a plan working through a .run while somebody chats to it -- and the
        rounds of one read, in the preamble of another, exactly like a question
        nobody has answered yet: a model handed that answers it and calls
        icaros_done, closing a session that was in the middle of something
        else. Its own rounds are dropped for the opposite reason -- they are in
        the transcript now, verbatim, and a one-line summary of a turn the
        model can already read in full is noise that costs budget. A session
        that has CLOSED stays: that is memory, and it reads as settled.

        A CONVERSATION gets a narrower past: only what was said, by or to this
        agent, and only from before it opened (its own life is the transcript).
        The reasoning cycle is cut out entirely, and that is the point -- see
        CONVERSATION_KINDS. Somebody is waiting for an answer, and two thousand
        characters of `deliberate:` and `belief +` in front of their question is
        how a model ends up narrating the coffee it is making instead of
        replying. The journal tools still reach the whole thing on request.

        Nothing is hidden from a selection prompt (`session is None`). It is the
        same reasoning in reverse: a selection answers with an index and cannot
        close anything, so an open conversation there is context rather than a
        trap, and context is the whole point of a preamble.

        The .mas2i's `prompt:` block is read for a SESSION only, which is the
        cfg line below. A selection keeps the framework defaults on purpose:
        the block exists to shrink what a round trip carries, and a selection
        has neither a grounding section nor a transcript to carry the weight
        instead -- pruning it there would be loss with nothing in exchange.
        """
        if self._ts is None:
            return ""
        cfg = self._prompt if session is not None else DEFAULT_PROMPT
        if session is None:
            open_now = set()
        else:
            open_now = set(self._ts.circumstance.icaros_sessions)

        def keep(entry) -> bool:
            if entry.kind is JournalKind.LLM_GENERATE:
                if entry.detail.get("session") in open_now:
                    return False
            # a conversation inherits what came before it and nothing from its
            # own life -- that half is the transcript, and in better words
            return session is None or not session.conversation \
                or entry.cycle < session.opened_at_cycle

        kinds = NARRATIVE_KINDS
        title = "What has happened so far"
        if session is not None and session.conversation:
            kinds = CONVERSATION_KINDS
            title = "What had been said before this"
        try:
            return self._ts.ag.journal.render(n=cfg.history_cycles,
                                              kinds=kinds,
                                              beliefs=beliefs,
                                              history=cfg.history_cycles is not None,
                                              where=keep, title=title)
        except Exception:  # a broken preamble must never break the decision
            return ""

    def _rag_context(self, question: str) -> str:
        """The beliefs closest in meaning to `question`, rendered for the top
        of a prompt -- the RAG belief base's own contribution to a round, on
        par with the journal preamble rather than a tool the model has to
        remember to reach for.

        "" for an agent with no semantic index to search (a plain
        BeliefBase), an empty `question`, or a retrieval that failed -- same
        stance as _preamble's own try/except: a broken grounding step must
        never break the round, and there is no fallback to the full belief
        dump here (see _round: `beliefs=` is off for these agents by default,
        so the belief base does not silently blow up the prompt as it grows).
        .rag_search still answers on demand at any rung this session was
        offered it; this is only the every-round default.

        "" as well for `prompt: - rag_grounding: off`, which is how an agent
        asks to keep retrieval as a tool it reaches for rather than something
        standing in front of it every round.
        """
        if self._ts is None or not question.strip():
            return ""
        k = self._prompt.rag_grounding_k
        if k is None:
            return ""
        bb = self._ts.ag.bb
        if not isinstance(bb, RagBeliefBase):
            return ""
        try:
            hits = bb.retrieve(question, k=k)
        except Exception:
            return ""
        if not hits:
            return ""
        lines = "\n".join(f"- {hit.text}" for hit in hits)
        return f"## What you believe that might be relevant\n{lines}"

    def send(self, msg: str, options: list[str] = None, *, purpose: str = "send",
             record: LlmCall | None = None, stateless: bool = False):
        """One round trip. `record`, when given, is filled in and emitted by
        this call -- _select() passes its own so it can add the parsed choice
        before the trace goes out.

        `stateless` sends only this prompt instead of appending to the running
        conversation -- see _select().
        """
        call = record if record is not None else self._record(purpose, msg, options)
        if self.on_call_started is not None:
            self.on_call_started(call)
        try:
            return self._client.ask(msg, options, call=call, stateless=stateless)
        finally:
            # emitted from the finally, so a failed round trip still produces
            # a record -- a trace that only shows successes is no use for the
            # failure you are actually debugging
            if record is None and self.on_call_finished is not None:
                self.on_call_finished(call)

    # how long text piles up before it is published to whoever is watching.
    # Under the 0.1 s the dev UI's websocket drains its ring at, so the text
    # still reads as continuous, while the ring sees a dozen events a second
    # instead of one per token from a local model running at fifty.
    CHUNK_SECONDS = 0.08

    def _chunk_sink(self, session: IcarosSession, call: LlmCall):
        """The per-delta callback for a streamed answer, or None.

        None -- which is what turns streaming off in providers.py -- unless
        this is a chat, streaming is enabled for this agent, and somebody has
        actually hooked on_call_chunk. A .run session working through a plan
        gets None: nobody is reading it as it happens, and the ring it would
        fill is bounded and shared with the events that are read.

        ag: it coalesces rather than forwarding each token. The ring evicts
        under pressure and says so (`gap`), so the cost of a chatty producer
        is paid by every other event in the timeline, not by this one. What
        goes out stays a delta -- just a bigger one.

        The returned callable carries a `flush()`, and _round calls it when
        the round trip is over. Without it the tail after the last window is
        never published -- and worse, a short reply that streams in under one
        window would publish NOTHING, which is exactly the case a person
        chatting hits most often.
        """
        if not (self._chat_stream and session.conversation
                and self.on_call_chunk is not None):
            return None

        pending: list[str] = []
        last = [0.0]  # 0, not now: the first delta publishes immediately

        def publish() -> None:
            if not pending:
                return
            text, pending[:] = "".join(pending), []
            last[0] = time.monotonic()
            try:
                self.on_call_chunk(call, text)
            except Exception:  # a watching UI must never break the round trip
                pass

        def sink(delta: str) -> None:
            pending.append(delta)
            if time.monotonic() - last[0] >= self.CHUNK_SECONDS:
                publish()

        sink.flush = publish
        return sink

    def _round(self, session: IcarosSession
              ) -> tuple[bool, str | None, list[tuple[str, dict, str | None]]]:
        """One round of an Icaros session, without dispatching what it asked
        for.

        Returns (the session is over, what the model concluded, the GOAL/
        INTERNAL_ACTION tool calls it made -- name, arguments, and the id the
        provider itself assigned the call (None for Ollama, which assigns
        none) -- still undispatched, in call order). A CONTROL faculty
        (icaros_add_plan/icaros_add_action) is still carried out here,
        synchronously and unconditionally: it is not a goal or an action for
        the cycle to run, it is a change to the agent's own plans/actions,
        made and reported back to the model in this same round -- see
        _run_control. DONE_TOOL is likewise handled here, never dispatched.

        ag: the inbox is read but not cleared until the round trip has come
        back. A round that fails leaves the session exactly as it was, so the
        next cycle simply tries again with the same question, and MAX_ROUNDS
        is what eventually gives up. The transcript follows the same rule from
        the other end: the question is remembered before the call, because it
        was asked whether or not the model answers, and the answer is
        remembered only once there is one.
        """
        pending = list(session.inbox)
        # ag: the model is told before its last round, not after it: a session
        # that runs out fails the goal (generation.py), and a model that knows
        # this is the moment to call icaros_done usually does.
        if session.rounds >= session.max_rounds:
            pending.append(prompts.last_round_notice(DONE_TOOL.name))
        question = "\n".join(pending)
        cfg = self._prompt
        # ag: built once and used three times -- the capabilities sentence is
        # composed from it, the trace records it, and it is what goes out as
        # `tools=`. Walking the plan library once per round instead of twice is
        # the smaller half of the reason; the larger one is that these three
        # cannot disagree if they are the same list.
        #
        # The except is _tool_specs' own stance, kept now that this call has
        # moved out in front of it: a tool list that cannot be built must not
        # take the round down with it. The round then offers nothing, and the
        # sentence composed from the same empty list says so rather than
        # promising what is not there.
        try:
            offered = self.callable_tools(session.level, session)
        except Exception:
            offered = []
        # ag: the full "## What I believe now" dump is what _rag_context exists
        # to replace for a RagBeliefBase agent -- the relevant subset instead
        # of everything, so the prompt does not grow with the whole belief
        # base. A plain BeliefBase has nothing to substitute it with, so it
        # keeps the full dump. That rule is now only the DEFAULT: `prompt: -
        # beliefs: on|off` overrides it either way, which is the one way to
        # ask for both sections at once, or for neither.
        rag_backed = isinstance(self._ts.ag.bb, RagBeliefBase)
        beliefs = cfg.beliefs if cfg.beliefs is not None else not rag_backed
        grounding = self._rag_context(question) if rag_backed else ""
        system = prompts.session_system(self._preamble(session, beliefs=beliefs),
                                        grounding, session.level.capabilities(offered))
        # ag: appended before the round trip and NOT rolled back if it fails.
        # A failed round leaves the inbox untouched, so the same lines would be
        # remembered twice on the retry -- hence the guard: this turn only
        # joins the transcript if it is not already its last one.
        if not session.transcript or session.transcript[-1] != {"role": "user",
                                                                "content": question}:
            session.remember("user", question)
        messages = session.messages(system)
        # ag: the specs recorded on the trace ARE the ones sent, not a second
        # rendering of the same question -- llm_tools() walks the plan library,
        # and a round is the one place where "what was offered" and "what was
        # recorded as offered" must be the same list by construction.
        #
        # `prompt` is the flattened transcript, not the list: LlmCall.prompt is
        # what /api/transcript/{seq} shows and what --llm-trace keeps, and
        # "what was the model actually shown" must stay answerable in one
        # string now that the thing sent is several.
        call = self._record("generate", prompts.as_text(messages), None, level=session.level,
                            session=session, tools=offered)
        call.session = session.id
        # _record reads the client's own running conversation, which a
        # generation round does not use: what went out is this list.
        call.messages_len = len(messages)
        done, summary = False, None
        dispatchable: list[tuple[str, dict, str | None]] = []
        if self.on_call_started is not None:
            self.on_call_started(call)
        on_chunk = self._chunk_sink(session, call)
        try:
            message = self._client.chat(messages, call=call, tools=call.tool_specs,
                                        on_chunk=on_chunk)
            if message is None:
                # no provider to ask. Nothing was said, so the question stays
                # in the inbox and the session tries again next cycle, exactly
                # as it does for a round trip that failed.
                return False, None, []
            session.inbox.clear()

            # ag: the raw provider dict for each call this round actually
            # dispatches -- parallel to `dispatchable` below, and kept because
            # it (not the (name, arguments) pair) is what remember_assistant_turn
            # sends back verbatim next round, so the model sees its own call
            # exactly as it made it.
            raw_dispatchable: list[dict] = []
            for raw in message.get("tool_calls") or []:
                name, arguments = tool_call_of(raw)
                call.tool_calls.append({"name": name, "arguments": arguments})
                if name == DONE_TOOL.name:
                    done = True
                    summary = (str(arguments.get("summary") or "").strip() or None
                               if isinstance(arguments, dict) else None)
                    continue
                # arguments the provider could not read: carried on to
                # .icaros_step as such, which refuses the call with the reason
                if field_of(raw, ARGUMENTS_ERROR):
                    arguments = InvalidArguments(field_of(raw, ARGUMENTS_ERROR))
                # ag: a faculty is executed here, in the round, rather than
                # handed to the cycle -- see ToolKind.CONTROL. That is what
                # lets the outcome go back as the next round's question: a
                # plan that does not parse is the model's problem to fix, and
                # it can only fix it if it hears about it while it is still
                # thinking about it.
                #
                # Looked up by name across ALL rungs, not in what this session
                # was offered: a model that names a faculty it was not given
                # has to be told so (_run_control refuses and says which rung
                # it would need). Falling through to .icaros_step would
                # only refuse it as a tool never offered and burn the session's rounds against
                # a wall it cannot see.
                #
                # ag: NOT added to raw_dispatchable -- a faculty's outcome
                # reaches the model through session.inbox (_say, _run_control),
                # a plain text turn, not a role:"tool" reply. It is answered
                # within this same round, before there is even an assistant
                # turn to remember, so there is no call left dangling for
                # remember_assistant_turn to have promised a reply to.
                faculty = FACULTY_TOOLS.get(name)
                if faculty is not None:
                    self._run_control(faculty, arguments, session)
                    continue
                dispatchable.append((name, arguments, field_of(raw, "id")))
                raw_dispatchable.append(raw)

            if not call.tool_calls:
                # ag: the model answered in prose and asked for nothing, which
                # leaves the session open with nothing to do and the plan that
                # opened it suspended forever. Its own words go back to it as
                # the next round's question -- bounded by MAX_ROUNDS, so a
                # model that will not use a tool fails the goal instead of
                # holding the intention indefinitely.
                #
                # Kept, though, and not only bounced: for a session that was a
                # question this sentence IS the answer, and the summary the
                # model files a round later is a description of having given
                # it. .talk("...", A) binds this when there is one.
                session.last_answer = (call.content or "").strip() or None
                session.inbox.append(prompts.prose_only_nudge(call.content, DONE_TOOL.name))

            # ag: the model's own turn, kept so the next round sees exactly
            # what it did -- its own words AND, when it reached for something,
            # the provider's own tool_calls structure, not a sentence
            # describing it. That is what used to happen here (a synthetic "(I
            # called X)"), from when a result could come back cycles later,
            # out of order or never, and there was no honest way to pair a
            # role:"tool" reply with the call it answered. Under the bubble
            # (generation.py's .icaros_step/.icaros_consider_results), at most
            # one round's worth of calls is ever outstanding at a time, so the
            # pairing is exactly what it looks like: this turn's tool_calls,
            # answered by the role:"tool" turns .icaros_consider_results adds
            # right after.
            session.remember_assistant_turn(call.content or "", raw_dispatchable)
        except BaseException as e:
            if call.error is None:
                call.error = f"{type(e).__name__}: {e}"
            # a round that failed after the inbox was cleared must still
            # leave the session as it found it: the retry asks the same thing
            if not session.inbox:
                session.inbox.extend(p for p in pending
                                     if p != prompts.last_round_notice(DONE_TOOL.name))
            raise
        finally:
            # ag: before the journal entry and before on_call_finished, so
            # what a watcher sees arrives in the order it happened: the tail
            # of the answer, then the round it belonged to closing. From the
            # finally because a stream that died halfway still said something,
            # and the words it managed are worth more on screen than lost.
            if on_chunk is not None:
                on_chunk.flush()
            self._journal_generate(call, session, pending)
            if self.on_call_finished is not None:
                self.on_call_finished(call)
        return done, summary, dispatchable

    def _journal_generate(self, call: LlmCall, session: IcarosSession, pending: list[str]) -> None:
        """What was asked of the model and what it reached for, onto the
        agent's journal.

        Same reasoning as _journal_choice below: `thinking` is the answer to
        "why did you do that" in the model's own words, and it is thrown away
        once the round returns. The agent reads this back as the preamble of
        the next round, so a session can see what its earlier rounds did.
        """
        if self._ts is None:
            return
        self._ts.ag.journal.record(
            JournalKind.LLM_GENERATE, level=str(session.level), round=str(session.rounds),
            # ag: which conversation this round belongs to. The closing entry
            # has always said so; a round did not, and without it there is no
            # way to keep two open sessions out of each other's preamble.
            session=session.id,
            about="; ".join(pending)[:200], thinking=call.thinking, error=call.error,
            asked=", ".join(c["name"] for c in call.tool_calls))

    def _select(self, items, purpose: str):
        labels = [f"{i}: {item!r}" for i, item in enumerate(items)]
        prompt = prompts.selection_prompt(
            prompts.SELECT_PROMPTS[purpose], labels, self._preamble())
        # ag: stateless, and that is the change the preamble forces. _messages
        # never got pruned, so the conversation already carried every earlier
        # prompt and answer of the whole run -- prepending a journal to that
        # would send the same history twice and grow it every cycle. The
        # journal IS the memory now: curated, bounded, and the same text the
        # UI can show as what the model actually saw.
        call = self._record(purpose, prompt, labels)
        try:
            choice = self.send(prompt, labels, record=call, stateless=True)
            call.choice = choice
            index = int(choice.split(":", 1)[0])
            item = items[index]
            del items[index]
            return item
        except BaseException as e:
            if call.error is None:  # raised after the round trip, e.g. a bad index
                call.error = f"{type(e).__name__}: {e}"
            raise
        finally:
            self._journal_choice(call)
            if self.on_call_finished is not None:
                self.on_call_finished(call)

    def _journal_choice(self, call: LlmCall) -> None:
        """What the model picked, and its reasoning, onto the agent's journal.

        The `thinking` is the whole reason this entry exists: for an
        LLM-driven agent it is the literal answer to "why did you do that",
        in the model's own words, and it is otherwise thrown away once the
        selection returns.
        """
        if self._ts is None:
            return
        self._ts.ag.journal.record(JournalKind.LLM_CHOICE, purpose=call.purpose,
                                   choice=call.choice, thinking=call.thinking,
                                   error=call.error)

    # ag: the five decision points of the reasoning cycle, and the only thing
    # that differs between them is which one it is -- the wording lives in
    # prompts.SELECT_PROMPTS, keyed by the same purpose that lands on the trace.
    def select_event(self, events):
        return self._select(events, "select_event")

    def select_message(self, messages):
        return self._select(messages, "select_message")

    def select_option(self, options):
        return self._select(options, "select_option")

    def select_intention(self, intentions):
        return self._select(intentions, "select_intention")

    def select_action(self, actions):
        return self._select(actions, "select_action")

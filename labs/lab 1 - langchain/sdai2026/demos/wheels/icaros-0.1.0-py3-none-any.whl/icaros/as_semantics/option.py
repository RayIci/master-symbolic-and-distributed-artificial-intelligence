from __future__ import annotations

from icaros.as_semantics.unifier import Unifier
from icaros.as_syntax.plan import Plan
from icaros.as_semantics.event import Event


class Option:

    def __init__(self, plan: Plan, unifier: Unifier, event: Event | None = None):
        self._plan = plan
        self._unifier = unifier
        self._event = event

    def __str__(self):
        return f"({self._plan},{self._unifier})"

    def __repr__(self) -> str:
        return str(self)

    @property
    def plan(self):
        return self._plan

    @plan.setter
    def plan(self, plan: Plan):
        self._plan = plan

    @property
    def unifier(self):
        return self._unifier

    @unifier.setter
    def unifier(self, unifier: Unifier):
        self._unifier = unifier

    @property
    def event(self):
        return self._event

    @event.setter
    def event(self, event: Event):
        self._event = event
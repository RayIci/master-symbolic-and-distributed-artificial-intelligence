from __future__ import annotations

from collections import deque
import uuid

from icaros.as_semantics.event import Event
from icaros.as_semantics.intended_means import IntendedMeans, IMCondition
from icaros.as_syntax.term import Term
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.trigger import Trigger, TEOperator
from icaros.as_semantics.circumstance import Circumstance
from icaros.as_semantics.unifier import Unifier
from icaros.pl.plan_library import PlanLibrary


class Intention:

    def __init__(self):
        self._id: uuid.UUID = uuid.uuid4()
        self._atomic_count: int = 0
        self._suspended: bool = False
        self._suspended_reason: Term | None = None

        self._interested_in_update_events = 0
        self._im_with_goal_condition = 0
        self._g_intention: Intention | None = None
        self._intended_means: deque[IntendedMeans] = deque()

    @property
    def g_intention(self):
        return self._g_intention

    @g_intention.setter
    def g_intention(self, value):
        self._g_intention = value

    @property
    def id(self) -> uuid.UUID:
        return self._id

    def push(self, intended_means: IntendedMeans) -> None:
        self._intended_means.appendleft(intended_means)
        if intended_means.is_atomic():
            self._atomic_count += 1
        if intended_means.plan.has_interest_in_update_events():
            self._interested_in_update_events += 1
        if intended_means.plan.has_goal_condition():
            self._im_with_goal_condition += 1

    def peek(self) -> IntendedMeans | None:
        return self._intended_means[0] if self._intended_means else None

    def root(self) -> IntendedMeans | None:
        """The intended means at the bottom of the stack: the one this whole
        intention was created for.

        ag: peek()'s twin, and O(1) for the same reason -- push() appendlefts,
        so the first frame is the last element. What it answers is "what is
        this intention ultimately doing", which is a different question from
        "what is it doing right now" and the only one that survives a plan
        calling a subgoal. Agent.revise uses it to tell whether a belief change
        happened inside a goal the model asked for.
        """
        return self._intended_means[-1] if self._intended_means else None

    def pop(self) -> IntendedMeans:
        top: IntendedMeans = self._intended_means.popleft()
        if self.is_atomic() and top.is_atomic():
            self._atomic_count -= 1
        if self.has_interest_in_update_events() and top.plan.has_interest_in_update_events():
            self._interested_in_update_events -= 1
        if self.has_goal_condition() and top.plan.has_goal_condition():
            self._im_with_goal_condition -= 1
        return top

    def is_atomic(self) -> bool:
        return self._atomic_count > 0

    def set_atomic(self, atomic_count: int) -> None:
        self._atomic_count = atomic_count

    def copy_to(self, other: Intention) -> None:
        # used by fork and by the update-event branching in SelEv1; as in Jason,
        # the interest/goal-condition counters are not copied (callers reset or
        # don't rely on them)
        other._atomic_count = self._atomic_count
        other._intended_means = deque(self._intended_means)

    def set_no_interest_in_update_events(self) -> None:
        self._interested_in_update_events = 0

    def has_interest_in_update_events(self) -> bool:
        return self._interested_in_update_events > 0

    def has_goal_condition(self) -> bool:
        return self._im_with_goal_condition > 0

    def __iter__(self):
        return iter(self._intended_means)

    def is_finished(self) -> bool:
        return not self._intended_means

    def size(self) -> int:
        return len(self._intended_means)

    def clear_intended_means(self) -> None:
        self._intended_means.clear()

    @property
    def suspended(self) -> bool:
        return self._suspended

    @suspended.setter
    def suspended(self, suspended: bool) -> None:
        self._suspended = suspended

    @property
    def suspended_reason(self) -> Term:
        if self._suspended_reason is None:
            return Atom( "no_reason" )
        return self._suspended_reason

    @suspended_reason.setter
    def suspended_reason(self, reason: Term) -> None:
        self._suspended_reason = reason

    def get_intended_means(self, condition: IMCondition, unifier: Unifier) -> IntendedMeans | None:
        for intended_mean in self._intended_means:
            if condition.test(intended_mean, unifier):
                return intended_mean
        return None

    def has_trigger(self, trigger: Trigger, unifier: Unifier) -> bool:
        for intended_mean in self._intended_means:
            if unifier.unifies(trigger, intended_mean.trigger):
                return True
        return False

    def drop_goal(self, condition: IMCondition, unifier: Unifier) -> IntendedMeans | None:
        result: IntendedMeans | None = None
        while (im := self.get_intended_means(condition, unifier)) is not None:
            while self.peek() is not im:
                self.pop()
            result = self.pop()
        return result

    def fail(self, circumstance: Circumstance) -> None:
        """Last rites for an intention whose failure found no -!g handler
        anywhere (Java's Intention.fail(C)). A no-op here -- the intention is
        about to be dropped by the caller -- and an extension point for
        subclasses: .fork's branches use it to tear down their siblings."""

    def find_event_for_failure(self, trigger: Trigger, plan_lib: PlanLibrary,
                                circumstance: Circumstance) -> tuple[Event | None, int]:
        """Looks for a -!g/-?g failure-handling plan for `trigger`, walking up the
        intention's call stack (and then up plan_lib's father chain) until one is
        found. Returns the failure event to raise (or None if no handler exists
        anywhere) and how many frames down the stack it was found at.
        """
        items = list(self._intended_means)
        index = 0
        pos_in_stack = len(items)
        tevent = trigger

        if tevent.is_goal() and not tevent.is_addition():
            # failure inside a fail-handling plan itself: walk down to the goal it was handling
            im = items[index]
            index += 1
            found = False
            while index < len(items) and not found:
                im = items[index]
                index += 1
                pos_in_stack -= 1
                while index < len(items) and im.unifier.unifies(im.trigger.literal, tevent.literal):
                    im = items[index]
                    index += 1
                    pos_in_stack -= 1
                    found = True
            tevent = im.trigger

        fail_trigger = Trigger(TEOperator.DEL, tevent.type, tevent.literal)
        while not plan_lib.has_candidate_plan(fail_trigger) and index < len(items):
            im = items[index]
            index += 1
            tevent = im.trigger
            fail_trigger = Trigger(TEOperator.DEL, tevent.type, tevent.literal)
            pos_in_stack -= 1

        if tevent.is_goal() and plan_lib.has_candidate_plan(fail_trigger):
            return Event(fail_trigger.clone(), self), pos_in_stack
        elif not plan_lib.is_root():
            return self.find_event_for_failure(tevent, plan_lib.father, circumstance)
        else:
            return None, 0

    def __str__(self) -> str:
        means = " | ".join(str(im) for im in self._intended_means)
        suspended_reason = f", reason={self.suspended_reason}" if self.suspended else ""
        return f"intended_means=[{means}], suspended={self.suspended}{suspended_reason}"

    def __repr__(self) -> str:
        return str(self)
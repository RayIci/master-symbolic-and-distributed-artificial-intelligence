from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.trigger import Trigger

if TYPE_CHECKING:
    from icaros.as_semantics.intention import Intention
    from icaros.as_semantics.option import Option

class Event:

    # ag: intention=None plays Java's Intention.EmptyInt role (see is_external below)
    def __init__(self, trigger: Trigger, intention: Intention | None = None):
        self._trigger: Trigger = trigger
        self._intention: Intention | None = intention
        self._option: Option | None = None

    @property
    def trigger(self):
        return self._trigger

    @property
    def intention(self):
        return self._intention

    @intention.setter
    def intention(self, intention: Intention):
        self._intention = intention

    @property
    def option(self):
        return self._option

    @option.setter
    def option(self, option: Option):
        self._option = option

    def is_external(self):
        return self.intention is None

    def is_internal(self):
        return self.intention is not None

    def is_atomic(self):
        return self.intention is not None and self.intention.is_atomic()

    def __eq__(self, other: Event):
        if other is None:
            return False
        if other is self:
            return True
        if isinstance(other, Event):
            if self.intention is None and other.intention is not None:
                return False
            if self.intention is not None and not other.intention == self.intention:
                return False
            return self.trigger == other.trigger
        return False

    # ag: clone not ported, we can use deepcopy

    def __str__(self):
        if self.intention is None:
            return str(self.trigger)
        return str(self.trigger) + "\n" + str(self.intention)

    def __repr__(self) -> str:
        kind = "external" if self.is_external() else "internal"
        return f"trigger={self.trigger}, kind={kind}, intention={self.intention}"
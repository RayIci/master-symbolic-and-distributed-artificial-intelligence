from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_semantics.event import Event
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.trigger import Trigger


class GoalStates(Enum):
    PENDING = "pending"
    EXECUTING = "executing"
    SUSPENDED = "suspended"
    RESUMED = "resumed"
    WAITING = "waiting"
    ACHIEVED = "achieved"
    DROPPED = "dropped"
    FAILED = "failed"
    FINISHED = "finished"

    def __str__(self) -> str:
        return self.value


class GoalListener:
    """Callback interface to be notified about events on goals. Mirrors
    Jason's GoalListener -- see CircumstanceListener for why this is a
    plain base class with no-op bodies rather than Protocol/ABC."""

    def goal_started(self, goal: Event) -> None: ...

    def goal_finished(self, goal: Trigger, result: GoalStates | None) -> None: ...

    def goal_failed(self, goal: Trigger, reason: Term | None) -> None: ...

    def goal_suspended(self, goal: Trigger, reason: Term | None) -> None: ...

    def goal_waiting(self, goal: Trigger, reason: Term | None) -> None: ...

    def goal_resumed(self, goal: Trigger, reason: Term | None) -> None: ...

    def goal_executing(self, goal: Trigger, reason: Term | None) -> None: ...
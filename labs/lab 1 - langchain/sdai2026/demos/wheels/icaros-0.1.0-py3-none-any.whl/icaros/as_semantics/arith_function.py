from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from collections.abc import Callable

    from icaros.as_syntax.term import Term

    ArithFn = Callable[["list[Term]"], float]


@runtime_checkable
class ArithFunction(Protocol):
    """The contract ArithFunctionTerm.resolve() calls arithmetic functions
    through (Java's ArithFunction interface). Mirrors InternalAction in
    stdlib/registry.py, but for the different call convention arithmetic
    functions need: no Unifier (args arrive already resolved, see
    ArithFunctionTerm.resolve()), and a float result instead of
    bool | Iterator[Unifier].

    ag: Java's evaluate() also takes a TransitionSystem, since ArithFunctionTerm
    binds itself to its owning Agent at construction time to obtain it. Ported
    without that -- no ArithFunctionTerm is ever bound to an Agent here (see
    porting.md), and among all the built-ins ported so far none actually need
    agent context, so evaluate() only takes the already-resolved args."""

    def get_name(self) -> str: ...

    def evaluate(self, args: list[Term]) -> float:
        """Computes the function's numeric result from its (already-resolved)
        argument terms."""
        ...

    def check_arity(self, a: int) -> bool: ...

    def allow_unground_terms(self) -> bool:
        """If True, evaluate() may run even when the args aren't fully
        ground (unused by any of the built-ins ported so far -- always
        False, unlike Jason's .count/RuleToFunction, out of scope here)."""
        ...


class FunctionArith(ArithFunction):
    """Adapts a plain function `fn(args) -> float` to the ArithFunction
    protocol, adding arity validation. Built by the @arith_function decorator
    (stdlib/arith_registry.py). No new_instance()/per-agent state unlike
    FunctionIA -- every built-in arithmetic function is stateless (even
    math::random has none of its own, it borrows .random's module-level RNG,
    see stdlib/math/__init__.py)."""

    def __init__(self, fn: ArithFn, name: str, min_args: int = 0, max_args: int | None = None,
                 allow_unground: bool = False):
        self._fn = fn
        self._name = name
        self._min_args = min_args
        self._max_args = max_args
        self._allow_unground = allow_unground
        self.__doc__ = fn.__doc__

    def get_name(self) -> str:
        return self._name

    def check_arity(self, a: int) -> bool:
        if a < self._min_args:
            return False
        return self._max_args is None or a <= self._max_args

    def evaluate(self, args: list[Term]) -> float:
        return float(self._fn(args))

    def allow_unground_terms(self) -> bool:
        return self._allow_unground

    def __repr__(self) -> str:
        return f"<arithmetic function '{self._name}'>"
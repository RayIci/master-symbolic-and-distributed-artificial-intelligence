from __future__ import annotations

import threading
import uuid
from collections import deque
from typing import Dict, Iterator, TYPE_CHECKING
from icaros.as_semantics.circumstance_listener import CircumstanceListener
from icaros.as_semantics.event import Event
from icaros.as_semantics.action_exec import ActionExec
from icaros.as_semantics.message import Message
from icaros.as_semantics.option import Option
from icaros.as_syntax.factory import create_structure
from icaros.as_syntax.plan_body import PlanBody
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.term import Term
from icaros.as_syntax.trigger import TEOperator, TEType
from icaros.as_syntax.trigger import Trigger
from icaros.as_semantics.unifier import Unifier

if TYPE_CHECKING:
    from icaros.llm import IcarosSession, LlmToolResult
    from icaros.as_semantics.intention import Intention


class Circumstance:

    def __init__(self):
        self._events: deque[Event] = deque()
        self._intentions: deque[Intention] = deque()
        self._action: ActionExec | None = None

        self._mailbox: deque[Message] = deque()

        self._relevant_plans: list[Option] | None = None
        self._applicable_plans: list[Option] | None = None

        self._selected_event: Event | None = None
        self._selected_option: Option | None = None
        self._selected_intention: Intention | None = None

        self._atomic_intention: Intention | None = None
        self._atomic_event: Event | None = None
        self._atomic_intention_suspended: bool = False

        self._pending_actions: Dict[ uuid.UUID, ActionExec ] = {}
        self._feedback_actions: deque[ActionExec] = deque()

        # when an llm calls a plan or a IA the results will be stored here
        # waiting for being consumed
        self._llm_results: deque[LlmToolResult] = deque()

        # the model conversations open right now, keyed by session id. A dict
        # because results are routed back by id; its insertion order is the
        # order the sessions were opened, which is the order GENERATE serves
        # them in.
        self._icaros_sessions: Dict[str, IcarosSession] = {}

        # what each goal the model asked for changed in the belief base, keyed
        # by llm_call id, filled by Agent.revise and emptied into the result
        # when the goal ends. A call whose goal never ends keeps its entry --
        # it lives exactly as long as the intention that opened it, which is
        # the most that can be said without inventing an expiry.
        self._llm_belief_deltas: Dict[str, list[str]] = {}

        self._feedback_actions_lock = threading.RLock()

        self._pending_intentions: Dict[str, Intention] = {}
        self._pending_events: Dict[str, Event] = {}

        self._intentions_with_goal_condition = 0

        self._last_deed: PlanBody | None = None

        self._listeners: list[CircumstanceListener] = []

    ### Listeners ################
    def add_event_listener(self, listener: CircumstanceListener) -> None:
        self._listeners.append(listener)

    def remove_event_listener(self, listener: CircumstanceListener) -> None:
        try:
            self._listeners.remove(listener)
        except ValueError:
            pass

    def has_listener(self) -> bool:
        return bool(self._listeners)

    @property
    def listeners(self):
        return self._listeners

    def _notify(self) -> tuple[CircumstanceListener, ...]:
        # ag: a snapshot, not the live list -- a listener may deregister
        # itself from inside its own callback (e.g. .wait's _WaitEvent), and
        # iterating the live list while that happens silently skips whatever
        # comes after it.
        return tuple(self._listeners)

    def reset(self):
        self.reset_sense()
        self.reset_deliberate()
        self.reset_act()

    def reset_sense(self):
        pass

    def has_intention_with_goal_condition(self) -> bool:
        return self._intentions_with_goal_condition > 0

    def reset_intention_with_goal_condition(self):
        self._intentions_with_goal_condition = 0

    def reset_deliberate(self):
        self._relevant_plans = None
        self._applicable_plans = None
        self._selected_event = None
        self._selected_option = None

    def reset_act(self):
        self._action = None
        self._selected_intention = None
        self._last_deed = None

    def add_achieve_goal(self, literal: Literal, intention: Intention) -> Event:
        event: Event = Event(Trigger(TEOperator.ADD, TEType.ACHIEVE, literal), intention)
        self.add_event(event)
        return event

    def add_external_event(self, trigger: Trigger) -> None:
        self.add_event(Event(trigger,None))

    def add_event(self, event: Event) -> None:
        if event.is_atomic():
            self._atomic_event = event
        else:
            self._events.append(event)
        for listener in self._notify():
            listener.event_added(event)

    def add_meta_event(self, event: Event) -> None:
        index = 0
        while index < len(self._events) and self._events[index].trigger.is_meta_event():
            index += 1
        self._events.insert(index, event)

    def remove_event(self, event: Event) -> bool:
        if event == self._atomic_event:
            self._atomic_event = None
            removed = True
        else:
            try:
                self._events.remove(event)
                removed = True
            except ValueError:
                removed = False
        if removed and event.intention is not None:
            for listener in self._notify():
                listener.intention_dropped(event.intention)
        return removed

    def remove_events(self, trigger: Trigger, unifier: Unifier) -> None:
        # ag: single-pass rebuild instead of deque.remove() (O(n)) inside a
        # loop over a snapshot -- was O(n^2) on the number of pending events.
        # ag: listener notifications are collected during the rebuild and
        # fired afterward (once _events is consistent again) rather than
        # inline as in Java -- observationally identical for the only real
        # consumer, and safer against a listener that re-enters Circumstance.
        survivors = deque()
        dropped: list[Intention] = []
        for event in self._events:
            cur_trigger = event.trigger
            if event.intention is not None:
                cur_trigger = cur_trigger.resolve(event.intention.peek().unifier)
            if not unifier.clone().unifies_no_undo(trigger, cur_trigger):
                survivors.append(event)
            elif event.intention is not None:
                dropped.append(event.intention)
        self._events = survivors
        if dropped:
            for listener in self._notify():
                for intention in dropped:
                    listener.intention_dropped(intention)

    def clear_events(self, only_goals: bool = False) -> None:
        # ag: notifies for every event in E (and the atomic event), even
        # when only_goals=True and only a subset is actually removed below
        # -- faithfully matches Java's clearEvents(boolean), which does the
        # same over-broad notify. Java's no-arg clearEvents() has its own
        # notify block commented out as dead code (its delegate already
        # notifies), so unlike that dead branch, this always notifies.
        if self._listeners:
            for listener in self._notify():
                for e in self._events:
                    if e.intention is not None:
                        listener.intention_dropped(e.intention)
                if self._atomic_event is not None and self._atomic_event.intention is not None:
                    listener.intention_dropped(self._atomic_event.intention)
        self._atomic_event = None
        if not only_goals:
            self._events.clear()
            return
        self._events = deque(e for e in self._events if not e.trigger.is_goal())

    @property
    def events(self):
        return self._events

    @property
    def events_plus_atomic(self):
        # ag: atomic event goes first, matching Jason's Circumstance.java --
        # this port used to append it last (a real priority inversion for the
        # 6 call sites that iterate this, though verified harmless: all 6 are
        # order-independent full scans/any(), not "first match wins")
        if not self._atomic_event:
            return list(self._events)
        return [self._atomic_event] + list(self._events)

    def has_event(self):
        return self._atomic_event is not None or bool(self._events)

    def remove_atomic_event(self):
        tmp = self._atomic_event
        self._atomic_event = None
        if tmp is not None and tmp.intention is not None:
            for listener in self._notify():
                listener.intention_dropped(tmp.intention)
        return tmp

    ### Messages ################
    @property
    def mailbox(self):
        return self._mailbox

    def add_msg(self, msg: Message) -> None:
        self._mailbox.append(msg)

    # def has_msg(self) -> bool:
    #     return len(self._mailbox) > 0

    ### Intentions ###############

    @property
    def running_intentions(self):
        return self._intentions

    @property
    def running_intentions_plus_atomic(self):
        # ag: always a fresh list -- used to return the live self._intentions
        # deque when there was no atomic intention, a fresh list otherwise,
        # an inconsistent contract (sometimes mutating through this reached
        # the source, sometimes it didn't) matching events_plus_atomic above
        if self._atomic_intention is None:
            return list(self._intentions)
        return list(self._intentions) + [self._atomic_intention]

    @property
    def nb_running_intentions(self):
        n = len(self._intentions)
        if self._atomic_intention is not None:
            n += 1
        if self._selected_intention is not None and self._atomic_intention != self._selected_intention:
            n += 1
        return n

    def has_running_intentions(self):
        return bool(self._intentions) or self._atomic_intention is not None

    def has_running_intention(self, intention: Intention) -> bool:
        return intention == self._atomic_intention or intention in self._intentions

    def add_running_intention(self, intention: Intention) -> None:
        if intention.is_atomic():
            self.atomic_intention = intention
        else:
            self._intentions.append(intention)
        if intention.has_goal_condition():
            self._intentions_with_goal_condition += 1
        for listener in self._notify():
            listener.intention_added(intention)

    def resume_intention(self, intention: Intention, reason: Term | None) -> None:
        self.add_running_intention(intention)
        for listener in self._notify():
            listener.intention_executing(intention, reason)

    def remove_running_intention(self, intention: Intention) -> bool:
        if intention == self._atomic_intention:
            self.atomic_intention = None
            return True
        try:
            self._intentions.remove(intention)
            return True
        except ValueError:
            return False

    def drop_running_intention(self, intention: Intention) -> bool:
        removed = self.remove_running_intention(intention)
        if removed:
            for listener in self._notify():
                listener.intention_dropped(intention)
        return removed

    def clear_running_intentions(self) -> None:
        self.atomic_intention = None
        # ag: matches Java's clearRunningIntentions -- AI is cleared first
        # and never notified; only the intentions in I are.
        if self._listeners:
            for listener in self._notify():
                for intention in self._intentions:
                    listener.intention_dropped(intention)
        self._intentions.clear()

    @property
    def atomic_intention(self):
        return self._atomic_intention

    @atomic_intention.setter
    def atomic_intention(self, intention: Intention) -> None:
        self._atomic_intention = intention

    def remove_atomic_intention(self) -> Intention | None:
        if self._atomic_intention is None:
            return None
        if self._atomic_intention_suspended:
            return None
        tmp = self._atomic_intention
        self.remove_running_intention(self._atomic_intention)
        return tmp

    def has_atomic_intention(self) -> bool:
        return self._atomic_intention is not None

    def is_atomic_intention_suspended(self) -> bool:
        # ag: regression -- this used to read self._atomic_intention.suspended,
        # a field only ever written by the .suspend/.resume internal actions.
        # add_pending_action/add_pending_intention (and their remove_* /
        # remove_atomic_intention counterparts) correctly maintain
        # _atomic_intention_suspended instead, so an atomic intention that
        # dispatched an action was handed straight back to SEL_INT on the very
        # next cycle -- it ran its next body step while its own action was
        # still outstanding, breaking atomicity.
        return self._atomic_intention is not None and self._atomic_intention_suspended

    @property
    def pending_intentions(self):
        return self._pending_intentions

    def get_pending_intentions_key(self, intention: Intention) -> str | None:
        for key, pending_intention in self._pending_intentions.items():
            if pending_intention == intention:
                return key
        return None

    def has_pending_intentions(self) -> bool:
        return bool(self._pending_intentions)

    def clear_pending_intentions(self) -> None:
        if self._listeners:
            for listener in self._notify():
                for intention in self._pending_intentions.values():
                    listener.intention_dropped(intention)
        self._pending_intentions.clear()

    def add_pending_intention(self, pending_id: str, intention: Intention, reason: Term | None = None,
                               *, suspend: bool = True) -> None:
        if reason is None:
            reason = Atom(pending_id)
        if intention.is_atomic():
            self.atomic_intention = intention
            self._atomic_intention_suspended = True
        self._pending_intentions[pending_id] = intention
        intention.suspended_reason = reason
        for listener in self._notify():
            if suspend:
                im = intention.peek()
                listener.intention_suspended(im.trigger if im is not None else None, intention, reason)
            else:
                listener.intention_waiting(intention, reason)

    def remove_pending_intention(self, pending_id: str | uuid.UUID) -> Intention | None:
        if isinstance(pending_id, str):
            intention = self._pending_intentions.pop(pending_id, None)
            if intention is not None and intention.is_atomic():
                self._atomic_intention_suspended = False
            return intention
        for key, intention in self._pending_intentions.items():
            if intention.id == pending_id:
                return self.remove_pending_intention(key)
        return None

    def drop_pending_intention(self, intention: Intention) -> bool:
        for key, pending_intention in self._pending_intentions.items():
            if pending_intention == intention:
                self.remove_pending_intention(key)
                for listener in self._notify():
                    listener.intention_dropped(intention)
                return True
        return False

    ### Events ##################
    @property
    def pending_events(self):
        return self._pending_events

    def has_pending_events(self) -> bool:
        return bool(self._pending_events)

    def clear_pending_events(self) -> None:
        if self._listeners:
            for listener in self._notify():
                for e in self._pending_events.values():
                    if e.intention is not None:
                        listener.intention_dropped(e.intention)
        self._pending_events.clear()

    def add_pending_event(self, pending_id: str, event: Event, reason: Term):
        self._pending_events[pending_id] = event
        if event.intention is not None:
            event.intention.suspended_reason = reason
        for listener in self._notify():
            listener.intention_suspended(event.trigger, event.intention, reason)

    def remove_pending_event(self, pending_id: str, *, notify: bool = True) -> Event | None:
        # ag: notify=False lets .resume's pending-event branch pop without
        # firing intention_dropped -- Java's resume() removes from PE via a
        # raw iterator there, deliberately not through a notifying method
        # (resume.java), because the intention is being resumed, not dropped.
        event = self._pending_events.pop(pending_id, None)
        if notify and event is not None and event.intention is not None:
            for listener in self._notify():
                listener.intention_dropped(event.intention)
        return event

    def remove_pending_events(self, trigger: Trigger, unifier: Unifier) -> None:
        for key in list(self._pending_events.keys()):
            pending_event = self._pending_events[key]
            pe_trigger = pending_event.trigger
            if pending_event.intention is not None:
                pe_trigger = pe_trigger.resolve(pending_event.intention.peek().unifier)
            if unifier.clone().unifies_no_undo(trigger, pe_trigger):
                self._pending_events.pop(key)
                if pending_event.intention is not None:
                    for listener in self._notify():
                        listener.intention_dropped(pending_event.intention)

    ### Actions ################
    @property
    def action(self):
        return self._action

    @action.setter
    def action(self, action: ActionExec) -> None:
        self._action = action

    @property
    def applicable_plans(self):
        return self._applicable_plans

    @applicable_plans.setter
    def applicable_plans(self, options) -> None:
        self._applicable_plans = options

    def has_feedback_action(self):
        # ag: locked because this is the one Circumstance structure written
        # from outside the agent's own thread -- the environment's action
        # threads and TimeSteppedEnvironment's step thread both reach
        # add_feedback_action() via AgArch.action_executed(). Iterating it
        # unlocked while one of them appends raises "deque mutated during
        # iteration", and can_sleep() calls this on every reasoning cycle.
        if not self._feedback_actions:
            # ag: unlocked fast path for the overwhelmingly common case.
            # deque.__len__ is a single atomic read (no iteration), under the
            # GIL and free-threaded alike, and only the agent's own thread
            # consumes -- so a False here can only be stale by an append that
            # is immediately followed by wake_up_act() (ag_arch.action_executed),
            # which re-runs the check. Nothing can be lost.
            return False
        with self._feedback_actions_lock:
            for action in self._feedback_actions:
                if not action.intention.suspended:
                    return True
            return False

    @property
    def feedback_actions_lock(self):
        return self._feedback_actions_lock

    @property
    def feedback_actions(self):
        return self._feedback_actions

    def add_feedback_action(self, action: ActionExec) -> None:
        # called from the environment's action threads and from
        # TimeSteppedEnvironment's step thread, never the agent's own --
        # pairs with has_feedback_action()'s iteration above
        with self._feedback_actions_lock:
            self._feedback_actions.append(action)

    @property
    def pending_actions(self):
        return self._pending_actions

    def add_pending_action(self, action: ActionExec) -> None:
        if action.intention.is_atomic():
            self.atomic_intention = action.intention
            self._atomic_intention_suspended = True
        self._pending_actions[action.intention.id] = action
        for listener in self._notify():
            listener.intention_waiting(action.intention, create_structure("action", action.action_term))

    def clear_pending_actions(self) -> None:
        if self._listeners:
            for listener in self._notify():
                for act in self._pending_actions.values():
                    listener.intention_dropped(act.intention)
        self._pending_actions.clear()

    def has_pending_action(self):
        return bool(self._pending_actions)

    def remove_pending_action(self, intention_id: uuid.UUID) -> ActionExec | None:
        act : ActionExec | None = self._pending_actions.pop(intention_id, None)
        if act is not None and act.intention.is_atomic():
            self._atomic_intention_suspended = False
        return act

    def drop_pending_action(self, intention: Intention) -> bool:
        removed = self.remove_pending_action(intention.id) is not None
        if removed:
            for listener in self._notify():
                listener.intention_dropped(intention)
        return removed

    ### LLM results ################

    @property
    def llm_results(self):
        return self._llm_results

    def add_llm_result(self, result: LlmToolResult) -> None:
        self._llm_results.append(result)

    def has_llm_result(self) -> bool:
        """"Is there anything for the model to consider?"

        Asking is free and changes nothing: only take_llm_results() consumes.
        """
        return bool(self._llm_results)

    def take_llm_results(self) -> list[LlmToolResult]:
        """Hands over every result collected so far and empties the queue."""
        results = list(self._llm_results)
        self._llm_results.clear()
        return results

    def note_llm_belief_change(self, call_id: str, added, deleted) -> None:
        """Records what a goal the model asked for changed in the belief base.

        Kept per call rather than per session: two goals from the same round
        can be in flight at once, and "the world changed" is only useful to a
        model if it knows which of the things it asked for did it.
        """
        bucket = self._llm_belief_deltas.setdefault(call_id, [])
        bucket.extend(f"+{literal}" for literal in added)
        bucket.extend(f"-{literal}" for literal in deleted)

    def take_llm_belief_changes(self, call_id: str) -> tuple[str, ...]:
        """Hands over what one call changed, and forgets it."""
        return tuple(self._llm_belief_deltas.pop(call_id, ()))

    def take_llm_results_for(self, session_id: str) -> list[LlmToolResult]:
        """Hands over the results addressed to ONE session, and only those.

        ag: a partial take, where take_llm_results() above is a drain. What is
        left behind is every result nobody is waiting for: a goal whose
        session closed before it finished, or whose failure took the session's
        intention down with it. Deposited-and-left is what those have always been,
        and dropping them here to keep the deque tidy would quietly change
        what the Circumstance promises about an answer it was handed.

        .icaros_consider_results is the one caller (generation.py), and it
        acts for exactly one session -- reaching into another open session's
        results as a side effect would be wrong even if harmless today.
        """
        if not self._llm_results:
            return []
        taken: list[LlmToolResult] = []
        kept: deque[LlmToolResult] = deque()
        for result in self._llm_results:
            (taken if result.session == session_id else kept).append(result)
        self._llm_results = kept
        return taken

    ### Icaros sessions ############
    # ag: a session outlives the deliberation that advances it, so none of this
    # is touched by reset_deliberate() -- it is the agent's open conversations,
    # not the state of one cycle.

    @property
    def icaros_sessions(self) -> Dict[str, IcarosSession]:
        return self._icaros_sessions

    def open_icaros_session(self, session: IcarosSession) -> None:
        self._icaros_sessions[session.id] = session

    def icaros_session(self, session_id: str | None) -> IcarosSession | None:
        return None if session_id is None else self._icaros_sessions.get(session_id)

    def close_icaros_session(self, session_id: str) -> IcarosSession | None:
        """Forgets the session, returning it. Resuming whoever opened it is
        TransitionSystem's job, not this one's: here there is only the record."""
        return self._icaros_sessions.pop(session_id, None)

    def drop_intention(self, intention: Intention, *, notify: bool = True) -> None:
        # ag: single-pass rebuild instead of remove_event() (O(n) deque.remove)
        # inside a loop over every event -- was O(n^2). Emits at most one
        # intention_dropped notification at the end regardless of how many
        # buckets (events / pending events / pending action / running
        # intentions / pending intentions) the intention was found in --
        # built on the non-notifying remove_* primitives throughout (as
        # opposed to their notifying drop_*/clear_* counterparts) so nothing
        # double-fires. notify=False lets a caller that is about to re-park
        # the intention elsewhere (e.g. .suspend, moving it to pending
        # intentions) skip the drop notification entirely -- the intention
        # isn't being dropped, it's being relocated, and Java's .suspend
        # doesn't fire intentionDropped for that either.
        was_present = False
        survivors = deque()
        for event in self._events:
            if event.intention is not None and event.intention == intention:
                was_present = True
            else:
                survivors.append(event)
        self._events = survivors
        if (self._atomic_event is not None and self._atomic_event.intention is not None
                and self._atomic_event.intention == intention):
            self._atomic_event = None
            was_present = True
        for key in list(self._pending_events.keys()):
            cur_int = self._pending_events.get(key).intention
            if cur_int is not None and cur_int == intention:
                self._pending_events.pop(key)
                was_present = True
        if self.remove_pending_action(intention.id) is not None:
            was_present = True
        if self.remove_running_intention(intention):
            was_present = True
        for key, pending_intention in list(self._pending_intentions.items()):
            if pending_intention == intention:
                self.remove_pending_intention(key)
                was_present = True
        if self._icaros_sessions:
            # ag: an intention carrying an icaros bubble is an ordinary running
            # intention now (see generation.py's _open) -- dropped like any
            # other by whatever found it above. Nobody will ever select it
            # again, so nobody will ever run its .icaros_step/
            # .icaros_consider_results far enough to close the session itself;
            # without this the entry in _icaros_sessions would leak forever.
            for session_id, session in list(self._icaros_sessions.items()):
                if session.intention == intention:
                    self.close_icaros_session(session_id)
        if was_present and notify and self._listeners:
            for listener in self._notify():
                listener.intention_dropped(intention)

    def all_intentions(self) -> Iterator[Intention]:
        # iterates over snapshots, so callers may add/remove events and
        # intentions while consuming the generator (e.g. Rule SelEv1)
        by_selection: set[Intention] = set()
        if self._selected_event is not None and self._selected_event.intention is not None:
            by_selection.add(self._selected_event.intention)
            yield self._selected_event.intention
        if self._selected_intention is not None and self._selected_intention not in by_selection:
            by_selection.add(self._selected_intention)
            yield self._selected_intention
        for event in self.events_plus_atomic:
            if event.intention is not None and event.intention not in by_selection:
                yield event.intention
        for event in list(self._pending_events.values()):
            if event.intention is not None and event.intention not in by_selection:
                yield event.intention
        for action in list(self._pending_actions.values()):
            if action.intention is not None and action.intention not in by_selection:
                yield action.intention
        for intention in list(self._pending_intentions.values()):
            if intention not in by_selection:
                yield intention
        for intention in list(self.running_intentions_plus_atomic):
            if intention not in by_selection:
                yield intention

    @property
    def relevant_plans(self):
        return self._relevant_plans

    @relevant_plans.setter
    def relevant_plans(self, options) -> None:
        self._relevant_plans = options

    @property
    def selected_event(self):
        return self._selected_event

    @selected_event.setter
    def selected_event(self, event) -> None:
        self._selected_event = event

    @property
    def selected_intention(self):
        return self._selected_intention

    @selected_intention.setter
    def selected_intention(self, intention) -> None:
        self._selected_intention = intention

    @property
    def selected_option(self):
        return self._selected_option

    @selected_option.setter
    def selected_option(self, option) -> None:
        self._selected_option = option

    @property
    def last_deed(self):
        return self._last_deed

    @last_deed.setter
    def last_deed(self, last_deed):
        self._last_deed = last_deed

    def __str__(self):
        result = "Circumstance:\n"
        result += f"  E = {self._events}\n"
        result += f"  I = {self._intentions}\n"
        result += f"  A = {self._action}\n"
        result += f"  MB = {self.mailbox}\n"
        result += f"  RP = {self._relevant_plans}\n"
        result += f"  AP = {self._applicable_plans}\n"
        result += f"  SE = {self._selected_event}\n"
        result += f"  SO = {self._selected_option}\n"
        result += f"  SI = {self._selected_intention}\n"
        result += f"  AI = {self._atomic_intention}\n"
        result += f"  AE = {self._atomic_event}\n"
        result += f"  PA = {self._pending_actions}\n"
        result += f"  PI = {self._pending_intentions}\n"
        with self._feedback_actions_lock:  # formatting iterates it -- see has_feedback_action
            result += f"  FA = {list(self._feedback_actions)}."
        return result

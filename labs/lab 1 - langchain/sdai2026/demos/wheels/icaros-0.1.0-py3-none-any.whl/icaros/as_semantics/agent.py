from __future__ import annotations

import logging
from collections import deque
from typing import TYPE_CHECKING, Iterable

from icaros.as_semantics.action_exec import ActionExec
from icaros.as_semantics.event import Event
from icaros.as_semantics.intention import Intention
from icaros.llm import ToolKind, call_id_of, resolve_name_collisions, to_specs
from icaros.journal import Journal
from icaros.as_semantics.message import Message
from icaros.as_semantics.option import Option
from icaros.as_semantics.unifier import Unifier
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.logical_formula import LogicalFormula
from icaros.as_syntax.trigger import Trigger, TEOperator, TEType
from icaros.bb.belief_base import BeliefBase
from icaros.bb.rag.rag_belief_base import RagBeliefBase
from icaros.pl.plan_library import PlanLibrary

if TYPE_CHECKING:
    from pathlib import Path

    from icaros.as_semantics.icaros import Icaros
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_syntax.factory import AgentSource
    from icaros.llm import LlmTool
    from icaros.stdlib.registry import InternalAction


class Agent:
    """Belief base + plan library of an AgentSpeak agent, plus the default
    selection/revision functions and the internal-action lookup. No
    arith-function registry -- that needs infra (Settings) that isn't
    ported yet.
    """

    def __init__(self, bb: BeliefBase | None = None, options: dict[str, str] | None = None,
                 se_llm: bool = False, sm_llm: bool = False, so_llm: bool = False,
                 si_llm: bool = False, sa_llm: bool = False,
                 llm_tools: dict[str, frozenset[str] | None] | None = None):
        self._bb: BeliefBase = bb if bb is not None else BeliefBase()
        self._pl: PlanLibrary = PlanLibrary()
        self._ts: TransitionSystem | None = None
        self._internal_actions: dict[str, InternalAction] = {}
        self._logger = logging.getLogger(f"{__name__}.{type(self).__name__}")
        self.options: dict[str, str] = options or {}

        self._se_llm = se_llm
        self._sm_llm = sm_llm
        self._so_llm = so_llm
        self._si_llm = si_llm
        self._sa_llm = sa_llm
        # what llm_tools() may offer, from the mas2i `llm_tools:` property.
        # None means undeclared, and undeclared means nothing: see _selected().
        self._llm_tools = llm_tools
        # ag: always on, and that is a contract rather than a default. From the
        # moment a model reads this it is part of how the agent decides, so a
        # journal that only existed when a UI was attached would mean a run
        # behaving differently depending on whether anyone was watching.
        self._journal = Journal(beliefs_source=self._journal_beliefs,
                                cycle_source=lambda: self._ts.cycle_count if self._ts else -1)

    @property
    def bb(self) -> BeliefBase:
        return self._bb

    @bb.setter
    def bb(self, bb: BeliefBase) -> None:
        self._bb = bb

    def _journal_beliefs(self):
        """What goes into a journal checkpoint: the agent's beliefs minus the
        interpreter's own plumbing.

        ag: the kqml namespace holds four static rules from pl/kqml_plans.asl
        and nothing else -- no plan there ever asserts a kqml:: belief -- so
        dropping the namespace is exactly dropping the plumbing. Without this
        every checkpoint, and every prompt built from one, opens with four
        lines of source(self) list surgery before the first real belief.
        """
        return [belief for belief in self._bb if belief.ns.functor != "kqml"]

    @property
    def journal(self) -> Journal:
        """This agent's own record of what it did. Per-agent by construction:
        the MAS-wide view is telemetry's, and an agent reasoning over that one
        would be reading every other agent's mind."""
        return self._journal

    @property
    def pl(self) -> PlanLibrary:
        return self._pl

    @pl.setter
    def pl(self, pl: PlanLibrary) -> None:
        self._pl = pl

    @property
    def ts(self) -> TransitionSystem | None:
        return self._ts

    @ts.setter
    def ts(self, ts: TransitionSystem) -> None:
        self._ts = ts

    @property
    def so_llm(self):
        return self._so_llm

    @property
    def llm_tool_selection(self) -> dict[str, frozenset[str] | None] | None:
        """The mas2i `llm_tools:` as parsed, or None if it was not declared."""
        return self._llm_tools

    @property
    def logger(self) -> logging.Logger:
        return self._logger

    ### LLM tool views ##########

    # ag: the two read-only, self-inspection-only families (see ToolKind.
    # JOURNAL/RAG's own docstrings for why they're safe to hand a model
    # unasked) default to exposed even when llm_tools: never mentions them --
    # an agent that wrote an `agentic { }` section wants its own memory and its
    # own semantic index reachable without a second, separate opt-in. "plans" and
    # "internal_actions" stay closed by default: those DO things.
    _DEFAULT_ON_FAMILIES = frozenset({"journal", "rag"})

    def _selected(self, family: str) -> tuple[bool, frozenset[str] | None]:
        """(is this family exposed at all, which members) for `family`.

        ag: nothing beyond journal/rag is exposed unless the .mas2i asked for
        it -- an agent that never mentions llm_tools offers its model no
        goals or actions at all, not its whole plan library. These are limits
        on what an LLM may reach for, so the safe end of the scale is the
        default, and every widening beyond journal/rag is written down in the
        file where it can be read back.
        """
        if self._llm_tools is not None and family in self._llm_tools:
            return True, self._llm_tools[family]
        return family in self._DEFAULT_ON_FAMILIES, None

    def llm_tools(self, *, kinds: tuple[ToolKind, ...] | None = None,
                  include_all: bool = False) -> list[LlmTool]:
        """This agent's capabilities as LLM tool definitions.

        Empty of goals and actions unless the .mas2i asked for something:
        `llm_tools:` is what an agent may hand its model, opt-in for "plans"
        and "internal_actions". journal and rag are the exception -- see
        `_DEFAULT_ON_FAMILIES` -- and need no mention to be offered. Plans
        first (from the plan library, one tool per goal with that goal's
        plans as its variants), then internal actions -- the latter needing
        the family listed AND the action itself marked
        @internal_action(llm_tool=True). Each tool carries its `kind`, so the
        families stay distinguishable after the merge, and `kinds=` filters
        to one of them.

        `include_all` lifts the default exclusions on both sides (bundled
        KQML plans; the per-action opt-in marker).
        """
        from icaros.stdlib.ia_tools import ia_llm_tools as _ia_tools

        tools = []
        if kinds is None or ToolKind.GOAL in kinds:
            wanted, members = self._selected("plans")
            if wanted:
                tools.extend(self._plan_tools(members, include_all))
        from icaros.stdlib.internal_actions.journal_query import JOURNAL_ACTIONS
        from icaros.stdlib.internal_actions.rag_query import RAG_ACTIONS

        if kinds is None or ToolKind.INTERNAL_ACTION in kinds:
            wanted, members = self._selected("internal_actions")
            # ag: the journal and rag actions never ride along with this
            # family. `- internal_actions` says what the agent may DO; handing
            # over the read-only self-inspection actions on the back of it
            # would make an unrelated widening grant a capability nobody wrote
            # down. They have their own families, right below.
            actions = {n: ia for n, ia in self._all_internal_actions().items()
                       if n not in JOURNAL_ACTIONS and n not in RAG_ACTIONS}
            if wanted and members is not None:
                actions = {name: ia for name, ia in actions.items()
                           if name in members or name.lstrip(".") in members}
            tools.extend(_ia_tools(actions, enabled=wanted, include_all=include_all))
        if kinds is None or ToolKind.JOURNAL in kinds:
            wanted, members = self._selected("journal")
            available = {n: ia for n, ia in self._all_internal_actions().items()
                         if n in JOURNAL_ACTIONS}
            if wanted and members is not None:
                available = {name: ia for name, ia in available.items()
                             if name in members or name.lstrip(".") in members}
            tools.extend(tool.with_kind(ToolKind.JOURNAL)
                         for tool in _ia_tools(available, enabled=wanted, include_all=True))
        if kinds is None or ToolKind.RAG in kinds:
            wanted, members = self._selected("rag")
            # a plain BeliefBase has no semantic index to search -- offering
            # .rag_search would only ever hand the model a tool guaranteed to
            # fail (rag_query.py's own isinstance check), one wasted round
            # trip and a noisy ia_failed at a time.
            wanted = wanted and isinstance(self._bb, RagBeliefBase)
            available = {n: ia for n, ia in self._all_internal_actions().items()
                         if n in RAG_ACTIONS}
            if wanted and members is not None:
                available = {name: ia for name, ia in available.items()
                             if name in members or name.lstrip(".") in members}
            tools.extend(tool.with_kind(ToolKind.RAG)
                         for tool in _ia_tools(available, enabled=wanted, include_all=True))
        # a goal "+!print/1" and the action ".print" both want the name
        # "print"; this is what keeps every name in the list unique.
        return resolve_name_collisions(tools)

    def _plan_tools(self, members: frozenset[str] | None, include_all: bool) -> list[LlmTool]:
        if members is None:
            return self._pl.llm_tools(include_all=include_all)
        # PlanLibrary.indicators_for resolves whichever way the selector was
        # written in the .mas2i -- "+!book_flight/1", "book_flight/1",
        # "book_flight", or a plan label of that goal
        selected = []
        for selector in sorted(members):
            for pi in self._pl.indicators_for(selector):
                tool = self._pl.llm_tool(pi, include_all=include_all)
                if tool is not None and tool not in selected:
                    selected.append(tool)
        return selected

    def llm_tool_specs(self, dialect: str = "openai", **kwargs) -> list[dict]:
        """llm_tools() rendered in a provider dialect ("openai"/"ollama"/"anthropic")."""
        return to_specs(self.llm_tools(**kwargs), dialect)

    def _all_internal_actions(self) -> dict[str, InternalAction]:
        # get_ia populates _internal_actions lazily, on first call, so early on
        # it is nearly empty -- the tool list has to describe what this agent
        # COULD call, not just what it happens to have called already. Per-agent
        # registrations still win over the stdlib ones, as in get_ia.
        from icaros.stdlib import load_internal_actions

        return {**load_internal_actions(), **self._internal_actions}

    ### default selection functions ##########
    # each pops (not just peeks) its argument, mirroring Java's Queue.poll() contract

    def _agentic(self) -> Icaros | None:
        """This agent's Agentic, or None when it has none.

        ag: a booted agent legitimately has no Agentic -- that is what a .mas2i
        with no `agentic { }` section asks for, and what boot_agent() gives by
        default. The .mas2i path cannot combine llm_selections with a missing
        Agentic (it is written inside that section, so there is nowhere to put
        one without the other), but a custom agent_class: can flip
        _se_llm in init_ag(), and Python callers can pair Agent(se_llm=True)
        with boot_agent(agentic=None). Falling back to the default selection there
        beats an AttributeError on NoneType.
        """
        return self.ts.agentic if self.ts is not None else None

    def select_event(self, events: deque[Event]) -> Event | None:
        if self._se_llm and events is not None and len(events) > 1 and (agentic := self._agentic()):
            return agentic.select_event( events )
        return events.popleft() if events else None

    def select_message(self, messages: deque[Message]) -> Message | None:
        if self._sm_llm and messages is not None and len(messages) > 1 and (agentic := self._agentic()):
            return agentic.select_message(messages)
        return messages.popleft() if messages else None

    def select_option(self, options: list[Option] | None) -> Option | None:
        if not options:
            return None
        if self._so_llm and len(options) > 1 and (agentic := self._agentic()):
            return agentic.select_option(options)
        return options.pop(0)

    def select_intention(self, intentions: deque[Intention]) -> Intention | None:
        if self._si_llm and intentions is not None and len(intentions) > 1 and (agentic := self._agentic()):
            return agentic.select_intention(intentions)
        return intentions.popleft() if intentions else None

    def select_action(self, actions: deque[ActionExec]) -> ActionExec | None:
        if self._sa_llm and actions is not None and len(actions) > 1 and (agentic := self._agentic()):
            return agentic.select_action(actions)
        return actions.popleft() if actions else None

    ### internal actions ##########

    def get_ia(self, functor: str) -> InternalAction:
        """The internal action for `functor` (e.g. ".print"): the per-agent
        registrations win over the stdlib ones (Java's Agent.getIA). Each
        agent gets its own instance via new_instance() -- matching Java,
        where internalActions is never shared across agents -- so a stateful
        action (e.g. .random) can't leak state between agents."""
        ia = self._internal_actions.get(functor)
        if ia is None:
            from icaros.stdlib import load_internal_actions
            ia = load_internal_actions().get(functor)
            if ia is None:
                raise KeyError(f"internal action '{functor}' not found")
            ia = ia.new_instance()
            self._internal_actions[functor] = ia
        return ia

    def register_internal_actions(self, actions: dict[str, InternalAction]) -> None:
        # Java's Agent.setIA; entry point for user-defined actions
        # (load_internal_actions(extra_paths=...)) once boot/mas2i pass them.
        # new_instance() per entry, same as get_ia()'s cache-miss path -- actions
        # is typically the shared stdlib dict itself, and storing it unwrapped
        # would leak the 4 stateful IAs' (Wait/Send/_Random/Suspend) singleton
        # instances across every agent that registers it.
        self._internal_actions.update({name: ia.new_instance() for name, ia in actions.items()})

    ### message acceptance / kill acceptance ##########

    def soc_acc(self, message: Message) -> bool:
        return True

    def kill_acc(self, agent_name: str) -> bool:
        return True

    ### belief queries ##########

    def believes(self, belief: LogicalFormula, unifier: Unifier) -> bool:
        consequences = belief.logical_consequence(self, unifier)
        if consequences is None:
            return False
        try:
            unifier.compose(next(consequences))
            return True
        except StopIteration:
            return False

    def find_bel(self, belief: Literal, unifier: Unifier) -> Literal | None:
        candidates = self._bb.get_candidate_beliefs_for_literal(belief, unifier)
        if candidates is None:
            return None
        return next((c for c in candidates if not c.is_rule() and unifier.unifies(belief, c)), None)

    ### belief revision ##########

    def brf(self, belief_to_add: Literal | None, belief_to_del: Literal | None,
            intention: Intention | None, add_end: bool = False) -> tuple[list[Literal], list[Literal]] | None:
        """Revises the BB with the given add/del literals. Returns the (added, deleted)
        literals actually changed, used to generate +/- belief events, or None if nothing changed.
        This base implementation does not really "revise" -- it just adds/dels the belief;
        override for real belief revision.
        """
        added: list[Literal] = []
        deleted: list[Literal] = []

        if belief_to_add is not None and self._bb.add(belief_to_add, add_end):
            added.append(belief_to_add)

        if belief_to_del is not None:
            removed = self._bb.remove(belief_to_del)
            if not removed and not belief_to_del.is_ground():
                try:
                    unifier = intention.peek().unifier
                except (AttributeError, IndexError):
                    unifier = Unifier()
                candidates = self._bb.get_candidate_beliefs(belief_to_del.get_predicate_indicator())
                for candidate in list(candidates) if candidates is not None else []:
                    if unifier.clone().unifies_no_undo(belief_to_del, candidate):
                        belief_to_del = belief_to_del.resolve(unifier)
                        candidate.del_annots(belief_to_del.annots)
                        if not candidate.has_source():
                            removed = self._bb.remove(candidate)
                        break
            if removed:
                deleted.append(belief_to_del)

        if not added and not deleted:
            return None
        return added, deleted

    def revise(self, belief_to_add: Literal | None, belief_to_del: Literal | None,
               intention: Intention | None, add_end: bool = False
               ) -> tuple[list[Literal], list[Literal]] | None:
        """brf() plus the journal entry. Call this, not brf().

        ag: the split exists so the two concerns cannot collide. brf() is
        documented as the thing to override for real belief revision, and an
        override that forgot to record would leave the journal quietly wrong --
        which for a fold means every later reconstruction is wrong too. So the
        recording lives out here, in the method nobody is expected to replace,
        and an override is free to revise however it likes.
        """
        result = self.brf(belief_to_add, belief_to_del, intention, add_end)
        if result is not None:
            self._journal.record_belief_change(*result)
            self._note_llm_belief_change(intention, *result)
        return result

    def _note_llm_belief_change(self, intention: Intention | None, added, deleted) -> None:
        """If this revision happened inside a goal the model asked for, tells
        the Circumstance, so it can go back to the model with that goal's
        result.

        ag: `intention` is the whole reason this can be attributed at all, and
        it was already being handed to brf() and thrown away here. The two
        callers that pass it are the plan-body `+b`/`-b` steps
        (TransitionSystem._add_belief/_del_belief); add_bel/del_bel pass
        None. Percepts never get here at all (buf() bypasses revise(), as in
        Jason) -- a percept is not something a plan did, and telling a model
        its goal caused one would be a lie.

        The dict truthiness is the guard that keeps this off the hot path: an
        agent with no session open (every agent that never calls
        .talk/.run/.fly/.burn) pays that one test per belief revision and
        nothing else. A direct call rather than a CircumstanceListener for the
        reason the journal's own ag: note gives in transition_system.py --
        listeners are built on the assumption that nobody is listening.
        """
        if intention is None or self._ts is None:
            return
        circumstance = self._ts.circumstance
        if not circumstance.icaros_sessions:
            return
        # ag: the nearest frame the model asked for, not intention.root(): a
        # model's goal is a `!goal` step of the intention that opened the
        # session, so it sits somewhere up that intention's stack, above the
        # plan that called .run. Iteration goes from the top down (see
        # Intention.push), so a goal the model asked for inside another one
        # it asked for is credited to the inner one -- the one that did it.
        call_id = next((cid for im in intention
                        if (cid := call_id_of(im.trigger)) is not None), None)
        if call_id is not None:
            circumstance.note_llm_belief_change(call_id, added, deleted)

    def add_bel(self, belief: Literal) -> bool:
        if not belief.has_source():
            belief.add_annot(BeliefBase.self_source_term)
        return self._revise_and_signal(belief, None)

    def del_bel(self, belief: Literal) -> bool:
        if not belief.has_source():
            belief.add_annot(BeliefBase.self_source_term)
        return self._revise_and_signal(None, belief)

    def buf(self, percepts: Iterable[Literal] | None) -> int:
        """Belief update function: brings the [source(percept)] beliefs in
        line with `percepts`, the agent's current perception (as returned by
        AgArch.perceive()) -- every percept belief no longer perceived loses
        source(percept), every perceived literal not yet believed is added
        with it. A literal perceived before and still perceived is left
        alone, so a persistent fact never re-fires its +belief plan. None
        means "nothing new" and changes nothing. Returns how many beliefs
        were added or deleted.

        ag: like Jason's, this bypasses brf() and applies the changes to the
        belief base directly. The journal still gets the delta -- one entry
        for the whole perception, not one per percept.
        """
        if percepts is None:
            return 0
        perceived = {_StructureWrapperForLiteral(literal) for literal in percepts}
        added: list[Literal] = []
        deleted: list[Literal] = []
        circumstance = self._ts.circumstance if self._ts is not None else None

        # deleting percepts in the BB that are not perceived anymore
        for belief in self._bb.get_percepts():
            wrapper = _StructureWrapperForLiteral(belief)
            if not belief.subject_to_buf() or wrapper in perceived:
                perceived.discard(wrapper)
                continue
            # ag: a copy without the other annots, so remove() takes away
            # source(percept) only -- a belief also told by someone else
            # survives with its remaining sources, as with Jason's iterator
            # remove(). Built before the removal, and also the literal of the
            # -belief event.
            literal = belief.copy().clear_annots()
            literal.add_annot(BeliefBase.percept_source_term)
            if not self._bb.remove(literal):
                continue
            deleted.append(literal)
            if circumstance is not None:
                trigger = Trigger(TEOperator.DEL, TEType.BELIEF, literal)
                if circumstance.has_listener() or self._pl.has_candidate_plan(trigger):
                    circumstance.add_event(Event(trigger, None))

        # add() only adds a belief when appropriate, checking all percepts is not a problem
        for wrapper in perceived:
            try:
                # copied before annotating: the literal belongs to the
                # environment's snapshot, possibly shared by every agent
                literal = wrapper.literal.copy().force_full_literal_impl()
                literal.add_annot(BeliefBase.percept_source_term)
                if self._bb.add(literal):
                    added.append(literal)
                    if self._ts is not None:
                        self._ts.update_events(Event(Trigger(TEOperator.ADD, TEType.BELIEF, literal), None))
            except Exception:
                self._logger.exception("Error adding percept %s", wrapper.literal)

        self._journal.record_belief_change(added, deleted)
        return len(added) + len(deleted)

    def _revise_and_signal(self, belief_to_add: Literal | None, belief_to_del: Literal | None) -> bool:
        result = self.revise(belief_to_add, belief_to_del, None)
        if result is None:
            return False
        if self._ts is not None:
            added, deleted = result
            circumstance = self._ts.circumstance
            for belief in added:
                circumstance.add_event(Event(Trigger(TEOperator.ADD, TEType.BELIEF, belief), None))
            for belief in deleted:
                circumstance.add_event(Event(Trigger(TEOperator.DEL, TEType.BELIEF, belief), None))
        return True

    def abolish(self, belief: Literal, unifier: Unifier | None = None) -> None:
        unifier = unifier if unifier is not None else Unifier()
        candidates = self._bb.get_candidate_beliefs_for_literal(belief, unifier)
        to_delete = [c for c in (candidates or [])
                     if not c.is_rule() and unifier.clone().unifies_no_undo(belief, c)]
        for candidate in to_delete:
            self.del_bel(candidate)

    ### relevant / applicable plans ##########

    def relevant_plans(self, trigger: Trigger, event: Event | None) -> list[Option] | None:
        """Plans (as Options: plan + unifier) whose trigger event matches `trigger`,
        searched from the proper plan library scope outwards (sub-plans/enclosing
        scope of the intention behind `event`, then its ancestors).
        """
        te = trigger.clone()
        result: list[Option] | None = None

        plan_lib: PlanLibrary | None = self._pl
        if event is not None and event.is_internal() and not event.intention.is_finished():
            plan = event.intention.peek().plan
            if plan.has_sub_plans():
                plan_lib = plan.sub_plans
            elif plan.scope is not None:
                plan_lib = plan.scope

        while plan_lib is not None:
            for candidate in plan_lib.get_candidate_plans(te) or []:
                rel_unifier = None
                if event is not None and event.is_internal():
                    for im in event.intention:
                        if im.plan.has_sub_plans() and im.plan.sub_plans.get(candidate.label) is not None:
                            rel_unifier = im.trigger_unifier.clone()
                            break

                rel_unifier = candidate.is_relevant(te, rel_unifier)
                if rel_unifier is not None:
                    if result is None:
                        result = []
                    result.append(Option(candidate, rel_unifier, event))
            plan_lib = plan_lib.father

        return result

    ### loading from source ##########

    def load_asl(self, source: str, origin: str | None = None, base_dir: Path | None = None,
                 source_name: str | None = None) -> list[Trigger]:
        """Parses an .asl file's contents into this agent's belief base and
        plan library, mirroring Java's Agent.loadAS. Returns the initial-goal
        triggers (Java's Agent.addInitialGoalsInTS) for the caller to seed
        into a Circumstance once one exists.

        `origin` tags every parsed plan (Plan.source_file) -- used by
        PlanLibrary.add() to tell the bundled KQML default plans (boot.py)
        apart from an agent's own, for has_user_kqml_received_plans.

        `base_dir`, when given, is the directory `{include("...")}`
        directives in `source` resolve relative paths against (see
        factory.py's parse_agent) -- typically the .asl file's own directory.

        `source_name`, when given, names the file in any syntax-error message.
        """
        from icaros.as_syntax.factory import parse_agent
        return self.load_parsed_asl(
            parse_agent(source, base_dir=base_dir, source_name=source_name), origin)

    def load_parsed_asl(self, parsed: AgentSource, origin: str | None = None) -> list[Trigger]:
        """Same as load_asl, but for a source already parsed by a previous
        load_asl/parse_agent call -- lets a caller that loads the exact same
        .asl text into many agents (boot.py's kqml_plans.asl, loaded into
        every agent it boots) parse it once and reuse the result, instead of
        re-parsing per agent.

        Each call gets its OWN copies (`.clone()`/`.copy()`), not the shared
        parsed objects: PlanLibrary.add() mutates the plan it's given
        (`p.scope = self`, an annot on the label, `p.is_plan_term`), so
        handing out the same Plan to every agent means whichever agent
        boots last silently owns every other agent's plan scope -- a real
        bug even single-threaded, and a data race across agent-creation
        threads. Cloning is cheap (structural copy, no re-parsing), so the
        boot-time win from parsing once is kept.
        """
        # ag: reversed() is Java's Agent.addInitialBelsInBB ("Once beliefs are
        # stored in a Stack in the BB, insert them in inverse order"):
        # BeliefBucket.add() prepends (belief_base.py, Java's add(l,false)), so
        # walking the source order would leave every same-predicate group
        # reversed in the belief base -- and for rules the order IS the
        # semantics (examples/water-jugs' a_star_l/4 tries the "explore" clause
        # before the "goal reached" one, and never terminates).
        for belief in reversed(parsed.beliefs):
            belief = belief.copy()
            if not belief.has_source():
                belief.add_annot(BeliefBase.self_source_term)
            self._bb.add(belief)
        for plan in parsed.plans:
            plan = plan.clone()
            if origin is not None:
                plan.source_file = origin
            self._pl.add(plan)
        return parsed.initial_goals

    def applicable_plans(self, relevant: list[Option] | None) -> list[Option] | None:
        """Filters relevant plans (Options) down to those whose context currently
        holds, one Option per successful unification of the context.
        """
        result: list[Option] | None = None
        if relevant is None:
            return None

        for option in relevant:
            context = option.plan.context
            if context is None:
                if result is None:
                    result = []
                result.append(option)
                continue

            all_unifs = option.plan.is_all_unifs() or self._bb.has_select_option
            consequences = context.logical_consequence(self, option.unifier)
            if consequences is None:
                continue

            for unifier in consequences:
                option.unifier = unifier
                if result is None:
                    result = []
                result.append(option)
                if not all_unifs:
                    break
                option = Option(option.plan, None, option.event)

        return result


class _StructureWrapperForLiteral:
    """Jason's StructureWrapperForLiteral: lets buf() match a perceived
    literal against a belief regardless of annotations -- hash() of a
    literal already ignores them, and equals_as_structure() compares only
    namespace, functor and terms.

    ag: equals_as_structure() ignores negation too (only the hash tells `p`
    from `~p`), so __eq__ checks it explicitly -- a hash collision must not
    make buf() take `~p` for `p`."""

    __slots__ = ("literal",)

    def __init__(self, literal: Literal):
        self.literal = literal

    def __hash__(self) -> int:
        return hash(self.literal)

    def __eq__(self, other: object) -> bool:
        return (isinstance(other, _StructureWrapperForLiteral)
                and self.literal.negated() == other.literal.negated()
                and self.literal.equals_as_structure(other.literal))

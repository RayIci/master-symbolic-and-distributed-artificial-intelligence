from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_syntax.literal import Literal
    from icaros.as_semantics.intention import Intention

class ActionExec:

    def __init__(self, action: Literal, intention: Intention):
        self._action = action
        self._intention = intention
        self._result = False
        self._failure_reason = None
        self._failure_msg = None

    def __eq__(self, other):
        if other is None:
            return False
        if not isinstance(other, ActionExec):
            return False
        return self._action == other._action

    def __hash__(self):
        return hash(self._action)

    @property
    def action_term(self):
        from icaros.as_syntax.structure import Structure
        if isinstance(self._action, Structure):
            return self._action
        return Structure(self._action)

    @property
    def intention(self):
        return self._intention

    @property
    def result(self):
        return self._result

    @result.setter
    def result(self, result: bool):
        self._result = result

    @property
    def failure_reason(self):
        return self._failure_reason

    @failure_reason.setter
    def failure_reason(self, failure_reason: str):
        self._failure_reason = failure_reason

    @property
    def failure_msg(self):
        return self._failure_msg

    @failure_msg.setter
    def failure_msg(self, failure_msg: str):
        self._failure_msg = failure_msg

    def __str__(self):
        return f"<{self._action},{self._intention},{self._result}>"

    def __repr__(self) -> str:
        return str(self)
// Plans that let a model reach the journal query actions.
//
// A tool call from an LLM is a GOAL, not an execution: .icaros_step writes
// !llm_<tool>(...)[source(llm), llm_call(Id)] into the intention that opened
// the session and stops there, so once the cycle gets to that step the call
// has to find a plan the ordinary way -- relevance, applicability,
// selection. These are those plans. Bundled and loaded into every agent by
// runtime/boot.py, exactly like kqml_plans.asl, and for the same reason:
// library material, written once, not something generated at runtime.
//
// One plan per arity the action accepts, because the caller drops the
// arguments the model did not supply (see llm/decode.py's json2literal) and .timeline
// really does take 1, 3 or 4 of them.
//
// They are excluded from the agent's own goal tools (PlanLibrary._tool_group),
// so a model never sees them twice: once as a journal tool and once as a goal
// of the plan library it is standing in.

@llm_full_timeline
+!llm_timeline(Entries)
   <- .timeline(Entries).

@llm_timeline_in_cyclespan
+!llm_timeline(From, To, Entries)
   <- .timeline(From, To, Entries).

@llm_timeline_in_cycle_span_filtered
+!llm_timeline(From, To, Kinds, Entries)
   <- .timeline(From, To, Kinds, Entries).

@llm_recall
+!llm_recall(Cycle, Facts)
   <- .recall(Cycle, Facts).

@llm_beliefs_at
+!llm_beliefs_at(Cycle, Beliefs)
   <- .beliefs_at(Cycle, Beliefs).
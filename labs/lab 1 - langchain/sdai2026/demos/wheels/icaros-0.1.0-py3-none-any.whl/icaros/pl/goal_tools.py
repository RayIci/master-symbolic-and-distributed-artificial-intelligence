from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.plan_doc import DEFAULT_TYPE
from icaros.as_syntax.trigger import TEOperator, TEType
from icaros.llm import LlmTool, LlmToolParam, LlmToolVariant, ToolKind, sanitize_tool_name

if TYPE_CHECKING:
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.plan import Plan

# ag: turns a group of plans sharing one trigger -- which is exactly what
# PlanLibrary._rel_plans already keys by PredicateIndicator -- into a single
# LLM tool definition. One goal is one tool; its several plans are the tool's
# *variants*, i.e. the contexts in which each version applies. That mapping is
# the whole point: an LLM picking a tool is choosing a goal, and the variant
# list is what tells it which situation each version was written for.

# how a trigger's operator/type pair prefixes the tool name. An achievement
# goal is the ordinary case and takes the bare name -- "+!book_flight/2" is
# the tool "book_flight" -- because that is the agent's own vocabulary.
_TRIGGER_PREFIX = {
    (TEOperator.ADD, TEType.ACHIEVE): "",
    (TEOperator.DEL, TEType.ACHIEVE): "fail_",
    (TEOperator.ADD, TEType.TEST): "test_",
    (TEOperator.DEL, TEType.TEST): "fail_test_",
    (TEOperator.ADD, TEType.BELIEF): "on_add_",
    (TEOperator.DEL, TEType.BELIEF): "on_del_",
    (TEOperator.ADD, TEType.SIGNAL): "on_add_",
    (TEOperator.DEL, TEType.SIGNAL): "on_del_",
}


def tool_name_for(trigger) -> str:
    """The tool name for a trigger: "+!book_flight/2" -> "book_flight"."""
    literal = trigger.literal
    if trigger.operator == TEOperator.GOAL_STATE:
        prefix = "goal_state_"
    else:
        prefix = _TRIGGER_PREFIX.get((trigger.operator, trigger.type), "")

    from icaros.as_syntax.literal import Literal as _Literal

    ns = "" if literal.ns == _Literal.default_ns else f"{literal.ns}__"
    return sanitize_tool_name(f"{ns}{prefix}{literal.functor}")


def _param_names(literal: Literal, plans: list[Plan]) -> list[str]:
    """Parameter names, position by position.

    A goal is declared as `+!book_flight(Dest, Date)`, so the variable names in
    the trigger are the natural parameter names. A position that is a constant
    in every version (e.g. `+!move(up)`) has no name to borrow and falls back
    to "arg{i}".
    """
    arity = literal.get_arity()
    names: list[str | None] = [None] * arity
    for plan in plans:
        terms = plan.trigger.literal.get_terms() or []
        for i, term in enumerate(terms[:arity]):
            if names[i] is None and term.is_var():
                functor = getattr(term, "functor", None)
                if functor:
                    names[i] = str(functor)
        if all(n is not None for n in names):
            break
    return [n if n is not None else f"arg{i}" for i, n in enumerate(names)]


def _params_for(plans: list[Plan]) -> tuple[LlmToolParam, ...]:
    literal = plans[0].trigger.literal
    names = _param_names(literal, plans)

    params: list[LlmToolParam] = []
    for name in names:
        param_type, description = DEFAULT_TYPE, ""
        # first version that documents this parameter wins
        for plan in plans:
            doc = plan.doc
            documented = None if doc is None else doc.params.get(name)
            if documented is not None:
                param_type, description = documented.type, documented.description
                break
        # a goal's arguments are positional and all present: AgentSpeak has no
        # optional parameters, so every one of them is required.
        params.append(LlmToolParam(name=name, type=param_type, description=description,
                                   required=True))
    return tuple(params)


def _variant_for(plan: Plan) -> LlmToolVariant:
    doc = plan.doc
    when = doc.when if doc is not None and doc.when else ""
    if not when and plan.context is not None:
        # no prose was written, so fall back to the guard itself -- less
        # readable for a model than an @when, but far better than nothing.
        when = str(plan.context)
    label = "" if plan.label is None else str(plan.label.functor)
    return LlmToolVariant(
        label=label,
        when=when,
        summary="" if doc is None else doc.summary,
    )


def _description_for(variants: tuple[LlmToolVariant, ...]) -> str:
    summary = next((v.summary for v in variants if v.summary), "")

    # a single unconditional version needs no variant list: the summary is the
    # whole story, and a one-line "Variants:" block would just be noise.
    if len(variants) == 1 and not variants[0].when:
        return summary

    lines = []
    for v in variants:
        head = f"- [{v.label}]" if v.label else "-"
        if v.when:
            head += f" when {v.when}"
        # the variant that donated the goal summary doesn't repeat it here
        if v.summary and v.summary != summary:
            head += f": {v.summary}"
        lines.append(head)

    block = "Variants:\n" + "\n".join(lines)
    return f"{summary}\n\n{block}" if summary else block


def build_goal_tool(plans: list[Plan]) -> LlmTool | None:
    """One LlmTool for a group of plans sharing a trigger, in library order.

    The order of `plans` is the order PlanLibrary tries them in, so it is also
    the order the variants are listed in -- what the model reads matches what
    the agent would actually do.
    """
    if not plans:
        return None
    trigger = plans[0].trigger
    variants = tuple(_variant_for(p) for p in plans)
    return LlmTool(
        name=tool_name_for(trigger),
        kind=ToolKind.GOAL,
        description=_description_for(variants),
        params=_params_for(plans),
        variants=variants,
        origin=trigger,
    )

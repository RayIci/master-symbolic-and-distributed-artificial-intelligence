from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_syntax.plan import Plan


class PlanLibraryListener:
    """Callback interface to be notified about changes to a PlanLibrary.
    Mirrors Jason's PlanLibraryListener -- see CircumstanceListener for why
    this is a plain base class with no-op bodies rather than Protocol/ABC."""

    def plan_added(self, plan: Plan) -> None: ...

    def plan_removed(self, plan: Plan) -> None: ...
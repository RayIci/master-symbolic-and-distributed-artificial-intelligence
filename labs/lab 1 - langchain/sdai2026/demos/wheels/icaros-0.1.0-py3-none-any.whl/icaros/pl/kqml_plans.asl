// Default plans to handle KQML performatives
// Users can override them by defining their own +kqml_received plans
//
// Variables:
//   Sender:  the sender (an atom)
//   Content: content (typically a literal)
//   MsgId:   message id (an atom)
//
// Ported from Jason's jason-interpreter/src/main/resources/asl/kqmlPlans.asl,
// loaded into every agent by boot.py after the agent's own .asl (see
// runtime/boot.py) so a user-defined +kqml_received plan is found and
// selected first, exactly as in Java (plan selection tries options in
// insertion order).

/* ---- tell performatives ---- */

@kqmlReceivedTellStructure[atomic]
+!kqml_received(Sender, tell, NS::Content, _)
   :  .literal(Content) &
      .ground(Content) &
      not .list(Content) &
      .add_nested_source(Content, Sender, CA)
   <- ++NS::CA.   // add with new focus (as external event)
@kqmlReceivedTellList
+!kqml_received(Sender, tell, Content, _)
   :  .list(Content)
   <- !add_all_kqml_received(Sender,Content).

@kqmlReceivedTellList1
+!add_all_kqml_received(_,[]).

@kqmlReceivedTellList2
+!add_all_kqml_received(Sender,[NS::H|T])
   :  .literal(H) &
      .ground(H)
   <- .add_nested_source(H, Sender, CA);
      ++NS::CA;
      !add_all_kqml_received(Sender,T).

@kqmlReceivedTellList3
+!add_all_kqml_received(Sender,[_|T])
   <- !add_all_kqml_received(Sender,T).

@kqmlReceivedUnTell[atomic]
+!kqml_received(Sender, untell, NS::Content, _)
    : .add_nested_source(Content, Sender, CA)
   <- --NS::CA.


/* ---- achieve performatives ---- */

@kqmlReceivedAchieve
+!kqml_received(Sender, achieve, NS::Content, _)
    : not .list(Content) & .add_nested_source(Content, Sender, CA)
   <- !!NS::CA.
@kqmlReceivedAchieveList
+!kqml_received(Sender, achieve, Content, _)
    : .list(Content)
   <- !add_all_kqml_achieve(Sender,Content).


@kqmlReceivedAchieveList1
+!add_all_kqml_achieve(_,[]).

@kqmlReceivedAchieveList2
+!add_all_kqml_achieve(Sender,[NS::H|T])
   <- .add_nested_source(H, Sender, CA);
      !!NS::CA;
      !add_all_kqml_achieve(Sender,T).


@kqmlReceivedUnAchieve[atomic]
+!kqml_received(_, unachieve, NS::Content, _)
   <- .drop_desire(NS::Content).


/* ---- ask performatives ---- */

@kqmlReceivedAskOne1d
+!kqml_received(Sender, askOne, NS::Content, MsgId)
    : kqml::bel_no_source_self(NS, Content, Ans)
   <- .send(Sender, tell, NS::Ans, MsgId).

@kqmlReceivedAskOne1c // (no belief, try to trigger a plan with +?)
+!kqml_received(Sender, askOne, NS::Content, MsgId)
   <- .add_nested_source(Content, Sender, CA);
      ?NS::CA;
      // remove source annot from CA
      .remove_source_annot(CA,CA2);
      .send(Sender, tell, NS::CA2, MsgId).

@kqmlReceivedAskOne2 // error in askOne by ?, send untell
-!kqml_received(Sender, askOne, NS::Content, MsgId)[error(test_goal_failed)]
   <- .send(Sender, untell, NS::Content, MsgId).

@kqmlReceivedAskAll2
+!kqml_received(Sender, askAll, NS::Content, MsgId)
   <- .findall(NS::Ans, kqml::bel_no_source_self(NS, Content, Ans), List);
      .send(Sender, tell, List, MsgId).

kqml::clear_source_self([],[])[hide_in_mind_inspector].
kqml::clear_source_self([source(self)|T],NT)[hide_in_mind_inspector]     :- kqml::clear_source_self(T,NT).
kqml::clear_source_self([A|T],           [A|NT])[hide_in_mind_inspector] :- A \== source(self) & kqml::clear_source_self(T,NT).

kqml::bel_no_source_self(NS, Content, Ans)[hide_in_mind_inspector] :-
   NS::Content[|LA] &
   kqml::clear_source_self(LA, NLA) &
   Content =.. [F,T,_] &
   NS::Ans =.. [NS,F,T,NLA].

/* ---- know-how performatives ---- */

// In tellHow, content must be a string representation
// of the plan (or a list of such strings)

@kqmlReceivedTellHow
+!kqml_received(Sender, tellHow, Content, _)
   <- .remove_source_annot(Content, ContentAn);
      .add_plan(ContentAn, Sender).

// In untellHow, content must be a plan's
// label (or a list of labels)
@kqmlReceivedUnTellHow
+!kqml_received(Sender, untellHow, Content, _)
   <- .remove_plan(Content, Sender).

// In askHow, content must be a string or plan term representing
// the triggering event
@kqmlReceivedAskHow
+!kqml_received(Sender, askHow, Content, MsgId)
   <- .relevant_plans(Content, ListOfPlans);
      .remove_source_annot(ListOfPlans, ListOfPlansAn); // remove "source(self)"
      .send(Sender, tellHow, ListOfPlansAn, MsgId).


/* ---- signal performative ---- */

@kqmlReceivedSignal
+!kqml_received(Sender, signal, NS::Content, _)
    : not .list(Content) & .add_nested_source(Content, Sender, CA)
   <- .signal( { +NS::CA }, type_signal ).


/* ---- chat performative ---- */

// A conversational turn addressed to this agent -- from a person through the
// dev UI's chat card, or from another agent with .send(Ag, chat, msg("...")).
// The default answer is to ask the model at the talk rung, where it may read
// its own journal and answer but cannot make the agent act, and then to say
// what it answered.
//
// The content is wrapped in msg(...) rather than being the bare string:
// every other performative here takes a literal as content, and a string term
// is the one kind of term that can neither carry an annotation nor be
// destructured -- the wrapper is what keeps a chat message a first-class
// content, matchable and extensible, like everything else in this file.
//
// The framing around Text is not decoration. icaros_done asks the model for
// "what you concluded", so a model handed a bare "ciao, chi sei?" writes a
// minute of the conversation rather than a reply -- and a minute is what the
// person would then read. Telling it who is listening is what turns the
// session's summary into an answer. It is three pieces because .concat takes
// three terms and the one it binds.
//
// The performative names the act, not the answer: an agent that wants to
// answer chat with its own logic (or with no model at all) writes its own
// +!kqml_received(Sender, chat, msg(Text), MsgId) plan, which is loaded
// before this file and so is selected first. A .talk that fails -- the rung
// below talk, or a model that never finishes -- falls into @kqmlError below,
// like any other communication failure.

@kqmlReceivedChat
+!kqml_received(Sender, chat, msg(Text), _)
   <- .concat("Someone is speaking to you and said: ", Text,
              " -- reply to them directly, in their own language. Write only the reply itself: no notes about yourself, nothing copied from the journal above.",
              Prompt);
      .talk(Prompt, Answer);
      .say(Answer).

/* general communication error handler */

@kqmlError
-!kqml_received(_Sender, _Per, _Content, _MsgId)[error(EID), error_msg(EMsg)]
   <- .print("Communication error -- ",EID, ": ", EMsg).
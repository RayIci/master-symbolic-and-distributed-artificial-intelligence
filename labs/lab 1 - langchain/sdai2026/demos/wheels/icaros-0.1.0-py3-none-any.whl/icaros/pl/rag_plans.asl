// Plans that let a model reach the RAG query action.
//
// A tool call from an LLM is a GOAL, not an execution: .icaros_step writes
// !llm_<tool>(...)[source(llm), llm_call(Id)] into the intention that opened
// the session and stops there, so once the cycle gets to that step the call
// has to find a plan the ordinary way -- relevance, applicability,
// selection. These are those plans. Bundled and loaded into every agent by
// runtime/boot.py, exactly like kqml_plans.asl and journal_plans.asl.
//
// One plan per arity .rag_search accepts (2 or 3 -- K is optional), because
// the caller drops the arguments the model did not supply (see
// llm/decode.py's json2literal).
//
// They are excluded from the agent's own goal tools (PlanLibrary._tool_group),
// so a model never sees them twice: once as a rag tool and once as a goal of
// the plan library it is standing in.

@llm_rag_search
+!llm_rag_search(Query, Beliefs)
   <- .rag_search(Query, Beliefs).

@llm_rag_search_k
+!llm_rag_search(Query, K, Beliefs)
   <- .rag_search(Query, K, Beliefs).
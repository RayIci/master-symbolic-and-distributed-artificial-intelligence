from __future__ import annotations

import itertools
from typing import Dict

from icaros.as_syntax.plan import Plan
from icaros.as_syntax.pred import Pred
from icaros.as_syntax.term import Term
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.trigger import Trigger, TEType
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.trigger import TEOperator
from icaros.as_syntax.predicate_indicator import PredicateIndicator
from icaros.as_semantics.message import Message
from icaros.llm import LlmTool, to_specs
from icaros.pl.plan_library_listener import PlanLibraryListener

class PlanLibrary:

    # ag: NOT thread-safe by design, and it does not need to be: a PlanLibrary
    # belongs to exactly one Agent and is only ever mutated by that agent's own
    # reasoning thread (.add_plan/.remove_plan/tellHow all run there, and
    # Runner.clone_agent reads the SOURCE library on the cloning agent's own
    # thread). A newly booted agent's library is fully populated before
    # start_thread(), so publication is safe too. `_last_plan_label` below is
    # the one genuinely shared piece of state, hence itertools.count.

    # ag: mirrors Java's static AtomicInteger lastPlanLabel -- itertools.count's
    # next() is C-implemented and atomic under both the GIL and free-threaded
    # builds, unlike a plain int with `+=` (a non-atomic read-modify-write;
    # same fix already applied to as_syntax/unnamed_var.py's _var_cont)
    _last_plan_label = itertools.count(1)
    KQML_PLANS_FILE = "kqmlPlans.asl"  # Plan.source_file tag for the bundled defaults (boot.py)
    JOURNAL_PLANS_FILE = "journalPlans.asl"  # same, for the journal tool wrappers (boot.py)
    RAG_PLANS_FILE = "ragPlans.asl"  # same, for the rag tool wrapper (boot.py)
    TE_JAG_SLEEPING : Trigger = Trigger(TEOperator.ADD, TEType.BELIEF, Atom("jag_sleeping"))
    TE_JAG_AWAKING : Trigger = Trigger(TEOperator.ADD, TEType.BELIEF, Atom("jag_awaking"))
    TE_JAG_SHUTTING_DOWN : Trigger = Trigger(TEOperator.ADD, TEType.BELIEF, Atom("jag_shutting_down"))

    def __init__(self, father: PlanLibrary | None = None):
        self._father = father
        self._plans: list[Plan] = []
        self._var_plans: list[Plan] = []
        self._rel_plans: Dict[PredicateIndicator, list[Plan]] = dict()
        self._plan_labels: Dict[str, Plan] = dict()
        self._has_meta_event_plans = False
        self._has_jag_plans: bool = False
        self._has_user_kqml_received = False
        self._has_plans_for_update_events = False
        self._kqml_received_functor = Message.kqml_received_functor
        self._listeners: list[PlanLibraryListener] = []

    def add_listener(self, listener: PlanLibraryListener) -> None:
        self._listeners.append(listener)

    def remove_listener(self, listener: PlanLibraryListener) -> None:
        try:
            self._listeners.remove(listener)
        except ValueError:
            pass

    def has_listener(self) -> bool:
        return bool(self._listeners)

    def is_root(self) -> bool:
        return self._father is None

    @property
    def father(self) -> PlanLibrary | None:
        return self._father

    @father.setter
    def father(self, pl: PlanLibrary | None):
        self._father = pl

    @property
    def has_plans_for_update_events(self) -> bool:
        return self._has_plans_for_update_events

    def get_unique_label(self) -> Pred:
        while True:
            label = f"p__{next(PlanLibrary._last_plan_label)}"
            if label not in self._plan_labels:
                return Pred(label)

    @staticmethod
    def _label_key(label: Literal) -> str:
        key = f"{label.ns}::" if label.ns != Literal.default_ns else ""
        key += label.functor
        if label.has_term():
            key += "".join(str(t) for t in label.get_terms())
        return key

    def add(self, p: Plan, source: Term | None = None, before: bool = False) -> Plan:
        # ag: Java's add(p) / add(p, before) / add(p, source, before) overloads
        # collapsed into optional params -- Python has no dispatch on parameter types.
        if source is not None:
            try:
                existing = self._plans[self._plans.index(p)]
            except ValueError:
                existing = None
            if existing is not None:
                existing.add_source(source)
                return existing
            if p.label is None:
                p.label = self.get_unique_label()
            elif p.label.functor == "undefined":
                label = self.get_unique_label()
                label.add_annots(*p.label.annots)
                p.label = label
            p.add_source(source)

        p.scope = self
        if p.label is not None:
            label_key = self._label_key(p.label)
            if label_key in self._plan_labels:
                plan_in_pl = self._plan_labels[label_key]
                if p == plan_in_pl:
                    plan_in_pl.add_source(p.get_sources().get_as_list()[0])
                    return plan_in_pl
                raise ValueError(f"There already is a plan with label {p.label}")
        else:
            p.label = self.get_unique_label()
            label_key = self._label_key(p.label)

        # ag: self-source annotation (BeliefBase.T_SELF) is skipped here --
        # not ported yet, see class docstring above

        if p.source_file:
            from icaros.as_syntax.factory import create_structure, create_string
            p.label.add_annot(create_structure("url", create_string(p.source_file)))

        p.is_plan_term = False
        self._plan_labels[label_key] = p

        pte = p.trigger
        if (pte.literal.functor == self._kqml_received_functor
                and p.source_file != PlanLibrary.KQML_PLANS_FILE):
            self._has_user_kqml_received = True

        if pte.literal.is_var() or pte.literal.ns.is_var():
            self._var_plans.insert(0, p) if before else self._var_plans.append(p)
            for lp in self._rel_plans.values():
                if lp and lp[0].trigger.same_type(pte):
                    lp.insert(0, p) if before else lp.append(p)
        else:
            if pte.is_update():
                self._has_plans_for_update_events = True
            codes_list = self._rel_plans.get(pte.get_predicate_indicator())
            if codes_list is None:
                codes_list = [vp for vp in self._var_plans if vp.trigger.same_type(pte)]
                self._rel_plans[pte.get_predicate_indicator()] = codes_list
            codes_list.insert(0, p) if before else codes_list.append(p)

        if pte.operator == TEOperator.GOAL_STATE:
            self._has_meta_event_plans = True

        self._plans.insert(0, p) if before else self._plans.append(p)

        for listener in list(self._listeners):
            listener.plan_added(p)
        return p

    def join(self, pl: PlanLibrary) -> None:
        # ag: clones each plan before adding -- add() mutates its scope/label,
        # so joining another library's plans by reference (Runner.clone_agent's
        # only caller) would leave the SOURCE library's plans scoped to the
        # new agent instead of their own. Same fix as Agent.load_parsed_asl.
        for p in pl:
            self.add(p.clone())

    def add_all(self, plans: list[Plan]) -> None:
        for p in plans:
            self.add(p)

    @property
    def has_meta_event_plans(self) -> bool:
        return self._has_meta_event_plans

    @property
    def has_user_kqml_received_plans(self) -> bool:
        return self._has_user_kqml_received

    @property
    def has_jag_plans(self) -> bool:
        return self._has_jag_plans

    def get(self, label: Literal | str) -> Plan | None:
        if not isinstance(label, Literal):
            label = Atom(label)
        return self._plan_labels.get(self._label_key(label))

    @property
    def plans(self) -> list[Plan]:
        return self._plans

    def clear(self) -> None:
        self._plan_labels.clear()
        self._plans.clear()
        self._var_plans.clear()
        self._rel_plans.clear()

    def remove(self, label: Literal, source: Term | None = None) -> bool:
        if source is not None:
            plan = self.get(label)
            if plan is None:
                return False
            has_source: bool = plan.del_source(source)
            if not has_source or plan.has_source():
                return True
        plan : Plan | None = self._plan_labels.pop(self._label_key(label), None)
        if plan is None:
            return False
        self._plans.remove(plan)
        if plan.trigger.literal.is_var():
            self._var_plans.remove(plan)
            for pred_i in list(self._rel_plans.keys()):
                plan_list = self._rel_plans[pred_i]
                plan_list.remove(plan)
                if not plan_list:
                    del self._rel_plans[pred_i]
        else:
            pi = plan.trigger.get_predicate_indicator()
            codes_list = self._rel_plans.get(pi)
            codes_list.remove(plan)
            if not codes_list:
                self._rel_plans.pop(pi)
        for listener in list(self._listeners):
            listener.plan_removed(plan)
        return True

    def has_candidate_plan(self, trigger: Trigger | None) -> bool:
        if trigger is None:
            return False
        return self.get_candidate_plans(trigger) is not None

    def get_candidate_plans(self, trigger: Trigger) -> list[Plan] | None:
        candidates = None
        if trigger.literal.is_var() or trigger.ns.is_var():
            for plan in self._plans:
                if plan.trigger.same_type(trigger):
                    if candidates is None:
                        candidates = []
                    candidates.append(plan)
        else:
            candidates = self._rel_plans.get(trigger.get_predicate_indicator())
            if (candidates is None or not candidates) and self._var_plans and trigger != PlanLibrary.TE_JAG_SLEEPING and trigger != PlanLibrary.TE_JAG_AWAKING:
                for plan in self._var_plans:
                    if plan.trigger.same_type(trigger):
                        if candidates is None:
                            candidates = []
                        candidates.append(plan)
        return candidates


    # -- LLM tool views -------------------------------------------------
    # ag: _rel_plans is already "one goal -> its versions, in the order they
    # are tried", which is exactly the grouping a tool definition needs, so
    # these read off that index rather than adding one of their own.

    def _tool_group(self, pi: PredicateIndicator, include_all: bool) -> list[Plan]:
        plans = self._rel_plans.get(pi) or []
        if include_all:
            return list(plans)
        # the bundled KQML plans (boot.py) are protocol plumbing every agent
        # gets for free, not part of what this agent can be asked to do. The
        # journal and rag wrappers are bundled for the same reason and hidden
        # for a sharper one: they ARE those tools, so leaving them here would
        # offer the model the same capability twice, once per family.
        return [p for p in plans if p.source_file not in (PlanLibrary.KQML_PLANS_FILE,
                                                          PlanLibrary.JOURNAL_PLANS_FILE,
                                                          PlanLibrary.RAG_PLANS_FILE)]

    def llm_tool(self, key: PredicateIndicator | Trigger | str,
                 *, include_all: bool = False) -> LlmTool | None:
        """The packaged LLM tool definition for one goal.

        `key` may be a PredicateIndicator, a Trigger, the indicator's text
        ("+!book_flight/2"), or the label of any plan of that goal.
        """
        from icaros.pl.goal_tools import build_goal_tool

        pi = self._as_predicate_indicator(key)
        if pi is None:
            return None
        return build_goal_tool(self._tool_group(pi, include_all))

    def llm_tools(self, *, include_all: bool = False) -> list[LlmTool]:
        """One LlmTool per goal, in insertion order.

        Plans with a variable trigger (_var_plans) never yield a tool of their
        own: there is no name to give it. They still show up as variants of
        every concrete goal they are relevant to, since _rel_plans already
        merges them in.
        """
        from icaros.pl.goal_tools import build_goal_tool

        tools = []
        for pi in self._rel_plans:
            tool = build_goal_tool(self._tool_group(pi, include_all))
            if tool is not None:
                tools.append(tool)
        return tools

    def llm_tool_specs(self, dialect: str = "openai", *, include_all: bool = False) -> list[dict]:
        """llm_tools() rendered in a provider dialect ("openai"/"ollama"/"anthropic")."""
        return to_specs(self.llm_tools(include_all=include_all), dialect)

    def indicators_for(self, selector: str) -> list[PredicateIndicator]:
        """Every goal a .mas2i selector names, most specific form first.

        ag: str(pi) carries the trigger prefix ("+!book_flight/1"), which is
        precise but a mouthful to write in a config file. So a selector may
        also drop the prefix ("book_flight/1"), drop the arity as well
        ("book_flight" -- then every arity of that functor matches, which is
        what someone listing a goal by name means), or be a plan label.
        Returns a list because only the bare-functor form can be plural.
        """
        exact = self._as_predicate_indicator(selector)
        if exact is not None:
            return [exact]
        bare = selector.lstrip("+-!?")
        matches = [pi for pi in self._rel_plans if str(pi).lstrip("+-!?") == bare]
        if matches:
            return matches
        return [pi for pi in self._rel_plans
                if str(pi).lstrip("+-!?").rsplit("/", 1)[0] == bare]

    def _as_predicate_indicator(
            self, key: PredicateIndicator | Trigger | str) -> PredicateIndicator | None:
        if isinstance(key, PredicateIndicator):
            return key
        if isinstance(key, Trigger):
            return key.get_predicate_indicator()
        if isinstance(key, str):
            for pi in self._rel_plans:
                if str(pi) == key:
                    return pi
            plan = self.get(key)  # fall back to reading `key` as a plan label
            if plan is not None:
                return plan.trigger.get_predicate_indicator()
        return None

    def __iter__(self):
        return iter(self._plans)

    def __len__(self) -> int:
        return len(self._plans)

    def get_as_txt(self) -> str:
        return "\n".join(str(p) for p in self._plans)

    def __str__(self) -> str:
        return str(self._plans)
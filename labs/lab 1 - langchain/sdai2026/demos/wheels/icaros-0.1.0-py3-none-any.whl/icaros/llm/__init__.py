"""Everything Icaros knows about talking to a language model.

ag: the rule that keeps this package worth having is one-directional -- nothing
here imports `icaros.as_semantics` at runtime (tests/test_layering.py enforces
it). What lives here knows about the model: the tool format, the round trip, the
prompts, the records a round leaves behind. What knows about the BDI cycle --
posting events, building intentions, running the agent's faculties -- lives in
`as_semantics/agentic.py`, which is the one door between the two.

Everything importable from here is the public surface, and nothing outside this
package should reach into its modules -- the same contract `icaros.journal`
states, for the same reason: the split between `tools.py` and `faculties.py`, or
between `client.py` and `prompts.py`, is this package's business to keep
rearranging, and a caller that named a module would be holding it still.
`prompts` is exported as the module itself: `prompts.session_system(...)`
says which of several near-identical strings is meant, where a bare import
would not.

Every seam is injection, `LlmClient(chat=...)`/`Icaros(client_factory=...)`,
never patching a module attribute -- `icaros/mas2i/loader.py`'s
`llm_client_factory` parameter is what lets `load_mas` (which builds the
client itself) still be tested without reaching into this package.
"""

from icaros.llm import prompts
from icaros.llm.client import ANTHROPIC, OLLAMA, OPENAI, OPENAI_COMPATIBLE, LlmClient
from icaros.llm.decode import (
    is_achieve_goal,
    json2literal,
    json2term,
    json2terms,
    tool_call_of,
)
from icaros.llm.faculties import (
    ADD_ACTION_TOOL,
    ADD_PLAN_TOOL,
    DONE_TOOL,
    FACULTY_TOOLS,
    IcarosState,
)
from icaros.llm.result import (
    CALL_ANNOT,
    SOURCE_LLM,
    TOOL_CALL_FUNCTOR,
    LlmToolResult,
    call_id_of,
    session_of,
    tool_name_of,
)
from icaros.llm.session import MAX_ROUNDS, MAX_TRANSCRIPT_CHARS, IcarosSession
from icaros.llm.tools import (
    LlmTool,
    LlmToolParam,
    LlmToolVariant,
    ToolKind,
    resolve_name_collisions,
    sanitize_tool_name,
    to_specs,
)
from icaros.llm.trace import LlmCall

__all__ = [
    # tools: the provider-neutral tool format
    "LlmTool", "LlmToolParam", "LlmToolVariant", "ToolKind",
    "sanitize_tool_name", "to_specs", "resolve_name_collisions",
    # faculties: the CONTROL tools Icaros defines itself, and the generation
    # scale (rung) that decides which of them a session is granted
    "DONE_TOOL", "ADD_PLAN_TOOL", "ADD_ACTION_TOOL", "FACULTY_TOOLS", "IcarosState",
    # result: the model's fingerprints on the agent's own state
    "SOURCE_LLM", "CALL_ANNOT", "TOOL_CALL_FUNCTOR",
    "call_id_of", "session_of", "tool_name_of", "LlmToolResult",
    # session: one conversation, alive across cycles
    "IcarosSession", "MAX_ROUNDS", "MAX_TRANSCRIPT_CHARS",
    # trace: one round trip, recorded
    "LlmCall",
    # client: the connection, and the only place that talks to a model
    "LlmClient", "OLLAMA", "OPENAI", "ANTHROPIC", "OPENAI_COMPATIBLE",
    # decode: what the model sent back, as terms the interpreter can act on
    "json2term", "json2terms", "json2literal", "tool_call_of", "is_achieve_goal",
    # prompts: what the agent says to a model, as a module (see above)
    "prompts",
]
"""Per-provider translation: how the neutral (messages, format, tools, params)
shape LlmClient works with becomes one provider SDK's request, and how that
provider's response comes back as the neutral {"content", "tool_calls",
"thinking"} shape decode.py/icaros.py already read.

`params` is the one thing here that is NOT translated: it is the .mas2i's
`params { }` block, and it reaches the API under the names that API uses.
What this file decides about it is only WHERE it lands -- flat in the request
for OpenAI and Anthropic, split between the request and `options={...}` for
ollama -- plus which keys are refused outright and which are merely unknown.
See _RESERVED_PARAMS/_KNOWN_PARAMS below.

ag: split out of client.py so that file stays the thin orchestration layer --
the injection seam, the timing, the LlmCall bookkeeping -- and this one
carries every SDK import and every provider's request/response shape. Same
reason tools.py keeps its dialect adapters (to_openai/to_anthropic) next to
each other and away from LlmTool's own definition: a third provider should be
a new branch in this file, not an edit spread across LlmClient.

Every SDK import is lazy (inside a function, wrapped in try/except) because
every provider's package is an optional install (pyproject.toml's `ollama`/
`openai`/`anthropic` extras) -- a process that only ever talks to one
provider should never be made to import the other two. `openai_compatible`
reuses the `openai` package pointed at a different `base_url`, so it needs no
extra of its own.

Response parsing goes through decode.py's `field_of` (dict.get / getattr,
whichever the object supports) rather than assuming a real SDK object, so a
test can inject a plain nested dict standing in for OpenAI's/Anthropic's
response shape without installing either SDK -- the same reason `field_of`
exists in decode.py in the first place (ollama hands back pydantic models, a
test hands back a dict).
"""

from __future__ import annotations

import json
import os

from icaros.llm.decode import field_of

OLLAMA = "ollama"
OPENAI = "openai"
ANTHROPIC = "anthropic"
OPENAI_COMPATIBLE = "openai_compatible"

# required by Anthropic's API on every call. The default when the .mas2i says
# nothing; `params { max_tokens: N }` overrides it like any other parameter,
# which is what this constant used to lack a way of expressing.
_ANTHROPIC_MAX_TOKENS = 4096

# ag: what a params { } block may NOT name, per provider -- the keys icaros
# builds itself. Overriding `messages` or `tools` would not fail loudly; it
# would produce a session that talks to the wrong conversation or offers the
# wrong tools, and the .mas2i is a long way from where that gets noticed. A
# parse error is the cheap end of that. `stream` is in here because nothing in
# icaros reads a streamed response: setting it would break decoding, not
# change the pace.
_RESERVED_COMMON = frozenset({"model", "messages", "tools", "stream"})
_RESERVED_PARAMS = {
    OLLAMA: _RESERVED_COMMON | {"format"},
    OPENAI: _RESERVED_COMMON | {"response_format"},
    OPENAI_COMPATIBLE: _RESERVED_COMMON | {"response_format"},
    ANTHROPIC: _RESERVED_COMMON | {"system", "output_config"},
}

# ollama takes these at the top level of the request; everything else it
# understands lives inside `options={...}`. That split is the whole reason
# params is not a flat passthrough -- see _ollama_params.
_OLLAMA_TOP_LEVEL = frozenset({"think", "keep_alive"})

# ag: for the boot warning only, never to reject. ollama IGNORES an option it
# does not recognise, so a misspelled `tempreature` would otherwise be
# completely invisible -- no error, no effect, just a model that behaves as if
# the line had not been written. OpenAI and Anthropic answer a bad parameter
# with a 400 naming it, which LlmClient.chat already records on the call, so
# for them this is a convenience rather than the only signal.
#
# Deliberately not exhaustive and deliberately not enforced: a closed list
# would mean editing icaros every time a provider ships a parameter, which is
# the maintenance this passthrough exists to avoid. A name missing from here
# is a warning, and the request goes out unchanged.
_KNOWN_PARAMS = {
    OLLAMA: _OLLAMA_TOP_LEVEL | {
        "num_ctx", "num_predict", "num_keep", "num_batch", "num_gpu", "main_gpu",
        "num_thread", "temperature", "top_p", "top_k", "min_p", "typical_p",
        "repeat_penalty", "repeat_last_n", "presence_penalty", "frequency_penalty",
        "seed", "stop", "mirostat", "mirostat_tau", "mirostat_eta", "use_mmap", "numa",
    },
    OPENAI: frozenset({
        "temperature", "top_p", "seed", "stop", "max_tokens", "max_completion_tokens",
        "reasoning_effort", "verbosity", "presence_penalty", "frequency_penalty",
        "logit_bias", "logprobs", "top_logprobs", "n", "user", "service_tier",
        "parallel_tool_calls", "tool_choice", "metadata", "store",
    }),
    ANTHROPIC: frozenset({
        "temperature", "top_p", "top_k", "stop_sequences", "max_tokens", "thinking",
        "metadata", "service_tier", "tool_choice", "container", "mcp_servers",
    }),
}
# an openai_compatible endpoint is whatever server the user pointed us at --
# llama.cpp, LM Studio, vLLM, a gateway -- so there is no list to check
# against and everything it is given passes without comment.
_KNOWN_PARAMS[OPENAI_COMPATIBLE] = None


def reserved_params(provider: str | None, params: dict | None) -> list[str]:
    """The keys in `params` that icaros builds itself, in written order.

    Used by the .mas2i parser to refuse them at parse time, which is why it
    lives here next to the request builders that would otherwise be silently
    overridden -- the rule and the thing it protects stay in one file.
    """
    if not params:
        return []
    reserved = _RESERVED_PARAMS.get(provider, _RESERVED_COMMON)
    return [name for name in params if name in reserved]


def unknown_params(provider: str | None, params: dict | None) -> list[str]:
    """The keys in `params` this build does not recognise for `provider`.

    Advisory: the caller warns, nothing is dropped. Empty for a provider with
    no list to check against (openai_compatible) or none at all. Only the top
    level is checked -- what is inside a nested group is that parameter's own
    shape, and its keys belong to the provider's schema, not to this one.
    """
    if not params:
        return []
    known = _KNOWN_PARAMS.get(provider)
    if known is None:
        return []
    return [name for name in params if name not in known]


def _ollama_params(params: dict | None) -> tuple[dict, dict]:
    """(top-level request keys, `options` keys) for ollama.

    ag: the default for an unrecognised name is `options`, not the top level.
    ollama's own top level is a short, closed list (think/keep_alive being the
    two an agent has any reason to set), while `options` is where the whole
    sampling and context surface lives -- so guessing "options" is right for
    every new parameter, and guessing "top level" would be wrong for almost
    all of them.
    """
    if not params:
        return {}, {}
    top, options = {}, {}
    for name, value in params.items():
        (top if name in _OLLAMA_TOP_LEVEL else options)[name] = value
    return top, options


def _missing_sdk(provider: str, package: str, extra: str, exc: ImportError) -> RuntimeError:
    return RuntimeError(
        f"provider '{provider}' needs the {package} package: "
        f"run `uv add icaros[{extra}]` or `pip install icaros[{extra}]`")


def _with_usage(message: dict, source, prompt_keys: tuple, completion_keys: tuple) -> dict:
    """Carry token usage out of the provider's answer inside the message dict.

    ag: providers.call() contracts to return just the message, but every
    provider puts usage on the answer around it -- ollama at the top level
    (prompt_eval_count/eval_count), the OpenAI family and Anthropic on
    `response.usage` under other names. Rather than widen that contract with a
    second return value, the counts ride along as `_usage`, which LlmClient
    lifts onto the LlmCall and nothing else ever reads. The key lists are
    candidates tried in order, so openai_compatible (whose server may answer
    in either dialect) works without its own branch. field_of so a test's
    plain dict reads the same way a real SDK object does.
    """
    def first(keys):
        for key in keys:
            value = field_of(source, key)
            if value is not None:
                return value
        return None

    prompt, completion = first(prompt_keys), first(completion_keys)
    if prompt is not None or completion is not None:
        message["_usage"] = {"prompt_tokens": prompt, "completion_tokens": completion}
    return message


def _ollama_chat():
    try:
        from ollama import chat
    except ImportError as e:
        raise _missing_sdk(OLLAMA, "ollama", "ollama", e) from e
    return chat


def _openai_module():
    try:
        import openai
    except ImportError as e:
        raise _missing_sdk(OPENAI, "openai", "openai", e) from e
    return openai


def _openai_compatible_module():
    try:
        import openai
    except ImportError as e:
        raise _missing_sdk(OPENAI_COMPATIBLE, "openai (reused for its "
                           "OpenAI-compatible client)", "openai", e) from e
    return openai


def _anthropic_module():
    try:
        import anthropic
    except ImportError as e:
        raise _missing_sdk(ANTHROPIC, "anthropic", "anthropic", e) from e
    return anthropic


def warm_up(provider: str, model: str, chat) -> None:
    """Loads the model into the provider's memory before the first real call.

    ag: only Ollama needs this (a local server that otherwise pays the load
    cost on the first real round trip) -- OpenAI/Anthropic/openai_compatible
    are stateless HTTP APIs with nothing to warm up.
    """
    if provider != OLLAMA:
        return
    call_fn = chat if chat is not None else _ollama_chat()
    call_fn(model=model)


# -- streaming --
#
# ag: every assembler below has one job and it is a contract, not a style:
# produce the SAME dict the non-streaming parser produces for the same reply.
# Get that right and nothing downstream knows the difference -- Icaros._round,
# decode.py's tool_call_of and IcarosSession.remember_assistant_turn all keep
# reading the shape they always read. Get it wrong and the failure is a
# tool call that silently loses an argument, which is the worst kind.
#
# `on_chunk` is called with TEXT deltas only, never with reasoning and never
# with fragments of a tool call's arguments: what it feeds is the chat bubble
# a person is watching, and neither of those two belongs there. It is also the
# switch -- on_chunk=None takes the original non-streaming path untouched,
# which is what keeps every injected `chat=` fake (they return a dict, not an
# iterator) working exactly as before.


def _call_ollama(*, model, messages, format, tools, params, chat, on_chunk=None):
    call_fn = chat if chat is not None else _ollama_chat()
    offered = {} if tools is None else {"tools": tools}
    top, options = _ollama_params(params)
    if options:
        offered["options"] = options
    if on_chunk is None:
        answer = call_fn(model=model, messages=messages, format=format, **top, **offered)
        return _with_usage(answer["message"], answer,
                           prompt_keys=("prompt_eval_count", "prompt_tokens"),
                           completion_keys=("eval_count", "completion_tokens"))

    # ag: ollama is the gentle one. Content and thinking arrive as deltas, but
    # a tool call arrives whole inside one chunk rather than split across
    # several, so there is nothing to reassemble for the part that would hurt
    # most if it were reassembled wrong.
    content, thinking, tool_calls = [], [], []
    prompt_count = completion_count = None
    for chunk in call_fn(model=model, messages=messages, format=format,
                         stream=True, **top, **offered):
        # the final chunk is the one that carries the counts; keep the last
        # non-None seen so partial re-answers cannot reset them
        prompt_count = field_of(chunk, "prompt_eval_count") or prompt_count
        completion_count = field_of(chunk, "eval_count") or completion_count
        message = field_of(chunk, "message") or {}
        piece = field_of(message, "content") or ""
        if piece:
            content.append(piece)
            on_chunk(piece)
        reasoning = field_of(message, "thinking") or ""
        if reasoning:
            thinking.append(reasoning)
        for raw in field_of(message, "tool_calls") or []:
            tool_calls.append(raw)
    answer = {"content": "".join(content), "tool_calls": tool_calls}
    if prompt_count is not None or completion_count is not None:
        answer["_usage"] = {"prompt_tokens": prompt_count, "completion_tokens": completion_count}
    if thinking:
        answer["thinking"] = "".join(thinking)
    return answer


# -- OpenAI / openai_compatible (same request/response shape, different client) --

def _openai_tool_call(raw: dict) -> dict:
    """One stored tool_calls entry, re-serialized for the outbound request.

    ag: the normalizer below turns OpenAI's `arguments` JSON string into a
    dict so decode.py can read it like every other provider's; sending the
    turn back as history has to undo exactly that, since the API expects the
    same string-encoded shape it originally sent.
    """
    function = raw.get("function") or {}
    arguments = function.get("arguments")
    if not isinstance(arguments, str):
        arguments = json.dumps(arguments or {})
    return {
        "id": raw.get("id") or "",
        "type": "function",
        "function": {"name": function.get("name", ""), "arguments": arguments},
    }


def _openai_messages(messages: list[dict]) -> list[dict]:
    """The neutral transcript (session.py's IcarosSession.messages()), shaped
    for OpenAI's chat.completions -- a role:"tool" turn needs `tool_call_id`
    tacked on, an assistant turn with tool_calls needs them re-serialized."""
    out = []
    for turn in messages:
        role = turn["role"]
        if role == "tool":
            out.append({
                "role": "tool",
                "tool_call_id": turn.get("provider_call_id") or turn.get("tool_name", ""),
                "content": turn["content"],
            })
        elif role == "assistant" and turn.get("tool_calls"):
            out.append({
                "role": "assistant",
                "content": turn["content"] or None,
                "tool_calls": [_openai_tool_call(tc) for tc in turn["tool_calls"]],
            })
        else:
            out.append({"role": role, "content": turn["content"]})
    return out


def _openai_request(messages, format, tools) -> dict:
    request: dict = {"messages": _openai_messages(messages)}
    if tools is not None:
        request["tools"] = tools
    if format is not None:
        # OpenAI Structured Outputs -- needs a model that supports it
        # (gpt-4o-2024-08-06+); an older model or openai_compatible backend
        # that rejects `response_format` surfaces as a normal exception
        # through LlmClient.chat()'s own error handling, not a silent failure.
        request["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": "response", "strict": True, "schema": format},
        }
    return request


# ag: the key a tool call carries when the model's arguments could not be
# read as JSON. Read back by Icaros._round, which refuses the call with this
# text so the model learns what it got wrong instead of losing a round in
# silence. Never sent back to a provider: every outbound serializer here
# rebuilds a call field by field.
ARGUMENTS_ERROR = "_arguments_error"


def _decode_arguments(text: str) -> tuple[dict, str | None]:
    """A tool call's JSON-string arguments as a dict, plus why not when they
    are not one: ({}, reason) for text that does not parse or parses to
    something other than an object."""
    if not text:
        return {}, None
    try:
        arguments = json.loads(text)
    except json.JSONDecodeError as e:
        excerpt = text if len(text) <= 200 else text[:200] + "..."
        return {}, f"the arguments were not valid JSON ({e.msg}): {excerpt}"
    if not isinstance(arguments, dict):
        return {}, "the arguments must be a JSON object of name -> value"
    return arguments, None


def _tool_call_dict(call_id, name: str, arguments: dict, error: str | None) -> dict:
    call = {"id": call_id, "function": {"name": name, "arguments": arguments}}
    if error is not None:
        call[ARGUMENTS_ERROR] = error
    return call


def _openai_message_from(response) -> dict:
    usage = field_of(response, "usage")
    message = {"content": "", "tool_calls": []}
    choices = field_of(response, "choices") or []
    if choices:
        raw_message = field_of(choices[0], "message") or {}
        message["content"] = field_of(raw_message, "content") or ""
        tool_calls = []
        for raw in field_of(raw_message, "tool_calls") or []:
            function = field_of(raw, "function") or {}
            arguments = field_of(function, "arguments")
            # OpenAI's own arguments are a JSON string, unlike Ollama/Anthropic --
            # normalized to a dict here so decode.py's tool_call_of (which does
            # dict(...) on it) works the same regardless of provider.
            error = None
            if isinstance(arguments, str):
                arguments, error = _decode_arguments(arguments)
            tool_calls.append(_tool_call_dict(field_of(raw, "id"), field_of(function, "name") or "",
                                              arguments or {}, error))
        message["tool_calls"] = tool_calls
    if usage is not None:
        _with_usage(message, usage,
                    prompt_keys=("prompt_tokens", "prompt_eval_count"),
                    completion_keys=("completion_tokens", "eval_count"))
    return message


def _openai_stream_message(stream, on_chunk) -> dict:
    """OpenAI's delta stream, assembled into what _openai_message_from returns.

    ag: `tool_calls` is the whole difficulty. The deltas are keyed by `index`
    and arrive interleaved with the text: the id and the function name come
    once, near the start, and `arguments` comes as a run of JSON string
    fragments that mean nothing until concatenated. Accumulating by index (not
    by arrival order, and not by name -- the same tool can be called twice in
    one turn) is what makes two parallel calls come out as two calls instead
    of one with a mangled argument string.
    """
    content, calls = [], {}
    for event in stream:
        choices = field_of(event, "choices") or []
        if not choices:
            continue
        delta = field_of(choices[0], "delta") or {}
        piece = field_of(delta, "content") or ""
        if piece:
            content.append(piece)
            on_chunk(piece)
        for raw in field_of(delta, "tool_calls") or []:
            index = field_of(raw, "index") or 0
            slot = calls.setdefault(index, {"id": None, "name": "", "arguments": []})
            if field_of(raw, "id"):
                slot["id"] = field_of(raw, "id")
            function = field_of(raw, "function") or {}
            if field_of(function, "name"):
                slot["name"] = field_of(function, "name")
            fragment = field_of(function, "arguments")
            if fragment:
                slot["arguments"].append(fragment)

    tool_calls = []
    for index in sorted(calls):
        slot = calls[index]
        # a truncated stream leaves half a JSON object. Better an empty
        # argument set the model is told about than a crash inside the
        # provider layer: LlmClient.chat records the round either way.
        arguments, error = _decode_arguments("".join(slot["arguments"]))
        tool_calls.append(_tool_call_dict(slot["id"], slot["name"], arguments, error))
    return {"content": "".join(content), "tool_calls": tool_calls}


def _call_openai_family(client_fn, *, model, messages, format, tools, params, chat,
                        on_chunk=None):
    # reasoning effort, sampling, penalties: all of it arrives through params
    # under OpenAI's own names (`reasoning_effort`, `temperature`, ...). This
    # used to be the place that explained why `think` could not be honoured
    # here -- an effort level is not an on/off switch and there was no
    # faithful mapping between them. There is nothing left to map.
    request = _openai_request(messages, format, tools)
    request.update(params or {})
    if on_chunk is not None:
        request["stream"] = True
    if chat is not None:
        response = chat(model=model, **request)
    else:
        response = client_fn().chat.completions.create(model=model, **request)
    if on_chunk is not None:
        return _openai_stream_message(response, on_chunk)
    return _openai_message_from(response)


def _openai_client():
    return _openai_module().OpenAI()  # OPENAI_API_KEY from the environment


def _openai_compatible_client():
    openai = _openai_compatible_module()
    base_url = os.environ.get("ICAROS_OPENAI_COMPATIBLE_BASE_URL")
    if not base_url:
        raise RuntimeError(
            "provider 'openai_compatible' needs ICAROS_OPENAI_COMPATIBLE_BASE_URL "
            "set to the server's OpenAI-compatible endpoint "
            "(e.g. http://localhost:8080/v1 for llama.cpp's server)")
    # many local servers (llama.cpp, LM Studio) never check the key at all,
    # but the SDK still requires a non-empty string to construct a client
    api_key = os.environ.get("ICAROS_OPENAI_COMPATIBLE_API_KEY") or "not-needed"
    return openai.OpenAI(base_url=base_url, api_key=api_key)


def _call_openai(*, model, messages, format, tools, params, chat, on_chunk=None):
    return _call_openai_family(_openai_client, model=model, messages=messages,
                               format=format, tools=tools, params=params, chat=chat,
                               on_chunk=on_chunk)


def _call_openai_compatible(*, model, messages, format, tools, params, chat, on_chunk=None):
    return _call_openai_family(_openai_compatible_client, model=model, messages=messages,
                               format=format, tools=tools, params=params, chat=chat,
                               on_chunk=on_chunk)


# -- Anthropic --

def _anthropic_system_and_messages(messages: list[dict]) -> tuple[str, list[dict]]:
    """Anthropic has no `system` role in `messages` (it is a top-level
    parameter) and answers to a multi-tool_use assistant turn must arrive as
    ONE following user message carrying every tool_result block, not one
    message per result the way the neutral transcript stores them -- so
    consecutive role:"tool" turns are merged here."""
    system_parts: list[str] = []
    out: list[dict] = []
    pending_results: list[dict] = []

    def flush_results():
        if pending_results:
            out.append({"role": "user", "content": list(pending_results)})
            pending_results.clear()

    for turn in messages:
        role = turn["role"]
        if role == "system":
            system_parts.append(turn["content"])
            continue
        if role == "tool":
            pending_results.append({
                "type": "tool_result",
                "tool_use_id": turn.get("provider_call_id") or turn.get("tool_name", ""),
                "content": turn["content"],
            })
            continue
        flush_results()
        if role == "assistant" and turn.get("tool_calls"):
            content: list[dict] = []
            if turn["content"]:
                content.append({"type": "text", "text": turn["content"]})
            for tc in turn["tool_calls"]:
                function = tc.get("function") or {}
                content.append({
                    "type": "tool_use",
                    "id": tc.get("id") or "",
                    "name": function.get("name", ""),
                    "input": function.get("arguments") or {},
                })
            out.append({"role": "assistant", "content": content})
        else:
            out.append({"role": role, "content": turn["content"]})
    flush_results()
    return "\n\n".join(system_parts), out


def _anthropic_request(messages, format, tools) -> dict:
    system, anthropic_messages = _anthropic_system_and_messages(messages)
    request: dict = {
        "system": system,
        "messages": anthropic_messages,
        "max_tokens": _ANTHROPIC_MAX_TOKENS,
    }
    if tools is not None:
        request["tools"] = tools
    if format is not None:
        # native structured outputs (anthropic.types.OutputConfigParam /
        # JSONOutputFormatParam, confirmed against the installed SDK) -- the
        # answer comes back as ordinary text content constrained to `format`,
        # so no response-side special-casing is needed the way a forced
        # tool-choice fallback would need: LlmClient.ask()'s own
        # json.loads(content) already reads it the same way it reads Ollama's
        # format=<schema> answer.
        request["output_config"] = {"format": {"type": "json_schema", "schema": format}}
    return request


def _anthropic_message_from(response) -> dict:
    blocks = field_of(response, "content") or []
    text_parts, thinking_parts, tool_calls = [], [], []
    for block in blocks:
        kind = field_of(block, "type")
        if kind == "text":
            text_parts.append(field_of(block, "text") or "")
        elif kind == "thinking":
            thinking_parts.append(field_of(block, "thinking") or "")
        elif kind == "tool_use":
            # already a parsed dict, unlike OpenAI's string
            arguments = field_of(block, "input") or {}
            error = field_of(block, ARGUMENTS_ERROR)
            if not isinstance(arguments, dict):
                arguments, error = {}, "the arguments must be a JSON object of name -> value"
            tool_calls.append(_tool_call_dict(field_of(block, "id"), field_of(block, "name") or "",
                                              dict(arguments), error))
    message = {"content": "".join(text_parts), "tool_calls": tool_calls}
    usage = field_of(response, "usage")
    if usage is not None:
        _with_usage(message, usage,
                    prompt_keys=("input_tokens", "prompt_tokens"),
                    completion_keys=("output_tokens", "completion_tokens"))
    if thinking_parts:
        message["thinking"] = "".join(thinking_parts)
    return message


def _anthropic_stream_message(stream, on_chunk) -> dict:
    """Anthropic's event stream, folded back into a content-block list.

    ag: this one rebuilds the SHAPE rather than the answer -- it collects the
    blocks and then hands them to _anthropic_message_from, which is the same
    function the non-streaming path uses. Duplicating that reader would be two
    places to keep in step over how a tool_use block becomes a tool call, and
    they would drift the first time either changed.

    The events are per content block: content_block_start announces one (with
    its type, and for a tool_use its id and name), content_block_delta carries
    text_delta / thinking_delta / input_json_delta, and input_json_delta is
    Anthropic's equivalent of OpenAI's argument fragments -- a run of JSON
    string pieces, meaningless until joined.
    """
    blocks: dict[int, dict] = {}
    for event in stream:
        kind = field_of(event, "type")
        index = field_of(event, "index") or 0
        if kind == "content_block_start":
            start = field_of(event, "content_block") or {}
            block = {"type": field_of(start, "type")}
            if block["type"] == "tool_use":
                block.update({"id": field_of(start, "id"),
                              "name": field_of(start, "name"), "_json": []})
            else:
                block["_text"] = []
            blocks[index] = block
        elif kind == "content_block_delta":
            delta = field_of(event, "delta") or {}
            block = blocks.setdefault(index, {"type": "text", "_text": []})
            what = field_of(delta, "type")
            if what == "text_delta":
                piece = field_of(delta, "text") or ""
                if piece:
                    block.setdefault("_text", []).append(piece)
                    on_chunk(piece)
            elif what == "thinking_delta":
                block.setdefault("_text", []).append(field_of(delta, "thinking") or "")
            elif what == "input_json_delta":
                block.setdefault("_json", []).append(field_of(delta, "partial_json") or "")

    assembled = []
    for index in sorted(blocks):
        block = blocks[index]
        if block["type"] == "tool_use":
            # a truncated stream; see the OpenAI assembler
            arguments, error = _decode_arguments("".join(block.get("_json", [])))
            assembled.append({"type": "tool_use", "id": block.get("id"),
                              "name": block.get("name"), "input": arguments,
                              ARGUMENTS_ERROR: error})
        elif block["type"] == "thinking":
            assembled.append({"type": "thinking", "thinking": "".join(block.get("_text", []))})
        else:
            assembled.append({"type": "text", "text": "".join(block.get("_text", []))})
    return _anthropic_message_from({"content": assembled})


def _call_anthropic(*, model, messages, format, tools, params, chat, on_chunk=None):
    request = _anthropic_request(messages, format, tools)
    # ag: params last, so `max_tokens` written in the .mas2i wins over the
    # default _anthropic_request just put there. Extended thinking is asked
    # for the way Anthropic asks for it -- `thinking { type: enabled
    # budget_tokens: N }` -- and a budget must stay under max_tokens, which is
    # why raising one usually means raising the other in the same block.
    request.update(params or {})
    if on_chunk is not None:
        request["stream"] = True
    if chat is not None:
        response = chat(model=model, **request)
    else:
        client = _anthropic_module().Anthropic()  # ANTHROPIC_API_KEY from the environment
        response = client.messages.create(model=model, **request)
    if on_chunk is not None:
        return _anthropic_stream_message(response, on_chunk)
    return _anthropic_message_from(response)


# -- dispatch --

_CALL_HANDLERS = {
    OLLAMA: _call_ollama,
    OPENAI: _call_openai,
    ANTHROPIC: _call_anthropic,
    OPENAI_COMPATIBLE: _call_openai_compatible,
}


def call(provider, *, model, messages, format, tools, params, chat,
         on_chunk=None) -> dict | None:
    """One round trip's worth of provider-specific request/response
    translation, or None when `provider` names nothing this build knows how
    to call -- the same "no provider to ask" stance LlmClient.chat() has
    always taken for an agent booted with none.

    `on_chunk`, when given, asks the provider to stream and is called with
    each text delta as it arrives. The dict that comes back is the same one
    either way; see the assemblers above for why that is the whole contract.
    """
    handler = _CALL_HANDLERS.get(provider)
    if handler is None:
        return None
    return handler(model=model, messages=messages, format=format, tools=tools,
                   params=params, chat=chat, on_chunk=on_chunk)
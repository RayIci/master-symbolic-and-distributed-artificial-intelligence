from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from icaros.llm.faculties import IcarosState

if TYPE_CHECKING:
    from icaros.as_semantics.intention import Intention
    from icaros.as_syntax.plan_body import PlanBody
    from icaros.as_syntax.term import Term

# ag: the default ceiling on how many round trips one session may take, for
# any agent whose .mas2i does not say otherwise (gen_max_rounds:, threaded
# through TransitionSystem.gen_max_rounds and read once per session at open,
# generation.py's _open). It exists because it is the only thing standing
# between an agent and a model that never calls icaros_done: the intention
# that opened the session is suspended until it closes, so a session that
# cannot end is a plan that never resumes. Reached, it fails the goal -- the
# same stance .wait takes on a timeout, and for the same reason: a silent
# forever-wait is worse than a failure a -!g plan can handle.
#
# 12 rather than the 8 this started at, and the number comes from watching
# rather than from taste: examples/missing-plan composes four goals, and a
# mid-sized model spent three turns reading its own journal and two answering
# in prose before getting to the fourth -- it had done the work and ran out of
# room to say so. A cap has to be loose enough that reaching it means the model
# is stuck, not merely thorough -- an agent whose plans genuinely need more
# room than that (many goals composed in one session, or one session carrying
# an entire multi-phase pipeline) raises its own ceiling instead of living
# with a default sized for a four-goal example.
MAX_ROUNDS = 12

# ag: the ceiling on the transcript, in characters, and it is a second budget
# rather than a reuse of the journal's. The journal's budget answers "how much
# background fits"; this one answers "how much of the conversation itself must
# survive", and the honest answer is nearly all of it -- MAX_ROUNDS already
# caps a session at a dozen turns, so this only bites when a goal result comes
# back enormous. Generous on purpose: dropping a turn of the conversation to
# make room for more of the same conversation is the trade nothing wants.
#
# ag: this is icaros's own budget and shadows nothing the provider has. It
# decides how much of the transcript THIS class has stored goes into the
# messages list; it is not a context window, it is not measured in tokens, and
# no API takes a parameter it could be overriding. The model's own limit is a
# separate thing, now said separately: `params { num_ctx: N }` in the .mas2i,
# under ollama's name for it, passed through untranslated.
#
# It is deliberately NOT configurable, unlike the ambient half of a prompt
# (the .mas2i's `prompt:` block, which prunes the journal, the belief dump and
# the RAG grounding). Beyond the reason above there is a harder one:
# messages() below trims whole turns but knows nothing about the pairing
# between an assistant turn carrying `tool_calls` and the role:"tool" turns
# answering them. At 8000 characters the cut never lands between them; at a
# few thousand it would routinely, and a tool result with no matching tool
# call is rejected outright by OpenAI and Anthropic. An agent that genuinely
# needs a shorter conversation lowers gen_max_rounds, which shortens it from
# the end that stays consistent.
#
# ag: worth revisiting now that num_ctx is reachable. This number was picked
# when nothing else about the request could be tuned, so it had to be safe for
# a default 4096-token context; a session given 32k has room this does not use.
# Raising it means first teaching messages() about tool-call pairing.
MAX_TRANSCRIPT_CHARS = 8000


@dataclass(slots=True)
class IcarosSession:
    """One conversation between an agent and its model, alive across cycles.

    Opened by .talk/.run/.fly/.burn, which splice a synthetic .icaros_step
    call into the calling intention's own body (see generation.py's _open) --
    the intention keeps running, its own selection carries the session
    forward, and closing it (the icaros_done tool, or MAX_ROUNDS running out)
    is just falling through to whatever followed the call.

    ag: mutable, unlike LlmToolResult next door -- that one is a record of
    something that already happened, this one is something still happening,
    and `inbox` is what keeps arriving while it does. `level` rides on the
    session and not on the agent, which is what makes sessions nest: a .talk
    opened by a plan running inside a .fly session gets its own session at its
    own level, and neither one can lower or raise the other's faculties.

    ag: __deepcopy__ returns self, like ForkData does (fork.py) and for the
    same reason -- a fork'd branch's PlanBody.clone() would otherwise deep-copy
    the ObjectTerm(session) each .icaros_step/.icaros_consider_results node
    carries, splitting one conversation into several private ones.
    """

    id: str
    # the level this session runs at -- decides which tools the model is
    # offered and what it is told it may do (IcarosState.allowed_kinds /
    # .capabilities). Never changes once the session is open.
    level: IcarosState
    # what to put in front of the model at the next round: the opening prompt
    # first, then the results of whatever goals it asked for, as they end.
    inbox: deque[str] = field(default_factory=deque)
    # whichever intention is currently carrying this session's bubble forward.
    # Set to the caller at open, and reassigned by .icaros_consider_results
    # after a fork/join round -- .fork abandons the intention that called it
    # (fork.py), so the branch that wins the .join is a DIFFERENT Intention
    # object, and this must follow it or every later lookup keyed on
    # session.intention would be looking at a dead, never-again-scheduled one.
    # None only when the action was called with no intention in hand (direct
    # execute() in a test), in which case nothing is ever resumed.
    intention: Intention | None = None
    # the plan-body chain to fall through to once the session closes -- the
    # `.body_next` of the .talk/.run/.fly/.burn call itself, captured once at
    # open time (generation.py's _open), the same way _exec_while/_exec_for
    # capture what follows a loop before splicing the reentrant step in.
    continuation: PlanBody | None = None
    # the term the caller wants the answer in -- .talk("...", Answer)'s second
    # argument, held here from the call until the session closes, which is the
    # only moment there is an answer to bind. None when the action was called
    # in its one-argument form, and then the answer lives on the journal alone.
    #
    # ag: kept as a field rather than re-read from the plan body at close time
    # (which is what .send's sync ask does with current_step.body_term) --
    # .wait's elapsed_var is the better model: the term is captured once, while
    # the call is on screen, and nothing later has to reconstruct which
    # argument it was.
    result_var: Term | None = None
    # the last thing the model actually said in prose, as opposed to the
    # account of itself it files when it calls icaros_done. When a session was
    # a question -- someone chatting, a plan asking for an explanation -- this
    # is the answer, and the summary is a minute of having answered.
    #
    # ag: kept because the protocol throws the prose away otherwise. A model
    # that answers without calling a tool is told "that is not enough, call
    # one", so the good sentence arrives a round before the one that closes the
    # session, and only this field survives the gap.
    last_answer: str | None = None
    rounds: int = 0
    # the ceiling rounds is compared against to give up (generation.py's
    # IcarosStep.execute) -- captured once at open, from the opening agent's
    # ts.gen_max_rounds, the same "read once, ride the session" treatment
    # `level` gets. Defaults to MAX_ROUNDS so a session built directly (a
    # test, or any caller with no ts.gen_max_rounds to read) keeps today's
    # global ceiling.
    max_rounds: int = MAX_ROUNDS
    opened_at_cycle: int = -1
    # was this session opened in answer to somebody, rather than by a plan of
    # the agent's own? Decided once, at the call, from the trigger the calling
    # intention is ultimately serving -- see generation.py's _is_conversation.
    #
    # ag: a flag and not a rung, because the rung cannot tell them apart: .talk
    # is BOTH how a chat is answered and how an agent is asked to explain
    # itself (examples/missing-plan does the second), and those two want
    # opposite preambles. What separates them is not what the model may do, it
    # is whether somebody is waiting for an answer.
    conversation: bool = False
    # the session as it actually happened: one {"role", "content"} per turn, in
    # order, the model's own words included.
    #
    # ag: this is what the journal preamble was standing in for, badly. A round
    # used to reach the model as a single rebuilt `user` message, so the
    # session's earlier turns arrived only as the one-liners render.py writes
    # for LLM_GENERATE -- "I asked the model about X and it reached for
    # nothing" -- competing for the same budget as every `sense:` line. The
    # agent knew more about its own machinery than about the conversation it
    # was in.
    transcript: list[dict] = field(default_factory=list)
    # icaros's own call_id (Icaros._stamp's uuid4, the key llm_call results
    # come back under) -> the id the PROVIDER assigned that same tool call,
    # when it assigned one at all. Populated at dispatch time (Icaros.
    # goal_step/_tool_call_intention), read back by
    # remember_tool_result so a role:"tool" turn can carry the id OpenAI's
    # tool_call_id / Anthropic's tool_use_id must echo. Ollama never assigns
    # one, so this stays empty for an all-Ollama session and providers.py's
    # Ollama adapter never looks at it -- the two ids exist for the same
    # reason and answer different questions: icaros's is how a result finds
    # its way back to THIS session at all (it rides the llm_call annotation
    # through the reasoning cycle, which knows nothing of providers); the
    # provider's is what THAT PROVIDER needs to accept the answer back.
    provider_call_ids: dict[str, str] = field(default_factory=dict)
    # the tool names the calling plan restricted this session to (the third
    # argument of .talk/.run/.fly/.burn). None: no restriction beyond
    # llm_tools: and the level. Never widens either of those.
    allowed_tools: frozenset[str] | None = None
    # set once allowed_tools has been checked against the tools the agent can
    # actually offer, so a name that matches nothing is warned about once.
    allowed_tools_checked: bool = False

    def __deepcopy__(self, memo: dict) -> "IcarosSession":
        return self

    def __str__(self) -> str:
        # ag: the dataclass-generated repr is what str() falls back to
        # without this, and it is not a description -- it is a full,
        # recursive dump of the session, `intention` included, which itself
        # re-embeds the very ObjectTerm(session) carrying THIS session as one
        # of its own frames. Anywhere a plan-body step gets stringified (the
        # journal, IntendedMeansView.current_step in the mind inspector), a
        # bare .icaros_step(...)/.icaros_consider_results(...) call would
        # otherwise print that whole tree. This is the short answer instead.
        return f"session {self.id} ({self.level.name.lower()}, round {self.rounds})"

    def has_work(self) -> bool:
        """Is there anything to say to the model right now?"""
        return bool(self.inbox)

    def take_inbox(self) -> list[str]:
        """Hands over everything waiting and empties it."""
        pending = list(self.inbox)
        self.inbox.clear()
        return pending

    def remember(self, role: str, content: str) -> None:
        """Adds one turn to the transcript. Empty turns are not turns."""
        if content:
            self.transcript.append({"role": role, "content": content})

    def remember_assistant_turn(self, content: str, tool_calls: list[dict]) -> None:
        """The model's own turn: what it said, and -- when there was one --
        the raw tool_calls the provider sent, kept exactly as it made them.

        ag: `remember` alone cannot carry this: a turn with tool_calls but no
        content is real (the model reached for something and said nothing)
        and must not be dropped the way remember's empty-content guard would
        drop it, and tool_calls does not belong squeezed into `content` --
        that road is what used to render a call as the sentence "(I called
        X)" instead of the structure the model itself produced. Falls back to
        plain `remember` when there is nothing to call.
        """
        if not tool_calls:
            self.remember("assistant", content)
            return
        self.transcript.append({"role": "assistant", "content": content, "tool_calls": tool_calls})

    def remember_tool_result(self, tool_name: str, content: str, *,
                             call_id: str | None = None) -> None:
        """One tool's answer, tagged with which tool it is answering.

        ag: .icaros_consider_results (generation.py) calls this once per
        result a round's tool_calls produced -- for N>1 (a fork, see
        icaros/stdlib/internal_actions/fork.py) that is N calls in a row,
        answering the N tool_calls the preceding assistant turn made, exactly
        the shape a provider's own tool-result messages take. Always a real
        turn, even if `content` is empty (an achieved goal that changed
        nothing and bound nothing still answers the call), so this does not
        route through remember's empty-content guard either.

        `call_id` is the LlmToolResult's own (icaros's internal correlator,
        not the provider's) -- looked up in provider_call_ids so the turn can
        carry the id the provider itself assigned that call, when there is
        one. None for a result whose trigger predates call_id, or one Ollama
        made (Ollama never assigns tool call ids, so there is nothing to find).
        """
        turn = {"role": "tool", "tool_name": tool_name, "content": content}
        provider_call_id = self.provider_call_ids.get(call_id) if call_id else None
        if provider_call_id is not None:
            turn["provider_call_id"] = provider_call_id
        self.transcript.append(turn)

    def messages(self, system: str,
                 budget_chars: int = MAX_TRANSCRIPT_CHARS) -> list[dict]:
        """What to put in front of the model this round: the standing
        instructions, then the conversation.

        `system` is rebuilt every round rather than remembered, so the beliefs
        and the background it carries are the current ones -- a session lives
        across cycles, and an agent's beliefs do not hold still while it does.

        ag: the FIRST user turn is pinned and the trim eats forwards from the
        second. That turn is the question -- the thing that was actually asked
        -- and a conversation that has lost it while keeping its own later
        chatter is exactly the failure this whole transcript exists to fix.
        Turns are dropped whole: half a turn is a sentence the model is held to
        having said and did not.
        """
        head = [{"role": "system", "content": system}] if system else []
        if not self.transcript:
            return head

        first, rest = self.transcript[0], self.transcript[1:]
        used = len(first["content"])
        kept: list[dict] = []
        for turn in reversed(rest):  # newest first: recency is what survives
            size = len(turn["content"])
            if used + size > budget_chars and kept:
                break
            kept.append(turn)
            used += size
        kept.reverse()
        return head + [first] + kept
from __future__ import annotations

from collections.abc import Sequence
from enum import Enum
from functools import total_ordering

from icaros.llm.tools import LlmTool, LlmToolParam, ToolKind


def _joined(parts: list[str]) -> str:
    """"a", "a and b", "a, b, and c" -- one clause list, read aloud."""
    if len(parts) == 1:
        return parts[0]
    if len(parts) == 2:
        return f"{parts[0]} and {parts[1]}"
    return ", ".join(parts[:-1]) + f", and {parts[-1]}"

# ag: the CONTROL tools, apart from tools.py's schema machinery. Everything in
# that module answers "what shape is a tool"; these three answer "which tools
# does Icaros itself define", and they are the only instances the codebase
# builds by hand -- every other LlmTool is derived from a plan or an internal
# action. Keeping them here is what lets tools.py stay a description of the
# format, readable without knowing anything about rungs or sessions.

# ag: how a model says "I am done", and the only way an Icaros session ends of
# its own accord. A tool rather than a magic word in the reply text because the
# reply text is prose and prose is not a protocol: a model that writes "ok,
# done" while still meaning to call something else would end the session by
# accident. Offered at every level (see IcarosState.allowed_kinds), including
# the ones that can do nothing else -- a session that cannot be closed is a
# suspended intention that never resumes.
#
# ag: `summary` used to be described as "what you concluded", and that was
# right while it was only a journal line. It is the session's return value now
# -- .talk("...", Answer) binds it, and a plan may hand it straight to a person
# -- so a model that answers in its prose and then files a minute of itself in
# the summary leaves the plan holding the minute. Asked for the answer instead,
# it gives the answer; the introspective use ("explain the coffee") is
# unaffected, because there the answer IS the explanation.
DONE_TOOL = LlmTool(
    name="icaros_done",
    kind=ToolKind.CONTROL,
    description="Call this when you have fully handled the request and have nothing "
                "left to ask for. It ends the session and lets the agent's plan continue.",
    params=(LlmToolParam(
        "summary",
        description="what to hand back to whoever asked. If you were asked something, this is "
                    "the answer itself, written to be read by them -- not a description of "
                    "what you did. Otherwise, what you concluded, in one or two sentences"),),
)

# ag: the two faculties the top rungs of the Icaros scale grant -- fly writes
# plans, burn also writes actions (IcarosState.faculties). Unlike DONE_TOOL
# they are not offered at every level, and unlike everything in
# Agent.llm_tools() they are not filtered by the .mas2i: there is nothing in an
# agent called "write a plan you do not have", so there is nothing for
# `llm_tools:` to name. The rung is the whole grant.
#
# The descriptions carry the syntax the model has to produce, because these are
# the only two tools whose argument is a language rather than a value. A model
# that has to guess the shape of a plan spends its rounds guessing.
ADD_PLAN_TOOL = LlmTool(
    name="icaros_add_plan",
    kind=ToolKind.CONTROL,
    description="Write a new plan into the agent's plan library, so it can pursue a goal "
                "it has no plan for yet. The plan is available immediately, to this session "
                "and to the agent from then on.",
    params=(LlmToolParam(
        "source",
        description="one AgentSpeak plan, ending with a period, e.g. "
                    "\"+!make_coffee : has(beans) <- grind; brew.\" -- an optional "
                    "@label may come first, the ': context' part may be left out"),),
)

ADD_ACTION_TOOL = LlmTool(
    name="icaros_add_action",
    kind=ToolKind.CONTROL,
    description="Write a new internal action in Python, so the agent can do something "
                "none of its actions cover. Once added it is callable from a plan body "
                "like any other action.",
    params=(
        LlmToolParam("name", description="the action's name, without the leading dot"),
        LlmToolParam(
            "code",
            description="a Python module defining the action with the @internal_action "
                        "decorator. Return True for success, False for failure; bind an "
                        "output with un.unifies. For example:\n"
                        "from icaros.as_syntax.factory import create_number\n"
                        "from icaros.stdlib.registry import internal_action\n"
                        "\n"
                        "@internal_action(min_args=2, max_args=2)\n"
                        "def double(ts, un, args):\n"
                        "    '''.double(X, -Y): binds Y to twice X.'''\n"
                        "    return un.unifies(args[1], create_number(args[0].solve() * 2))"),
    ),
)


# ag: by name, across every rung, because the question "is this a faculty?" has
# to be answerable BEFORE knowing whether this session was granted it. A model
# that names one it was not given must be told which rung it would need, and
# looking only in what the session was offered would leave it talking to a wall.
FACULTY_TOOLS = {t.name: t for t in (ADD_PLAN_TOOL, ADD_ACTION_TOOL)}


@total_ordering
class IcarosState(Enum):
    STILL = 0 # Only classic reasoning
    TALK =  1 # It can read its own journal, search its beliefs by meaning, and answer; it cannot make the agent act
    RUN =   2 # It can follow plans (ask for goals) but cannot call IAs outside plans nor create them
    FLY =   3 # It can generate new plans (stored in the PL and annotated as generated)
    BURN =  4 # It can also generate IAs (very powerful since they are written in python)
    # Maximum level can be set in mas2i file using gen_limit parameter

    def allowed_kinds(self) -> tuple[ToolKind, ...]:
        # Which tool kinds the LLM can use considering given the state
        if self is IcarosState.STILL:
            return ()
        if self is IcarosState.TALK:
            return ToolKind.JOURNAL, ToolKind.RAG
        if self is IcarosState.RUN:
            # ag: run reaches actions only through the agent's plans (GOAL);
            # calling an internal action bare, outside any plan, starts at fly.
            return ToolKind.JOURNAL, ToolKind.RAG, ToolKind.GOAL
        return ToolKind.JOURNAL, ToolKind.RAG, ToolKind.GOAL, ToolKind.INTERNAL_ACTION

    def faculties(self) -> tuple[LlmTool, ...]:
        if self >= IcarosState.BURN:
            return ADD_PLAN_TOOL, ADD_ACTION_TOOL
        if self >= IcarosState.FLY:
            return (ADD_PLAN_TOOL,)
        return ()

    def capabilities(self, offered: Sequence[LlmTool] | None = None) -> str:
        """What this session is allowed to do, in the words the model reads.

        ag: composed from TWO sources, because two different things decide it.
        The rung grants the writing faculties outright and llm_tools: cannot
        narrow them (there is nothing in an agent for "write a plan you do not
        have" to name), so those clauses come from `self`. Everything else --
        memory, goals, actions -- is offered only if llm_tools: asked for it,
        so those clauses come from `offered`, the list actually being sent.

        This used to read off the rung alone, and it lied whenever the two
        disagreed. A `run` agent whose llm_tools: names `- plans` and nothing
        else was told it "may call one of its actions directly" while being
        handed no actions at all -- and a small model, told that, goes looking
        for the tool it was promised, fails to find it, answers in prose, and
        burns a round on prose_only_nudge. The restriction was always real and
        enforced three times over (the rung gates the session, allowed_kinds
        filters what is sent, and an unoffered call is refused at dispatch);
        only the sentence was out of step.

        `offered` is None for a caller with no list in hand, which keeps the
        old rung-only wording rather than inventing a narrower claim.
        """
        kinds = None if offered is None else {t.kind for t in offered}

        def has(kind: ToolKind) -> bool:
            return kinds is None or kind in kinds

        can_recall = has(ToolKind.JOURNAL) or has(ToolKind.RAG)
        can_ask = self >= IcarosState.RUN and has(ToolKind.GOAL)
        can_act = self >= IcarosState.FLY and has(ToolKind.INTERNAL_ACTION)
        if not (can_recall or can_ask or can_act) and self < IcarosState.FLY:
            return "You may not act."

        able = []
        if can_recall:
            able.append("inspect your own memory")
        if can_ask:
            able.append("ask the agent to pursue one of the goals it already has plans for")
        if can_act:
            able.append("call one of its actions directly")
        # "answer" is what is left when the session cannot reach for anything
        # that acts -- and it is also the whole of `able` for a rung that was
        # granted a writing faculty but offered no tools at all.
        if not (can_ask or can_act):
            able.append("answer")

        sentence = "You may " + _joined(able) + "."
        # the negations earn their place: they stop a model spending a round
        # asking for something it was never going to be given. Only one of the
        # two is ever needed -- "you cannot make the agent act" already covers
        # not writing plans, and saying both reads as padding.
        if not (can_ask or can_act):
            sentence += (" You cannot make the agent act: there is nothing you can ask "
                         "it to pursue.")
        # ag: the capitals mark what THIS rung adds, which is why the plan
        # clause loses them at burn -- shouting everything shouts nothing, and
        # the thing a burn agent needs to notice is the action one.
        if self >= IcarosState.BURN:
            sentence += (" You may also write a new plan when it has none for what is "
                         "needed, and WRITE A NEW ACTION, in Python, when none of the "
                         "agent's actions can do what a plan needs.")
        elif self >= IcarosState.FLY:
            sentence += (" You may also WRITE A NEW PLAN when it has none for what is "
                         "needed, and then ask for that goal.")
        elif can_ask or can_act:
            sentence += " You cannot write new plans."
        return sentence

    # a *limit* is only useful if you can compare against it -- the
    # question the runtime asks is "am I at least FLY?", not "am I exactly
    # FLY". Ordering by value rather than IntEnum so an IcarosState never
    # silently compares equal to a bare int.
    def __lt__(self, other):
        if not isinstance(other, IcarosState):
            return NotImplemented
        return self.value < other.value

    def __str__(self) -> str:
        # the mas2i spelling: `gen_limit: fly`
        return self.name.lower()

    @classmethod
    def parse(cls, value: str | IcarosState) -> IcarosState:
        """Accepts either the enum or the mas2i spelling of it. The
        grammar already restricts the text to these five names, so a bad
        value here means a caller bypassed the parser."""
        if isinstance(value, cls):
            return value
        try:
            return cls[str(value).strip().upper()]
        except KeyError:
            names = ", ".join(str(s) for s in cls)
            raise ValueError(
                f"unknown gen_limit '{value}' (expected one of: {names})") from None
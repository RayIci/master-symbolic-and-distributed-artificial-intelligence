from __future__ import annotations

import re
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any

# ag: the provider-neutral tool definition. Both families of tools -- the
# agent's goals (pl/plan_library.py) and its internal actions
# (stdlib/ia_tools.py) -- build one of these, and the dialect adapters below
# are the only place that knows what a particular LLM API wants. LlmClient
# already switches on provider (llm/client.py), so keeping the shape neutral
# here means adding a provider doesn't reach back into the plan library.

# what OpenAI/Anthropic accept as a tool name
_NAME_RE = re.compile(r"[^A-Za-z0-9_-]")
_MAX_NAME_LEN = 64


def sanitize_tool_name(raw: str) -> str:
    """Coerces `raw` into a legal tool name (^[A-Za-z0-9_-]{1,64}$)."""
    name = _NAME_RE.sub("_", raw).strip("_")
    if not name:
        name = "unnamed"
    if name[0].isdigit():
        name = f"_{name}"
    return name[:_MAX_NAME_LEN]


class ToolKind(Enum):
    """Which family a tool comes from. Kept on the tool itself so goals and
    internal actions stay distinguishable even when merged into one list."""

    GOAL = "goal"
    INTERNAL_ACTION = "internal_action"
    # ag: tools the SESSION grants, as opposed to tools the agent has. Two
    # things follow from that, and together they are what the family means:
    #
    #   - they never come from Agent.llm_tools(), because there is nothing in
    #     the agent for them to correspond to. The .mas2i's `llm_tools:` says
    #     which of the agent's own plans and actions a model may reach for, and
    #     "end this session" or "write a plan that does not exist yet" are not
    #     among them. What grants these is the rung
    #     (IcarosState.faculties);
    #   - the round executes them itself, instead of handing them to the
    #     reasoning cycle as a `!goal` step or a frame. That is what makes the
    #     answer immediate: whether a generated plan even parses is known
    #     before the round returns, and goes back to the model as the next
    #     round's question rather than a cycle later.
    #
    # icaros_done was the first and steers the generation itself; add_plan and
    # add_action, below, act on the agent. Different targets, the same two
    # properties, and it is the properties that make them one family.
    CONTROL = "control"
    # ag: journal tools are internal actions too -- same decorator, same
    # execution contract, callable from a plan by an agent with no model at
    # all. The separate kind is about what they DO: a goal or an ordinary
    # internal action changes the world, these only read what the agent has
    # already done. That is what makes them the ones safe to hand a model in a
    # tool-calling loop, where a wrong call costs a wasted round trip rather
    # than a corrupted belief base.
    JOURNAL = "journal"
    # ag: same shape as JOURNAL -- an internal action, read-only, its own
    # family -- but a different question: not what happened, but what is
    # believed, found by meaning rather than by predicate name
    # (RagBeliefBase.retrieve). Kept apart from JOURNAL rather than folded
    # into it because the two answer different questions and an agent may
    # want one without the other -- a plain BeliefBase has no index to search,
    # so ".rag_search" fails cleanly for it while journal tools still work.
    RAG = "rag"


@dataclass(frozen=True)
class LlmToolParam:
    name: str
    type: str = "string"
    description: str = ""
    required: bool = True
    # ag: an output parameter (Jason's `-X` mode prefix) is where the action
    # writes its answer, not something the caller supplies. It stays in
    # `params` because the executor has to know to pass a fresh variable for
    # it, but it is kept OUT of the schema below -- a model asked to fill in
    # the variable that is supposed to come back holding the answer will
    # invent one, and then the answer has nowhere to go.
    output: bool = False

    def to_schema(self) -> dict[str, Any]:
        schema: dict[str, Any] = {"type": self.type}
        if self.description:
            schema["description"] = self.description
        return schema


@dataclass(frozen=True)
class LlmToolVariant:
    """One version of a goal: same trigger, different context.

    ag: text, and only text -- what the model reads in order to describe what
    it wants, never a handle on the Plan to run. It used to carry the Plan
    itself, from when a tool call was executed by whoever had picked it; now
    the model writes a `!goal` step and the cycle picks the plan, so a
    reference here would be an invitation to go back to choosing for it.
    """

    label: str
    when: str = ""
    summary: str = ""


@dataclass(frozen=True)
class LlmTool:
    name: str
    kind: ToolKind
    description: str = ""
    params: tuple[LlmToolParam, ...] = ()
    variants: tuple[LlmToolVariant, ...] = ()  # goals only; empty for internal actions
    origin: Any = None  # Trigger for a goal, InternalAction for an internal action

    def with_kind(self, kind: ToolKind) -> LlmTool:
        """A copy under a different kind -- the journal actions are built by
        the internal-action machinery but belong to their own family."""
        return replace(self, kind=kind)

    def rename(self, name: str) -> LlmTool:
        """A copy under a different name -- used to break a collision between
        a goal and an internal action that mangle to the same tool name."""
        return replace(self, name=name)

    # -- dialect adapters --

    @property
    def inputs(self) -> tuple[LlmToolParam, ...]:
        """The parameters a caller supplies -- everything but the outputs."""
        return tuple(p for p in self.params if not p.output)

    @property
    def outputs(self) -> tuple[LlmToolParam, ...]:
        """Where the action writes its answer."""
        return tuple(p for p in self.params if p.output)

    def _parameters_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {p.name: p.to_schema() for p in self.inputs},
            "required": [p.name for p in self.inputs if p.required],
        }

    def to_openai(self) -> dict[str, Any]:
        """The OpenAI function-calling shape -- also what ollama accepts in
        its `tools=` parameter, which is the provider Agentic speaks today."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self._parameters_schema(),
            },
        }

    def to_anthropic(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self._parameters_schema(),
        }


_DIALECTS = {
    "openai": LlmTool.to_openai,
    "ollama": LlmTool.to_openai,
    "openai_compatible": LlmTool.to_openai,
    "anthropic": LlmTool.to_anthropic,
}


def to_specs(tools: list[LlmTool], dialect: str = "openai") -> list[dict[str, Any]]:
    """Renders `tools` in the named dialect."""
    try:
        adapter = _DIALECTS[dialect]
    except KeyError:
        raise ValueError(
            f"unknown tool dialect '{dialect}' (known: {', '.join(sorted(_DIALECTS))})") from None
    return [adapter(t) for t in tools]


def resolve_name_collisions(tools: list[LlmTool]) -> list[LlmTool]:
    """Makes tool names unique across families.

    A goal `+!print/1` and the internal action `.print` both mangle to
    "print". Goals are the agent's own vocabulary and keep the plain name;
    the colliding internal action gets an "ia_" prefix. The input order is
    preserved -- goals just get first claim on a contested name, via the
    two passes below rather than by sorting.
    """
    goal_names = {t.name for t in tools if t.kind is ToolKind.GOAL}
    seen: set[str] = set()
    out: list[LlmTool] = []
    for tool in tools:
        name = tool.name
        # an internal action yields to a goal of the same name even when it
        # comes first in the list -- goal_names is computed up front for
        # exactly that case.
        contested = name in seen or (tool.kind is ToolKind.INTERNAL_ACTION and name in goal_names)
        if contested:
            prefix = "ia_" if tool.kind is ToolKind.INTERNAL_ACTION else "goal_"
            candidate = sanitize_tool_name(f"{prefix}{name}")
            suffix = 2
            while candidate in seen or candidate in goal_names:
                candidate = sanitize_tool_name(f"{prefix}{name}_{suffix}")
                suffix += 1
            tool = tool.rename(candidate)
            name = candidate
        seen.add(name)
        out.append(tool)
    return out

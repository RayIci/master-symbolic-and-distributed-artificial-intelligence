"""The connection to a model, and the only place in icaros that talks to one.

ag: everything provider-shaped lives behind this class and its sibling
providers.py -- the import of the provider SDK, the warm-up, the running
conversation, the shape of a round trip. `Agentic` next door decides WHAT to
ask and what to do with the answer; this decides how the asking is done. This
file stays the thin orchestration layer (the injection seam, the timing, the
LlmCall bookkeeping); providers.py carries every SDK import and every
provider's request/response translation, so a new provider is a new branch
there, not an edit spread across a god class. The provider call itself is a
constructor argument, so a test hands over its own model instead of patching
a module global -- the seam is in the signature, where it can be seen.

It fills in the `LlmCall` it is handed but never emits it: when a trace goes out
is the facade's decision, because only the facade knows whether this round trip
was a selection, a free-form send, or one round of a session.
"""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING

from icaros.llm import providers
from icaros.llm.providers import ANTHROPIC, OLLAMA, OPENAI, OPENAI_COMPATIBLE  # noqa: F401

if TYPE_CHECKING:
    from icaros.llm.trace import LlmCall


class LlmClient:
    """One model, and the conversation held with it."""

    def __init__(self, provider, model, params=None, *, chat=None):
        # ag: how to reach the provider is a parameter, so a test hands over its
        # own model instead of reaching into this module to replace a global.
        # Injecting rather than patching is what lets two clients disagree about
        # the provider in the same process -- and it means moving this file
        # cannot silently un-fake a test. None (the default) means "no
        # override": providers.py resolves the real SDK, lazily, per provider.
        self._provider_chat = chat
        self._provider = provider
        self._model = model
        # ag: the .mas2i's `params { }`, sent to the provider under its own
        # names -- see providers.py for where each one lands. None means "the
        # provider's own defaults", which is what every agent got before this
        # was reachable at all.
        #
        # The one worth knowing about without reading that file: thinking
        # models (lfm2.5-thinking, and everything else that reasons before
        # answering) put their reasoning in a separate `thinking` field only
        # when asked to. Left alone, the model inlines it into `content`
        # instead -- which breaks the json.loads() in ask() every time
        # `format` is a schema, because the reply is no longer only JSON. On
        # ollama, `params { think: false }` is how that is said.
        self._params = dict(params) if params else None
        self._messages: list[dict] = []
        providers.warm_up(self._provider, self._model, self._provider_chat)
        # ag: after the warm-up, so a provider that cannot even be reached
        # fails on its own terms first. Advisory only -- nothing is dropped
        # from the request. It exists for ollama, which ignores an option it
        # does not recognise: without this, a misspelled parameter is a line
        # in the .mas2i that does nothing and says nothing.
        for name in providers.unknown_params(self._provider, self._params):
            logging.getLogger(__name__).warning(
                "mas2i: params { %s: ... } is not a known %s parameter "
                "(model %s); it will be sent anyway", name, self._provider, self._model)

    @property
    def provider(self):
        return self._provider

    @property
    def model(self):
        return self._model

    @property
    def conversation_len(self) -> int:
        """How long the running conversation is, for the trace.

        ag: the stateless select_* path never appends, so this stays 0 there and
        only moves for a free-form send() -- which is exactly what makes the
        number worth recording. See LlmCall.messages_len.
        """
        return len(self._messages)

    def chat(self, messages: list[dict], *, call: LlmCall, format=None, tools=None,
             on_chunk=None):
        """One call to the provider, timed and recorded on `call`.

        Returns the message the model sent back, or None when there is no
        provider to ask. ask() and Icaros._round() differ in what they ask
        for and what they do with the answer, not in how the round trip is made
        or recorded.

        `on_chunk` asks the provider to stream and is called with each text
        delta on the way. It changes nothing about what this returns -- the
        message is assembled in providers.py into the same shape the
        non-streaming path produces -- so a caller that does not pass it is on
        exactly the code path it was on before streaming existed. The timing
        and the error handling below cover a stream that dies halfway as they
        already covered a request that did.
        """
        started = time.perf_counter()
        try:
            message = providers.call(
                self._provider, model=self._model, messages=messages, format=format,
                tools=tools, params=self._params, chat=self._provider_chat,
                on_chunk=on_chunk)
            if message is None:
                call.content = "PROVIDER NOT PROVIDED"
                return None
            # captured, but deliberately NOT appended to self._messages: the
            # reasoning is for the reader, not part of the conversation
            call.thinking = message.get("thinking")
            call.content = message["content"]
            usage = message.get("_usage")
            if usage is not None:
                call.prompt_tokens = usage.get("prompt_tokens")
                call.completion_tokens = usage.get("completion_tokens")
            return message
        except BaseException as e:
            call.error = f"{type(e).__name__}: {e}"
            raise
        finally:
            call.duration_ms = (time.perf_counter() - started) * 1000.0

    def ask(self, msg: str, options: list[str] | None = None, *,
            call: LlmCall, stateless: bool = False):
        """One free-form round trip, recorded on `call`.

        With `options`, the reply is pinned to that enum by a JSON schema and
        the chosen label is returned; without, the prose is.

        `stateless` sends only this prompt instead of appending to the running
        conversation -- the selection path's stance, see Agentic._select.
        """
        if stateless:
            messages = [{"role": "user", "content": msg}]
        else:
            self._messages.append({"role": "user", "content": msg})
            messages = self._messages
        format_schema = None
        if options:
            format_schema = {
                "type": "object",
                "properties": {"choice": {"type": "string", "enum": options}},
                "required": ["choice"],
            }
        try:
            message = self.chat(messages, call=call, format=format_schema)
            if message is None:
                return call.content
            content = call.content
            if not stateless:
                self._messages.append({"role": "assistant", "content": content})
            if options:
                return json.loads(content)["choice"]
            return content
        except BaseException as e:
            if call.error is None:  # raised after the round trip, e.g. a bad reply
                call.error = f"{type(e).__name__}: {e}"
            raise
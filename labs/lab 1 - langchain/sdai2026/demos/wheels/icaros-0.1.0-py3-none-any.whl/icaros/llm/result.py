from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_semantics.goal_listener import GoalStates

# ag: the two annotations every event a model adds carries. They are the
# provenance ("the model asked for this, the agent did not decide it") and,
# through llm_call, the correlation key that gets the answer back to the call.
# On the literal rather than on the Event so they survive clone/resolve and
# show up in str(trigger) -- journal, telemetry and the dev UI get them for
# free -- and so a plan can match on them: `+!g[source(llm)] : ... <- ...`.
SOURCE_LLM = "llm"
# ag: llm_call(CallId, SessionId) -- two terms, one annotation. The session was
# very nearly an annotation of its own, and did not need to be: every event a
# model adds belongs to exactly one call, and every call to exactly one
# session, so a second term says it without a second thing to keep in sync. The
# session's level is deliberately NOT here: it is fixed for the life of the
# session, so it is already known wherever the session is, and the journal's
# llm_generate line records it per round for the reader.
CALL_ANNOT = "llm_call"
# ag: the trigger functor of an intended means the model reached for directly,
# with no plan of the agent's own standing between the two -- see
# Icaros.add_tool_call. It is not a goal anybody wrote, and no plan is ever
# relevant to it: the frame is one synthetic plan whose single body step is
# the internal action, pushed onto the intention that opened the session. The
# name is in this module, next to the two annotations, because these three
# together are how the interpreter recognises the model's fingerprints on its
# own state.
TOOL_CALL_FUNCTOR = "llm_tool_call"


def _annot_term(trigger, index: int) -> str | None:
    """One term of the llm_call annotation a trigger carries, or None.

    ag: one annotation per call and no more -- Icaros._stamp stamps a
    fresh copy of the literal every time, so a trigger can never be in two
    calls (nor two sessions) at once, and get_annot's first match is the only
    match.
    """
    literal = getattr(trigger, "literal", None)
    annot = None if literal is None else literal.get_annot(CALL_ANNOT)
    if annot is None or annot.get_arity() <= index:
        return None
    return str(annot.get_term(index)).strip('"')


def call_id_of(trigger) -> str | None:
    """The llm_call(...) id a trigger carries, or None if it carries none.

    ag: how the interpreter tells "the model asked for this" from "the agent
    decided this", and which call it was. An annotation rather than matching
    on str(trigger), because the trigger is resolved and cloned on its way
    through the cycle while an annotation rides along untouched -- and because
    two calls to the same tool would otherwise look identical.
    """
    return _annot_term(trigger, 0)


def session_of(trigger) -> str | None:
    """The Icaros session a trigger belongs to, or None if it belongs to none.

    What GENERATE routes the goal's result back by: a session is a
    conversation, and an answer only means something inside the one that
    asked the question.
    """
    return _annot_term(trigger, 1)


def tool_name_of(trigger) -> str | None:
    """The name the model called this tool by, or None if it carries none.

    ag: what .icaros_consider_results (generation.py) tags a role:"tool"
    reply with, so the model reads its answer back framed exactly as what it
    is -- the result of the call it just made -- rather than as a fact to
    guess the provenance of. Riding the same llm_call annotation as call_id/
    session rather than a new one: the three travel together by construction
    (Icaros._stamp stamps all three at once), so there is nothing to keep in
    sync between two annotations that could drift apart.
    """
    return _annot_term(trigger, 2)


@dataclass(slots=True, frozen=True)
class LlmToolResult:
    """How a goal the model asked for ended.

    ag: text, not live objects, for the same reason a JournalEntry is text --
    the intended means this is read from is popped and gone a moment later,
    and a record that pointed at it would be a record of something that no
    longer exists. Built complete, when the goal ends, by
    TransitionSystem._deposit_llm_result: there is no half-filled state to
    keep, because nobody holds one of these before it has an answer.
    """

    call_id: str
    # which conversation this answers. None only for a trigger that carries
    # no llm_call at all -- a model's call always comes from a session.
    session: str | None
    # the goal as it ended, resolved: "llm_timeline(1,5,[\"rc1 ...\"])"
    goal: str
    outcome: GoalStates
    # output variable -> the term it ended up bound to. A variable that came
    # back unbound is absent rather than empty: "no answer" and "the answer
    # was nothing" are different things to tell a model.
    values: dict[str, str] = field(default_factory=dict)
    # what this goal changed in the belief base, already prefixed "+"/"-".
    # ag: the outcome says the goal ended; this says what it did, which for a
    # model composing goals is the difference between guessing what to ask for
    # next and knowing. Literals WITH their annotations, as in the journal's
    # own record_belief_change: "[source(self)]" against "[source(percept)]" is
    # half of why the agent believes a thing.
    beliefs: tuple[str, ...] = ()
    reason: str | None = None
    cycle: int = -1
    # the name the model called this tool by (tool_name_of the original
    # trigger). None only for a result whose trigger predates this field
    # (carries no llm_call third term) or carried no session at all.
    tool_name: str | None = None

    def as_text(self) -> str:
        """This answer as the content of the role:"tool" message the model
        reads at the start of its next round.

        ag: no longer repeats `goal` (which tool, with which arguments) --
        that's on the message itself now (IcarosSession.remember_tool_result
        tags it with `tool_name`), the same way a provider's own tool-result
        message never restates the call it is answering. What is left here is
        purely the answer: how it ended, what it bound, what it changed.

        The record renders itself, rather than Agentic doing it -- what a
        result is made of is this class's business, and the prompt should not
        have to know that an unbound output variable is absent from `values`
        rather than empty in it.
        """
        head = str(self.outcome)
        if self.reason:
            head = f"{head} ({self.reason})"
        if self.values:
            answers = ", ".join(f"{name}={value}" for name, value in self.values.items())
            head = f"{head}: {answers}"
        if self.beliefs:
            head = f"{head}\n  it changed what I believe: {' '.join(self.beliefs)}"
        return head
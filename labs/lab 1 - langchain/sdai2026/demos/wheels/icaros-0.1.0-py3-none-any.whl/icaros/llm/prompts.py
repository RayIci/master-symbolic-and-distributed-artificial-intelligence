"""What the agent says to a model.

ag: the wording of every prompt Icaros sends, in one file, because the wording
IS the interface -- changing "Choose one option" changes what a model does, as
surely as changing a function signature does, and it should be reviewable
without reading the round-trip code around it. The other half is decode.py.

Pure functions over strings: the journal preamble and the rung's capabilities
arrive already rendered, because reaching for them needs the agent and nothing
here does.
"""

from __future__ import annotations

from dataclasses import dataclass

from icaros.llm.decode import tool_call_of


@dataclass(frozen=True)
class PromptConfig:
    """Which parts of a session's system message get built, and how big.

    ag: the .mas2i's `prompt:` block, resolved. It lives here because this
    file is already the answer to "what does the agent say to a model", and
    what a prompt CONTAINS is the same question as how it is worded -- a
    reader asking why a model never saw the agent's beliefs should find the
    answer next to session_system, not in a constructor signature three
    packages away (which is where these numbers used to be: Icaros.__init__'s
    journal_window/journal_chars/rag_k, reachable from nowhere).

    The defaults ARE the behaviour icaros had before any of this was
    configurable, deliberately: unlike llm_tools, this block prunes rather
    than permits, so the closed end would quietly gut every agent already
    written. An unwritten key means "as before".

    `beliefs` is three-valued because the old behaviour was conditional: a
    RagBeliefBase agent got the retrieved subset instead of the full dump, and
    None keeps that rule. True or False overrides it in either direction --
    both sections at once, or neither -- which was not sayable before.

    There is no field for the rung's capabilities sentence: it is ~180
    characters and, unlike these three sections, it does not grow with the
    life of the agent. See IcarosState.capabilities.
    """

    # how many reasoning cycles of journal to show; None drops the section.
    # Journal.render's own character budget still applies on top, so this is
    # a ceiling on cycles and not a promise of how many arrive.
    history_cycles: int | None = 40
    # the "## What I believe now" full dump. None = the old rule: on for a
    # plain BeliefBase, off for a RagBeliefBase (where grounding replaces it).
    beliefs: bool | None = None
    # how many beliefs _rag_context retrieves for the round's question; None
    # drops the section. Inert for an agent whose belief base cannot retrieve.
    rag_grounding_k: int | None = 5

    @classmethod
    def from_mas2i(cls, settings: dict[str, int | bool] | None) -> PromptConfig:
        """Built from the parsed `prompt:` block, or the defaults for None.

        The one place `0`/`off` becomes "no section at all": the .mas2i says
        it two ways because both read naturally (`rag_grounding: 0` and
        `rag_grounding: off`), and everything downstream sees one.
        """
        if not settings:
            return cls()

        def size(key: str, default: int | None) -> int | None:
            value = settings.get(key, default)
            if value is True:      # `on` -- the default size, spelled out
                return default
            if value is False or value == 0:
                return None
            return value

        beliefs = settings.get("beliefs")
        return cls(history_cycles=size("history", 40),
                   beliefs=None if beliefs is None else bool(beliefs),
                   rag_grounding_k=size("rag_grounding", 5))


DEFAULT_PROMPT = PromptConfig()

# ag: "strictly between these" is doing real work -- without it a model answers
# with a sixth option of its own invention and the index lookup in
# Agentic._select raises. The `format` schema pins the reply to the enum too;
# this is the same instruction in the language the model actually reads.
SELECT_PROMPTS = {
    "select_event": "Choose one event to consider strictly between these",
    "select_message": "Choose one message to consider strictly between these",
    "select_option": "Choose one option to consider strictly between these",
    "select_intention": "Choose one intention to consider strictly between these",
    "select_action": "Choose one action to consider strictly between these",
}


def selection_prompt(prompt_prefix: str, labels: list[str], preamble: str = "") -> str:
    """One numbered list of choices, under the agent's journal.

    The labels are "0: ...", "1: ..." and the reply is read back off that index,
    so the numbering is protocol rather than presentation.
    """
    prompt = f"{prompt_prefix}:\n" + "\n".join(labels)
    return f"{preamble}\n\n{prompt}" if preamble else prompt


def session_system(preamble: str, grounding: str, capabilities: str) -> str:
    """The standing half of a round: who the agent is and what it may do.

    ag: the split from generation_prompt is the whole point. What is waiting
    for the model is now a `user` turn in a real conversation, and what stands
    behind it -- the background, the beliefs, the rung's sentence -- is a
    `system` message rebuilt each round. Before, both were one string, and the
    background came FIRST and longest: a model reading top to bottom met two
    thousand characters of reasoning cycle before it met the question, and
    answered the reasoning cycle.

    `grounding` is the RAG belief base's own contribution -- the beliefs
    closest in meaning to THIS round's question, when the agent has a
    semantic index to search (Icaros._rag_context). Ambient like `preamble`,
    not something the model has to remember to ask for: that is what makes it
    part of what the agent knows rather than a tool it may or may not reach
    for. Empty, like the other two pieces can be, for an agent with no
    semantic index.
    """
    return "\n\n".join(part for part in (preamble, grounding, capabilities) if part)


def _tool_calls_text(tool_calls: list) -> str:
    parts = []
    for raw in tool_calls:
        name, arguments = tool_call_of(raw)
        parts.append(f"{name}({arguments})" if arguments else f"{name}()")
    return "; ".join(parts)


def as_text(messages: list[dict]) -> str:
    """A message list flattened back into one readable transcript.

    ag: for the record, not for the provider. LlmCall.prompt is what the dev
    UI shows at /api/transcript/{seq} and what an --llm-trace file keeps, and
    "what the model was actually shown" has to stay answerable in one string
    now that the thing sent is a list. Roles are labelled because without them
    a transcript reads as one voice, which is the exact confusion this change
    is undoing.

    ag: an assistant turn that reached for a tool can have empty `content` --
    that is the whole point of remember_assistant_turn (session.py), the turn
    is real even with nothing said -- so without this the flattened line
    would read as blank exactly where something happened. A role:"tool" turn
    is tagged with which tool it is answering the same way, off `tool_name`.
    """
    lines = []
    for m in messages:
        role = m.get("role", "?")
        tag = f"{role} · {m['tool_name']}" if role == "tool" and m.get("tool_name") else role
        body = m.get("content") or ""
        tool_calls = m.get("tool_calls")
        if tool_calls:
            called = f"called: {_tool_calls_text(tool_calls)}"
            body = f"{body}\n{called}" if body else called
        lines.append(f"[{tag}]\n{body}")
    return "\n\n".join(lines)


def prose_only_nudge(content: str | None, done_tool_name: str) -> str:
    """Sent back to a model that answered in prose and asked for nothing.

    ag: its own words go back to it as the next round's question. A session
    left with nothing to do is a plan suspended forever, and MAX_ROUNDS is
    what eventually gives up -- this is the cheaper way out, one round earlier.
    """
    return (f"You answered: {content}\nThat is not enough on its own: call a tool, "
            f"or call {done_tool_name} if there is nothing left to do.")

def last_round_notice(done_tool_name: str) -> str:
    """Added to the question of a session's last round.

    ag: running out of rounds fails the goal that opened the session, and a
    model that was never told there was a limit cannot be blamed for reaching
    it. Said once, on the round it matters, rather than as a standing line in
    the system prompt every round would pay for.
    """
    return (f"This is your last round in this session: call {done_tool_name} now with "
            f"your answer. Anything else will end the session as a failure.")

"""What the model sent back, as something the interpreter can act on.

ag: the other half of prompts.py -- that one is what the agent says to a model,
this is what it reads back. JSON in, AgentSpeak terms out, and nothing in either
direction that needs the agent, which is why this is here and not in
`as_semantics/agentic.py`: only `as_syntax` is reached for, so the translation
can be read and tested without booting an agent or opening a session.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from icaros.as_syntax.factory import (create_atom, create_list, create_literal, create_number,
                                      create_string, create_var)
from icaros.as_syntax.trigger import TEOperator, TEType
from icaros.llm.tools import ToolKind

if TYPE_CHECKING:
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.term import Term


def json2term(value) -> Term:
    """One JSON value from the model as an AgentSpeak term."""
    if isinstance(value, bool):
        return create_atom("true" if value else "false")
    if isinstance(value, (int, float)):
        return create_number(value)
    if isinstance(value, (list, tuple)):
        return create_list(*[json2term(v) for v in value])
    return create_string(str(value))


def is_achieve_goal(trigger) -> bool:
    """Is this a `+!g` trigger, the only shape add_event knows how to post?"""
    return (trigger is not None and trigger.operator == TEOperator.ADD
            and trigger.type == TEType.ACHIEVE)


def field_of(obj, name: str):
    """One field of `obj`, whether it is a dict or an object -- ollama hands
    back pydantic models, a test hands back a dict, and OpenAI/Anthropic's own
    SDKs hand back their own pydantic models, so every reader of a provider's
    raw response (this module, providers.py) goes through this once rather
    than each teaching itself which shape it is looking at."""
    return obj.get(name) if isinstance(obj, dict) else getattr(obj, name, None)


def tool_call_of(call) -> tuple[str, dict]:
    """(name, arguments) of one tool call, however the provider spells it.

    ag: ollama hands back pydantic models and a test hands back a dict, and
    both are the same two fields. Read either way once here, rather than
    teaching the round-trip code which one it is looking at.

    ag: arguments that are not an object (a list, a bare string a provider
    let through undecoded) come back as they are, not forced through dict():
    that raised in the middle of a round and lost it in silence.
    argument_problem is what refuses them, with a reason the model can read.
    """
    function = field_of(call, "function")
    if function is None:
        return "", {}
    arguments = field_of(function, "arguments")
    if arguments is None:
        arguments = {}
    elif isinstance(arguments, str):
        try:
            arguments = json.loads(arguments) if arguments.strip() else {}
        except json.JSONDecodeError:
            pass
    elif not isinstance(arguments, dict) and hasattr(arguments, "items"):
        arguments = dict(arguments)
    return str(field_of(function, "name") or ""), arguments


def goal_functor(tool) -> str:
    """The functor to post a tool call under.

    ag: the two families do not answer this the same way, and getting it wrong
    is silent -- the event is posted, no plan is relevant to it, and the model
    waits forever for an answer nobody is computing. A journal/internal-action
    tool is reached through a wrapper plan in pl/journal_plans.asl, named
    `llm_<tool>`. A goal tool IS one of the agent's own goals, and its name is
    already that goal's functor (goal_tools.tool_name_for): posting
    `llm_book_flight` would find nothing, `book_flight` finds the plans the
    agent was written with.
    """
    if tool.kind is ToolKind.GOAL and tool.origin is not None:
        return tool.origin.literal.functor
    return f"llm_{tool.name}"


def json2terms(tool, arguments: dict) -> list[Term]:
    """The arguments of one tool call as the model sent them, in call order.

    ag: inputs are placed by position, in the order the tool declares them,
    and a missing one stops the list rather than being skipped -- the
    positions are what the callee reads, so a gap would silently shift every
    later argument into the wrong slot. The outputs are appended in a second
    pass, not dropped along with the inputs that stopped the first: they are
    where the answer comes back, and a call that cannot answer is not worth
    making (for the journal wrappers it would not even have an arity any plan
    has).

    ag: its own function because the same call reaches the agent two ways --
    as a goal to post (json2literal below) and as an internal action to run
    (Agentic._tool_call_intention) -- and only the functor differs between
    them. Two copies of this rule drifting apart is precisely how an argument
    ends up in the wrong slot with nothing raising.
    """
    terms: list[Term] = []
    for param in tool.inputs:
        if param.name not in arguments:
            break
        terms.append(json2term(arguments[param.name]))
    for index, param in enumerate(tool.outputs, 1):
        # the parameter's own name when it can be a variable ("Entries",
        # "Facts"), which keeps the answer readable in the goal itself -- and
        # readable is all it has to be, since what comes back is read off
        # whichever variables are still free when the goal ends
        terms.append(create_var(param.name if param.name[:1].isupper() else f"Out{index}"))
    return terms


class InvalidArguments(str):
    """A tool call's arguments that could not even be read -- the text says
    why (providers.py's ARGUMENTS_ERROR). Travels where the arguments would
    have, so argument_problem refuses the call with that reason."""


def argument_problem(tool, arguments) -> str | None:
    """Why `json2terms` cannot build this call, or None when it can.

    ag: the guard that keeps a call with the wrong arguments from being
    BUILT: json2terms stops its term list at the first missing declared
    input, so a call missing one arrives as a literal of lower arity than
    any plan has -- the event is posted, no plan is relevant to it, and the
    session waits forever for an answer nobody is computing (seen live: a
    model calling `recall` with no arguments raised +!llm_recall(Facts),
    arity 1, and hung the reasoning cycle of the game it was grading an
    exam in). Refusing the call instead answers the model, which is a thing
    it can act on: retry with the arguments, or move on.

    Three ways to be wrong, all refused: arguments that are not an object;
    names the tool does not declare (they would be dropped and the model's
    contribution silently lost); and required inputs missing entirely, or
    supplied after a missing optional one (a later argument would fill the
    earlier one's slot).
    """
    if isinstance(arguments, InvalidArguments):
        return str(arguments)
    if not isinstance(arguments, dict):
        return "arguments must be a JSON object of name -> value"
    declared = {p.name for p in tool.inputs}
    unknown = [n for n in arguments if n not in declared]
    if unknown:
        return (f"unknown argument(s) {'/'.join(sorted(unknown))}; this tool accepts "
                f"only {', '.join(sorted(declared)) or 'no arguments'}")
    missing = [p.name for p in tool.inputs if p.required and p.name not in arguments]
    if missing:
        return f"missing required argument(s) {'/'.join(missing)}"
    reached_gap = False
    for p in tool.inputs:
        if p.name not in arguments:
            reached_gap = True
        elif reached_gap:
            return (f"argument '{p.name}' may not be supplied after a missing one: "
                    f"it would fill the preceding argument's slot")
    return None


def json2literal(tool, arguments: dict) -> Literal:
    """One tool call as the model sent it -- a name and a JSON object -- as the
    goal literal to post.

    What the goal is depends on the family the tool comes from -- see
    goal_functor above -- because what a model adds is an event, and an event
    needs a plan to be relevant to.
    """
    return create_literal(goal_functor(tool), *json2terms(tool, arguments))
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class LlmCall:
    """One round trip to the model, recorded whether it succeeded or not.

    ag: `purpose` is what makes a trace readable -- Agentic.send() only ever sees
    a prompt string, so it cannot tell "the agent is choosing between three
    applicable plans" from "the agent is picking which event to handle". The
    select_* wrappers set it, along with `choice`, which is the datum the
    whole feature exists for: which option the model actually picked.
    """

    agent: str
    cycle: int
    purpose: str  # "send" | "select_event" | "select_option" | ...
    provider: str | None
    model: str | None
    prompt: str
    # how many messages went out. The select_* path is stateless -- its history
    # arrives as the journal preamble inside `prompt`, not as a conversation --
    # so this stays 0 there. A generation round sets it to the length of the
    # session's transcript as sent, which is what makes "was the model shown
    # the question it was asked?" answerable from a trace file alone.
    messages_len: int
    started_at: float
    duration_ms: float
    options: list[str] = field(default_factory=list)
    thinking: str | None = None
    content: str | None = None
    choice: str | None = None
    tool_specs: list[dict] = field(default_factory=list)
    # what the model actually reached for, as {"name": ..., "arguments": {...}}.
    # tool_specs above says what it could have called; this says what it did,
    # and the two are only worth having together.
    tool_calls: list[dict] = field(default_factory=list)
    # set on a generation round: which Icaros session, at which level. Both
    # None for the select_* calls, which belong to no session.
    level: str | None = None
    session: str | None = None
    error: str | None = None
    # token counts lifted from the provider's own usage block (None when the
    # provider did not report them). What makes cost-per-game answerable from
    # a trace file alone instead of from the provider's dashboard.
    prompt_tokens: int | None = None
    completion_tokens: int | None = None

    @property
    def failed(self) -> bool:
        return self.error is not None

    def summary(self) -> str:
        """One line for a log or a collapsed row."""
        head = f"{self.agent} c{self.cycle} {self.purpose}"
        if self.error is not None:
            return f"{head}: FAILED {self.error}"
        if self.choice is not None:
            return f"{head}: chose {self.choice} ({self.duration_ms:.0f} ms)"
        if self.tool_calls:
            asked = ", ".join(c.get("name", "?") for c in self.tool_calls)
            return f"{head}: called {asked} ({self.duration_ms:.0f} ms)"
        return f"{head}: {self.duration_ms:.0f} ms"

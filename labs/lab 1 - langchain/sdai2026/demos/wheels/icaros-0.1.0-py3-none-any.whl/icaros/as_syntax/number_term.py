from __future__ import annotations

from abc import abstractmethod

from icaros.as_syntax.term import Term

class NumberTerm(Term):

    @abstractmethod
    def solve(self) -> float: ...
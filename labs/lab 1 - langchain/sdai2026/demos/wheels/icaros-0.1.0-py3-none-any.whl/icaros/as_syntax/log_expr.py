from __future__ import annotations

import logging
from collections.abc import Iterator
from enum import Enum
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.binary_structure import BinaryStructure
from icaros.as_syntax.logical_formula import LogicalFormula

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.term import Term

class LogicalOp(Enum):
    NONE = "none"
    NOT = "not"
    AND = "and"
    OR = "or"

    def __str__(self) -> str:
        return _LOGICAL_OP_STR[self]


_LOGICAL_OP_STR = {
    LogicalOp.NONE: "",
    LogicalOp.NOT: "not ",
    LogicalOp.AND: " & ",
    LogicalOp.OR: " | ",
}


class LogExpr(BinaryStructure, LogicalFormula):

    _logger: logging.Logger = logging.getLogger(__name__)

    EMPTY_UNIF_LIST: list = []  # ag: Java's Collections.emptyList() -- a plain [] is fine, immutable by convention

    def __init__(self, a: LogicalFormula | LogicalOp, b: LogicalOp | LogicalFormula, c: LogicalFormula | object = _unset):
        # ag: Java's LogExpr(LogicalFormula,LogicalOp,LogicalFormula) [binary]
        # / LogExpr(LogicalOp,LogicalFormula) [unary] overloads collapsed here.
        if c is not _unset:
            f1, oper, f2 = a, b, c
            super().__init__(f1, str(oper), f2)
            self._op = oper
        else:
            oper, f = a, b
            super().__init__(str(oper), f)
            self._op = oper

    # ag: lhs/rhs are inherited from BinaryStructure.{lhs,rhs} as-is -- Java redeclared
    # get_lhs()/get_rhs() here purely to narrow the return type to LogicalFormula, which
    # Python's duck typing doesn't need.
    @property
    def op(self) -> LogicalOp:
        return self._op

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        try:
            if self._op == LogicalOp.NONE:
                pass
            elif self._op == LogicalOp.NOT:
                if next(self.lhs.logical_consequence(ag, un), None) is None:
                    yield from LogExpr.create_unif_iterator(un)
                    return
            elif self._op == LogicalOp.AND:
                for u1 in self.lhs.logical_consequence(ag, un):
                    yield from self.rhs.logical_consequence(ag, u1)
                return
            elif self._op == LogicalOp.OR:
                original_un = un.clone()
                yield from self.lhs.logical_consequence(ag, un)
                yield from self.rhs.logical_consequence(ag, original_un)
                return
        except Exception as e:
            # ag: Java re-evaluates lhs/rhs a second time here to log which solutions
            # existed -- risky (could itself raise, or re-trigger side effects) for a
            # debug log line, so this just logs the error instead.
            self._logger.error(f"Error evaluating expression {self}: {e}")
        return

    @staticmethod
    def create_unif_iterator(*unifs: Unifier) -> Iterator[Unifier]:
        return iter(unifs)

    def resolve(self, u: Unifier) -> Term:
        # do not call constructor with term parameter!
        if self.is_unary():
            return LogExpr(self._op, self.get_term(0).resolve(u))
        else:
            return LogExpr(self.get_term(0).resolve(u), self._op, self.get_term(1).resolve(u))

    def clone(self) -> LogicalFormula:
        if self.is_unary():
            return LogExpr(self._op, self.get_term(0).clone())
        else:
            return LogExpr(self.get_term(0).clone(), self._op, self.get_term(1).clone())

    def clone_ns(self, newnamespace: Atom) -> Literal:
        if self.is_unary():
            return LogExpr(self._op, self.get_term(0).clone_ns(newnamespace))
        else:
            return LogExpr(self.get_term(0).clone_ns(newnamespace), self._op, self.get_term(1).clone_ns(newnamespace))

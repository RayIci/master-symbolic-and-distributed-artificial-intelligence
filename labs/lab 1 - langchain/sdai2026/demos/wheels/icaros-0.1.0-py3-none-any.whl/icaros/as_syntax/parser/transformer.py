from __future__ import annotations

import itertools

from lark import Transformer, v_args

from icaros.as_syntax.agent_source import AgentSource, Directive
from icaros.as_syntax.arith_expr import ArithExpr, ArithmeticOp
from icaros.as_syntax.arith_function_term import ArithFunctionTerm
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import is_keyword
from icaros.as_syntax.internal_action_literal import InternalActionLiteral
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.literal_impl import LiteralImpl
from icaros.as_syntax.log_expr import LogExpr, LogicalOp
from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.as_syntax.plan import Plan
from icaros.as_syntax.plan_body import BodyType, PlanBody
from icaros.as_syntax.pred import Pred
from icaros.as_syntax.rel_expr import RelExpr, RelationalOp
from icaros.as_syntax.rule import Rule
from icaros.as_syntax.source_info import SourceInfo
from icaros.as_syntax.string_term import StringTerm
from icaros.as_syntax.structure import Structure
from icaros.as_syntax.trigger import TEOperator, TEType, Trigger
from icaros.as_syntax.unnamed_var import UnnamedVar
from icaros.as_syntax.var_term import VarTerm

from icaros.as_syntax.parser.errors import ASParseError

# ag: full escape-sequence support -- a deliberate divergence from Java's
# real parser, which only actually unescapes \n and \" despite its token
# grammar defining more. See porting.md.
_ESCAPES = {"n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f", "\\": "\\", "'": "'", '"': '"'}


def _unescape_string(raw: str) -> str:
    inner = raw[1:-1]
    out = []
    i = 0
    while i < len(inner):
        c = inner[i]
        if c == "\\" and i + 1 < len(inner):
            out.append(_ESCAPES.get(inner[i + 1], inner[i + 1]))
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


_REL_OPS = {
    "<": RelationalOp.LT,
    "<=": RelationalOp.LTE,
    ">": RelationalOp.GT,
    ">=": RelationalOp.GTE,
    "==": RelationalOp.EQ,
    "\\==": RelationalOp.DIF,
    "=": RelationalOp.UNIFY,
    "=..": RelationalOp.LITERAL_BUILDER,
}


class AgentSpeakTransformer(Transformer):

    # ----- literals / preds -----

    def ns_prefix_atom(self, children):
        atom_tok, _dblcolon_tok = children
        text = str(atom_tok)
        if text == "default":
            return Literal.default_ns
        # ag: "this_ns" (Java: ambient namespace tracked by the {begin
        # namespace()}...{end} directive system) is NOT special-cased here --
        # icaros has no ambient-namespace/directive tracking (out of scope,
        # see porting.md). Parses as an ordinary namespace atom literally named
        # "this_ns", a documented divergence from Java.
        return Atom(text)

    def ns_prefix_var(self, children):
        var_tok, _dblcolon_tok = children
        return VarTerm(str(var_tok))

    def literal_pred(self, children):
        ns_node, neg_tok, pred_obj = children
        neg = neg_tok is not None
        if "." in pred_obj.functor:
            if pred_obj.has_annot():
                raise ASParseError(f"Internal actions cannot have annotations: {pred_obj}")
            if neg:
                raise ASParseError(f"Internal actions cannot be negated: {pred_obj}")
            # ag: matches Java's InternalActionLiteral(F, curAg) 2-arg path (used
            # for every internal action except the out-of-scope `.include`) -- an
            # explicit ns:: prefix on an internal action is silently dropped,
            # exactly as in Java.
            return InternalActionLiteral(pred_obj, None)
        pos = Literal.l_neg if neg else Literal.l_pos
        # ag: Java's literal() forces NS back to Literal.DefaultNS when the
        # predicate is a reserved keyword functor (ASSyntax.isKeyword), silently
        # overriding any explicit ns:: prefix -- see factory.py's _keywords/is_keyword.
        ns = Literal.default_ns if (ns_node is None or is_keyword(pred_obj)) else ns_node
        return LiteralImpl(ns, pos, pred_obj)

    def literal_var(self, children):
        ns_node, neg_tok, var_obj = children
        if ns_node is not None:
            var_obj = var_obj.clone_ns(ns_node)
        var_obj.set_negated(Literal.l_neg if neg_tok is not None else Literal.l_pos)
        return var_obj

    def literal_true(self, children):
        return Literal.l_true

    def literal_false(self, children):
        return Literal.l_false

    def pred(self, children):
        atom_tok, terms, annots = children
        p = Pred(str(atom_tok))
        if terms is not None:
            p.add_terms(*terms)
        if annots is not None:
            p.set_annots(annots)
        return p

    def terms(self, children):
        return list(children)

    # ----- lists -----

    def list(self, children):
        *elems, _pipe_tok, tail = children
        if len(elems) == 1 and elems[0] is None:
            elems = []
        # ag: built in one pass (prepend from the tail backward) rather than
        # extend()'s old per-element append() -- append() recurses to the
        # current tail on every call, so building an n-element list that way
        # was O(n) stack depth for its own last call alone; a list literal
        # past ~1000 elements hit Python's recursion limit outright.
        node = ListTerm()
        for t in reversed(elems):
            node = ListTerm(t, node)
        lt = node
        if tail is not None:
            if isinstance(tail, ListTerm):
                lt.concat(tail)
            else:
                lt.set_tail(tail)
        return lt

    def tail_var(self, children):
        return VarTerm(str(children[0]))

    def tail_unnamedvar(self, children):
        return UnnamedVar.create(str(children[0]))

    def tail_list(self, children):
        return children[0]

    # ----- arithmetic / relational / logical -----

    def number(self, children):
        return NumberTermImpl(float(str(children[0])))

    def arith_literal(self, children):
        # ag: a literal reached in arithmetic-expression position (e.g.
        # math::sqrt(9)) is, syntactically, just an ordinary namespaced
        # literal -- literal_pred already built it. Here we check whether it
        # names a known arithmetic function and, if so, re-wrap it as an
        # ArithFunctionTerm instead; otherwise it's an ordinary predicate/
        # query used in arithmetic position (already handled/failed at
        # resolve-time by ArithExpr today) and passes through unchanged.
        # Two shapes name a function: a namespaced literal (math::sqrt(9),
        # system::time) and a dot-prefixed internal-action literal, Java's own
        # spelling for the functions that double as internal actions
        # (.length(L) -- jason.functions.Length). Everything else passes
        # through: VarTerm (math::X) via is_var(), and Literal.l_true/l_false
        # and plain non-namespaced literals via the ns check, none of which can
        # ever name a registered function.
        #
        # Name AND arity must match, exactly as Java's getArithFunction +
        # checkArity: that is what keeps `.length(L)` (this function) apart
        # from `.length(L, X)` (the internal action of the same name), and it
        # is decided here once, at parse time -- never at run time.
        term = children[0]
        if isinstance(term, Literal) and not term.is_var():
            if term.ns != Literal.default_ns:
                name = f"{term.ns}::{term.functor}"
            elif term.is_internal_action():
                name = term.functor
            else:
                name = None
            if name is not None:
                from icaros.stdlib.arith_registry import load_arith_functions
                function = load_arith_functions().get(name)
                if function is not None and function.check_arity(term.get_arity()):
                    aft = ArithFunctionTerm(function)
                    aft.set_terms(term.get_terms() or [])
                    aft.src_info = term.src_info
                    return aft
        return term

    def unary_plus(self, children):
        return ArithExpr(ArithmeticOp.PLUS, children[1])

    def unary_minus(self, children):
        return ArithExpr(ArithmeticOp.MINUS, children[1])

    def arith_add(self, children):
        return ArithExpr(children[0], ArithmeticOp.PLUS, children[2])

    def arith_sub(self, children):
        return ArithExpr(children[0], ArithmeticOp.MINUS, children[2])

    def arith_mul(self, children):
        return ArithExpr(children[0], ArithmeticOp.TIMES, children[2])

    def arith_div(self, children):
        return ArithExpr(children[0], ArithmeticOp.DIV, children[2])

    def arith_intdiv(self, children):
        return ArithExpr(children[0], ArithmeticOp.INTDIV, children[2])

    def arith_mod(self, children):
        return ArithExpr(children[0], ArithmeticOp.MOD, children[2])

    def arith_pow(self, children):
        return ArithExpr(children[0], ArithmeticOp.POW, children[2])

    def log_or(self, children):
        return LogExpr(children[0], LogicalOp.OR, children[2])

    def log_and(self, children):
        return LogExpr(children[0], LogicalOp.AND, children[2])

    def log_not(self, children):
        return LogExpr(LogicalOp.NOT, children[1])

    def rel(self, children):
        lhs, op_tok, rhs = children
        return RelExpr(lhs, _REL_OPS[str(op_tok)], rhs)

    def string(self, children):
        return StringTerm(_unescape_string(str(children[0])))

    # ----- variables -----

    def named_var(self, children):
        tok, annots = children
        v = VarTerm(str(tok))
        if annots is not None:
            v.set_annots(annots)
        return v

    def unnamedvarid_term(self, children):
        tok, annots = children
        name = str(tok)
        digits = "".join(itertools.takewhile(str.isdigit, name[1:]))
        v = UnnamedVar.create_with_id(Literal.default_ns, int(digits), name)
        if annots is not None:
            v.set_annots(annots)
        return v

    def unnamedvar_term(self, children):
        tok, annots = children
        v = UnnamedVar.create(str(tok))
        if annots is not None:
            v.set_annots(annots)
        return v

    # ----- term (Java's changeToAtom collapse) -----

    def term(self, children):
        t = children[0]
        if t is Literal.l_true or t is Literal.l_false:
            return t
        if hasattr(t, "is_atom") and t.is_atom():
            return Atom(t)
        return t

    # ----- plans / triggers / plan bodies / rules -----

    def plan_annotation(self, children):
        if len(children) == 1:
            functor = "undefined"
            annots = children[0]
        else:
            functor = str(children[0])
            annots = children[1]
        p = Pred(functor)
        if annots is not None:
            p.add_annots(*annots)
        return p

    @v_args(meta=True)
    def plan(self, meta, children):
        annotation, trig, context, _arrow_tok, body = children[:5]
        if body is not None and body.body_term is not None and body.body_term == Literal.l_true:
            body = body.body_next
        p = Plan(annotation, trig, context, body)
        # ag: the plan's own line span, which nothing set before -- entry_points
        # needs it to attach the doc-comment sitting immediately above the
        # plan. meta.line covers the optional "@label" too, so a doc written
        # above the annotation still lands on the right plan. `source` is
        # filled in by parse(), which is the layer that knows the file name.
        if not meta.empty:
            p.src_info = SourceInfo(None, meta.line, meta.end_line)
        # ag: sub-plans ("{ plan* }" after the "."). rest is either empty
        # (no sub-plan block at all) or [LBRACE, *subplans, RBRACE].
        rest = children[5:]
        if rest and rest[0] is not None:
            for sub_p in rest[1:-1]:
                p.add_sub_plan(sub_p)
        return p

    def trigger_add(self, children):
        return self._trigger(TEOperator.ADD, children)

    def trigger_del(self, children):
        return self._trigger(TEOperator.DEL, children)

    def _trigger(self, op, children):
        _op_tok, type_tok, literal = children
        if type_tok is None:
            te_type = TEType.BELIEF
        elif str(type_tok) == "!":
            te_type = TEType.ACHIEVE
        else:
            te_type = TEType.TEST
        return Trigger(op, te_type, literal.force_full_literal_impl())

    def plan_body(self, children):
        head, rest = children
        if rest is not None:
            head.body_next = rest
        return head

    def achieve(self, children):
        return PlanBody(BodyType.ACHIEVE, children[-1])

    def achieve_nf(self, children):
        return PlanBody(BodyType.ACHIEVE_NF, children[-1])

    def test_formula(self, children):
        return PlanBody(BodyType.TEST, children[-1])

    def add_bel(self, children):
        return self._bel_body(BodyType.ADD_BEL, children[-1])

    def add_bel_new_focus(self, children):
        return self._bel_body(BodyType.ADD_BEL_NEW_FOCUS, children[-1])

    def add_bel_begin(self, children):
        # ag: Java's "+<" is documented as an alias for plain addBel
        return self._bel_body(BodyType.ADD_BEL, children[-1])

    def add_bel_end(self, children):
        return self._bel_body(BodyType.ADD_BEL_END, children[-1])

    def del_bel(self, children):
        return self._bel_body(BodyType.DEL_BEL, children[-1])

    def del_add_bel(self, children):
        return self._bel_body(BodyType.DEL_ADD_BEL, children[-1])

    def del_bel_new_focus(self, children):
        return self._bel_body(BodyType.DEL_BEL_NEW_FOCUS, children[-1])

    @staticmethod
    def _bel_body(form_type: BodyType, literal) -> PlanBody:
        if literal.is_internal_action():
            raise ASParseError(f"Wrong combination of operator {form_type} and internal action {literal}.")
        return PlanBody(form_type, literal)

    def plain_body_item(self, children):
        # ag: mirrors Java's body_formula() post-parse dispatch for the
        # no-prefix case: a RelExpr becomes a constraint, a dotted-functor
        # Literal becomes an internal action, anything else stays a plain
        # action. See porting.md.
        (b,) = children
        if isinstance(b, RelExpr):
            return PlanBody(BodyType.CONSTRAINT, b)
        if isinstance(b, Literal):
            form_type = BodyType.INTERNAL_ACTION if b.is_internal_action() else BodyType.ACTION
            return PlanBody(form_type, b)
        return b

    def rule_or_belief(self, children):
        head, body = children
        if body is None:
            return head
        return Rule(head, body)

    # ----- rule_plan_term ("{...}" used as an ordinary term) -----

    def rule_plan_term(self, children):
        # ag: LBRACE/RBRACE are named terminals, so (unlike an inline "{"
        # string literal) Lark keeps them as real children -- content is the
        # middle one.
        _lbrace, content, _rbrace = children
        if content is None:
            empty = PlanBody(BodyType.NONE, None)
            empty.is_body_term = True
            return empty
        return content

    def trigger_led_term(self, children):
        annotation, trigger, context, tail = children
        is_arrow_tail = tail is not None and tail.data == "tail_arrow"
        is_semi_tail = tail is not None and tail.data == "tail_semi"
        # ag: LEFT_ARROW is a named terminal (kept as a token child in
        # tail_arrow, unlike the inline ";" in tail_semi, which Lark filters
        # out) -- the plan_body is always the LAST child either way.
        body = tail.children[-1] if tail is not None else None

        # pb ("only plan body"): mirrors Java's rule_plan_term() local of the
        # same name -- true only for a bare belief trigger (no annotation, no
        # context, and if a tail is present it must be a ";"-chain, not "<-").
        pb = annotation is None and trigger.type == TEType.BELIEF and context is None and not is_arrow_tail

        if not pb and is_semi_tail:
            # ag: Java's own validation -- a ";"-tail is only meaningful right
            # after a bare belief trigger (chaining more belief updates); for
            # anything else (achieve/test trigger, or with annotation/context)
            # it's a ParseException ("Wrong place for ';'"), replicated here.
            raise ASParseError("rule_plan_term: ';' is only valid after a bare belief trigger")

        if pb:
            # case 2: {+g}, {-g}, {+g; +h} -> a PlanBody chain, same shape as
            # if +g/-g had been written directly as plan-body items.
            body_type = BodyType.ADD_BEL if trigger.operator == TEOperator.ADD else BodyType.DEL_BEL
            head = PlanBody(body_type, trigger.literal)
            head.body_next = body
            head.is_body_term = True
            return head

        if context is None and tail is None and annotation is None:
            # case 3: {+!g}, {-!g}, {+?g}, {-?g} -- a bare non-belief trigger,
            # nothing else given.
            trigger.set_as_trigger_term(True)
            return trigger

        # case 4: {@lbl +g}, {+g : ctx}, {+g <- body}, or any combination --
        # a full Plan used as a term.
        plan = Plan(annotation, trigger, context, body)
        plan.is_plan_term = True
        return plan

    def body_led_term(self, children):
        body, rule_formula = children
        if rule_formula is not None:
            # case 1: {h(X) :- body} -- a Rule used as a term. The head is
            # whatever literal plan_body/plain_body_item wrapped, regardless
            # of the BodyType it was classified with (ACTION/INTERNAL_ACTION/
            # ...) -- that classification is irrelevant here, only the
            # underlying literal matters.
            rule = Rule(body.body_term, rule_formula)
            rule.is_term = True
            return rule
        # case 5: { .println(x) }, { !g1; !g2 } -- a generic PlanBody term.
        body.is_body_term = True
        return body

    def initial_goal(self, children):
        # ag: reuses Trigger as the marker type for an initial goal (rather
        # than a new wrapper class) -- it's exactly the Event trigger the
        # bootstrap code needs to seed the circumstance with.
        literal = children[-1]
        return Trigger(TEOperator.ADD, TEType.ACHIEVE, literal.force_full_literal_impl())

    def directive(self, children):
        _lbrace_tok, atom_tok, terms, _rbrace_tok = children
        return Directive(str(atom_tok), list(terms) if terms is not None else [])

    def agent(self, children):
        source = AgentSource()
        for item in children:
            if isinstance(item, Plan):
                source.plans.append(item)
            elif isinstance(item, Trigger):
                source.initial_goals.append(item)
            elif isinstance(item, Directive):
                source.directives.append(item)
            else:
                source.beliefs.append(item)
        return source

    # ----- forks (|&|/|||, JasonER concurrency sugar) -----

    def fork_and(self, children):
        return self._fork("and", children)

    def fork_or(self, children):
        return self._fork("or", children)

    @staticmethod
    def _fork(op: str, children) -> PlanBody:
        # ag: replicates Java's same-operator flattening (A |&| B |&| C
        # becomes one .fork(and,A,B,C), not nested .fork(and,A,.fork(and,B,C)))
        # for byte-for-byte parity with the real parser's output -- see
        # porting.md. The grammar's right-recursion always nests as
        # fork_and(f, fork_and(g, h)) for "f |&| g |&| h", so the flattening
        # happens here, in the transformer, not in the grammar.
        f, _op_tok, r = children
        op_atom = Atom(op)
        s = Structure(".fork")
        s.add_terms(op_atom, f)
        if (
            isinstance(r, PlanBody)
            and r.body_type == BodyType.INTERNAL_ACTION
            and r.body_term.is_internal_action()
            and r.body_term.functor == ".fork"
            and r.body_term.get_arity() > 0
            and r.body_term.get_term(0) == op_atom
        ):
            for i in range(1, r.body_term.get_arity()):
                s.add_terms(r.body_term.get_term(i))
        else:
            s.add_terms(r)
        ial = InternalActionLiteral(s, None)
        return PlanBody(BodyType.INTERNAL_ACTION, ial)

    # ----- ER statement sugar (if/elif/else, for, while) -----

    def stmt_if(self, children):
        return children[1]

    def stmt_if_common(self, children):
        cond = children[0]
        then_body = children[2] if children[2] is not None else PlanBody()
        if len(children) == 6:
            # "... ELIF stmt_if_common" -- children[5] is the nested
            # stmt_if_common's already-transformed PlanBody result.
            else_arg = children[5]
        elif children[4] is not None:
            # "... ELSE LBRACE [plan_body] RBRACE"
            else_arg = children[6] if children[6] is not None else PlanBody()
        else:
            # neither ELIF nor ELSE present
            else_arg = None
        return self._if_then_else(cond, then_body, else_arg)

    @staticmethod
    def _if_then_else(cond, then_body, else_arg) -> PlanBody:
        # ag: if/for/while are language constructs (BodyType.IF/FOR/WHILE),
        # not internal actions -- see transition_system.py's
        # _exec_if/_exec_while/_exec_for for the splice logic. Plain
        # Structure (not InternalActionLiteral): nothing looks these up
        # through the internal-action registry.
        s = Structure("if")
        s.add_terms(cond, then_body)
        if else_arg is not None:
            s.add_terms(else_arg)
        s.src_info = cond.src_info
        return PlanBody(BodyType.IF, s)

    def stmt_for(self, children):
        return self._stmt_loop(BodyType.FOR, "for", children)

    def stmt_while(self, children):
        return self._stmt_loop(BodyType.WHILE, "while", children)

    @staticmethod
    def _stmt_loop(body_type: BodyType, functor: str, children) -> PlanBody:
        _kw_tok, cond, _lbrace_tok, body, _rbrace_tok = children
        if body is None:
            body = PlanBody()
        s = Structure(functor)
        s.add_terms(cond, body)
        s.src_info = cond.src_info
        return PlanBody(body_type, s)

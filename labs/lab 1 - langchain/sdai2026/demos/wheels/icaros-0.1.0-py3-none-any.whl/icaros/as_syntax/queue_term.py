from __future__ import annotations

import heapq
from collections import deque
from functools import total_ordering
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.map_term import _collection_term_lt

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_syntax.term import Term


@total_ordering  # ag: __lt__ + the identity __eq__ inherited from object give us
                 # <=/>/>= for free -- missing this meant `queue_term <= queue_term`
                 # raised TypeError
class QueueTerm(DefaultTerm):
    """A FIFO queue (default) or a priority queue (priority=True) of terms.

    ag: Jason's queue/*.java wraps a raw java.util.Queue (ArrayDeque, or
    PriorityBlockingQueue for the priority variant) inside an anonymous
    ObjectTermImpl, rather than having a real QueueTerm type -- ported here
    as a first-class Term instead, in the same style as MapTerm/SetTerm.

    Priority mode uses heapq over Term's own total order (the same order
    .sort in lists.py relies on via Term.__lt__). Like Java's
    PriorityBlockingQueue, only head()/poll() are guaranteed to return
    elements in priority order -- iterating the queue (e.g. via .queue.to_list)
    is not.

    Equality is by identity (no __eq__ override, so the default object
    identity applies): Jason's underlying Java queues don't override
    equals() either, unlike Map/SetTermImpl which compare by value.
    """

    def __init__(self, priority: bool = False):
        self._priority = priority
        self._items: deque[Term] | list[Term] = [] if priority else deque()

    def clone(self) -> Term:
        return self  # shallow, same reasoning as MapTerm/SetTerm

    def deep_clone(self) -> QueueTerm:
        t = QueueTerm(self._priority)
        if self._priority:
            t._items = [item.clone() for item in self._items]
        else:
            t._items = deque(item.clone() for item in self._items)
        return t

    def resolve(self, u) -> Term:
        return self  # TODO: think about this! (matches Java's own TODO, see MapTerm/SetTerm)

    def calc_hash_code(self) -> int:
        return id(self)

    def __lt__(self, o: Term) -> bool:
        return _collection_term_lt(self, o)

    def is_queue(self) -> bool:
        return True

    def size(self) -> int:
        return len(self._items)

    def is_empty(self) -> bool:
        return len(self._items) == 0

    def __iter__(self) -> Iterator[Term]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def add(self, t: Term) -> bool:
        if self._priority:
            heapq.heappush(self._items, t)
        else:
            self._items.append(t)
        return True

    def head(self) -> Term | None:
        return self._items[0] if self._items else None

    def poll(self) -> Term | None:
        if not self._items:
            return None
        return heapq.heappop(self._items) if self._priority else self._items.popleft()

    def clear(self):
        self._items.clear()

    def __str__(self) -> str:
        items = ",".join(str(t) for t in self._items)
        return f"queue(priority)[{items}]" if self._priority else f"queue[{items}]"

from __future__ import annotations

import logging
from collections.abc import Iterator
from enum import Enum
from typing import TYPE_CHECKING

from icaros.as_syntax.binary_structure import BinaryStructure
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.log_expr import LogExpr
from icaros.as_syntax.logical_formula import LogicalFormula

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.list_term import ListTerm
    from icaros.as_syntax.term import Term

class RelationalOp(Enum):
    NONE = "none"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    EQ = "eq"
    DIF = "dif"
    UNIFY = "unify"
    LITERAL_BUILDER = "literalBuilder"

    def __str__(self) -> str:
        return _RELATIONAL_OP_STR[self]


_RELATIONAL_OP_STR = {
    RelationalOp.NONE: "",
    RelationalOp.GT: " > ",
    RelationalOp.GTE: " >= ",
    RelationalOp.LT: " < ",
    RelationalOp.LTE: " <= ",
    RelationalOp.EQ: " == ",
    RelationalOp.DIF: " \\== ",
    RelationalOp.UNIFY: " = ",
    RelationalOp.LITERAL_BUILDER: " =.. ",
}


class RelExpr(BinaryStructure, LogicalFormula):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, t1: Term, oper: RelationalOp, t2: Term):
        super().__init__(t1, str(oper), t2)
        self._op = oper

    @property
    def op(self) -> RelationalOp:
        return self._op

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        xp = self.get_term(0).resolve(un)
        yp = self.get_term(1).resolve(un)

        answer: Iterator[Unifier] | None = None

        if self._op == RelationalOp.NONE:
            pass
        elif self._op == RelationalOp.GT:
            if xp > yp: answer = LogExpr.create_unif_iterator(un)
        elif self._op == RelationalOp.GTE:
            if xp >= yp: answer = LogExpr.create_unif_iterator(un)
        elif self._op == RelationalOp.LT:
            if xp < yp: answer = LogExpr.create_unif_iterator(un)
        elif self._op == RelationalOp.LTE:
            if xp <= yp: answer = LogExpr.create_unif_iterator(un)
        elif self._op == RelationalOp.EQ:
            if xp == yp: answer = LogExpr.create_unif_iterator(un)
        elif self._op == RelationalOp.DIF:
            if xp != yp: answer = LogExpr.create_unif_iterator(un)
        elif self._op == RelationalOp.UNIFY:
            if un.unifies(xp, yp): answer = LogExpr.create_unif_iterator(un)
        elif self._op == RelationalOp.LITERAL_BUILDER:
            answer = self._literal_builder(xp, yp, un)

        is_in_debug = ag is not None and ag.logger.isEnabledFor(logging.DEBUG)
        if answer is None:
            if is_in_debug: ag.logger.debug(f"     | {self} failed  -- {un}")
            return iter(LogExpr.EMPTY_UNIF_LIST)
        else:
            if is_in_debug: ag.logger.debug(f"     | {self} succeeded  -- {un}")
            return answer

    def _literal_builder(self, xp: Term, yp: Term, u: Unifier) -> Iterator[Unifier] | None:
        try:
            p: Literal = xp  # lhs
            lt: ListTerm = yp  # rhs

            if not p.is_var() and not lt.is_var():
                # both are not vars, using normal unification
                palt = p.get_as_list_of_terms()
                if lt.size() == 3:  # list without name space
                    palt = palt.get_next()
                if u.unifies(palt, lt):
                    return LogExpr.create_unif_iterator(u)
            elif p.is_var() and lt.is_list():
                # first is var, second is list, var is assigned to lt transformed in literal
                if lt.size() == 4 and lt.get_as_list()[3].is_plan_body():  # the case where the list is for a plan
                    from icaros.as_syntax.plan import Plan
                    t = Plan.new_from_list_of_terms(lt)
                else:
                    t = Literal.new_from_list_of_terms(lt)
                if u.unifies(p, t):
                    return LogExpr.create_unif_iterator(u)
            elif p.is_literal() and lt.is_var():
                # first is literal, second is var, var is assigned to lt transformed in list
                if u.unifies(p.get_as_list_of_terms(), lt):
                    return LogExpr.create_unif_iterator(u)
            else:
                # both are vars, error
                self._logger.error(f"Both arguments of {self.get_term(0)} =.. {self.get_term(1)} are variables!")
        except Exception as e:
            self._logger.error(f"The arguments of operator =.. are not Literal and List: {e}")
        return None

    def resolve(self, u: Unifier) -> Term:
        return RelExpr(self.get_term(0).resolve(u), self._op, self.get_term(1).resolve(u))

    def clone(self) -> LogicalFormula:
        return RelExpr(self.get_term(0).clone(), self._op, self.get_term(1).clone())

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return RelExpr(self.get_term(0).clone_ns(newnamespace), self._op, self.get_term(1).clone_ns(newnamespace))

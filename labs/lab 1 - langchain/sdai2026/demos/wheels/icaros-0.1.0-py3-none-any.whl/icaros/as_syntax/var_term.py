from __future__ import annotations

import logging
from collections import Counter
from collections.abc import Iterator
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.literal_impl import LiteralImpl

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.list_term import ListTerm
    from icaros.as_syntax.term import Term

# ag: Java's VarTerm implements NumberTerm and ListTerm too, but purely to satisfy
# static typing: a variable can stand in for any term shape once resolved, and every
# NumberTerm/ListTerm method it implements (besides solve()) is a dead stub (returns
# None/False, never meaningfully called). Python is duck-typed and the rest of this
# port already dispatches via is_list()/is_numeric()/... rather than isinstance checks
# against those interfaces, so VarTerm just keeps solve() as a real method and skips
# formally inheriting NumberTerm/ListTerm (which would also collide: Literal.get_term(i)
# indexed access vs ListTerm.get_term() cons-cell access share a name in Java only
# because Java resolves overloads by arity, which Python can't do).
class VarTerm(LiteralImpl):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, a: str | Atom, b: str | Literal | object = _unset):
        # ag: Java's VarTerm(String) / VarTerm(Atom,String) / VarTerm(Atom,Literal)
        # overloads collapsed here (same pattern as Atom/Structure/Pred/LiteralImpl).
        if b is _unset:
            # VarTerm(s: str)
            s = a
            super().__init__(s)
            if s and s[0:1].islower():
                self._logger.warning(
                    f"Are you sure you want to create a VarTerm that begins with lowercase ({s})? Should it be a Term instead?")
        elif isinstance(b, str):
            # VarTerm(namespace, functor)
            namespace, functor = a, b
            super().__init__(namespace, Literal.l_pos, functor)
        else:
            # VarTerm(namespace, v: Literal)
            namespace, v = a, b
            super().__init__(namespace, not v.negated(), v)

    def resolve(self, u: Unifier) -> Term:
        if u is not None:
            if (vl := u.get(self)) is not None:
                if not vl.is_cyclic_term() and vl.has_var(self, u):
                    from icaros.as_syntax.cyclic_term import CyclicTerm
                    from icaros.as_semantics.unifier import Unifier

                    u.remove(self)  # remove this var to avoid loops in the resolve below
                    temp_vl = vl.resolve(u)
                    u.bind(self, vl)

                    ct = CyclicTerm(temp_vl, self)
                    renamed_vars = Unifier()  # remove "this" from the value to avoid loops
                    ct.make_vars_annon(renamed_vars)
                    renamed_vars.remove(self)
                    u.compose(renamed_vars)
                    vl = ct

                vl = vl.resolve(u)  # should clone here, since there is no cloning in unify

                if vl.is_literal():
                    if self.ns != Literal.default_ns:
                        # use var ns for the value ns
                        vl = vl.clone_ns(self.ns.resolve(u))  # this var ns could be a var, so resolve
                    if self.negated():
                        vl.set_negated(Literal.l_neg)

                # decide whether to use var annots in resolve
                #   X = p[a]
                #   !X[b]
                # what's the event: +!p[a] or +!p[a,b]? Answer: use annots of var,
                # useful for meta-programming like P[step(N)]
                if vl.is_literal() and self.has_annot():
                    vll = vl.force_full_literal_impl()
                    if vll.has_annot():
                        vll.add_annots(*self.annots.resolve(u))
                    else:
                        # use set_annots to copy the tail in the list of annots
                        vll.set_annots(self.annots.resolve(u))
                    vl = vll
                return vl
            elif self.has_annot():
                # no value for the var, consider the annots
                cloned = self.clone()
                cloned.set_annots(self.annots.resolve(u))
                return cloned
        return self.clone()

    def clone(self) -> Term:
        return VarTerm(self.ns, self)

    def clone_ns(self, new_namespace: Atom) -> Literal:
        return VarTerm(new_namespace, self)

    def clone_lt(self) -> ListTerm:
        return self.clone()

    def is_var(self) -> bool: return True
    def is_unnamed_var(self) -> bool: return False
    def is_ground(self) -> bool: return False

    # DO NOT consider ns in equals and hash! idem for negated -- in the unifier, the
    # vars have no ns neither negation.
    def __eq__(self, t: object) -> bool:
        if t is None: return False
        if t is self: return True
        if isinstance(t, VarTerm):
            return self.functor == t.functor
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        # Do not consider NS and negated! (in unifier, A = ~A)
        return hash(self.functor)

    def __lt__(self, t: Term) -> bool:
        if t.is_unnamed_var():
            return True
        elif t.is_var():
            return self.functor < t.functor
        else:
            return False

    def subsumes(self, t: Term) -> bool:
        return True

    # ----------
    # Term methods overridden -- in case this VarTerm has a value, use value's methods
    # ----------

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        t = self.resolve(un)
        if t == self:
            # the variable is still a var, find all bels that unify
            yield from super().logical_consequence(ag, un)
        else:
            yield from t.logical_consequence(ag, un)

    def get_term(self, i: int) -> Term | None: return None

    def add_term(self, t: Term):
        self._logger.warning(f"The add_term '{t}' in {self} was lost, since I am a var.")

    def get_arity(self) -> int: return 0
    def get_terms(self) -> list[Term] | None: return None
    def set_terms(self, terms: list[Term]) -> Literal: return self
    def set_term(self, i: int, t: Term): pass

    # ag: Java's addTerms(List<Term>) merged into the variadic add_terms already
    # established at the Structure level; this override matches it
    def add_terms(self, *ts: Term) -> Literal: return self

    def is_internal_action(self) -> bool: return False
    def is_list(self) -> bool: return False
    def is_string(self) -> bool: return False
    def is_plan_body(self) -> bool: return False
    def is_numeric(self) -> bool: return False
    def is_pred(self) -> bool: return False
    def is_literal(self) -> bool: return False
    def is_structure(self) -> bool: return False
    def is_atom(self) -> bool: return False
    def is_rule(self) -> bool: return False
    def is_arith_expr(self) -> bool: return False
    def is_cyclic_term(self) -> bool: return False

    def has_var(self, t: VarTerm, u: Unifier) -> bool:
        if self == t:
            return True
        if u is not None:
            if (vl := u.get(self)) is not None:
                try:
                    u.remove(self)  # avoid going to search inside it again
                    return vl.has_var(t, u)
                finally:
                    u.bind(self, vl)
        return False

    def count_vars(self) -> Counter:
        c = Counter()
        c[self] += 1
        c.update(super().count_vars())
        return c

    def can_be_added_in_bb(self) -> bool: return False

    # ----------
    # NumberTerm method -- kept as a real method without formally inheriting
    # NumberTerm (see module docstring above)
    # ----------

    def solve(self) -> float:
        raise ValueError(f"Error evaluating {self}. It is not ground!")


# ag: shared by every other DefaultTerm sibling's __lt__ (ListTerm,
# ArithFunctionTerm, StringTerm, NumberTermImpl): VarTerm's own compareTo
# always ranks itself after non-var terms, so any of those __lt__ methods
# short-circuit to True as soon as the other side is a VarTerm. Was duplicated
# verbatim (isinstance check + comment) across all 4 files -- extracted here.
def sorts_after_var(o: Term) -> bool:
    return isinstance(o, VarTerm)

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

from lark import Lark
from lark.exceptions import UnexpectedInput, VisitError

from icaros.as_syntax.parser.errors import ASParseError
from icaros.as_syntax.parser.transformer import AgentSpeakTransformer
from icaros.as_syntax.plan_doc import parse_doc_comment
from icaros.as_syntax.source_info import SourceInfo
from icaros.parse_diagnostics import describe_syntax_error, format_syntax_error

_GRAMMAR_TEXT = (Path(__file__).resolve().parent / "agentspeak.lark").read_text()

# regex-defined terminals with no fixed spelling -- every other terminal in
# this grammar is a keyword/punctuation literal, picked up automatically by
# format_syntax_error() from the grammar itself.
_OVERRIDES = {
    "VAR": "a variable (starts with an uppercase letter)",
    "UNNAMEDVARID": "an anonymous variable (e.g. _1)",
    "UNNAMEDVAR": "an anonymous variable (e.g. _foo)",
    "ATOM": "an atom (starts with a lowercase letter)",
    "NUMBER": "a number",
    "STRING": "a quoted string",
    "TRIG_TYPE": "'!' or '?'",
    "REL_OP": "a comparison operator (e.g. '==', '<')",
}

_START_RULES = (
    "literal", "var", "term", "plan", "plan_body", "trigger", "list", "formula", "rule_or_belief",
    "agent",
)

# ag: doc-comments ("/** ... */" and runs of "///") are captured through lexer
# callbacks rather than by giving them their own grammar rule. Both spellings
# are already matched by the existing COMMENT_BLOCK/COMMENT_LINE terminals and
# %ignore'd, so this costs no grammar change at all -- and therefore carries no
# risk of introducing LALR conflicts, and no risk that a doc-comment written
# somewhere the grammar didn't expect turns into a syntax error.
#
# The filter on the "/**" and "///" prefixes is what keeps an ordinary comment
# ordinary: examples/auction/auctioneer.asl opens with a plain "// this agent
# manages the auction", which must NOT become the documentation of the plan
# that follows it.
#
# The buffer is thread-local because _parsers below is module-level and shared
# across every agent's reasoning thread; a plain list here would interleave the
# comments of concurrently-parsed sources.
_scan = threading.local()


def _collect_comment(token):
    buf = getattr(_scan, "docs", None)
    if buf is not None and (token.value.startswith("/**") or token.value.startswith("///")):
        buf.append(token)
    return token


_LEXER_CALLBACKS = {"COMMENT_BLOCK": _collect_comment, "COMMENT_LINE": _collect_comment}

# ag: one Lark instance per start symbol, not Lark's multi-start feature --
# sharing LALR states across start symbols that both reach `pred`/`literal`
# (e.g. `literal` and `term`) produced genuine reduce/reduce conflicts during
# development. Building each start rule its own parser sidesteps that
# entirely. See porting.md.
_parsers: dict[str, Lark] = {
    start: Lark(_GRAMMAR_TEXT, parser="lalr", start=start, maybe_placeholders=True,
                propagate_positions=True, lexer_callbacks=_LEXER_CALLBACKS)
    for start in _START_RULES
}

_transformer = AgentSpeakTransformer()


def parse(start: str, text: str, *, source: str | None = None) -> Any:
    # ag: Lark requires the given start rule to consume the entire input to
    # succeed, so there's no separate "parse, then check for leftover
    # tokens" step the way Java's ASSyntax.parseX does explicitly with
    # getNextToken().kind != EOF.
    parser = _parsers[start]

    # save/restore rather than plain assignment: parse_agent -> _resolve_includes
    # -> parse re-enters this function for each {include(...)}, and the outer
    # source's comments must survive the nested parse.
    previous = getattr(_scan, "docs", None)
    _scan.docs = []
    try:
        try:
            tree = parser.parse(text)
        except UnexpectedInput as e:
            raise ASParseError(
                format_syntax_error(e, text, parser, source=source, overrides=_OVERRIDES),
                explanation=describe_syntax_error(e, parser, overrides=_OVERRIDES)) from e
        try:
            result = _transformer.transform(tree)
        except VisitError as e:
            # ag: Transformer.transform() wraps any exception raised inside a
            # transformer method (e.g. our own ASParseError for a validation
            # failure like a negated internal action) in a VisitError -- unwrap
            # it so callers see the real ASParseError directly.
            if isinstance(e.orig_exc, ASParseError):
                raise e.orig_exc from e
            raise
        _attach_docs(result, _scan.docs, text, source)
        return result
    finally:
        _scan.docs = previous


# -- doc-comment attachment --------------------------------------------------


class _DocBlock:
    __slots__ = ("text", "begin_line", "end_line", "used")

    def __init__(self, text: str, begin_line: int, end_line: int):
        self.text = text
        self.begin_line = begin_line
        self.end_line = end_line
        self.used = False


def _group_doc_tokens(tokens) -> list[_DocBlock]:
    """One block per "/** */"; consecutive "///" lines merge into one block."""
    blocks: list[_DocBlock] = []
    for tok in sorted(tokens, key=lambda t: (t.line or 0, t.column or 0)):
        line = tok.line or 0
        end_line = tok.end_line or line
        if (tok.value.startswith("///") and blocks
                and blocks[-1].text.startswith("///") and blocks[-1].end_line == line - 1):
            blocks[-1].text += "\n" + tok.value
            blocks[-1].end_line = end_line
        else:
            blocks.append(_DocBlock(tok.value, line, end_line))
    return blocks


def _iter_plans(node):
    """Every Plan in a parse result, sub-plans included."""
    from icaros.as_syntax.agent_source import AgentSource
    from icaros.as_syntax.plan import Plan

    if isinstance(node, AgentSource):
        plans = node.plans
    elif isinstance(node, Plan):
        plans = [node]
    else:
        return

    for plan in plans:
        yield plan
        if plan.sub_plans is not None:
            for sub in plan.sub_plans:
                yield from _iter_plans(sub)


def _attach_docs(result, tokens, text: str, source: str | None) -> None:
    """Attaches each doc-comment to the plan directly below it.

    "Directly below" means: nothing but blank lines between the end of the
    comment and the start of the plan. That check is what stops a doc written
    above a belief, a rule, or another plan from drifting onto whatever plan
    happens to come next.
    """
    plans = list(_iter_plans(result))
    if not plans:
        return

    blocks = _group_doc_tokens(tokens) if tokens else []
    lines = text.splitlines()

    for plan in plans:
        info = plan.src_info
        if info is None:
            continue
        if source is not None:
            plan.src_info = SourceInfo(source, info.begin_src_line, info.end_src_line)
        if not blocks:
            continue

        start = info.begin_src_line
        candidate = None
        for block in blocks:
            if block.used or block.end_line >= start:
                continue
            if candidate is None or block.end_line > candidate.end_line:
                candidate = block
        if candidate is None:
            continue

        # lines are 1-based; the gap is everything strictly between them
        gap = lines[candidate.end_line:start - 1]
        if any(line.strip() for line in gap):
            continue

        doc = parse_doc_comment(candidate.text)
        candidate.used = True
        if doc is not None:
            plan.doc = doc

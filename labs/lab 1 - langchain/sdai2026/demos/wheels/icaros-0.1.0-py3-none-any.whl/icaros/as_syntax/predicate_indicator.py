from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_syntax.atom import Atom


# ag: eq=False keeps the hand-written hash-shortcut __eq__/__hash__ below exactly
# as they were -- dataclass(eq=False) leaves __eq__/__hash__ completely untouched
# rather than generating its own. frozen=True needs __post_init__ +
# object.__setattr__ to set the cached _hash (a plain instance attribute, not a
# dataclass field, since it isn't part of the constructor signature).
@dataclass(frozen=True, eq=False)
class PredicateIndicator:
    ns: Atom
    functor: str
    arity: int

    def __post_init__(self):
        object.__setattr__(self, "_hash", self._calc_hash())

    @classmethod
    def of(cls, functor: str, arity: int) -> PredicateIndicator:
        from icaros.as_syntax.literal import Literal
        return cls(Literal.default_ns, functor, arity)

    def _calc_hash(self) -> int:
        t = 31 * self.arity * hash(self.ns)
        if self.functor is not None:
            t = 31 * t + hash(self.functor)
        return t

    def __eq__(self, o: object) -> bool:
        if o is self: return True
        if isinstance(o, PredicateIndicator) and hash(o) == hash(self):
            return self.arity == o.arity and self.functor == o.functor and self.ns == o.ns
        return False

    def __hash__(self) -> int: return self._hash

    def __lt__(self, pi: PredicateIndicator) -> bool:
        return (self.ns, self.functor, self.arity) < (pi.ns, pi.functor, pi.arity)

    def __str__(self) -> str:
        from icaros.as_syntax.literal import Literal
        if self.ns == Literal.default_ns:
            return f"{self.functor}/{self.arity}"
        else:
            return f"{self.ns}::{self.functor}/{self.arity}"

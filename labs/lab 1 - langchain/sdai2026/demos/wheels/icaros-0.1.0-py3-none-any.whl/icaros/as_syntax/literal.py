from __future__ import annotations

import logging
from abc import abstractmethod
from collections.abc import Iterator
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.logical_formula import LogicalFormula
from icaros.as_syntax.predicate_indicator import PredicateIndicator

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.list_term import ListTerm
    from icaros.as_syntax.rule import Rule
    from icaros.as_syntax.source_info import SourceInfo
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.var_term import VarTerm

class Literal(DefaultTerm, LogicalFormula):

    _logger: logging.Logger = logging.getLogger(__name__)

    l_pos: bool = True
    l_neg: bool = False

    # ag: bootstrapped by atom.py (TrueLiteral/FalseLiteral/DefaultNameSpace live there,
    # since they genuinely need Atom to exist as their base class at runtime)
    default_ns: Atom | None = None
    l_true: Literal | None = None
    l_false: Literal | None = None

    @staticmethod
    def parse_literal(s_literal: str) -> Literal | None:
        # ag: delegates to the as2j parser in Java, which doesn't exist yet in icaros
        raise NotImplementedError

    def copy(self) -> Literal:
        return self.clone()

    @property
    @abstractmethod
    def functor(self) -> str: ...

    def new_functor(self, f: str) -> Literal:
        from icaros.as_syntax.literal_impl import LiteralImpl
        lit = LiteralImpl(self.ns, not self.negated(), f)
        if self.has_term():
            lit.add_terms(*self.get_terms())
        if self.has_annot():
            lit.add_annots(*self.annots)
        return lit

    @property
    @abstractmethod
    def ns(self) -> Atom: ...

    def is_literal(self) -> bool: return True

    def get_predicate_indicator(self) -> PredicateIndicator:
        return PredicateIndicator(self.ns, self.functor, self.get_arity())

    # default implementation of some methods

    def get_arity(self) -> int: return 0
    def has_term(self) -> bool: return False
    def get_terms(self) -> list[Term]: return []

    def get_singleton_vars(self) -> list[VarTerm]: return []

    def make_terms_annon(self): pass

    # ag: Java's makeVarsAnnon()/makeVarsAnnon(Unifier) overloads merged into one
    # optional-arg method
    def make_vars_annon(self, un: Unifier | None = None) -> Literal: return self

    @property
    def annots(self) -> ListTerm | None: return None

    # ag: Java's hasAnnot()/hasAnnot(Term) overloads merged into one optional-arg method
    def has_annot(self, t: Term | None = None) -> bool: return False

    # ag: Java's hasSubsetAnnot(Literal)/hasSubsetAnnot(Literal, Unifier) merged
    def has_subset_annot(self, p: Literal, u: Unifier | None = None) -> bool: return True

    def clear_annots(self) -> Literal: return self

    # ag: renamed from getAnnots(String) to avoid a name clash with the no-arg get_annots()
    def get_annots_by_functor(self, functor: str) -> ListTerm:
        from icaros.as_syntax.list_term import ListTerm
        return ListTerm()

    def get_annot(self, functor: str) -> Literal | None: return None

    def get_sources(self) -> ListTerm:
        from icaros.as_syntax.list_term import ListTerm
        return ListTerm()

    # ag: Java's hasSource()/hasSource(Term) overloads merged into one optional-arg method
    def has_source(self, ag_name: Term | None = None) -> bool: return False

    def can_be_added_in_bb(self) -> bool: return False
    def subject_to_buf(self) -> bool: return True

    def negated(self) -> bool: return False

    def equals_as_structure(self, p: object) -> bool: return False

    # Not implemented methods (mirror Java: log and return a "did nothing" value
    # instead of raising, since only Structure/Pred/LiteralImpl actually implement these)

    def add_term(self, t: Term):
        self._logger.error(f"add_term is not implemented in the class {type(self).__name__}")

    def del_term(self, index: int):
        self._logger.error(f"del_term is not implemented in the class {type(self).__name__}")

    # ag: Java's addTerms(Term...)/addTerms(List<Term>) overloads merged into one variadic method
    def add_terms(self, *ts: Term) -> Literal | None:
        self._logger.error(f"add_terms is not implemented in the class {type(self).__name__}")
        return None

    def get_term(self, i: int) -> Term | None:
        self._logger.error(f"get_term(i) is not implemented in the class {type(self).__name__}")
        return None

    def set_terms(self, terms: list[Term]) -> Literal | None:
        self._logger.error(f"set_terms is not implemented in the class {type(self).__name__}")
        return None

    def set_term(self, i: int, t: Term):
        self._logger.error(f"set_term is not implemented in the class {type(self).__name__}")

    def set_annots(self, annots: ListTerm | None) -> Literal | None:
        self._logger.error(f"set_annots is not implemented in the class {type(self).__name__}")
        return None

    def add_annot(self, t: Term) -> bool:
        self._logger.error(f"add_annot({t}) is not implemented in the class {type(self).__name__} of object {self}")
        return False

    # ag: Java's addAnnots(Term...)/addAnnots(List<Term>) overloads merged into one variadic method
    def add_annots(self, *terms: Term) -> Literal | None:
        self._logger.error(f"add_annots is not implemented in the class {type(self).__name__}")
        return None

    def del_annot(self, t: Term) -> bool:
        self._logger.error(f"del_annot is not implemented in the class {type(self).__name__}")
        return False

    # ag: Java's delAnnots(List<Term>)/delAnnots() overloads merged into one optional-arg method
    def del_annots(self, annots: list[Term] | None = None) -> bool:
        self._logger.error(f"del_annots is not implemented in the class {type(self).__name__}")
        return False

    def import_annots(self, p: Literal) -> bool:
        self._logger.error(f"import_annots is not implemented in the class {type(self).__name__}")
        return False

    def add_source(self, ag_name: Term) -> Literal | None:
        self._logger.error(f"({self}) add_source is not implemented in the class {type(self).__name__}")
        return None

    def del_source(self, ag_name: Term) -> bool:
        self._logger.error(f"del_source is not implemented in the class {type(self).__name__}")
        return False

    def del_sources(self):
        self._logger.error(f"del_sources is not implemented in the class {type(self).__name__}")

    def no_source(self) -> Literal:
        lit = self.copy()
        lit.del_sources()
        return lit

    def set_negated(self, b: bool) -> Literal | None:
        self._logger.error(f"set_negated is not implemented in the class {type(self).__name__}")
        return None

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        is_in_debug = ag.logger.isEnabledFor(logging.DEBUG)  # ag: FINE -> DEBUG

        il = ag.bb.get_candidate_beliefs_for_literal(self, un)
        if il is None:
            if is_in_debug: ag.logger.debug(f"     | no candidate belief for {self} with {un}")
            return

        arch = ag.ts.ag_arch if ag is not None and ag.ts is not None else None
        nb_annots = self.annots.size() if self.has_annot() and self.annots.get_tail() is None else 0

        annots_options: Iterator[list[Term]] | None = None
        rule_it: Iterator[Unifier] | None = None
        clone_annon: Literal | None = None
        rule: Rule | None = None
        bel_in_bb: Literal | None = None

        while True:
            if arch is not None and not arch.is_running():
                return

            restart = False

            if annots_options is not None:
                for terms in annots_options:
                    bel_to_try = bel_in_bb.copy().set_annots(None).add_annots(*terms)
                    u = un.clone()
                    if u.unifies_no_undo(self, bel_to_try):
                        if is_in_debug: ag.logger.debug(f"     | for {self}, belief annotation {bel_to_try} is an option -- {u}")
                        yield u
                    else:
                        if is_in_debug: ag.logger.debug(f"     | for {self}, belief annotation {bel_to_try} is NOT an option -- {u}")
                annots_options = None

            if rule_it is not None:
                for rule_un in rule_it:
                    rhead = rule.head_resolve(rule_un)
                    self._use_deref_vars(rhead, rule_un)
                    rhead.make_vars_annon()

                    un_c = un.clone()
                    if un_c.unifies_no_undo(self, rhead):
                        if is_in_debug: ag.logger.debug(f"     | for {self}, rule {rhead} is an option -- {un_c}")
                        yield un_c
                    else:
                        if is_in_debug: ag.logger.debug(f"     | for {self}, rule {rhead} is NOT an option -- {un_c}")
                rule_it = None

            for bel_in_bb in il:
                if bel_in_bb.is_rule():
                    rule = bel_in_bb

                    if clone_annon is None:
                        clone_annon = self.resolve(un)
                        clone_annon.make_vars_annon()

                    rule_un = type(un)()  # ag: fresh Unifier() -- constructed via the same class as `un`
                    if rule_un.unifies_no_undo(clone_annon, rule):
                        if is_in_debug: ag.logger.debug(f"     | for {clone_annon}, rule {rule} is an option -- {rule_un}")
                        rule_it = rule.get_body().logical_consequence(ag, rule_un)
                        restart = True
                        break
                    else:
                        if is_in_debug: ag.logger.debug(f"     | for {clone_annon}, rule {rule} is an NOT option -- {rule_un}")
                else:
                    if nb_annots > 0:
                        if bel_in_bb.has_annot():
                            nb_annots_b = bel_in_bb.annots.size()
                            if nb_annots_b >= nb_annots:
                                annots_options = bel_in_bb.annots.sub_sets(nb_annots)
                                restart = True
                                break
                    else:
                        u = un.clone()
                        if u.unifies_no_undo(self, bel_in_bb):
                            if is_in_debug: ag.logger.debug(f"     | for {self}, belief {bel_in_bb} is an option -- {u}")
                            yield u

            if restart:
                continue

            if is_in_debug: ag.logger.debug(f"     | NO more options for {self}")
            return

    def _use_deref_vars(self, p: Term, un: Unifier):
        if isinstance(p, Literal):
            for i in range(p.get_arity()):
                t = p.get_term(i)
                if t.is_var():
                    p.set_term(i, un.deref(t))
                else:
                    self._use_deref_vars(t, un)

    def get_as_list_of_terms(self) -> ListTerm:
        from icaros.as_syntax.list_term import ListTerm
        from icaros.as_syntax.literal_impl import LiteralImpl
        result = ListTerm()
        result.append(self.ns)
        result.append(LiteralImpl(not self.negated(), self.functor))
        lt = ListTerm()
        lt.extend(self.get_terms())
        result.append(lt)
        if self.has_annot():
            result.append(self.annots.clone_lt())
        else:
            result.append(ListTerm())
        return result

    @staticmethod
    def new_from_list_of_terms(lt: ListTerm) -> Literal:
        from icaros.as_syntax.literal_impl import LiteralImpl
        try:
            it = iter(lt)
            ns = Literal.default_ns
            if len(lt) == 4:
                ns = next(it)

            tfunctor = next(it)
            pos = Literal.l_pos
            if tfunctor.is_literal() and tfunctor.negated():
                pos = Literal.l_neg

            sfunctor = tfunctor.string if tfunctor.is_string() else tfunctor.functor

            lit = LiteralImpl(ns, pos, sfunctor)

            remaining = list(it)
            if len(remaining) > 0:
                # ag: set_terms wants list[Term], not a ListTerm -- Java's ListTerm
                # extends java.util.List<Term> so the Java original can pass the
                # ListTerm straight through; this port's ListTerm deliberately
                # isn't a list (porting.md), so it must be unwrapped here.
                lit.set_terms(remaining[0].clone_lt().get_as_list())
            if len(remaining) > 1:
                lit.set_annots(remaining[1].clone_lt())
            return lit
        except Exception as e:
            # ag: Java wraps this in a JasonException (jason.JasonException, outside asSyntax scope)
            raise ValueError(f"Error creating literal from {lt}. {e}") from e

    def force_full_literal_impl(self) -> Literal:
        from icaros.as_syntax.literal_impl import LiteralImpl
        if self.is_atom() and not isinstance(self, LiteralImpl):
            return LiteralImpl(self)
        else:
            return self

    def add_source_info_as_annots(self, info: SourceInfo | None) -> Literal:
        from icaros.as_syntax.source_info import SourceInfo
        from icaros.as_syntax.string_term import StringTerm
        from icaros.as_syntax.number_term_impl import NumberTermImpl
        from icaros.as_syntax.factory import create_structure

        codesrc: Term = SourceInfo.a_no_code
        codeline: Term = SourceInfo.a_no_code
        if info is not None:
            if info.src_file is not None:
                codesrc = StringTerm(info.src_file)
            codeline = NumberTermImpl(info.begin_src_line)

        if self.get_annot("code_src") is None:
            self.add_annot(create_structure("code_src", codesrc))
        if self.get_annot("code_line") is None:
            self.add_annot(create_structure("code_line", codeline))

        return self

    # ag: Java's getAsJson() omitted here -- needs a JSON serialization strategy
    # decision (javax.json has no direct Python counterpart), not core to the data model
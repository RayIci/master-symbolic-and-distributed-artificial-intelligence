from __future__ import annotations

import logging
from collections.abc import Iterator
from enum import Enum
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.structure import Structure

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term

class BodyType(Enum):
    NONE = "none"
    ACTION = "action"
    INTERNAL_ACTION = "internalAction"
    ACHIEVE = "achieve"
    TEST = "test"
    ADD_BEL = "addBel"
    ADD_BEL_NEW_FOCUS = "addBelNewFocus"
    ADD_BEL_BEGIN = "addBelBegin"   # equivalent to simple ADD_BEL
    ADD_BEL_END = "addBelEnd"
    DEL_BEL = "delBel"
    DEL_BEL_NEW_FOCUS = "delBelNewFocus"
    DEL_ADD_BEL = "delAddBel"
    ACHIEVE_NF = "achieveNF"
    CONSTRAINT = "constraint"
    IF = "if"
    WHILE = "while"
    FOR = "for"

    def __str__(self) -> str:
        return _BODY_TYPE_STR[self]


_BODY_TYPE_STR = {
    BodyType.NONE: "",
    BodyType.ACTION: "",
    BodyType.INTERNAL_ACTION: "",
    BodyType.ACHIEVE: "!",
    BodyType.TEST: "?",
    BodyType.ADD_BEL: "+",
    BodyType.ADD_BEL_NEW_FOCUS: "++",
    BodyType.ADD_BEL_BEGIN: "+<",
    BodyType.ADD_BEL_END: "+>",
    BodyType.DEL_BEL: "-",
    BodyType.DEL_BEL_NEW_FOCUS: "--",
    BodyType.DEL_ADD_BEL: "-+",
    BodyType.ACHIEVE_NF: "!!",
    BodyType.CONSTRAINT: "",
    BodyType.IF: "",
    BodyType.WHILE: "",
    BodyType.FOR: "",
}


# ag: Java's PlanBody interface and PlanBodyImpl merged into a single class (the only
# implementer; VarTerm's `implements PlanBody` is commented out even in Java).
#
# Represents a plan body item (achieve, test, action, ...) and its successors.
# A body like a1; ?t; !g is represented as (a1, (?t, (!g, ()))).
class PlanBody(Structure):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, t: BodyType = BodyType.NONE, b: Term | bool | object = _unset, plan_term: bool = False):
        # ag: Java's PlanBodyImpl() / PlanBodyImpl(BodyType) / PlanBodyImpl(BodyType,boolean)
        # / PlanBodyImpl(BodyType,Term) / PlanBodyImpl(BodyType,Term,boolean) overloads
        # collapsed here, disambiguated by the type of the 2nd positional argument.
        super().__init__(t.value)  # functor = the enum's Java-spelling value, e.g. "achieve"
        self._next: PlanBody | None = None
        self._form_type = t
        self._is_term = False
        self._term: Term | None = None

        if b is _unset:
            pass
        elif isinstance(b, bool):
            self.is_body_term = b
        else:
            self.is_body_term = plan_term
            if b is not None:
                self.src_info = b.src_info
            self._term = b

    @property
    def body_next(self) -> PlanBody | None:
        return self._next

    @body_next.setter
    def body_next(self, next: PlanBody):
        self._next = next

    def is_empty_body(self) -> bool:
        return self._term is None

    @property
    def body_type(self) -> BodyType:
        return self._form_type

    @body_type.setter
    def body_type(self, bt: BodyType):
        self._form_type = bt

    @property
    def body_term(self) -> Term | None:
        return self._term

    @body_term.setter
    def body_term(self, t: Term):
        self._term = t

    def get_head(self) -> PlanBody:
        return PlanBody(self.body_type, self.body_term)

    @property
    def is_body_term(self) -> bool:
        return self._is_term

    def is_atom(self) -> bool:
        return False

    @is_body_term.setter
    def is_body_term(self, b: bool):
        if b != self._is_term:
            self._is_term = b
            if self.body_next is not None:  # goes deep only if changed
                self.body_next.is_body_term = b

    def is_plan_body(self) -> bool:
        return True

    def __iter__(self) -> Iterator[PlanBody]:
        current = self
        while current is not None and current.body_term is not None:
            yield current
            current = current.body_next

    # Override some structure methods to work with unification/equals

    def get_arity(self) -> int:
        if self._term is None: return 0
        elif self._next is None: return 1
        else: return 2

    def get_term(self, i: int) -> Term | None:
        if i == 0: return self._term
        if i == 1: return self._next
        return None

    def get_terms(self) -> list[Term]:
        return [self.get_term(i) for i in range(self.get_arity())]

    def set_term(self, i: int, t: Term):
        if i == 0: self._term = t
        if i == 1:
            if self._next is not None and self._next.body_term.is_var() and self._next.body_next is None:
                self._next.body_term = t
            else:
                self._logger.warning("Should not set_term(1) of body literal!")

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        self._logger.warning("PlanBody cannot be used for logical consequence!")
        return iter(())

    def __eq__(self, o: object) -> bool:
        if o is None: return False
        if o is self: return True
        if isinstance(o, PlanBody):
            return self._form_type == o.body_type and super().__eq__(o)
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        return hash(self._form_type) + super().calc_hash_code()

    # ag: Java's add(PlanBody)/add(int,PlanBody) overloads merged into one optional-index method
    def add(self, a: PlanBody | int, b: PlanBody | object = _unset) -> bool:
        if b is _unset:
            # clone the plan body and add it in the end of this plan
            bl = a
            if bl is None:  # if bl is empty, do nothing
                return True
            if self._term is None:
                bl = bl.clone_pb()
                self._swap(bl)
                self._next = bl.body_next
            elif self._next is None:
                self._next = bl
            else:
                self._next.add(bl)
            return True
        else:
            index, bl = a, b
            if index == 0:
                newpb = PlanBody(self._form_type, self._term)
                newpb.body_next = self._next
                self._swap(bl)
                self._next = bl.body_next
                self.get_last_body().body_next = newpb
            elif self._next is not None:
                self._next.add(index - 1, bl)
            else:
                self._next = bl
            return True

    def get_last_body(self) -> PlanBody:
        if self._next is None:
            return self
        else:
            return self._next.get_last_body()

    def remove_body(self, index: int) -> Term | None:
        if index == 0:
            oldvalue = self._term
            if self._next is None:
                self._term = None  # becomes an empty
            else:
                self._swap(self._next)
                self._next = self._next.body_next
            return oldvalue
        else:
            return self._next.remove_body(index - 1)

    def get_plan_size(self) -> int:
        if self._term is None: return 0
        elif self._next is None: return 1
        else: return self._next.get_plan_size() + 1

    def _swap(self, bl: PlanBody):
        bt = self._form_type
        self._form_type = bl.body_type
        bl.body_type = bt

        t = self._term
        self._term = bl.body_term
        bl.body_term = t

    def resolve(self, u: Unifier) -> Term:
        if self._term is None:  # must copy c.is_term even if resolving an empty plan
            c = PlanBody()
            c._is_term = self._is_term
        else:
            ta = self._term.resolve(u)
            if ta.is_plan_body():
                c = PlanBody(ta.body_type, ta, self._is_term)
            else:
                c = PlanBody(self._form_type, ta, self._is_term)
            if c._term.is_plan_body():  # we cannot have "inner" body literals
                c._form_type = c._term.body_type
                c._next = c._term.body_next
                c._term = c._term.body_term

        if self._next is not None:
            nc = self._next.resolve(u)
            if not nc.is_empty_body():
                c.add(nc)

        return c

    def clone(self) -> PlanBody:
        if self._term is None:  # must copy c.is_term even if cloning an empty plan
            c = PlanBody()
        else:
            c = PlanBody(self._form_type, self._term.clone(), self._is_term)
        c._is_term = self._is_term
        if self._next is not None:
            c.body_next = self.body_next.clone_pb()
        return c

    def clone_pb(self) -> PlanBody:
        return self.clone()

    def __str__(self) -> str:
        if self._term is None:
            return "{ }" if self._is_term else ""
        out = []
        if self._is_term:
            out.append("{ ")
        pb = self
        while pb is not None:
            if pb.body_term is not None:
                out.append(str(pb.body_type))
                out.append(str(pb.body_term))
            pb = pb.body_next
            if pb is not None:
                out.append("; ")
        if self._is_term:
            out.append(" }")
        return "".join(out)
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.agent_source import AgentSource
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.literal_impl import LiteralImpl
from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.as_syntax.object_term import ObjectTerm
from icaros.as_syntax.predicate_indicator import PredicateIndicator
from icaros.as_syntax.rule import Rule
from icaros.as_syntax.string_term import StringTerm
from icaros.as_syntax.structure import Structure
from icaros.as_syntax.unnamed_var import UnnamedVar
from icaros.as_syntax.var_term import VarTerm

if TYPE_CHECKING:
    from pathlib import Path

    from icaros.as_syntax.logical_formula import LogicalFormula
    from icaros.as_syntax.number_term import NumberTerm
    from icaros.as_syntax.plan import Plan
    from icaros.as_syntax.plan_body import PlanBody
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.trigger import Trigger

# ag: Factory for objects used in the AgentSpeak syntax. A module of functions rather
# than a class (ASSyntax in Java is a static-method-only utility) -- see porting.md.

HARD_DEAD_LINE_STR = "hard_deadline"

_keywords: set[PredicateIndicator] = {
    PredicateIndicator.of("atomic", 0),
    PredicateIndicator.of("breakpoint", 0),
    PredicateIndicator.of("all_unifs", 0),
    PredicateIndicator.of("default", 0),
    PredicateIndicator.of("this_ns", 0),
    PredicateIndicator.of("source", 1),
    PredicateIndicator.of("self", 0),
    PredicateIndicator.of("percept", 0),
    PredicateIndicator.of("tell", 0),
    PredicateIndicator.of("untell", 0),
    PredicateIndicator.of("achieve", 0),
    PredicateIndicator.of("unachieve", 0),
    PredicateIndicator.of("askOne", 0),
    PredicateIndicator.of("askAll", 0),
    PredicateIndicator.of("askHow", 0),
    PredicateIndicator.of("tellHow", 0),
    PredicateIndicator.of("untellHow", 0),
}

def add_keyword(pi: PredicateIndicator):
    _keywords.add(pi)

def is_keyword(lit: Literal) -> bool:
    return lit.get_predicate_indicator() in _keywords


# ----
# ---- create_* functions
# ----

# ag: Java's createLiteral(String,Term...) / createLiteral(Atom,String,Term...)
# / createLiteral(boolean,String,Term...) / createLiteral(Atom,boolean,String,Term...)
# overloads collapsed into one function, disambiguated by the type of the leading
# positional argument(s).
def create_literal(a: str | Atom | bool, *rest: Term) -> Literal:
    if isinstance(a, str):
        functor = a
        return LiteralImpl(functor).add_terms(*rest)
    elif isinstance(a, bool):
        positive = a
        functor, *terms = rest
        return LiteralImpl(positive, functor).add_terms(*terms)
    else:
        namespace = a
        if rest and isinstance(rest[0], bool):
            positive, functor, *terms = rest
            return LiteralImpl(namespace, positive, functor).add_terms(*terms)
        else:
            functor, *terms = rest
            return LiteralImpl(namespace, Literal.l_pos, functor).add_terms(*terms)

def create_structure(functor: str, *terms: Term) -> Structure:
    return Structure(functor).add_terms(*terms)

_atom_cache: dict[str, Atom] = {}

def create_atom(functor: str) -> Atom:
    # ag: interning cache, mirrors Java's atomCache -- Atom is immutable so sharing
    # instances is safe and cheap.
    if functor not in _atom_cache:
        _atom_cache[functor] = Atom(functor)
    return _atom_cache[functor]

def create_number(vl: float) -> NumberTerm:
    return NumberTermImpl(vl)

# ag: Java's createString(String) / createString(Object) [uses .toString()] merged
def create_string(s: str | object) -> StringTerm:
    return StringTerm(s if isinstance(s, str) else str(s))

# ag: Java's createVar() [anonymous] / createVar(String) / createVar(Atom,String)
# / createVar(boolean,String) overloads collapsed here. Note the last form's `negated`
# arg is passed straight into set_negated(), which (faithfully to Java) actually sets
# the raw type value -- create_var(True, "X") produces a POSITIVE var. See
# LiteralImpl.set_negated and porting.md.
def create_var(a: str | Atom | bool | object = None, b: str | object = None) -> VarTerm:
    if a is None:
        return UnnamedVar()
    if isinstance(a, str):
        return VarTerm(a)
    if isinstance(a, bool):
        negated, functor = a, b
        v = VarTerm(functor)
        v.set_negated(negated)
        return v
    namespace, functor = a, b
    return VarTerm(namespace, functor)

# ag: Java also has createList(Collection<Term>) which clones each element -- dropped
# as a minor convenience overload; callers needing that can clone before spreading.
def create_list(*terms: Term) -> ListTerm:
    lt = ListTerm()
    lt.extend(terms)
    return lt

def create_rule(head: Literal, body: LogicalFormula) -> Rule:
    return Rule(head, body)


# ----
# ---- parse_* functions
# ----
# ag: each delegates to icaros.as_syntax.parser (a Lark grammar + transformer,
# see porting.md), mirroring ASSyntax.java's parseX methods 1:1. Imports are local
# to each function (not at module level) so building the 9 LALR parser tables --
# real, if small, work done at icaros.as_syntax.parser.entry_points import time --
# is only paid the first time a parse_* function is actually called, not by every
# caller of this module that only needs create_*/term_to_object.

def parse_literal(s_literal: str) -> Literal:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("literal", s_literal)

# ag: Java's parseNumber doesn't use the grammar at all (Double.parseDouble
# directly) -- neither does this. NumberTermImpl is float-only by construction,
# so there's no int/float decision to make here either. See porting.md.
def parse_number(s_number: str) -> NumberTerm:
    return NumberTermImpl(float(s_number.strip()))

def parse_structure(s_structure: str) -> Structure:
    from icaros.as_syntax.parser.entry_points import parse
    t = parse("term", s_structure)
    return t if isinstance(t, Structure) else Structure(t)

def parse_var(s_var: str) -> VarTerm:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("var", s_var)

def parse_term(s_term: str) -> Term:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("term", s_term)

def parse_plan(s_plan: str) -> Plan:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("plan", s_plan)

def parse_plan_body(s_plan_body: str) -> PlanBody:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("plan_body", s_plan_body)

def parse_trigger(s_te: str) -> Trigger:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("trigger", s_te)

def parse_list(s_list: str) -> ListTerm:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("list", s_list)

def parse_formula(s_expr: str) -> LogicalFormula:
    from icaros.as_syntax.parser.entry_points import parse
    return parse("formula", s_expr)

# ag: Java's ASSyntax.parseRule calls the shared belief() production (literal
# [":-" formula] ".") and does an unchecked cast to Rule, throwing a bare
# ClassCastException if the source had no ":-" clause. Replaced with a clear,
# documented error instead of faithfully reproducing an opaque CCE -- same policy
# as the MapTerm.equals fix elsewhere in this port. See porting.md.
def parse_rule(s_rule: str) -> Rule:
    from icaros.as_syntax.parser.entry_points import parse
    from icaros.as_syntax.parser.errors import ASParseError
    r = parse("rule_or_belief", s_rule)
    if not isinstance(r, Rule):
        raise ASParseError(f"'{s_rule}' is not a rule: expected 'head :- body.'")
    return r


def parse_agent(s_agent: str, *, base_dir: Path | None = None,
                source_name: str | None = None) -> AgentSource:
    """Parses a whole .asl file's text. `base_dir`, when given, is the
    directory `{include("...")}` directives resolve relative paths against
    (typically the .asl file's own directory) -- without it, an `include`
    directive is a clear ASParseError rather than a silent no-op, since a
    relative path has nothing to resolve against.

    `source_name`, when given (typically the .asl file's own path), names
    the file in any syntax-error message -- purely cosmetic, doesn't affect
    parsing.
    """
    from icaros.as_syntax.parser.entry_points import parse
    source = parse("agent", s_agent, source=source_name)
    return _resolve_includes(source, base_dir, frozenset())


def _resolve_includes(source: AgentSource, base_dir: Path | None, seen: frozenset[Path]) -> AgentSource:
    from icaros.as_syntax.parser.entry_points import parse
    from icaros.as_syntax.parser.errors import ASParseError

    included_beliefs: list = []
    included_goals: list = []
    included_plans: list = []
    remaining_directives: list = []

    for directive in source.directives:
        if directive.name != "include":
            # ag: Jason's other directives ({begin ns(...)}...{end}, etc.)
            # aren't ported (see porting.md) -- surfacing this loudly avoids
            # the false impression that an unrecognised directive quietly
            # did something.
            raise ASParseError(
                f"unsupported directive '{directive.name}(...)' -- only include(...) is implemented")
        if base_dir is None:
            raise ASParseError(
                "{include(...)} requires the agent to be loaded from a file (base_dir), not a bare string")
        if len(directive.args) != 1 or not directive.args[0].is_string():
            raise ASParseError(f"include(...) expects a single string argument, got {directive.args}")

        rel_path = directive.args[0].string
        include_path = (base_dir / rel_path).resolve()
        if include_path in seen:
            raise ASParseError(f"circular {{include(...)}} detected: '{include_path}'")
        if not include_path.is_file():
            raise ASParseError(f"included file not found: '{include_path}'")

        included_source = parse("agent", include_path.read_text(), source=str(include_path))
        included_source = _resolve_includes(included_source, include_path.parent, seen | {include_path})
        included_beliefs.extend(included_source.beliefs)
        included_goals.extend(included_source.initial_goals)
        included_plans.extend(included_source.plans)

    source.beliefs = included_beliefs + source.beliefs
    source.initial_goals = included_goals + source.initial_goals
    source.plans = included_plans + source.plans
    source.directives = remaining_directives
    return source


def term_to_object(t: Term) -> object:
    if t.is_atom():
        if t == Literal.l_true:
            return True
        elif t == Literal.l_false:
            return False
        else:
            return str(t)
    elif t.is_numeric():
        try:
            d = t.solve()
        except ValueError:
            d = 0
        # ag: Java picks the narrowest of byte/int/float/long that round-trips d;
        # Python has no equivalent fixed-width zoo, so just int-if-whole else float.
        return int(d) if d == int(d) else d
    elif t.is_string():
        return t.string
    elif t.is_list():
        return [term_to_object(t1) for t1 in t]
    elif isinstance(t, ObjectTerm):
        return t.value
    else:
        return str(t)

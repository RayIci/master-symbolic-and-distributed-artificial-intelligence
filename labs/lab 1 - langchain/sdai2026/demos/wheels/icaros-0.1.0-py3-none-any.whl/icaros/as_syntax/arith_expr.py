from __future__ import annotations

import math
from enum import Enum

from icaros.as_semantics.unifier import Unifier
from icaros.as_syntax.arith_function_term import ArithFunctionTerm
from icaros.as_syntax.atom import _unset
from icaros.as_syntax.number_term import NumberTerm
from icaros.as_syntax.term import Term
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.literal import Literal


class ArithmeticOp(Enum):
    NONE = "none"
    PLUS = "plus"
    MINUS = "minus"
    TIMES = "times"
    DIV = "div"
    MOD = "mod"
    POW = "pow"
    INTDIV = "intdiv"

    def eval(self, x: float, y: float) -> float:
        if self == ArithmeticOp.NONE: return 0
        if self == ArithmeticOp.PLUS: return x + y
        if self == ArithmeticOp.MINUS: return x - y
        if self == ArithmeticOp.TIMES: return x * y
        if self == ArithmeticOp.DIV: return x / y
        if self == ArithmeticOp.MOD: return math.fmod(x, y)  # ag: matches Java's % on doubles (sign follows dividend)
        if self == ArithmeticOp.POW: return x ** y
        if self == ArithmeticOp.INTDIV:
            # ag: Java's (int)x / (int)y truncates toward zero, unlike Python's // (floors)
            ix, iy = int(x), int(y)
            return float(int(ix / iy))
        raise ValueError(f"Unknown ArithmeticOp {self}")

    def __str__(self) -> str:
        return _ARITHMETIC_OP_STR[self]


_ARITHMETIC_OP_STR = {
    ArithmeticOp.NONE: "",
    ArithmeticOp.PLUS: "+",
    ArithmeticOp.MINUS: "-",
    ArithmeticOp.TIMES: "*",
    ArithmeticOp.DIV: "/",
    ArithmeticOp.MOD: " mod ",
    ArithmeticOp.POW: "**",
    ArithmeticOp.INTDIV: " div ",
}


class ArithExpr(ArithFunctionTerm, NumberTerm):

    def __init__(self, a: NumberTerm | ArithmeticOp | ArithExpr,
                 b: ArithmeticOp | NumberTerm | object = _unset, c: NumberTerm | object = _unset):
        # ag: Java's ArithExpr(NumberTerm,ArithmeticOp,NumberTerm) [binary]
        # / ArithExpr(ArithmeticOp,NumberTerm) [unary] / private ArithExpr(ArithExpr)
        # [clone-copy] overloads collapsed here.
        if c is not _unset:
            t1, oper, t2 = a, b, c
            super().__init__(str(oper))
            self.add_term(t1)
            self.add_term(t2)
            self._op = oper
            self.src_info = t1.src_info if t1.src_info is not None else t2.src_info
        elif b is not _unset:
            oper, t1 = a, b
            super().__init__(str(oper))
            self.add_term(t1)
            self._op = oper
            self.src_info = t1.src_info
        else:
            ae = a
            super().__init__(ae)  # clone args from ae
            self._op = ae._op

    def resolve(self, u: Unifier) -> Term:
        from icaros.as_syntax.number_term_impl import NumberTermImpl
        try:
            l_val = self.get_term(0).resolve(u).solve()
            if self.is_unary():
                if self._op == ArithmeticOp.MINUS:
                    self._value = NumberTermImpl(-l_val)
                else:
                    self._value = NumberTermImpl(l_val)
            else:
                r_val = self.get_term(1).resolve(u).solve()
                self._value = NumberTermImpl(self._op.eval(l_val, r_val))
            return self._value
        except AttributeError:
            # ag: Java's ClassCastException when the resolved term isn't a NumberTerm (no .solve())
            self._logger.warning(f"The value of {self} is not a number! Unifier = {u}. Code: {self.src_info}")
            return NumberTermImpl(float("nan"))
        except ValueError:
            return self.clone()  # ag: Java's NoValueException

    def check_arity(self, a: int) -> bool:
        return a == 1 or a == 2

    def clone(self) -> Term:
        return ArithExpr(self)

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return ArithExpr(self)

    @property
    def op(self) -> ArithmeticOp:
        return self._op

    @property
    def lhs(self) -> NumberTerm:
        return self.get_term(0)

    @property
    def rhs(self) -> NumberTerm:
        return self.get_term(1)

    def __str__(self) -> str:
        if self.is_unary():
            return f"({self._op}{self.get_term(0)})"
        else:
            return f"({self.get_term(0)}{self._op}{self.get_term(1)})"

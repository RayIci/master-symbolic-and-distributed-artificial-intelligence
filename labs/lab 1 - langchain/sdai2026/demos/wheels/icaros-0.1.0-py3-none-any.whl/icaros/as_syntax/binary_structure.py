from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.structure import Structure

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term

class BinaryStructure(Structure):

    def __init__(self, a: Term | str, b: str | Term, c: Term | object = _unset):
        # ag: Java's BinaryStructure(Term,String,Term) [binary op] / BinaryStructure(String,Term)
        # [unary op] overloads collapsed here.
        if c is not _unset:
            t1, id_, t2 = a, b, c
            super().__init__(id_)
            self.add_term(t1)
            self.add_term(t2)
            self.src_info = t1.src_info if t1.src_info is not None else t2.src_info
        else:
            id_, arg = a, b
            super().__init__(id_)
            self.add_term(arg)
            self.src_info = arg.src_info

    @property
    def lhs(self) -> Term:
        return self.get_term(0)

    @property
    def rhs(self) -> Term:
        return self.get_term(1)

    def __str__(self) -> str:
        if self.is_unary():
            return f"{self.functor}({self.get_term(0)})"
        else:
            return f"({self.get_term(0)}{self.functor}{self.get_term(1)})"

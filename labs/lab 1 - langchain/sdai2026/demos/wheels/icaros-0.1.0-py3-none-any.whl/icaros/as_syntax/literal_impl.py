from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom, _unset
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.pred import Pred
from icaros.as_syntax.predicate_indicator import PredicateIndicator

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term

class LiteralImpl(Pred):

    def __init__(self, a: bool | str | Atom | Literal, b=_unset, c=_unset):
        # ag: Java's LiteralImpl(String) / LiteralImpl(boolean,String) / LiteralImpl(Literal)
        # / LiteralImpl(boolean,Literal) / LiteralImpl(Atom,boolean,String)
        # / LiteralImpl(Atom,boolean,Literal) overloads collapsed here (same pattern as
        # Atom/Structure/Pred). The resolve-based copy constructor
        # (LiteralImpl(Literal,Unifier)) is exposed as LiteralImpl.from_resolve below.
        if c is not _unset:
            # LiteralImpl(ns, pos, functor_or_literal)
            ns, pos, functor_or_literal = a, b, c
            super().__init__(functor_or_literal, ns)
            self._type = pos
        elif b is not _unset:
            # LiteralImpl(pos, functor_or_literal)
            pos, functor_or_literal = a, b
            super().__init__(functor_or_literal)
            self._type = pos
        elif isinstance(a, str):
            # LiteralImpl(functor) -- positive
            super().__init__(a)
            self._type = Literal.l_pos
        else:
            # LiteralImpl(lit: Literal) -- copy, sign taken from lit
            lit = a
            super().__init__(lit)
            self._type = not lit.negated()

    @classmethod
    def from_resolve(cls, lit: Literal, u: Unifier) -> LiteralImpl:
        s = super().from_resolve(lit, u)
        s._type = not lit.negated()
        return s

    def is_atom(self) -> bool:
        return super().is_atom() and not self.negated()

    def can_be_added_in_bb(self) -> bool:
        return True

    def negated(self) -> bool:
        return self._type == Literal.l_neg

    # ag: despite the name, `b` here is the raw type value (Literal.l_pos/l_neg), not
    # "whether negated" -- set_negated(Literal.l_pos) makes the literal POSITIVE. Faithful
    # port of Java's `type = b` (LiteralImpl.setNegated); confusing but preserved as-is.
    def set_negated(self, b: bool) -> Literal:
        self._type = b
        return self

    def __eq__(self, o: object) -> bool:
        if o is None: return False
        if o is self: return True
        if isinstance(o, LiteralImpl):
            return self._type == o._type and hash(self) == hash(o) and super().__eq__(o)
        elif isinstance(o, Atom) and not self.negated():
            return super().__eq__(o)
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated;
                                      # always point at the one real implementation (see porting.md)

    def get_error_msg(self) -> str:
        src = "" if self.src_info is None else f" ({self.src_info})"
        return f"Error in '{self}'{src}"

    # ag: Java's compareTo override is commented out in LiteralImpl.java -- Atom's
    # __lt__ (already negation-aware) is inherited as-is.

    def clone(self) -> Term:
        return LiteralImpl(self)

    def resolve(self, u: Unifier) -> Term:
        return LiteralImpl.from_resolve(self, u)

    def clone_ns(self, new_namespace: Atom) -> Literal:
        return LiteralImpl(new_namespace, not self.negated(), self)

    def calc_hash_code(self) -> int:
        result = super().calc_hash_code()
        if self.negated():
            result += 3271
        return result

    def get_predicate_indicator(self) -> PredicateIndicator:
        functor = self.functor if self._type == Literal.l_pos else f"~{self.functor}"
        return PredicateIndicator(self.ns, functor, self.get_arity())

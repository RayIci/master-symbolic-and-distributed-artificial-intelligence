from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar, TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_syntax.atom import Atom


# ag: eq=False is required, not just a style choice -- SourceInfo currently has
# no __eq__ at all (plain identity equality), and a bare @dataclass(frozen=True)
# would silently add structural equality, which is a real behavior change.
@dataclass(frozen=True, eq=False)
class SourceInfo:
    source: str | None
    begin_src_line: int = 0
    end_src_line: int | None = None

    a_no_code: ClassVar[Atom | None] = None  # bootstrapped by atom.py: Atom("no_code")

    def __post_init__(self):
        if self.end_src_line is None:
            object.__setattr__(self, "end_src_line", self.begin_src_line)

    def clone(self) -> SourceInfo: return self

    @property
    def src_file(self) -> str | None: return self.source

    def __str__(self) -> str:
        file = self.source if self.source is not None else "nofile"
        return f"{file}:{self.begin_src_line}" if self.begin_src_line >= 0 else file
from __future__ import annotations

import logging
from collections import Counter
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.structure import Structure

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.list_term import ListTerm
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.var_term import VarTerm

class Pred(Structure):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, functor_or_literal: str | Literal, ns: Atom | None = None):
        # ag: Java's Pred(String) / Pred(Atom,String) / Pred(Literal) / Pred(Atom,Literal)
        # overloads collapsed here (same pattern as Atom/Structure). The resolve-based
        # copy constructor (Pred(Literal,Unifier)) is exposed as Pred.from_resolve below.
        # Java's Pred(String,int) capacity-preallocating overload is dropped, as in Structure.
        super().__init__(functor_or_literal, ns)
        self._annots: ListTerm | None = None
        if not isinstance(functor_or_literal, str):
            lit = functor_or_literal
            if lit.has_annot():
                self._annots = lit.annots.clone_lt()

    @classmethod
    def from_resolve(cls, lit: Literal, u: Unifier) -> Pred:
        s = super().from_resolve(lit, u)
        if lit.has_annot():
            s.set_annots(lit.annots.resolve(u))
        else:
            s._annots = None
        return s

    def is_pred(self) -> bool: return True

    def is_atom(self) -> bool:
        return super().is_atom() and not self.has_annot()

    def is_ground(self) -> bool:
        if self._annots is None:
            return super().is_ground()
        else:
            return super().is_ground() and self._annots.is_ground()

    def set_annots(self, annots: ListTerm | None) -> Literal:
        self._annots = None
        if annots is None:
            return self
        for lt in annots.list_term_iterator():
            if lt.get_term() is not None:
                self.add_annot(lt.get_term())  # use add_annot to sort them
            if lt.is_tail():
                if self._annots is None:
                    from icaros.as_syntax.list_term import ListTerm
                    self._annots = ListTerm()
                self._annots.set_tail(lt.get_tail())
        return self

    # ag: Comparable<T>.compareTo -> __eq__ + __lt__ (see porting.md). Java relied on
    # compareTo(null) == -1 to always insert before the sorted list's terminal (empty)
    # node; here that's an explicit `is None` check instead.
    def add_annot(self, t: Term) -> bool:
        if self._annots is None:
            from icaros.as_syntax.list_term import ListTerm
            self._annots = ListTerm()
        for lt in self._annots.list_term_iterator():
            node_term = lt.get_term()
            if node_term is None:
                lt.insert(t)  # terminal sentinel: always insert here if we got this far
                return True
            if t == node_term:
                return False  # duplicate
            if t < node_term:
                lt.insert(t)
                return True
        return False  # ag: only reached on an open (tail-var) list where the insertion point was never found

    # ag: Java's addAnnots(Term...)/addAnnots(List<Term>) overloads merged into one
    # variadic method (matches the same merge already made on Literal.add_annots)
    def add_annots(self, *annots: Term) -> Literal:
        for t in annots:
            self.add_annot(t)
        return self

    def del_annot(self, t: Term) -> bool:
        if self._annots is None:
            return False
        else:
            return self._annots.remove(t)  # TODO: use the sorted annots to reduce search (as in add_annot)

    def clear_annots(self) -> Literal:
        self._annots = None
        return self

    @property
    def annots(self) -> ListTerm | None:
        return self._annots

    def resolve_annots(self, u: Unifier) -> ListTerm:
        if self.has_annot():
            o = Pred("t")  # use this simple literal so that we do not need to clone all "this" to get resolved annots
            o.set_annots(self.annots.resolve(u))
            return o.annots
        else:
            from icaros.as_syntax.list_term import ListTerm
            return ListTerm()

    # ag: Java's hasAnnot(Term)/hasAnnot() overloads merged into one optional-arg method
    def has_annot(self, t: Term | None = None) -> bool:
        if t is None:
            return self._annots is not None and not self._annots.is_empty()
        if self._annots is None:
            return False
        # annots are ordered
        for lt in self._annots.list_term_iterator():
            node_term = lt.get_term()
            if node_term is None or t < node_term:
                return False
            if t == node_term:
                return True
        return False

    def get_annot(self, functor: str) -> Literal | None:
        if self._annots is None:
            return None
        for t in self._annots:
            if t.is_literal():
                if functor == t.functor:
                    return t
                elif functor < t.functor:
                    return None
        return None

    def has_var(self, t: VarTerm, u: Unifier) -> bool:
        return super().has_var(t, u) or (
            self._annots is not None and any(v.has_var(t, u) for v in self._annots)
        )

    def count_vars(self) -> Counter:
        c = super().count_vars()
        if self._annots is not None:
            for t in self._annots:
                c.update(t.count_vars())
        return c

    def import_annots(self, p: Literal) -> bool:
        imported = False
        if p.has_annot():
            kept = []
            for t in list(p.annots):
                if self.add_annot(t.clone()):
                    imported = True
                    kept.append(t)
            # p will only contain the annots actually added (for Event)
            p.clear_annots()
            p.add_annots(*kept)
        return imported

    # ag: Java's delAnnots(List<Term>)/delAnnots() overloads merged into one optional-arg
    # method; note Java's Pred does NOT override the no-arg case either, only List<Term>
    def del_annots(self, annots: list[Term] | None = None) -> bool:
        if annots is None:
            return super().del_annots()
        removed = False
        if annots and self.has_annot():
            for t in annots:
                r = self.del_annot(t)
                removed = removed or r
        return removed

    # ag: renamed from getAnnots(String) to avoid a name clash with the no-arg get_annots()
    def get_annots_by_functor(self, functor: str) -> ListTerm:
        from icaros.as_syntax.list_term import ListTerm
        ls = ListTerm()
        if self._annots is not None:
            ls.extend(ta for ta in self._annots if ta.is_literal() and ta.functor == functor)
        return ls

    # ag: Java's hasSubsetAnnot(Literal)/hasSubsetAnnot(Literal,Unifier) merged into one
    # optional-arg method
    def has_subset_annot(self, p: Literal, u: Unifier | None = None) -> bool:
        if u is None:
            return self._has_subset_annot_no_unifier(p)

        if not self.has_annot():
            return True
        if not p.has_annot():
            # the special case of a[|T]=a
            if self._annots.get_term() is None and self._annots.is_tail():
                from icaros.as_syntax.list_term import ListTerm
                return u.unifies_no_undo(self._annots.get_tail(), ListTerm.EMPTY_LIST)
            else:
                return False

        this_tail: VarTerm | None = None

        # since p's annots will be changed, work on a value-level (shallow) copy
        p_annots_items: list[Term] = list(p.annots)

        # the vars in p annots
        vars_in_p_annots = [ta for ta in p_annots_items if ta.is_var()]
        i_vars_in_p_annots = iter(vars_in_p_annots)

        p_tail = p.annots.get_tail()
        p_annot: Term | None = None
        p_annots_tail: ListTerm | None = None

        idx = 0  # cursor mirroring Java's Iterator<Term> i2 over p_annots_items
        i2_reset = False

        for lt in self.resolve_annots(u).list_term_iterator():
            annot = lt.get_term()
            if lt.is_tail():
                this_tail = lt.get_tail()
            if annot is None:
                break
            if annot.is_var() and not i2_reset:
                # when we arrive to the vars in the annots of "this", we need to start
                # searching from the begin again
                i2_reset = True
                idx = 0
                p_annot = None

            # search annot in p's annots
            ok = False
            while True:
                if p_annot is not None and u.unifies_no_undo(annot, p_annot):
                    ok = True
                    del p_annots_items[idx - 1]  # i2.remove()
                    idx -= 1
                    # pAnnot = i2.next() -- Java's ListTermImpl iterator returns null
                    # (not an exception) when exhausted, so mirror that with None
                    if idx < len(p_annots_items):
                        p_annot = p_annots_items[idx]
                        idx += 1
                    else:
                        p_annot = None
                    break
                elif p_annot is not None and p_annot > annot:
                    # consider to consume a var from p annots
                    if (v := next(i_vars_in_p_annots, None)) is not None:
                        if u.unifies_no_undo(annot, v):
                            ok = True
                            # ag: Java leaves the matched var in p_annots_items too
                            # ("Amandine bug" case, TermTest) -- do not remove it here
                    break  # quit the loop: current p annot is greater than this annot
                elif idx < len(p_annots_items):
                    p_annot = p_annots_items[idx]
                    idx += 1
                else:
                    break

            # if p has a tail, add annot in p's tail
            if not ok and p_tail is not None:
                if p_annots_tail is None:
                    p_annots_tail = u.get(p_tail)
                    if p_annots_tail is None:
                        from icaros.as_syntax.list_term import ListTerm
                        p_annots_tail = ListTerm()
                        u.unifies(p_tail, p_annots_tail)
                        p_annots_tail = u.get(p_tail)
                p_annots_tail.append(annot.clone())
                ok = True
            if not ok:
                return False

        # if this Pred has a Tail, unify it with p remaining annots
        if this_tail is not None:
            from icaros.as_syntax.list_term import ListTerm
            u.unifies(this_tail, ListTerm(p_annots_items))

        return True

    def _has_subset_annot_no_unifier(self, p: Literal) -> bool:
        if not self.has_annot(): return True
        if not p.has_annot(): return False

        # both have annots (annots are ordered)
        _missing = object()
        i2 = iter(p.annots)
        for my_annot in self._annots:
            # move i2 until it is >= my_annot
            t = next(i2, _missing)
            if t is _missing:
                return False
            equal = False
            while t is not _missing:
                if my_annot <= t:  # found my annot in p's annots OR my annot is not in p's annots
                    equal = (my_annot == t)
                    break
                t = next(i2, _missing)
            if not equal:
                return False
        return True

    def add_source(self, ag_name: Term) -> Literal:
        if ag_name is not None:
            self.add_annot(Pred.create_source(ag_name))
        return self

    def del_source(self, ag_name: Term) -> bool:
        if self._annots is not None:
            return self.del_annot(Pred.create_source(ag_name))
        else:
            return False

    @staticmethod
    def create_source(source: Term) -> Pred:
        if source.is_ground():
            s = _GroundSourcePred("source")
        else:  # source is a var, so cannot be optimised
            s = Pred("source")
        s.add_term(source)
        return s

    def get_sources(self) -> ListTerm:
        from icaros.as_syntax.list_term import ListTerm
        ls = ListTerm()
        if self._annots is not None:
            ls.extend(ta.get_term(0) for ta in self._annots if ta.is_structure() and ta.functor == "source")
        return ls

    def del_sources(self):
        if self._annots is not None:
            to_remove = [t for t in self._annots if t.is_structure() and t.functor == "source"]
            for t in to_remove:
                self.del_annot(t)

    # ag: Java's hasSource()/hasSource(Term) overloads merged into one optional-arg method
    def has_source(self, ag_name: Term | None = None) -> bool:
        if ag_name is not None:
            if self._annots is not None:
                return self.has_annot(Pred.create_source(ag_name))
            return False
        return self._annots is not None and any(
            ta.is_structure() and ta.functor == "source" for ta in self._annots
        )

    def make_vars_annon(self, un: Unifier | None = None) -> Literal:
        if un is None:
            from icaros.as_semantics.unifier import Unifier
            un = Unifier()
        if self._annots is not None:
            lt = self._annots
            while not lt.is_empty():
                if (ta := lt.get_term()) is not None:
                    if ta.is_var():
                        lt.set_term(self.var_to_replace(ta, un))
                    elif isinstance(ta, Structure):
                        ta.make_vars_annon(un)
                if lt.is_tail() and lt.get_next().is_var():
                    lt.set_next(self.var_to_replace(lt.get_next(), un))
                    break
                lt = lt.get_next()
        return super().make_vars_annon(un)

    def __eq__(self, o: object) -> bool:
        if o is None: return False
        if o is self: return True
        if isinstance(o, Pred):
            return super().__eq__(o) and self.has_subset_annot(o) and o.has_subset_annot(self)
        elif isinstance(o, Atom) and not self.has_annot():
            # if o is some object that extends Atom (e.g. structure), goes to super equals
            # -- consider super equals only when this has no annots
            return super().__eq__(o)
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated;
                                      # always point at the one real implementation (see porting.md)

    def equals_as_structure(self, p: object) -> bool:
        # ag: Java comment -- "this method must be in this class, do not move (I do not remember why!)"
        return super().__eq__(p)

    def resolve(self, u: Unifier) -> Term:
        return Pred.from_resolve(self, u)

    def clone(self) -> Term:
        return Pred(self)

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return Pred(self, newnamespace)


class _GroundSourcePred(Pred):
    # ag: mirrors the anonymous Pred subclass Java creates in Pred.createSource when
    # the source term is ground -- avoids re-checking groundness/re-cloning since a
    # ground source(X) annotation never needs to change.
    def clone(self) -> Term: return self
    def resolve(self, u: Unifier) -> Term: return self
    def is_ground(self) -> bool: return True
    def make_vars_annon(self, un: Unifier | None = None) -> Literal: return self

from __future__ import annotations

import itertools
import logging
from collections.abc import Iterable, Iterator
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.structure import Structure
from icaros.as_syntax.term import Term

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.var_term import VarTerm

LIST_FUNCTOR = "."

# ag: Java's ListTerm interface and ListTermImpl merged into a single class: once
# VarTerm dropped its dead-stub term-type interfaces (see var_term.py) ListTermImpl
# was the only implementer left, so the abstract layer was pure ceremony in Python.
# Java's ListTerm also extends java.util.List<Term> — the plain-list surface
# (__iter__, __len__, ...) is provided directly here.
#
# Represents a list node as in prolog .(t1,.(t2,.(t3,.))). Each cell has both a
# term and the next cell; the last cell is an empty one (term is None). A list with
# a tail ([a|X]) has next==X (a VarTerm), term==a.
class ListTerm(Structure):

    EMPTY_LIST: ListTerm | None = None  # bootstrapped right after the class definition

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, t: Term | Iterable[Term] | None = None, n: Term | object = _unset):
        # ag: Java's ListTermImpl() / private ListTermImpl(Term,Term) collapsed here
        # (the 2-arg form is used internally, see insert()/reverse() below). As a
        # pythonic addition (not part of Java's constructor set, whose callers use
        # append()/extend() instead) a single iterable of terms builds a full list.
        super().__init__(LIST_FUNCTOR)
        if n is not _unset or t is None or not isinstance(t, (list, tuple, set, frozenset)):
            self._term = t
            self._next = n if n is not _unset else None
        else:
            self._term = None
            self._next = None
            self.extend(t)

    # ag: Java's ListTerm.getTerm(i)/Literal.getTerm(i) (indexed "unifier compatibility"
    # view, i in {0,1} -> term/next) and ListTerm.getTerm() (no-arg cons-cell accessor)
    # share the name "getTerm" in Java only because Java resolves overloads by arity.
    # Merged here via an optional index: no index -> this cell's term (as pred.py's
    # extensive get_term()/set_term() usage on annot lists already assumes); index
    # given -> the arity-2 structural view Structure's generic term-tree-walking
    # methods (has_var, count_vars, make_vars_annon, subsumes) rely on.
    def get_term(self, i: int | object = _unset) -> Term | None:
        if i is _unset:
            return self._term
        if i == 0: return self._term
        if i == 1: return self._next
        return None

    def set_term(self, a, b: object = _unset):
        if b is _unset:
            self._term = a
        else:
            i, t = a, b
            if i == 0: self._term = t
            elif i == 1: self._next = t

    def set_next(self, t: Term):
        self._next = t

    def get_next(self) -> ListTerm | None:
        if isinstance(self._next, ListTerm):
            return self._next
        else:
            return None

    def get_arity(self) -> int:
        return 0 if self.is_empty() else 2  # for unifier compatibility: term and next

    def get_terms(self) -> list[Term]:
        self._logger.warning("Do not use get_terms in lists!")
        items = []
        if self._term is not None: items.append(self._term)
        if self._next is not None: items.append(self._next)
        return items

    def add_term(self, t: Term):
        self._logger.warning("Do not use add_term in lists! Use append(Term).")

    def clone(self) -> ListTerm:
        # ag: iterative (textbook linked-list clone) instead of recursive --
        # a recursive version blows Python's ~1000-frame stack on long lists;
        # see porting.md's list-literal cap note.
        head = ListTerm()
        dst = head
        src = self
        while True:
            dst._term = src._term.clone() if src._term is not None else None
            nxt = src._next
            if isinstance(nxt, ListTerm):
                dst._next = ListTerm()
                dst = dst._next
                src = nxt
                continue
            dst._next = nxt.clone() if nxt is not None else None
            return head

    def clone_lt(self) -> ListTerm:
        return self.clone()

    def clone_lt_shallow(self) -> ListTerm:
        t = ListTerm()
        if self._term is not None: t._term = self._term
        if self._next is not None: t._next = self._next.clone()
        return t

    def resolve(self, u: Unifier) -> Term:
        # ag: iterative, same reasoning as clone() above -- resolve() runs on
        # every unification of a bound list variable, so this is likely the
        # hottest of the cons-cell walks.
        head = ListTerm()
        dst = head
        src = self
        while True:
            if src._term is not None:
                dst._term = src._term.resolve(u)
            nxt = src._next
            if nxt is None:
                break
            if isinstance(nxt, ListTerm):
                dst._next = ListTerm()
                dst, src = dst._next, nxt
                continue
            dst._next = nxt.resolve(u)
            break
        # ag: the `[|T]` collapse (a headless cell resolving to exactly its
        # tail's resolution, unwrapped) can only ever be relevant for `self`
        # itself, never a cell reached mid-chain: a cell with _term is None
        # while _next is not None only exists as the result of set_tail()
        # being called on an originally-empty ListTerm() -- i.e. the whole
        # expression was `[|T]` -- since set_tail() on a longer list instead
        # rewrites the *last real* cell's _next in place (that cell already
        # has a term), never inserting a fresh headless cell after it.
        if self._term is None and head._next is not None and head._next.is_list():
            return head._next
        return head

    def __eq__(self, t: object) -> bool:
        if t is None: return False
        if t is self: return True
        if isinstance(t, Term) and t.is_var(): return False  # unground var is not equals a list
        if not isinstance(t, ListTerm):
            return False
        a, b = self, t
        while True:
            if a._term is None and b.get_term() is not None: return False
            if a._term is not None and a._term != b.get_term(): return False
            if a._next is None and b.get_next() is not None: return False
            if a._next is None:
                return True
            nxt_a = a._next
            if isinstance(nxt_a, ListTerm):
                nxt_b = b.get_next()
                if nxt_b is None:
                    return False
                a, b = nxt_a, nxt_b
                continue
            return nxt_a == b.get_next()

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        code = 0
        node = self
        while True:
            code += 37
            if node._term is not None:
                code += hash(node._term)
            nxt = node._next
            if nxt is None:
                return code
            if isinstance(nxt, ListTerm):
                node = nxt
                continue
            return code + hash(nxt)

    def __lt__(self, o: Term) -> bool:
        from icaros.as_syntax.var_term import sorts_after_var
        if sorts_after_var(o):
            return True
        if o.is_numeric() or o.is_string():
            return False
        return super().__lt__(o)

    def size(self) -> int:
        n = 0
        node = self
        while True:
            if node.is_empty():
                return n
            if node.is_tail():
                return n + 1
            n += 1
            node = node.get_next()

    def __len__(self) -> int:
        return self.size()

    def is_atom(self) -> bool: return False
    def is_list(self) -> bool: return True
    def is_literal(self) -> bool: return False

    def is_empty(self) -> bool:
        return self._term is None and self._next is None

    def is_end(self) -> bool:
        return self.is_empty() or self.is_tail()

    def is_ground(self) -> bool:
        node = self
        while True:
            if node.is_empty():
                return True
            if node.is_tail():
                return False
            if node._term is not None and node._term.is_ground():
                node = node.get_next()
                continue
            return False

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        self._logger.warning("ListTerm cannot be used for logical consequence!")
        return iter(())

    def is_tail(self) -> bool:
        return self._next is not None and self._next.is_var()

    def get_tail(self) -> VarTerm | None:
        node = self
        while True:
            if node.is_tail():
                return node._next
            if node._next is None:
                return None
            node = node.get_next()

    def set_tail(self, v: VarTerm):
        node = self
        while True:
            if node._next is None:
                node._next = v
                return
            nxt = node.get_next()
            if nxt.is_empty():
                node._next = v
                return
            node = nxt

    def get_last(self) -> ListTerm:
        r = self
        while not r.is_end() and r.get_next() is not None:
            r = r.get_next()
        return r

    def get_penultimate(self) -> ListTerm | None:
        node = self
        while True:
            if node.get_next() is None:
                return None
            if node.is_tail():
                return node
            if node.get_next().is_end() and not node.get_next().is_tail():
                return node
            node = node.get_next()

    def remove_last(self) -> Term | None:
        if (p := self.get_penultimate()) is not None:
            b = p.get_term()
            p.set_term(None)
            p.set_next(None)
            return b
        else:
            return None

    def append(self, t: Term) -> ListTerm | None:
        # ag: iterative -- a recursive version recurses once per existing
        # element, so calling this in a loop (extend()'s old strategy) was
        # O(n) stack depth for the n-th call. Returns the original list head
        # (self) rather than the newly-filled cell the old recursive version
        # returned -- verified nothing in the codebase used that return value.
        node = self
        while not node.is_empty():
            if node.is_tail():
                return None  # ag: matches Java's "What to do?" -- appending past an open tail is a no-op
            node = node.get_next()
        node._term = t
        node._next = ListTerm()
        return self

    def insert(self, t: Term) -> ListTerm:
        n = ListTerm(self._term, self._next)
        self._term = t
        self._next = n
        return n

    def concat(self, lt: ListTerm) -> ListTerm:
        node = self
        while True:
            if node.is_empty():
                node._set_values_from(lt)
                break
            if node._next.is_empty():
                node._next = lt
                break
            node = node._next
        return lt.get_last()

    def _set_values_from(self, lt: ListTerm):
        self._term = lt.get_term()
        self._next = lt.get_next()

    def reverse(self) -> ListTerm:
        return self._reverse_internal(ListTerm())

    def _reverse_internal(self, r: ListTerm) -> ListTerm:
        node = self
        while True:
            if node.is_empty():
                return r
            if node.is_tail():
                r = ListTerm(node._term.clone(), r)
                r.set_tail(node._next.clone())
                return r
            r = ListTerm(node._term.clone(), r)
            node = node.get_next()

    def union(self, lt: ListTerm) -> ListTerm:
        return self._set_to_list(sorted(set(self) | set(lt)))

    def intersection(self, lt: ListTerm) -> ListTerm:
        return self._set_to_list(sorted(set(lt) & set(self)))

    def difference(self, lt: ListTerm) -> ListTerm:
        return self._set_to_list(sorted(set(self) - set(lt)))

    def _set_to_list(self, items: list[Term]) -> ListTerm:
        result = ListTerm()
        result.extend(t.clone() for t in items)
        return result

    def sub_sets(self, k: int) -> Iterator[tuple[Term, ...]]:
        # ag: Java hand-rolls a DFS iterator for "all k-element subsets of this list";
        # itertools.combinations already does exactly this (and preserves each
        # combination's relative order, matching Java's DFS) -- backtracking order
        # doesn't need to match Java's exactly, only the enumerated set of subsets does.
        return itertools.combinations(self.get_as_list(), k)

    def list_term_iterator(self) -> Iterator[ListTerm]:
        # gives an iterator that includes the final empty list or tail: for [a,b,c]
        # yields [a,b,c]; [b,c]; [c]; []. For [a,b|T] yields [a,b|T]; [b|T]; [b|T]; T
        # is NOT yielded (get_next() returns None once next is a bare var).
        node = self
        while node is not None:
            yield node
            node = node.get_next()

    def __iter__(self) -> Iterator[Term]:
        # returns each Term of this list, the tail (if any) is not considered.
        # for [a,b,c] yields a, b, c. For [a,b|T] yields a, b.
        node = self
        while node is not None and node.get_term() is not None and node.is_list():
            yield node.get_term()
            node = node.get_next()

    def get_as_list(self) -> list[Term]:
        return list(self)

    def extend(self, items: Iterable[Term]):
        for t in items:
            self.append(t)

    def remove(self, o: object) -> bool:
        node = self
        while True:
            if node._term is not None and node._term == o:
                if node.get_next() is not None:
                    node._set_values_from(node.get_next())
                else:
                    node.clear()
                return True
            nxt = node.get_next()
            if nxt is None:
                return False
            node = nxt

    def clear(self):
        self._term = None
        self._next = None

    def __str__(self) -> str:
        s = ["["]
        cur = self
        while not cur.is_empty():
            if cur.get_term() is not None:
                s.append(str(cur.get_term()))
            if cur.is_tail():
                break
            cur = cur.get_next()
            if cur is None:
                break
            if not cur.is_empty():
                s.append(",")
        if cur.is_tail():
            s.append("|")
            s.append(str(cur.get_tail()))
        s.append("]")
        return "".join(s)


ListTerm.EMPTY_LIST = ListTerm()
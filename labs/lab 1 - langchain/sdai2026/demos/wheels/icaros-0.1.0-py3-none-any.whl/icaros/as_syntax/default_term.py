from __future__ import annotations

import logging
from abc import abstractmethod
from collections import Counter
from typing import TYPE_CHECKING

from icaros.as_syntax.term import Term

if TYPE_CHECKING:
    # ag: annotation-only in this file (from __future__ import annotations makes these
    # strings) -- real top-level imports here would be circular (Unifier -> CyclicTerm
    # -> DefaultTerm, VarTerm -> LiteralImpl -> Pred -> Structure -> Atom -> Literal ->
    # DefaultTerm), see porting.md's "real circular imports" convention.
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.source_info import SourceInfo
    from icaros.as_syntax.var_term import VarTerm


class DefaultTerm(Term):

    _logger: logging.Logger = logging.getLogger(__name__)
    l_pos: bool = True
    l_neg: bool = False
    _src_info: SourceInfo | None = None

    def is_var(self): return False
    def is_unnamed_var(self): return False
    def is_literal(self): return False
    def is_rule(self): return False
    def is_list(self): return False
    def is_set(self): return False
    def is_map(self): return False
    def is_queue(self): return False
    def is_string(self): return False
    def is_internal_action(self): return False
    def is_arith_expr(self): return False
    def is_numeric(self): return False
    def is_pred(self): return False
    def is_ground(self): return True
    def is_structure(self): return False
    def is_atom(self): return False
    def is_plan_body(self): return False
    def is_cyclic_term(self): return False

    @property
    def cyclic_var(self) -> VarTerm | None: return None

    def has_var(self, t: VarTerm, u: Unifier): return False

    # ag: Java's countVars(Map<VarTerm,Integer>) mutated a passed-in map; ported as a
    # method that returns a fresh Counter instead, to avoid a hidden-mutation API
    def count_vars(self) -> Counter: return Counter()

    @abstractmethod
    def clone(self) -> Term: ...
    @abstractmethod
    def calc_hash_code(self) -> int: ...

    # ag: no cache -- see porting.md ("manual cache+invalidation" convention).
    # __hash__ must stay consistent with __eq__ wherever a subclass overrides equality.
    def __hash__(self) -> int:
        return self.calc_hash_code()

    # ag: Comparable<T>.compareTo -> __eq__ + __lt__ (see porting.md). This base
    # fallback is used by terms with no richer ordering (Atom provides the real one).
    def __lt__(self, other: Term) -> bool:
        return str(self) < str(other)

    def subsumes(self, t: Term) -> bool:
        return not t.is_var()

    # ag: Java's capply(Unifier), renamed -- "clone with unifier substitutions applied".
    # Kept distinct from clone() because it diverges meaningfully in VarTerm (resolves
    # the variable to its bound value) and Structure (resolves each subterm recursively).
    def resolve(self, u: Unifier) -> Term:
        return self.clone()

    def clone_ns(self, new_namespace: Atom) -> Term:
        return self.clone()

    @property
    def src_info(self) -> SourceInfo | None: return self._src_info
    @src_info.setter
    def src_info(self, s: SourceInfo | None): self._src_info = s

    def get_error_msg(self) -> str:
        return "" if self._src_info is None else str(self._src_info)

    # ag: no term class defined __repr__, so any container of terms (a list, a
    # dict key/value, an assertion diff) printed Python object addresses --
    # Unifier.__str__'s str(self._function) on a dict[VarTerm, Term] being the
    # worst offender, since dict repr always calls repr() on its elements.
    # Dispatches to whatever __str__ the concrete subclass defines.
    def __repr__(self) -> str:
        return str(self)

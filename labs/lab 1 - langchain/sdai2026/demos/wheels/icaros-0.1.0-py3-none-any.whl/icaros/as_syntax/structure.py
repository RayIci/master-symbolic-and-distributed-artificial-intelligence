from __future__ import annotations

import logging
from collections import Counter
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.var_term import VarTerm

class Structure(Atom):

    _logger: logging.Logger = logging.getLogger(__name__)

    # ag: TODO: wire to real Config (Java: Config.get().getBoolean(Config.SHORT_UNNAMED_VARS))
    # once a Config equivalent exists in icaros -- out of scope for this pass
    use_short_unnamed_vars: bool = False

    def __init__(self, functor_or_literal: str | Literal, ns: Atom | None = None):
        # ag: Java's Structure(String) / Structure(Atom,String) / Structure(Literal)
        # / Structure(Atom,Literal) overloads collapsed here. The resolve-based copy
        # constructor (Structure(Literal,Unifier)) is exposed as Structure.from_resolve
        # below. Java's Structure(String,int) capacity-preallocating overload is
        # dropped -- Python lists don't need/benefit from capacity hints.
        from icaros.as_syntax.atom import _unset
        super().__init__(functor_or_literal, ns if ns is not None else _unset)
        self._terms: list[Term] | None = None
        if not isinstance(functor_or_literal, str):
            lit = functor_or_literal
            tss = lit.get_arity()
            if tss > 0:
                self._terms = [lit.get_term(i).clone() for i in range(tss)]

    @classmethod
    def from_resolve(cls, lit: Literal, u: Unifier) -> Structure:
        s = cls.__new__(cls)
        Atom.__init__(s, lit, lit.ns.resolve(u))
        tss = lit.get_arity()
        s._terms = [lit.get_term(i).resolve(u) for i in range(tss)] if tss > 0 else None
        return s

    def calc_hash_code(self) -> int:
        ts = self.get_arity()
        return super().calc_hash_code() + sum((i + 7) * hash(self.get_term(i)) for i in range(ts))

    def __eq__(self, t: object) -> bool:
        if t is None: return False
        if t is self: return True
        if isinstance(t, Structure):
            if t.is_var():
                return t == self
            ts = self.get_arity()
            if ts != t.get_arity(): return False
            if self.functor != t.functor: return False
            if self.ns != t.ns: return False
            return all(self.get_term(i) == t.get_term(i) for i in range(ts))
        if isinstance(t, Atom) and self.is_atom():
            return super().__eq__(t)
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated;
                                      # always point at the one real implementation (see porting.md)

    # ag: Java's compareTo override is commented out in Structure.java -- Atom's
    # __lt__ (which already dispatches on getTerm/getArity polymorphically) is
    # inherited as-is.

    def subsumes(self, t: Term) -> bool:
        if t.is_structure():
            ma = self.get_arity()
            oa = t.get_arity()
            return all(self.get_term(i).subsumes(t.get_term(i)) for i in range(min(ma, oa)))
        else:
            return super().subsumes(t)

    def resolve(self, u: Unifier) -> Term:
        return Structure.from_resolve(self, u)

    def clone(self) -> Term:
        return Structure(self)

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return Structure(self, newnamespace)

    def add_term(self, t: Term):
        if t is None: return
        if self._terms is None: self._terms = []
        self._terms.append(t)

    def del_term(self, index: int):
        if self._terms is None: return
        del self._terms[index]

    # ag: Java's addTerms(Term...)/addTerms(List<Term>) overloads merged into one
    # variadic method (matches the same merge already made on Literal.add_terms)
    def add_terms(self, *ts: Term) -> Literal:
        if self._terms is None: self._terms = []
        self._terms.extend(ts)
        return self

    def set_terms(self, terms: list[Term]) -> Literal:
        self._terms = terms
        return self

    def set_term(self, i: int, t: Term):
        if self._terms is None: self._terms = []
        self._terms[i] = t

    def get_term(self, i: int) -> Term | None:
        return None if self._terms is None else self._terms[i]

    def get_arity(self) -> int:
        return 0 if self._terms is None else len(self._terms)

    def get_terms(self) -> list[Term] | None:
        return self._terms

    def has_term(self) -> bool:
        return self.get_arity() > 0  # should use get_arity to work for list

    def is_structure(self) -> bool: return True
    def is_atom(self) -> bool: return not self.has_term()

    def is_ground(self) -> bool:
        return all(self.get_term(i).is_ground() for i in range(self.get_arity()))

    def is_unary(self) -> bool:
        return self.get_arity() == 1

    def make_vars_annon(self, un: Unifier | None = None) -> Literal:
        if un is None:
            from icaros.as_semantics.unifier import Unifier
            un = Unifier()
        size = self.get_arity()
        for i in range(size):
            ti = self.get_term(i)
            if ti.is_var():
                self.set_term(i, self.var_to_replace(ti, un))
            elif isinstance(ti, Structure):
                ti.make_vars_annon(un)
        return self

    def var_to_replace(self, t: Term, un: Unifier) -> VarTerm:
        from icaros.as_syntax.unnamed_var import UnnamedVar
        vt = t
        deref = un.deref(vt)

        # if the variable hasn't been renamed given the input unifier, then rename it.
        if deref == vt:
            ns = vt.ns
            if ns.is_var():
                ns = self.var_to_replace(ns, un)
            var = UnnamedVar(ns) if Structure.use_short_unnamed_vars else UnnamedVar.create(ns, str(t))

            if deref.has_annot():
                var.set_annots(deref.annots.clone_lt())
                var.make_vars_annon(un)
            un.bind(deref, var)
            return var
        else:
            # otherwise it has already been renamed in this scope so return the
            # existing renaming
            ns = vt.ns
            if ns.is_var():
                ns = self.var_to_replace(ns, un)
            deref = deref.clone_ns(ns)
            if vt.has_annot() and not deref.has_annot():
                deref.set_annots(vt.annots.clone_lt())
                deref.make_vars_annon(un)
            return deref

    def make_terms_annon(self):
        from icaros.as_syntax.unnamed_var import UnnamedVar
        size = self.get_arity()
        for i in range(size):
            self.set_term(i, UnnamedVar())

    def has_var(self, t: VarTerm, u: Unifier) -> bool:
        return any(self.get_term(i).has_var(t, u) for i in range(self.get_arity()))

    def get_singleton_vars(self) -> list[VarTerm]:
        all_vars = self.count_vars()
        return [k for k, v in all_vars.items() if v == 1 and not k.is_unnamed_var()]

    def count_vars(self) -> Counter:
        c = Counter()
        size = self.get_arity()
        for i in range(size):
            c.update(self.get_term(i).count_vars())
        return c

    def __str__(self) -> str:
        s = []
        if self.ns != Literal.default_ns:
            s.append(str(self.ns))
            s.append("::")
        if self.negated():
            s.append("~")
        if self.functor is not None:
            s.append(self.functor)
        if self.get_arity() > 0:
            s.append("(")
            s.append(",".join(str(t) for t in self._terms))
            s.append(")")
        if self.has_annot():
            s.append(str(self.annots))
        return "".join(s)

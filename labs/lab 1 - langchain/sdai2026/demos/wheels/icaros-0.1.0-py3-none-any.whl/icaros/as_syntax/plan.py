from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom, _unset
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.plan_body import BodyType
from icaros.as_syntax.structure import Structure

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.list_term import ListTerm
    from icaros.as_syntax.logical_formula import LogicalFormula
    from icaros.as_syntax.plan_body import PlanBody
    from icaros.as_syntax.plan_doc import PlanDoc
    from icaros.as_syntax.pred import Pred
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.trigger import Trigger
    from icaros.pl.plan_library import PlanLibrary

T_ATOMIC = Atom("atomic")
T_BREAK_POINT = Atom("breakpoint")
T_ALL_UNIFS = Atom("all_unifs")
NO_LABEL_ATOM = Atom("nolabel")

# ag: represents an AgentSpeak plan. Extends Structure so it can be used as a term.
class Plan(Structure):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, label: Pred | object = _unset, te: Trigger | object = _unset,
                 ct: LogicalFormula | object = _unset, bd: PlanBody | object = _unset):
        # ag: Java's Plan() [used by clone] / Plan(Pred,Trigger,LogicalFormula,PlanBody)
        # [used by parser] overloads collapsed here.
        super().__init__("plan")
        self._label: Pred | None = None
        self._tevent: Trigger | None = None
        self._context: LogicalFormula | None = None
        self._body: PlanBody | None = None

        # new in JasonER
        self._goal_condition: LogicalFormula | None = None
        self._subplans: PlanLibrary | None = None
        self._scope: PlanLibrary | None = None

        self._is_atomic = False
        self._is_all_unifs = False
        self._has_breakpoint = False
        self._is_term = False  # true when the plan is used as a term instead of an element of a plan
        self._source = ""  # the source of this plan (file, url, ...)
        # ag: the doc-comment written above this plan in the .asl source, if
        # any -- attached by parser/entry_points.py, consumed by
        # PlanLibrary.llm_tool(s) to describe the plan to an LLM. Deliberately
        # NOT part of __eq__/get_arity/get_term: it documents the plan, it is
        # not one of its terms, and it must not affect PlanLibrary.add()'s
        # dedup or the shape of a plan used as a term.
        self._doc: PlanDoc | None = None

        if te is not _unset:
            self._tevent = te
            self._tevent.set_as_trigger_term(False)
            self.label = label
            self.context = ct
            if bd is None:
                from icaros.as_syntax.plan_body import PlanBody
                self._body = PlanBody()
            else:
                self._body = bd
                self._body.is_body_term = False

    def get_arity(self) -> int:
        return 4

    @property
    def source_file(self) -> str:
        return self._source

    @source_file.setter
    def source_file(self, f: str | None):
        if f is not None:
            self._source = f

    def get_term(self, i: int) -> Term | None:
        if i == 0:
            return NO_LABEL_ATOM if self._label is None else self._label
        if i == 1:
            return self._tevent
        if i == 2:
            return Literal.l_true if self._context is None else self._context
        if i == 3:
            b = self._body
            if b is None:  # bare Plan(), e.g. mid-construction in clone()/resolve()
                return None
            if (b.body_next is None and b.body_term is not None
                    and b.body_type == BodyType.NONE and b.body_term.is_var()):
                # the case of body as a single var
                return b.body_term
            return b
        return None

    def set_term(self, i: int, t: Term):
        if i == 0: self._label = t
        elif i == 1: self._tevent = t
        elif i == 2: self._context = t
        elif i == 3: self._body = t

    @property
    def label(self) -> Pred | None:
        return self._label

    @label.setter
    def label(self, p: Pred | None):
        self._label = p
        self._is_atomic = False
        self._has_breakpoint = False
        self._is_all_unifs = False
        if p is not None and p.has_annot():
            for t in self._label.annots:
                if t == T_ATOMIC: self._is_atomic = True
                if t == T_BREAK_POINT: self._has_breakpoint = True
                if t == T_ALL_UNIFS: self._is_all_unifs = True
                # if change here, also change clone()!

    def del_label(self):
        self.label = None

    @property
    def context(self) -> LogicalFormula | None:
        return self._context

    @context.setter
    def context(self, le: LogicalFormula | None):
        self._context = le
        if Literal.l_true == le:
            self._context = None

    @property
    def doc(self) -> PlanDoc | None:
        """The doc-comment written above this plan, or None."""
        return self._doc

    @doc.setter
    def doc(self, d: PlanDoc | None):
        self._doc = d

    @property
    def is_plan_term(self) -> bool:
        return self._is_term

    @is_plan_term.setter
    def is_plan_term(self, b: bool):
        self._is_term = b

    def get_as_list_of_terms(self) -> ListTerm:
        from icaros.as_syntax.list_term import ListTerm
        result = ListTerm()
        result.append(self.label)
        result.append(self.trigger)
        result.append(Literal.l_true if self.context is None else self.context)
        result.append(self.get_body())
        return result

    def get_terms(self) -> list[Term]:
        return self.get_as_list_of_terms().get_as_list()

    @staticmethod
    def new_from_list_of_terms(lt: ListTerm) -> Plan:
        from icaros.as_syntax.pred import Pred
        items = lt.get_as_list()
        c = items[2]
        if c.is_plan_body():
            c = c.body_term
        return Plan(Pred(items[0]), items[1], c, items[3])

    @property
    def trigger(self) -> Trigger:
        return self._tevent

    def get_body(self) -> PlanBody:
        return self._body

    def is_atomic(self) -> bool:
        return self._is_atomic

    def has_breakpoint(self) -> bool:
        return self._has_breakpoint

    def is_all_unifs(self) -> bool:
        return self._is_all_unifs

    def is_relevant(self, te: Trigger, u: Unifier | None) -> Unifier | None:
        # annots in plan's TE must be a subset of the ones in the event! (see the
        # definition of Unifier.unifies for 2 Preds)
        if u is None:
            from icaros.as_semantics.unifier import Unifier
            u = Unifier()
        if u.unifies_no_undo(self._tevent, te):
            return u
        else:
            return None

    def __eq__(self, o: object) -> bool:
        if o is self: return True
        if o is not None and isinstance(o, Plan):
            if self._context is None and o._context is not None: return False
            if self._context is not None and o._context is not None and self._context != o._context: return False
            return self._tevent == o._tevent and self._body == o._body
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def resolve(self, u: Unifier) -> Plan:
        p = Plan()
        if self._label is not None:
            p._label = self._label.resolve(u)
            p._is_atomic = self._is_atomic
            p._has_breakpoint = self._has_breakpoint
            p._is_all_unifs = self._is_all_unifs
        p._tevent = self._tevent.resolve(u)
        if self._context is not None:
            p._context = self._context.resolve(u)
        p._body = self._body.resolve(u)
        p.src_info = self.src_info
        p._is_term = self._is_term
        p._doc = self._doc  # PlanDoc is frozen -- shared by reference, like _scope
        return p

    def clone(self) -> Plan:
        p = Plan()
        if self._label is not None:
            p.label = self._label.clone()
        p._tevent = self._tevent.clone()
        if self._context is not None:
            p._context = self._context.clone()
        p._body = self._body.clone_pb()
        p.src_info = self.src_info
        p._is_term = self._is_term
        p._source = self._source
        p._doc = self._doc

        if self._goal_condition is not None:
            p._goal_condition = self._goal_condition.clone()
        p._subplans = self._subplans
        p._scope = self._scope

        return p

    def clone_ns(self, ns: Atom) -> Plan:
        # TODO: should we change the namespace of all elements of the plan?
        return self.clone()

    def clone_only_body(self) -> Plan:
        # used to create a plan clone in a new intention
        p = Plan()
        if self._label is not None:
            p._label = self._label
            p._is_atomic = self._is_atomic
            p._has_breakpoint = self._has_breakpoint
            p._is_all_unifs = self._is_all_unifs
        p._tevent = self._tevent.clone()
        p._context = self._context
        p._body = self._body.clone_pb()
        p._scope = self._scope
        p.src_info = self.src_info
        p._is_term = self._is_term
        p._doc = self._doc
        return p

    def __str__(self) -> str:
        out = []
        if self._is_term:
            out.append("{ ")
        out.append("" if self._label is None else f"@{self._label} ")
        out.append(str(self._tevent))
        out.append("" if self._context is None else f" : {self._context}")
        out.append("" if self._goal_condition is None else f" <: {self._goal_condition}")
        if self._subplans is None:
            if self._body is not None and not self._body.is_empty_body():
                out.append(f" <- {self._body}")
            out.append(" }" if self._is_term else ".")
        else:
            out.append(" {")
            if self._body is not None and not self._body.is_empty_body():
                out.append(f"\n   <- {self._body}.")
            for p in self._subplans:
                out.append(f"\n   {p}")
            out.append("\n}")
            if self._is_term:
                out.append(" }")
        return "".join(out)

    # -- JasonER extensions (jason.pl.PlanLibrary is out of scope for this pass;
    # duck-typed forward references, same policy as Unifier/Agent) --

    def add_sub_plan(self, p: Plan):
        if self._subplans is None:
            from icaros.pl.plan_library import PlanLibrary
            self._subplans = PlanLibrary(self._scope)
        self._subplans.add(p)

    def has_sub_plans(self) -> bool:
        return self._subplans is not None

    def has_interest_in_update_events(self) -> bool:
        return self._subplans is not None and self._subplans.has_plans_for_update_events()

    @property
    def sub_plans(self) -> PlanLibrary | None:
        return self._subplans

    @property
    def scope(self) -> PlanLibrary | None:
        return self._scope

    @scope.setter
    def scope(self, pl: PlanLibrary):
        self._scope = pl
        if self._subplans is not None:
            self._subplans.set_father(self._scope)

    @property
    def goal_condition(self) -> LogicalFormula | None:
        return self._goal_condition

    @goal_condition.setter
    def goal_condition(self, f: LogicalFormula):
        self._goal_condition = f

    def has_goal_condition(self) -> bool:
        return self._goal_condition is not None

    # -- source annotations, delegated to the label --

    def has_source(self, ag_name: Term | None = None) -> bool:
        return self.label.has_source(ag_name)

    def get_sources(self) -> ListTerm:
        return self.label.get_sources()

    def add_source(self, ag_name: Term) -> Literal:
        self.label.add_source(ag_name)
        return self

    def del_source(self, ag_name: Term) -> bool:
        return self.label.del_source(ag_name)

    def del_sources(self):
        self.label.del_sources()

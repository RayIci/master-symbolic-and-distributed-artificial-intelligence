from __future__ import annotations

import logging
from collections.abc import Iterator
from functools import total_ordering
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term

_unset = object()  # ag: sentinel to distinguish "ns not passed" from "ns explicitly None"

@total_ordering  # ag: __lt__ below + __eq__ give us <=/>/>= for free; applied once here,
                 # subclasses only override __eq__ and still get correct <=/>/>= dynamically
class Atom(Literal):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, functor_or_literal: str | Literal, ns: Atom | None = _unset):
        # ag: Java's Atom(String) / Atom(Atom,String) / Atom(Literal) / Atom(Atom,Literal)
        # / Atom(Literal,Unifier) constructor overloads collapsed into one dispatching
        # __init__: pass a functor string (optionally with ns=), or an existing Literal
        # to copy functor/ns/src_info from (optionally with an explicit ns= override,
        # which DefaultNameSpace below deliberately passes as None -- mirroring Java's
        # `super(null, "default")`).
        if isinstance(functor_or_literal, str):
            functor = functor_or_literal
            if functor is None:
                self._logger.warning("The functor of an atom functor should not be null!")
            self._functor = functor
            self._ns = Literal.default_ns if ns is _unset else ns
        else:
            lit = functor_or_literal
            self._functor = lit.functor
            self._ns = lit.ns if ns is _unset else ns
            self.src_info = lit.src_info

    @classmethod
    def from_resolve(cls, lit: Literal, u: Unifier) -> Atom:
        return cls(lit, lit.ns.resolve(u))

    @property
    def functor(self) -> str:
        return self._functor

    @property
    def ns(self) -> Atom:
        return self._ns

    def clone(self) -> Term:
        return self  # since this object is immutable

    def resolve(self, u: Unifier) -> Term:
        if self._ns.is_var():
            return Atom.from_resolve(self, u)
        else:
            return self

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return Atom(self, newnamespace)

    def is_atom(self) -> bool:
        return True

    def __eq__(self, o: object) -> bool:
        if o is None: return False
        if o is self: return True
        if isinstance(o, Atom):
            return o.is_atom() and self.functor == o.functor and self.ns == o.ns
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated;
                                      # always point at the one real implementation (see porting.md)

    # ag: Comparable<T>.compareTo -> __eq__ + __lt__ (see porting.md). Where Java used
    # compareTo(null) == -1 as a sentinel (annot list terminal node), callers now check
    # `is None` explicitly instead (see Pred.add_annot etc.) -- nothing here handles None.
    def __lt__(self, t: Term) -> bool:
        if t.is_numeric():
            return False

        if self.is_list() and not t.is_list(): return True
        if not self.is_list() and t.is_list(): return False

        if t.is_var():
            return True

        if isinstance(t, Literal):
            if self.ns != t.ns:
                return self.ns < t.ns

            if self.functor != t.functor:
                return self.functor < t.functor

            if not self.negated() and t.negated(): return True
            if self.negated() and not t.negated(): return False

            ma = self.get_arity()
            oa = t.get_arity()
            for i in range(min(ma, oa)):
                a, b = self.get_term(i), t.get_term(i)
                if a != b:
                    return a < b
            if ma != oa:
                return ma < oa

            my_annots = self.annots
            other_annots = t.annots
            if my_annots is None and other_annots is None: return False
            if my_annots is None: return True
            if other_annots is None: return False

            for a, b in zip(my_annots, other_annots):
                if a != b:
                    return a < b

            ats = my_annots.size()
            ots = other_annots.size()
            if ats != ots:
                return ats < ots
            return False

        return super().__lt__(t)

    def calc_hash_code(self) -> int:
        return hash(self.functor) + hash(self.ns)

    def __str__(self) -> str:
        if self._ns == Literal.default_ns:
            return self._functor
        else:
            return f"{self.ns}::{self._functor}"


class TrueLiteral(Atom):

    def __init__(self):
        super().__init__("true")

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return self

    def resolve(self, u: Unifier) -> Term:
        return self

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        from icaros.as_syntax.log_expr import LogExpr
        return LogExpr.create_unif_iterator(un)


class FalseLiteral(Atom):

    def __init__(self):
        super().__init__("false")

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return self

    def resolve(self, u: Unifier) -> Term:
        return self

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        from icaros.as_syntax.log_expr import LogExpr
        return iter(LogExpr.EMPTY_UNIF_LIST)


class DefaultNameSpace(Atom):

    def __init__(self):
        super().__init__("default", ns=None)  # ag: Java passes ns=null explicitly here

    def calc_hash_code(self) -> int:
        return hash(self.functor)

    def resolve(self, u: Unifier) -> Term:
        return self

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return self

    @property
    def ns(self) -> Atom:
        return self

    def __eq__(self, o: object) -> bool:
        if o is None: return False
        if o is self: return True
        if isinstance(o, Atom):
            return o.is_atom() and self.functor == o.functor
        return False

    __hash__ = DefaultTerm.__hash__

    def __str__(self) -> str:
        return self.functor


# ag: bootstrap the Literal singletons here (not in literal.py) since they need Atom
# to exist as their base class -- order matters, each step depends on the previous one
Literal.default_ns = DefaultNameSpace()
Literal.l_true = TrueLiteral()
Literal.l_false = FalseLiteral()

from icaros.as_syntax.source_info import SourceInfo
SourceInfo.a_no_code = Atom("no_code")

from __future__ import annotations

import copy
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term

# ag: Java's ObjectTerm interface and ObjectTermImpl merged into a single class (the
# only implementer once VarTerm dropped its dead-stub term-type interfaces, see
# var_term.py).
class ObjectTerm(DefaultTerm):

    def __init__(self, o: object):
        self._object = o

    @property
    def value(self) -> object:
        return self._object

    def calc_hash_code(self) -> int:
        return hash(self._object)

    def __eq__(self, o: object) -> bool:
        if self._object is None: return False
        if o is None: return False
        if isinstance(o, ObjectTerm):
            return self._object == o._object
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    # ag: Java uses reflection to look up and invoke a .clone() method on the wrapped
    # object, falling back to `this` if there is none. Python's copy.deepcopy() is the
    # idiomatic equivalent of "try to clone the wrapped object", same fallback-to-self
    # on failure.
    def clone(self) -> Term:
        try:
            return ObjectTerm(copy.deepcopy(self._object))
        except Exception:
            return self

    def __str__(self) -> str:
        return str(self._object)
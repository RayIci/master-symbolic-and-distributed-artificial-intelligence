from __future__ import annotations

import itertools
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.var_term import VarTerm

if TYPE_CHECKING:
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.term import Term

_var_cont = itertools.count(1)  # ag: Java's AtomicInteger varCont.incrementAndGet()

class UnnamedVar(VarTerm):

    def __init__(self, ns_or_id: Atom | int | object = _unset, id_: int | object = _unset):
        # ag: Java's UnnamedVar() / UnnamedVar(Atom) / UnnamedVar(Atom,int) / UnnamedVar(int)
        # overloads collapsed here. The private UnnamedVar(String)/UnnamedVar(Atom,String)
        # ctors (used internally by create(), myId set by the caller afterward) are
        # exposed as the classmethod _from_name below instead.
        if ns_or_id is _unset:
            # UnnamedVar() -- ns=DefaultNS, fresh id
            my_id = next(_var_cont)
            super().__init__(Literal.default_ns, f"_{my_id}")
        elif isinstance(ns_or_id, int):
            # UnnamedVar(id: int) -- ns=DefaultNS implied
            my_id = ns_or_id
            super().__init__(f"_{my_id}")
        elif id_ is _unset:
            # UnnamedVar(ns: Atom) -- fresh id
            my_id = next(_var_cont)
            super().__init__(ns_or_id, f"_{my_id}")
        else:
            # UnnamedVar(ns: Atom, id: int)
            my_id = id_
            super().__init__(ns_or_id, f"_{my_id}")
        self.my_id = my_id

    @classmethod
    def _from_name(cls, ns: Atom, name: str) -> UnnamedVar:
        # do not allow the creation of unnamed var by name since my_id should be defined
        # by the caller! internal use only (see create()/create_with_id() below).
        v = cls.__new__(cls)
        VarTerm.__init__(v, ns, name)
        return v

    @classmethod
    def create(cls, ns_or_name: Atom | str, name: str | object = _unset) -> UnnamedVar:
        if name is _unset:
            return cls.create(Literal.default_ns, ns_or_name)
        ns = ns_or_name
        if len(name) == 1:  # the case of "_"
            return cls(ns)
        else:
            my_id = next(_var_cont)
            v = cls._from_name(ns, f"_{my_id}{name}")
            v.my_id = my_id
            return v

    @classmethod
    def create_with_id(cls, ns: Atom, id_: int, name: str) -> UnnamedVar:
        # create unnamed var with an id and name (usually from parsing something like _34Me)
        v = cls._from_name(ns, name)
        v.my_id = id_ * -1  # the ID is defined by the name (not auto from this class); flip sign to avoid clash
        return v

    def clone(self) -> Term:
        return self.clone_ns(self.ns)

    def clone_ns(self, new_namespace: Atom) -> Literal:
        newv = UnnamedVar._from_name(new_namespace, self.functor)
        newv.my_id = self.my_id
        if self.has_annot():
            newv.set_annots(self.annots.clone_lt())
        return newv

    def __eq__(self, t: object) -> bool:
        if t is None: return False
        if t is self: return True
        if isinstance(t, UnnamedVar):
            return t.my_id == self.my_id
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated
    # ag: no calc_hash_code override -- inherits VarTerm's hash(get_functor()), same as Java

    def __lt__(self, t: Term) -> bool:
        if isinstance(t, UnnamedVar):
            return self.my_id < t.my_id
        elif isinstance(t, VarTerm):
            return False  # self (unnamed) sorts after any named var
        else:
            return super().__lt__(t)

    def is_unnamed_var(self) -> bool: return True

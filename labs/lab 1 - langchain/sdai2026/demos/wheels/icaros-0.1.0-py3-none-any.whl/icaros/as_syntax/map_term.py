from __future__ import annotations

from collections.abc import Iterable
from functools import total_ordering
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term

# ag: shared by MapTerm and SetTerm -- byte-identical __lt__ bodies (both are direct
# DefaultTerm siblings, so super().__lt__ resolves to the same DefaultTerm.__lt__
# either way). Owned here, imported by set_term.py.
def _collection_term_lt(self: Term, o: Term) -> bool:
    if o.is_numeric() or o.is_string() or isinstance(o, Literal):
        return False
    return DefaultTerm.__lt__(self, o)


# ag: Java's MapTerm interface and MapTermImpl merged into a single class (the only
# implementer once VarTerm dropped its dead-stub term-type interfaces, see var_term.py).
@total_ordering  # ag: __lt__ + __eq__ give us <=/>/>= for free -- missing this meant
                 # `map_term <= map_term` raised TypeError
class MapTerm(DefaultTerm):

    def __init__(self):
        self._map: dict[Term, Term] = {}

    # ag: clone() returns self (shallow) on purpose -- Java's comment: a real deep
    # clone breaks "for each" loops over maps; deep_clone() below does the real copy.
    def clone(self) -> Term:
        return self

    def deep_clone(self) -> MapTerm:
        t = MapTerm()
        for k, v in self._map.items():
            t._map[k.clone()] = v.clone()
        return t

    def resolve(self, u: Unifier) -> Term:
        return self  # TODO: think about this! (matches Java's own TODO)

    def __eq__(self, t: object) -> bool:
        if t is None: return False
        if t is self: return True
        # ag: Java's equals checks `instanceof SetTerm` here, which looks like a
        # copy-paste bug from SetTermImpl (would make equals() always False between
        # two MapTermImpl instances, since a map is never a SetTerm) -- comparing
        # against MapTerm instead, clearly the intent.
        if isinstance(t, MapTerm):
            return self._map == t._map
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        return hash(frozenset(self._map.items()))

    def __lt__(self, o: Term) -> bool:
        return _collection_term_lt(self, o)

    def size(self) -> int:
        return len(self._map)

    def is_map(self) -> bool:
        return True

    def get(self, k: Term) -> Term | None:
        return self._map.get(k)

    def put(self, k: Term, v: Term):
        self._map[k] = v

    def remove(self, k: Term) -> Term | None:
        return self._map.pop(k, None)

    def keys(self) -> set[Term]:
        return set(self._map.keys())

    def values(self) -> Iterable[Term]:
        return self._map.values()

    def clear(self):
        self._map.clear()

    def __str__(self) -> str:
        items = ",".join(f"{k}->{self._map[k]}" for k in sorted(self._map.keys()))
        return f"{{{items}}}"
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.plan import Plan
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.trigger import Trigger


# ag: a parsed `{ name(arg, ...) }` top-level directive (Jason's
# `{include(...)}`/`{begin ns(...)}` system). Only `include` is given
# semantics (factory.py's parse_agent resolves and merges it away, see
# porting.md); any other name reaching Agent.load_parsed_asl is a clear
# error rather than a silently-ignored no-op.
@dataclass
class Directive:
    name: str
    args: list[Term] = field(default_factory=list)


# ag: the parsed contents of a whole .asl file (Java's agent() parser
# production populates Agent directly; this is the intermediate result
# Agent.load_asl then applies).
@dataclass
class AgentSource:
    beliefs: list[Literal] = field(default_factory=list)
    initial_goals: list[Trigger] = field(default_factory=list)
    plans: list[Plan] = field(default_factory=list)
    directives: list[Directive] = field(default_factory=list)

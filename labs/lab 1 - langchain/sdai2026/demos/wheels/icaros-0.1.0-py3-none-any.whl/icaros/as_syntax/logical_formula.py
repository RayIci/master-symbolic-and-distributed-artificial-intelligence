from __future__ import annotations

from abc import abstractmethod
from collections.abc import Iterator
from typing import TYPE_CHECKING

from icaros.as_syntax.term import Term

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier

class LogicalFormula(Term):

    @abstractmethod
    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]: ...
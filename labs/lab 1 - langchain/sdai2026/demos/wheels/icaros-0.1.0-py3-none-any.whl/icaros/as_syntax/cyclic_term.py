from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.literal_impl import LiteralImpl

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.var_term import VarTerm

class CyclicTerm(LiteralImpl):

    def __init__(self, t: Literal, v: VarTerm):
        super().__init__(t)
        self._cyclic_var = v

    @classmethod
    def from_resolve(cls, t: Literal, v: VarTerm, u: Unifier) -> CyclicTerm:
        s = super().from_resolve(t, u)
        s._cyclic_var = v
        return s

    @property
    def cyclic_var(self) -> VarTerm:
        return self._cyclic_var

    def is_cyclic_term(self) -> bool:
        return True

    def __eq__(self, o: object) -> bool:
        if o is None: return False
        if o is self: return True
        if isinstance(o, CyclicTerm):
            return super().__eq__(o)
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def make_vars_annon(self, un: Unifier | None = None) -> Literal:
        if un is None:
            from icaros.as_semantics.unifier import Unifier
            un = Unifier()
        super().make_vars_annon(un)
        v = un.deref(self._cyclic_var)
        if v is not None:
            self._cyclic_var = v
        return self

    def resolve(self, u: Unifier) -> Term:
        v = u.remove(self._cyclic_var)
        r = CyclicTerm.from_resolve(self, self._cyclic_var.clone(), u)
        if v is not None:
            u.bind(self._cyclic_var, v)
        return r

    def clone(self) -> Term:
        return CyclicTerm(self, self._cyclic_var.clone())

    def calc_hash_code(self) -> int:
        return super().calc_hash_code() + hash(self._cyclic_var)

    def __str__(self) -> str:
        return f"...{super().__str__()}/{self._cyclic_var}"

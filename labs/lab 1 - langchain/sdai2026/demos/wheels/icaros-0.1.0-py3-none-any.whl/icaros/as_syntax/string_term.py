from __future__ import annotations

from functools import total_ordering
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term

# ag: Java's StringTerm interface and StringTermImpl merged into a single class
# (the only implementer once VarTerm dropped its dead-stub term-type interfaces,
# see var_term.py).
@total_ordering  # ag: __lt__ below + __eq__ give us <=/>/>= for free -- missing this
                 # meant "abc" <= "abd" and comparing two literals with string
                 # annots (Pred.has_subset_annot) both raised TypeError
class StringTerm(DefaultTerm):

    def __init__(self, value: str | None = None):
        self._value = value

    @property
    def string(self) -> str | None:
        return self._value

    def clone(self) -> Term:
        return self  # immutable

    def is_string(self) -> bool:
        return True

    def length(self) -> int:
        return 0 if self._value is None else len(self._value)

    def __eq__(self, t: object) -> bool:
        if t is self: return True
        if isinstance(t, StringTerm):
            # ag: self._value == t.string already handles the None case correctly
            # (None == None is True), no need for a separate branch
            return self._value == t.string
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        return 0 if self._value is None else hash(self._value)

    def __lt__(self, o: Term) -> bool:
        from icaros.as_syntax.var_term import sorts_after_var
        if sorts_after_var(o):
            return True
        if o.is_numeric():
            return False  # numbers sort before strings
        return super().__lt__(o)

    def __str__(self) -> str:
        return f'"{self._value}"'
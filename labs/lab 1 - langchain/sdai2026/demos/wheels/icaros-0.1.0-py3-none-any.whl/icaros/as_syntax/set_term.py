from __future__ import annotations

from collections.abc import Collection, Iterable, Iterator
from functools import total_ordering
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.map_term import _collection_term_lt

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.list_term import ListTerm
    from icaros.as_syntax.term import Term

# ag: Java's SetTerm interface and SetTermImpl merged into a single class (the only
# implementer once VarTerm dropped its dead-stub term-type interfaces, see var_term.py).
# Java's SetTerm also extends Collection<Term>/Iterable<Term> — the collection-ish
# surface (__iter__, add, size, ...) is provided directly here, rather than pulling
# in collections.abc.MutableSet wholesale.
@total_ordering  # ag: __lt__ + __eq__ give us <=/>/>= for free -- missing this meant
                 # `set_term <= set_term` raised TypeError
class SetTerm(DefaultTerm):

    def __init__(self):
        self._set: set[Term] = set()

    # ag: clone() returns self (shallow) on purpose -- same reasoning as MapTerm.
    def clone(self) -> Term:
        return self

    def deep_clone(self) -> SetTerm:
        t = SetTerm()
        for a in self._set:
            t._set.add(a.clone())
        return t

    def resolve(self, u: Unifier) -> Term:
        return self  # TODO: think about this! (matches Java's own TODO)

    def __eq__(self, t: object) -> bool:
        if t is None: return False
        if t is self: return True
        if isinstance(t, SetTerm):
            return self._set == t._set
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        return hash(frozenset(self._set))

    def __lt__(self, o: Term) -> bool:
        return _collection_term_lt(self, o)

    def size(self) -> int:
        return len(self._set)

    def is_set(self) -> bool:
        return True

    def get_as_list_term(self) -> ListTerm:
        from icaros.as_syntax.list_term import ListTerm
        result = ListTerm()
        for t in sorted(self._set):
            result.append(t.clone())
        return result

    def __iter__(self) -> Iterator[Term]:
        return iter(self._set)

    def __len__(self) -> int:
        return len(self._set)

    def add(self, t: Term) -> bool:
        before = len(self._set)
        self._set.add(t)
        return len(self._set) != before

    def union(self, lt: Iterable[Term]):
        for t in lt:
            self.add(t)

    def intersection(self, lt: Collection[Term]):
        self._set &= set(lt)

    def difference(self, lt: Collection[Term]):
        self._set -= set(lt)

    def is_empty(self) -> bool:
        return len(self._set) == 0

    def clear(self):
        self._set.clear()

    def __contains__(self, o: object) -> bool:
        return o in self._set

    def remove(self, o: object) -> bool:
        try:
            self._set.remove(o)
            return True
        except KeyError:
            return False

    def __str__(self) -> str:
        return "{" + ",".join(str(t) for t in sorted(self._set)) + "}"
from __future__ import annotations

class ASParseError(Exception):
    # ag: Java's ParseException/TokenMgrError (checked exceptions) collapsed
    # into one unchecked exception type -- Python has no checked-exception
    # distinction to preserve here. See porting.md.

    def __init__(self, message: str, *, explanation: str | None = None):
        """`explanation` is the same failure said in one line, without the
        position and caret `message` carries -- for callers that parse a
        snippet lifted out of a larger file (mas2i belief lines) and need to
        report it against the position in *that* file instead."""
        super().__init__(message)
        self.explanation = explanation if explanation is not None else message

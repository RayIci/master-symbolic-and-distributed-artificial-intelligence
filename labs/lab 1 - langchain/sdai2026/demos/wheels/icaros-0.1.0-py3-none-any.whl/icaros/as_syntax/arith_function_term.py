from __future__ import annotations

import logging
from collections.abc import Iterator
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.number_term import NumberTerm
from icaros.as_syntax.structure import Structure

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.arith_function import ArithFunction
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.term import Term

# ag: this deliberately reuses Structure's functor+args storage/equality/toString
# machinery for something that isn't semantically a structure at all (is_atom/
# is_structure/is_literal all False, is_arith_expr/is_numeric True) -- a Java
# code-reuse wart, replicated as-is (not worth re-deriving the hierarchy for it,
# and other dispatch in the port already relies on exactly this override set).
class ArithFunctionTerm(Structure, NumberTerm):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, a: ArithFunction | ArithFunctionTerm | str, arity: int | object = _unset):
        # ag: Java's ArithFunctionTerm(ArithFunction) / ArithFunctionTerm(ArithFunctionTerm)
        # / ArithFunctionTerm(String,int) overloads collapsed here; arity is accepted
        # for API-shape parity but unused (no capacity preallocation, as elsewhere).
        if isinstance(a, str):
            super().__init__(a)
            self._function = None
        elif isinstance(a, ArithFunctionTerm):
            super().__init__(a)  # clone args from a
            self._function = a._function
        else:
            function = a
            super().__init__(function.get_name())
            self._function = function
        self._value = None  # value, when evaluated

    def is_numeric(self) -> bool: return True
    def is_atom(self) -> bool: return False
    def is_structure(self) -> bool: return False
    def is_literal(self) -> bool: return False
    def is_arith_expr(self) -> bool: return True

    # computes the value for this arithmetic function (as defined in NumberTerm)
    def resolve(self, u: Unifier) -> Term:
        if self._function is None:
            self._logger.error(
                f"{self.get_error_msg()} -- the function can not be evaluated, it has no function assigned to it!")
        else:
            v = super().resolve(u)
            if self._function.allow_unground_terms() or v.is_ground():
                try:
                    from icaros.as_syntax.number_term_impl import NumberTermImpl
                    self._value = NumberTermImpl(self._function.evaluate(v.get_terms()))
                    return self._value
                except ValueError:
                    pass  # ignore and return this (ag: Java's NoValueException)
                except Exception as e:
                    self._logger.error(
                        f"{self.get_error_msg()} -- {e} -- error while evaluating function, unifier = {u}")
        return self.clone()

    def solve(self) -> float:
        if self._value is None:  # try to solve without unifier
            self.resolve(None)
        if self._value is None:
            suffix = "" if self.is_ground() else " It is not ground."
            raise ValueError(f"Error evaluating {self}.{suffix}")
        else:
            return self._value.solve()

    def check_arity(self, a: int) -> bool:
        return self._function is not None and self._function.check_arity(a)

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        self._logger.warning(f"Arithmetic term cannot be used for logical consequence! {self.get_error_msg()}")
        return iter(())

    # ag: Java's compareTo override is otherwise identical to Structure's (via super);
    # only the VarTerm special-case is added.
    def __lt__(self, o: Term) -> bool:
        from icaros.as_syntax.var_term import sorts_after_var
        if sorts_after_var(o):
            return True
        return super().__lt__(o)

    def get_error_msg(self) -> str:
        return f"Error in '{self}' ({super().get_error_msg()})"

    def clone(self) -> Term:
        return ArithFunctionTerm(self)

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return ArithFunctionTerm(self)  # ag: Java ignores newnamespace here too

from __future__ import annotations

import re
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

# ag: the doc attached to a plan (or to an internal action). Deliberately
# independent of where the text came from: the .asl doc-comment reader in
# parser/entry_points.py and the Python-docstring reader in
# stdlib/ia_tools.py both funnel into parse_doc_comment below, so the two
# families of LLM tools (goals and internal actions) share one doc model.

# JSON-schema types a @param may declare. Anything else falls back to "string"
# and the unrecognised token is left in the description rather than dropped.
JSON_TYPES = frozenset({"string", "number", "integer", "boolean", "array", "object"})

DEFAULT_TYPE = "string"

# tags that get their own field on PlanDoc; every other @tag lands in .tags
_WHEN_TAGS = ("when", "context")
_PARAM_TAGS = ("param", "arg")
_RETURNS_TAGS = ("returns", "return")

_TAG_RE = re.compile(r"^\s*@(\w+)\b[ \t]*(.*)$")
# "Dest", "Date:string", "Date : string"
_PARAM_HEAD_RE = re.compile(r"^([A-Za-z_]\w*)\s*(?::\s*(\w+))?\s*(.*)$", re.DOTALL)


def _empty_map() -> Mapping:
    return MappingProxyType({})


@dataclass(frozen=True)
class ParamDoc:
    """One documented parameter of a goal or internal action."""

    name: str
    type: str = DEFAULT_TYPE
    description: str = ""
    required: bool = True


@dataclass(frozen=True)
class PlanDoc:
    """A parsed doc-comment: free text, then optional @tags.

    `summary` is everything before the first tag. `when` is the @when/@context
    text -- the part that tells a model in which situation this plan or action
    applies, which is the whole point of documenting the several versions of a
    goal separately. Unrecognised tags are kept in `tags` rather than dropped,
    so a project can add its own conventions without touching this module.
    """

    summary: str = ""
    when: str = ""
    params: Mapping[str, ParamDoc] = field(default_factory=_empty_map)
    returns: str | None = None
    tags: Mapping[str, tuple[str, ...]] = field(default_factory=_empty_map)
    raw: str = ""

    def is_empty(self) -> bool:
        return not (self.summary or self.when or self.params or self.returns or self.tags)


def strip_doc_markers(raw: str) -> str:
    """Removes the comment syntax, leaving the doc text.

    Handles `/** ... */`, a run of `///` lines, and a plain Python docstring
    (which arrives with no markers at all and only needs dedenting).
    """
    text = raw.strip()

    if text.startswith("/**"):
        # strip the closing delimiter FIRST: on the degenerate "/**/" the
        # trailing "*/" and the leading "/**" overlap, and taking the prefix
        # off first would leave a stray "/" behind as the summary.
        if text.endswith("*/"):
            text = text[:-2]
        text = text[3:] if text.startswith("/**") else ""
        # drop the decorative leading "*" of each continuation line
        lines = [re.sub(r"^\s*\*[ \t]?", "", line) for line in text.splitlines()]
    elif text.startswith("///"):
        lines = [re.sub(r"^\s*///[ \t]?", "", line) for line in text.splitlines()]
    else:
        lines = text.splitlines()

    # common-prefix dedent, so an indented docstring reads the same as a
    # column-0 one (textwrap.dedent can't be used directly: the first line of
    # a Python docstring carries no indentation at all).
    body = [line for line in lines[1:] if line.strip()]
    if body:
        indent = min(len(line) - len(line.lstrip()) for line in body)
        if indent:
            lines = lines[:1] + [line[indent:] if line.strip() else line for line in lines[1:]]

    return "\n".join(line.rstrip() for line in lines).strip("\n")


def _split_blocks(text: str) -> tuple[str, list[tuple[str, str]]]:
    """Splits doc text into (free text before the first tag, [(tag, body)]).

    A tag body continues onto the following lines until the next tag starts,
    so a long @when can be wrapped across several lines.
    """
    summary_lines: list[str] = []
    blocks: list[tuple[str, list[str]]] = []

    for line in text.splitlines():
        m = _TAG_RE.match(line)
        if m:
            blocks.append((m.group(1).lower(), [m.group(2)]))
        elif blocks:
            blocks[-1][1].append(line)
        else:
            summary_lines.append(line)

    summary = "\n".join(summary_lines).strip()
    return summary, [(tag, "\n".join(body).strip()) for tag, body in blocks]


def _parse_param(body: str) -> ParamDoc | None:
    m = _PARAM_HEAD_RE.match(body.strip())
    if m is None:
        return None
    name, declared, description = m.group(1), m.group(2), m.group(3)
    if declared is not None and declared.lower() in JSON_TYPES:
        param_type = declared.lower()
    else:
        param_type = DEFAULT_TYPE
        if declared is not None:
            # unrecognised: don't silently swallow it, put it back in the text
            description = f"{declared} {description}".strip()
    return ParamDoc(name=name, type=param_type, description=" ".join(description.split()))


def parse_doc_comment(raw: str | None) -> PlanDoc | None:
    """Parses a doc-comment (or a Python docstring) into a PlanDoc.

    Returns None when there is nothing left after stripping the comment
    markers -- e.g. `/**/` -- so callers can treat "no doc" and "empty doc"
    the same way.
    """
    if not raw:
        return None

    text = strip_doc_markers(raw)
    if not text.strip():
        return None

    summary, blocks = _split_blocks(text)

    when_parts: list[str] = []
    params: dict[str, ParamDoc] = {}
    returns: str | None = None
    tags: dict[str, list[str]] = {}

    for tag, body in blocks:
        if tag in _WHEN_TAGS:
            # collapse whitespace: a wrapped @when is one phrase, and its
            # continuation lines carry alignment padding that would otherwise
            # show up verbatim in the tool description.
            if body:
                when_parts.append(" ".join(body.split()))
        elif tag in _PARAM_TAGS:
            param = _parse_param(body)
            if param is not None and param.name not in params:
                params[param.name] = param
        elif tag in _RETURNS_TAGS:
            if returns is None:
                returns = " ".join(body.split())
        else:
            tags.setdefault(tag, []).append(body)

    doc = PlanDoc(
        summary=summary,
        when=" ".join(when_parts).strip(),
        params=MappingProxyType(params),
        returns=returns,
        tags=MappingProxyType({k: tuple(v) for k, v in tags.items()}),
        raw=raw,
    )
    return None if doc.is_empty() else doc

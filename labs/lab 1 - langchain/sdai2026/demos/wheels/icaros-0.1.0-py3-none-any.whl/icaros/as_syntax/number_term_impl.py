from __future__ import annotations

import logging
import math
from functools import total_ordering

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.number_term import NumberTerm
from icaros.as_syntax.term import Term

@total_ordering  # ag: __lt__ below + __eq__ give us <=/>/>= for free; see atom.py's same convention
class NumberTermImpl(DefaultTerm, NumberTerm):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, value: float | str | NumberTermImpl = 0.0):
        # ag: Java's NumberTermImpl() / NumberTermImpl(String) / NumberTermImpl(double)
        # / NumberTermImpl(NumberTermImpl) overloads collapsed here.
        if isinstance(value, str):
            try:
                self._value = float(value)
            except ValueError as e:
                self._logger.error(f"Error setting number term value from {value}: {e}")
                self._value = 0.0
        elif isinstance(value, NumberTermImpl):
            self._value = value._value
            self.src_info = value.src_info
        else:
            self._value = float(value)

    def solve(self) -> float:
        return self._value

    def clone(self) -> Term:
        return self  # immutable

    def is_numeric(self) -> bool:
        return True

    def __eq__(self, o: object) -> bool:
        if o is self: return True
        if isinstance(o, Term) and o.is_numeric() and not o.is_arith_expr():
            try:
                return self.solve() == o.solve()
            except Exception:
                pass  # ag: solve() can raise ValueError (unground ArithExpr) or similar; fall through to False
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        # ag: plain int(self._value) raises OverflowError on inf and ValueError
        # on nan -- Java's (int) cast instead saturates to Integer.MAX_VALUE/
        # MIN_VALUE for the infinities and returns 0 for NaN, so mirror that
        # rather than let hash() crash. nan is reachable in practice: a failed
        # ArithExpr.resolve() returns NumberTermImpl(nan) (see arith_expr.py).
        if math.isnan(self._value):
            return 0
        if math.isinf(self._value):
            return 37 * (2147483647 if self._value > 0 else -2147483648)
        return 37 * int(self._value)

    def __lt__(self, o: Term) -> bool:
        from icaros.as_syntax.var_term import sorts_after_var
        if sorts_after_var(o):
            return True
        if isinstance(o, NumberTermImpl):
            return self._value < o._value
        return True  # numbers sort before every other non-var term type

    def __str__(self) -> str:
        r = round(self._value)
        if self._value == float(r):
            return str(r)
        else:
            return str(self._value)

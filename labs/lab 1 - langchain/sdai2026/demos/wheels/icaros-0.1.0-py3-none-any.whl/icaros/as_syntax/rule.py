from __future__ import annotations

from collections import Counter
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.literal_impl import LiteralImpl

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.logical_formula import LogicalFormula
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.var_term import VarTerm

class Rule(LiteralImpl):

    def __init__(self, head: Literal, body: LogicalFormula):
        super().__init__(head)
        if head.is_rule():
            self._logger.error(f"The rule head ({head}) is a rule!")
        elif self.is_internal_action():
            self._logger.error(f"The rule head ({head}) can not be an internal action!")
        elif head is Literal.l_true or head is Literal.l_false:
            self._logger.error(f"The rule head ({head}) can not be a true or false!")
        self._body = body
        self._is_term = False  # true when the rule is used as a term ( { p :- q } )

    @classmethod
    def from_resolve(cls, r: Rule, u: Unifier) -> Rule:
        s = super().from_resolve(r, u)
        s._is_term = r._is_term
        s._body = r._body.resolve(u)
        return s

    def is_rule(self) -> bool: return True
    def is_atom(self) -> bool: return False
    def is_ground(self) -> bool: return False

    @property
    def is_term(self) -> bool: return self._is_term
    @is_term.setter
    def is_term(self, b: bool): self._is_term = b

    def __eq__(self, o: object) -> bool:
        if o is not None and isinstance(o, Rule):
            return super().__eq__(o) and self._body == o._body
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated

    def calc_hash_code(self) -> int:
        return super().calc_hash_code() + hash(self._body)

    def get_body(self) -> LogicalFormula:
        return self._body

    def get_head(self) -> Literal:
        return LiteralImpl(self)

    def make_vars_annon(self, un: Unifier | None = None) -> Literal:
        if un is None:
            from icaros.as_semantics.unifier import Unifier
            un = Unifier()
        if isinstance(self._body, Literal):
            self._body.make_vars_annon(un)
        return super().make_vars_annon(un)

    def resolve(self, u: Unifier) -> Term:
        return Rule.from_resolve(self, u)

    def clone(self) -> Rule:
        r = Rule(super().clone(), self._body.clone())
        r._is_term = self._is_term
        return r

    def head_clone(self) -> Literal:
        return super().clone()

    def head_resolve(self, u: Unifier) -> Literal:
        return super().resolve(u)

    def __str__(self) -> str:
        if self.is_term:
            return f"{{ {super().__str__()} :- {self._body} }}"
        else:
            return f"{super().__str__()} :- {self._body}"

    def has_var(self, t: VarTerm, u: Unifier) -> bool:
        return super().has_var(t, u) or self._body.has_var(t, u)

    def count_vars(self) -> Counter:
        c = super().count_vars()
        c.update(self._body.count_vars())
        return c

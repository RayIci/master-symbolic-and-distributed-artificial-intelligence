from __future__ import annotations

import logging
from collections.abc import Iterator
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import _unset
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.logical_formula import LogicalFormula
from icaros.as_syntax.structure import Structure

if TYPE_CHECKING:
    from icaros.as_semantics.agent import Agent
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.term import Term
    from icaros.stdlib.registry import InternalAction

# ag: represents an internal action call (functor containing a ".", e.g. ".send(...)")
class InternalActionLiteral(Structure, LogicalFormula):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, a: str | InternalActionLiteral | Structure | Atom,
                 b: object = _unset, c: object = _unset):
        # ag: Java's InternalActionLiteral(String) / InternalActionLiteral(ial) [clone]
        # / InternalActionLiteral(Structure,Agent) / InternalActionLiteral(Atom,Structure,Agent)
        # overloads collapsed here (the private cloneNS/capply forms are exposed as
        # __init__(ns,ial) / from_resolve below, disambiguated by whether the 2nd arg
        # is itself an InternalActionLiteral).
        if c is not _unset:
            # InternalActionLiteral(ns, p: Structure, ag: Agent) -- used by the parser
            ns, p, ag = a, b, c
            super().__init__(p, ns)
            self._ia = ag.get_ia(self.functor) if ag is not None else None
        elif b is not _unset:
            if isinstance(b, InternalActionLiteral):
                # InternalActionLiteral(ns, ial) -- used by clone_ns
                ns, ial = a, b
                super().__init__(ial, ns)
                self._ia = ial._ia
            else:
                # InternalActionLiteral(p: Structure, ag: Agent) -- used by the parser
                p, ag = a, b
                super().__init__(p, Literal.default_ns)
                self._ia = ag.get_ia(self.functor) if ag is not None else None
        elif isinstance(a, str):
            # InternalActionLiteral(functor)
            super().__init__(a)
            self._ia = None
        else:
            # InternalActionLiteral(ial) -- used by clone
            ial = a
            super().__init__(ial, ial.ns)
            self._ia = ial._ia

    @classmethod
    def from_resolve(cls, ial: InternalActionLiteral, u: Unifier) -> InternalActionLiteral:
        s = super().from_resolve(ial, u)
        s._ia = ial._ia
        return s

    def is_internal_action(self) -> bool: return True
    def is_atom(self) -> bool: return False

    def make_vars_annon(self, un: Unifier | None = None) -> Literal:
        if un is None:
            from icaros.as_semantics.unifier import Unifier
            un = Unifier()
        t = super().make_vars_annon(un)
        if t.functor == ".puts":
            # ag: Java also replaces vars inside .puts() string interpolation here
            # (jason.stdlib.puts) -- stdlib doesn't exist yet in this port, so this is
            # a known gap rather than a silent behavior difference.
            self._logger.warning(".puts variable substitution not yet implemented in this port")
        return t

    def logical_consequence(self, ag: Agent, un: Unifier) -> Iterator[Unifier]:
        if ag is None or ag.ts.ag_arch.is_running():
            try:
                ia = self.get_ia(ag)
                if not ia.can_be_used_in_context():
                    self._logger.error(
                        f"{self.get_error_msg()}: internal action {self.functor} cannot be used in context or rules!")
                    return iter(())

                oresult = ia.execute(ag.ts, un, ia.prepare_arguments(self, un))
                is_in_debug = ag.logger.isEnabledFor(logging.DEBUG)

                if isinstance(oresult, bool):
                    if oresult:
                        if is_in_debug: ag.logger.debug(f"     | internal action {self} executed  -- {un}")
                        from icaros.as_syntax.log_expr import LogExpr
                        return LogExpr.create_unif_iterator(un)
                    else:
                        if is_in_debug: ag.logger.debug(f"     | internal action {self} failed  -- {un}")
                elif isinstance(oresult, Iterator):
                    if is_in_debug:
                        def _logged() -> Iterator[Unifier]:
                            for r in oresult:
                                ag.logger.debug(f"     | internal action {self} option  -- {r}")
                                yield r
                        return _logged()
                    else:
                        return oresult
            except Exception as e:
                # ag: Java also special-cases ConcurrentModificationException with a
                # sleep-then-retry -- a JVM-collection-specific concern that doesn't
                # map cleanly here; dropped for now, revisit once the port's
                # concurrency model (if any) is designed.
                self._logger.error(f"{self.get_error_msg()}: {e}")
        return iter(())

    def set_ia(self, ia: InternalAction):
        self._ia = ia

    def get_ia(self, ag: Agent) -> InternalAction:
        if self._ia is None and ag is not None:
            self._ia = ag.get_ia(self.functor)
        return self._ia

    def get_error_msg(self) -> str:
        src = "" if self.src_info is None else f" ({self.src_info})"
        return f"Error in internal action '{self}'{src}"

    def resolve(self, u: Unifier) -> Term:
        return InternalActionLiteral.from_resolve(self, u)

    def clone(self) -> InternalActionLiteral:
        return InternalActionLiteral(self)

    def clone_ns(self, newnamespace: Atom) -> Literal:
        return InternalActionLiteral(newnamespace, self)

from __future__ import annotations

import logging
from enum import Enum
from typing import TYPE_CHECKING

from icaros.as_syntax.default_term import DefaultTerm
from icaros.as_syntax.plan_body import BodyType
from icaros.as_syntax.structure import Structure

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.predicate_indicator import PredicateIndicator
    from icaros.as_syntax.term import Term

class TEOperator(Enum):
    ADD = "add"
    DEL = "del"
    GOAL_STATE = "goalState"

    def __str__(self) -> str:
        return _TE_OPERATOR_STR[self]


_TE_OPERATOR_STR = {TEOperator.ADD: "+", TEOperator.DEL: "-", TEOperator.GOAL_STATE: "^"}


class TEType(Enum):
    BELIEF = "belief"
    ACHIEVE = "achieve"
    TEST = "test"
    SIGNAL = "signal"

    def __str__(self) -> str:
        return _TE_TYPE_STR[self]


_TE_TYPE_STR = {TEType.BELIEF: "", TEType.ACHIEVE: "!", TEType.TEST: "?", TEType.SIGNAL: ""}


# ag: represents an AgentSpeak trigger (+!g, +p, ...): an operator (+/-), a type
# (<empty>/!/?), and a literal. Extends Structure so it can be used as a term.
class Trigger(Structure):

    _logger: logging.Logger = logging.getLogger(__name__)

    def __init__(self, op: TEOperator, t: TEType, lit: Literal):
        super().__init__("te")
        self._literal = lit
        self._type = t
        self._operator = TEOperator.ADD
        self.operator = op
        self.src_info = lit.src_info
        self._is_term = False  # true when the trigger is used as a term instead of a plan element

    # override some structure methods

    def get_arity(self) -> int:
        return 2

    def get_term(self, i: int) -> Term | None:
        if i == 0:
            from icaros.as_syntax.string_term import StringTerm
            return StringTerm(str(self._operator) + str(self._type))
        if i == 1:
            return self._literal
        return None

    def set_term(self, i: int, t: Term):
        if i == 0:
            self._logger.warning("set_term(i,t) for i=0 -- the operator --, IS NOT IMPLEMENTED YET!!!")
        elif i == 1:
            self._literal = t

    def same_type(self, e: Trigger) -> bool:
        return self._operator == e._operator and (
            self._type == e._type
            or (self._type == TEType.SIGNAL and e._type == TEType.BELIEF)
            or (self._type == TEType.BELIEF and e._type == TEType.SIGNAL)
        )

    def __eq__(self, o: object) -> bool:
        if o is not None and isinstance(o, Trigger):
            return self._operator == o._operator and self._type == o._type and self._literal == o.literal
        return False

    __hash__ = DefaultTerm.__hash__  # ag: overriding __eq__ resets __hash__ unless restated
    # ag: no calc_hash_code override -- inherits Structure's, which already uses the
    # synthesized get_term(0)/get_term(1) above, same as Java.

    def is_achv_goal(self) -> bool: return self._type == TEType.ACHIEVE
    def is_failure_goal(self) -> bool: return self._type == TEType.ACHIEVE and self._operator == TEOperator.DEL
    def is_goal(self) -> bool: return self._type == TEType.ACHIEVE or self._type == TEType.TEST
    def is_update(self) -> bool: return self._type == TEType.BELIEF  # true if trigger is +bel or -bel
    def is_meta_event(self) -> bool: return self._operator == TEOperator.GOAL_STATE

    @property
    def operator(self) -> TEOperator: return self._operator
    @operator.setter
    def operator(self, op: TEOperator): self._operator = op

    @property
    def type(self) -> TEType: return self._type
    @type.setter
    def type(self, t: TEType): self._type = t

    def is_addition(self) -> bool: return self._operator == TEOperator.ADD

    def clone(self) -> Trigger:
        c = Trigger(self._operator, self._type, self._literal.copy())
        c._is_term = self._is_term
        return c

    def resolve(self, u: Unifier) -> Term:
        c = Trigger(self._operator, self._type, self._literal.resolve(u))
        c._is_term = self._is_term
        return c

    def get_predicate_indicator(self) -> PredicateIndicator:
        from icaros.as_syntax.predicate_indicator import PredicateIndicator
        return PredicateIndicator(
            self._literal.ns, f"{self._operator}{self._type}{self._literal.functor}",
            self._literal.get_arity())

    @property
    def literal(self) -> Literal: return self._literal
    @literal.setter
    def literal(self, literal: Literal): self._literal = literal

    def set_as_trigger_term(self, b: bool): self._is_term = b

    def __str__(self) -> str:
        if self._is_term:
            b, e = "{ ", " }"
        else:
            b, e = "", ""
        return f"{b}{self._operator}{self._type}{self._literal}{e}"

    @staticmethod
    def try_to_get_trigger(t: Term) -> Trigger | None:
        if isinstance(t, Trigger):
            return t
        if t.is_plan_body():
            p = t
            if p.get_plan_size() == 1:
                op = None
                if p.body_type == BodyType.ADD_BEL:
                    op = TEOperator.ADD
                elif p.body_type == BodyType.DEL_BEL:
                    op = TEOperator.DEL
                if op is not None:
                    lit = p.body_term.clone().force_full_literal_impl()
                    from icaros.bb.belief_base import BeliefBase  # ag: jason.bb, out of scope for this pass
                    lit.del_annot(BeliefBase.self_source_term)
                    return Trigger(op, TEType.BELIEF, lit)
        if t.is_string():
            from icaros.as_syntax.factory import parse_trigger
            return parse_trigger(t.string)
        return None

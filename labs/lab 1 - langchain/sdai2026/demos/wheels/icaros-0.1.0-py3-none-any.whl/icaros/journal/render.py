from __future__ import annotations

import json
from typing import TYPE_CHECKING

from icaros.journal.entry import JournalKind

if TYPE_CHECKING:
    from icaros.journal.entry import JournalEntry


def render_entry(entry: JournalEntry) -> str:
    """One entry, one line -- always.

    ag: the escaping is not cosmetic. Beliefs and plan steps carry string
    terms, and a `.print("done\\n")` embeds a real newline; left alone it
    splits the entry across two lines and every reader downstream, the prompt
    included, sees two events where there was one.
    """
    return _render(entry).replace("\n", "\\n").replace("\r", "\\r")


def _render(entry: JournalEntry) -> str:
    detail = entry.detail
    # ag: "rc12", not "c12". The bare letter reads as an index of something
    # unstated -- a model asked what happened at c12 had no way to know what
    # the number counted, and neither did a human opening the timeline cold.
    # Journal.render() spells it out once in a legend as well, because even
    # "rc" is an abbreviation you have to be told.
    head = f"rc{entry.cycle}"
    match entry.kind:
        case JournalKind.SENSE:
            return f"{head} sense: {detail.get('summary', '?')}"
        case JournalKind.DELIBERATE:
            return f"{head} {_deliberate(detail)}"
        case JournalKind.ACT:
            return f"{head} act: {detail.get('summary', '?')}"
        case JournalKind.CYCLE:
            # already rendered, at compaction time: the lines it stands for no
            # longer exist to be rendered again
            return detail.get("summary", head)
        case JournalKind.BB_DELTA:
            added = json.loads(detail.get("added", "[]"))
            deleted = json.loads(detail.get("deleted", "[]"))
            parts = [f"+{text}" for text in added] + [f"-{text}" for text in deleted]
            return f"{head} belief {' '.join(parts)}"
        case JournalKind.GOAL_FAILED:
            return f"{head} goal {detail.get('goal', '?')} FAILED: {detail.get('reason', '?')}"
        case JournalKind.PRINT:
            return f"{head} printed {detail.get('line', '').rstrip()}"
        case JournalKind.SAY:
            # first person, like the two LLM lines below: an agent rereading
            # this in its preamble should see that it already answered, and
            # what with -- "printed" would read as output, not as speech.
            return f"{head} I said {detail.get('text', '').rstrip()}"
        case JournalKind.MSG_OUT:
            return (f"{head} sent {detail.get('performative', '?')} "
                    f"to {detail.get('receiver', '?')}: {detail.get('content', '')}")
        case JournalKind.MSG_IN:
            # ag: a chat gets its own wording, and the difference is not
            # cosmetic. "bob sent chat: msg("ciao")" is the envelope; what the
            # agent has to see when it rereads this is that somebody SPOKE to
            # it, in the same first person as the "I said" line it will write
            # back. Every other performative keeps the envelope, because there
            # the envelope is the meaning -- a tell and an achieve from the
            # same sender are not the same event.
            sender = detail.get("sender", "?")
            content = detail.get("content", "")
            if detail.get("performative") == "chat":
                return f"{head} {sender} said {content}"
            return f"{head} {sender} sent {detail.get('performative', '?')}: {content}"
        case JournalKind.LLM_CHOICE:
            thinking = detail.get("thinking")
            because = f" -- {thinking}" if thinking else ""
            return f"{head} I chose {detail.get('choice', '?')}{because}"
        case JournalKind.LLM_GENERATE:
            # ag: written in the first person like the LLM_CHOICE line above,
            # and for the same reason: this is the agent's own account of its
            # reasoning, and the model reads it back as the journal preamble of
            # the next round.
            if "concluded" in detail:
                error = detail.get("error")
                if error:
                    return (f"{head} [{detail.get('level', '?')}] I asked the model and "
                            f"it never finished: {error}")
                return (f"{head} [{detail.get('level', '?')}] I asked the model and it "
                        f"concluded: {detail.get('concluded') or 'nothing in particular'}")
            asked = detail.get("asked") or "nothing"
            thinking = detail.get("thinking")
            because = f" -- {thinking}" if thinking else ""
            error = detail.get("error")
            if error:
                return f"{head} [{detail.get('level', '?')}] I asked the model and it FAILED: {error}"
            return (f"{head} [{detail.get('level', '?')} round {detail.get('round', '?')}] "
                    f"I asked the model about {detail.get('about', '?')} "
                    f"and it reached for {asked}{because}")
        case _:
            rest = " ".join(f"{k}={v}" for k, v in detail.items())
            return f"{head} {entry.kind} {rest}".rstrip()


def render_cycle_group(cycle: int, entries: list[JournalEntry]) -> str:
    """One reasoning cycle's entries, already filtered to a caller-chosen set
    of kinds, joined into one narrative paragraph. "" when there is nothing
    left to narrate, so the caller can drop the paragraph rather than emit an
    empty one.

    Fragments are joined with "; ", not a comma: several of them already
    carry a comma of their own (a binding like {X -> bob, Y -> 3}), and a
    comma-joined sentence would blur where one event ends and the next
    begins. No connective word is added between fragments either -- "so" or
    "but" would claim a causal or contrastive relationship between two
    entries that happened to land in the same cycle, which is not something
    this function actually knows to be true.

    A singleton CYCLE entry is passed through as-is: it is already a whole
    cycle's paragraph, baked in at compaction time by this same function (see
    Journal._fold_cycle) -- there is nothing left to merge.
    """
    if len(entries) == 1 and entries[0].kind is JournalKind.CYCLE:
        return entries[0].detail.get("summary", "")
    fragments = [text for e in entries if (text := _narrate(e))]
    if not fragments:
        return ""
    return f"on cycle {cycle}: " + "; ".join(fragments) + "."


def _narrate(entry: JournalEntry) -> str:
    """One entry as an rcN-free, first-person prose fragment, meant to be
    joined with others from the same cycle by render_cycle_group().

    Deliberately not shared with _render(): that function's wording is a tool
    contract (.timeline hands it to the model verbatim), and this one is
    prose the project keeps free to reword.
    """
    detail = entry.detail
    match entry.kind:
        case JournalKind.SENSE:
            return f"I sensed {detail.get('summary', '?')}"
        case JournalKind.DELIBERATE:
            return _deliberate_narrated(detail)
        case JournalKind.ACT:
            return f"I did {detail.get('summary', '?')}"
        case JournalKind.CYCLE:
            return detail.get("summary", "")
        case JournalKind.BB_DELTA:
            added = json.loads(detail.get("added", "[]"))
            deleted = json.loads(detail.get("deleted", "[]"))
            parts = [f"+{text}" for text in added] + [f"-{text}" for text in deleted]
            return f"I came to believe {' '.join(parts)}" if parts else ""
        case JournalKind.GOAL_FAILED:
            return f"the goal {detail.get('goal', '?')} failed: {detail.get('reason', '?')}"
        case JournalKind.PRINT:
            line = detail.get("line", "").rstrip()
            return f"I printed {line}" if line else ""
        case JournalKind.SAY:
            text = detail.get("text", "").rstrip()
            return f"I said {text}" if text else ""
        case JournalKind.MSG_OUT:
            return (f"I sent {detail.get('performative', '?')} "
                    f"to {detail.get('receiver', '?')}: {detail.get('content', '')}")
        case JournalKind.MSG_IN:
            sender = detail.get("sender", "?")
            content = detail.get("content", "")
            if detail.get("performative") == "chat":
                return f"{sender} said {content}"
            return f"{sender} sent {detail.get('performative', '?')}: {content}"
        case JournalKind.LLM_CHOICE:
            thinking = detail.get("thinking")
            because = f" -- {thinking}" if thinking else ""
            return f"I chose {detail.get('choice', '?')}{because}"
        case JournalKind.LLM_GENERATE:
            if "concluded" in detail:
                error = detail.get("error")
                if error:
                    return f"I asked the model and it never finished: {error}"
                return (f"I asked the model and it concluded: "
                        f"{detail.get('concluded') or 'nothing in particular'}")
            asked = detail.get("asked") or "nothing"
            thinking = detail.get("thinking")
            because = f" -- {thinking}" if thinking else ""
            error = detail.get("error")
            if error:
                return f"I asked the model and it failed: {error}"
            return (f"I asked the model about {detail.get('about', '?')} "
                    f"and it reached for {asked}{because}")
        case _:
            rest = " ".join(f"{k}={v}" for k, v in detail.items())
            return f"{entry.kind} {rest}".rstrip()


def _deliberate_narrated(detail: dict[str, str]) -> str:
    outcome = detail.get("outcome", "")
    trigger = detail.get("trigger", "?")
    if outcome == "no_option":
        return f"nothing to do for {trigger}: no option was chosen"
    if outcome != "selected":
        return f"nothing to do for {trigger}: no {outcome.removeprefix('no_')} plan"

    plan = detail.get("plan_label") or detail.get("source") or "an unlabelled plan"
    line = f"for {trigger} I ran {plan}"
    bindings = detail.get("bindings")
    if bindings and bindings != "{}":
        line += f" with {bindings}"
    failed = int(detail.get("context_failed", 0))
    unexamined = int(detail.get("unexamined", 0))
    notes = []
    if failed:
        notes.append(f"{failed} earlier plan(s) had a false context")
    if unexamined:
        notes.append(f"{unexamined} later plan(s) were not examined")
    if notes:
        line += f" ({'; '.join(notes)})"
    return line


def _deliberate(detail: dict[str, str]) -> str:
    """A deliberate line carries what the stage decided about one event: which
    plan it will run, or why it will run none."""
    # ag: outcome is a non-defaulted field of DeliberationRecord and as_detail
    # drops only Nones, so it is always here -- no "no outcome" branch, which
    # would be a shape the journal cannot emit.
    outcome = detail.get("outcome", "")
    trigger = detail.get("trigger", "?")
    if outcome == "no_option":
        # not "no ... plan": plans were found and one was applicable, and then
        # select_option turned them all down
        return f"deliberate: nothing to do for {trigger}, no option was chosen"
    if outcome != "selected":
        return f"deliberate: nothing to do for {trigger}, no {outcome.removeprefix('no_')} plan"

    plan = detail.get("plan_label") or detail.get("source") or "an unlabelled plan"
    line = f"deliberate: for {trigger} I ran {plan}"
    bindings = detail.get("bindings")
    if bindings and bindings != "{}":
        line += f" with {bindings}"
    # the shortcut's signature: plans whose context failed are not the same as
    # plans that were never looked at, and a model told otherwise will narrate
    # a deliberation that never took place
    failed = int(detail.get("context_failed", 0))
    unexamined = int(detail.get("unexamined", 0))
    notes = []
    if failed:
        notes.append(f"{failed} earlier plan(s) had a false context")
    if unexamined:
        notes.append(f"{unexamined} later plan(s) were not examined")
    if notes:
        line += f" ({'; '.join(notes)})"
    return line

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class JournalKind(Enum):
    """What an entry is. Same shape as GoalStates/IcarosState: the value is the
    wire spelling, and telemetry mirrors it onto the ring as that string.

    ag: one kind per reasoning-cycle stage rather than one per interpreter
    callback. The fine-grained stream (every event queued, every intention
    added and re-added) is what made the first cut unreadable -- several lines
    per cycle saying the machine was still running. A stage line says what the
    stage decided, which is the only part a reader, human or model, can use.
    """

    # the reasoning cycle itself
    SENSE = "sense"
    DELIBERATE = "deliberate"
    ACT = "act"
    # a whole past cycle, folded into one entry once it is old enough to stop
    # deserving full resolution -- see Journal._compact
    CYCLE = "cycle"
    # chokepoints that are not stages
    BB_DELTA = "bb_delta"
    BB_CHECKPOINT = "bb_checkpoint"
    GOAL_FAILED = "goal_failed"
    PRINT = "print"
    # what the agent said to a person (.say), as opposed to what it printed
    SAY = "say"
    MSG_OUT = "msg_out"
    # ag: MSG_OUT's twin, and it was missing. Without it the only trace of
    # having been SPOKEN TO was second-hand -- the `about` field of an
    # llm_generate line, truncated at 200 characters -- so an agent reading its
    # own journal could see every answer it gave and not one question it was
    # asked. A conversation rendered from that reads as a monologue.
    MSG_IN = "msg_in"
    LLM_CHOICE = "llm_choice"
    # one round of an Icaros session: what the agent put in front of the model
    # and what the model reached for. The counterpart of LLM_CHOICE for the
    # times the model acts instead of picking.
    LLM_GENERATE = "llm_generate"

    def __str__(self) -> str:
        return self.value


# what render() shows unless told otherwise. BB_CHECKPOINT is deliberately out:
# it is bookkeeping for the fold, and its content is already the "what I
# believe now" section.
NARRATIVE_KINDS = (
    JournalKind.SENSE, JournalKind.DELIBERATE, JournalKind.ACT, JournalKind.CYCLE,
    JournalKind.BB_DELTA, JournalKind.GOAL_FAILED, JournalKind.PRINT,
    JournalKind.SAY, JournalKind.MSG_IN, JournalKind.MSG_OUT, JournalKind.LLM_CHOICE,
    JournalKind.LLM_GENERATE,
)

# what a CONVERSATION inherits from before it began -- see Agentic._preamble.
#
# ag: these five and no others because of what they have in common: every one of
# them was addressed to somebody, or said by somebody. A `sense:` line, a
# deliberation, a belief delta and a `.print` are the agent talking to itself
# about its own machinery, and a model handed those while somebody is waiting
# for an answer narrates the machinery instead of answering -- it is the
# loudest thing in the prompt and it is happening right now.
#
# The cut is not censorship: the journal tools (pl/journal_plans.asl) still
# reach the whole thing. What changes is who decides -- the reasoning cycle
# stops shouting over the question, and a model that actually wants to know
# what the agent is up to has to ask.
CONVERSATION_KINDS = (
    JournalKind.SAY, JournalKind.MSG_IN, JournalKind.MSG_OUT,
    JournalKind.GOAL_FAILED, JournalKind.LLM_GENERATE,
)

# kinds whose detail carries an `added`/`deleted` pair the fold must apply.
# CYCLE is in here because compaction merges a cycle's deltas into it rather
# than dropping them -- that is what keeps beliefs_at() answerable across
# compacted history.
DELTA_KINDS = (JournalKind.BB_DELTA, JournalKind.CYCLE)


@dataclass(slots=True)
class JournalEntry:
    """One thing this agent did or learned, captured as text when it happened."""

    seq: int
    cycle: int
    kind: JournalKind
    detail: dict[str, str]


@dataclass(slots=True, frozen=True)
class Checkpoint:
    """A full belief base, kept OUTSIDE the entry deque so eviction can never
    take the anchor a fold starts from. `seq` is the sequence number the next
    entry will get, i.e. deltas with seq >= this one are the ones to apply."""

    seq: int
    cycle: int
    beliefs: tuple[str, ...]
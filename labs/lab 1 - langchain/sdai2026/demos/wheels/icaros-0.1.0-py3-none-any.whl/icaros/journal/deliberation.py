from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_semantics.option import Option
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.trigger import Trigger

# ag: the functor icaros.llm.result.CALL_ANNOT stamps on everything a tool
# call touches -- llm_call(call_id, session, tool_name). Kept as a literal
# string rather than imported: icaros.journal has to stay usable with no LLM
# stack loaded at all (see pyproject.toml's dependency-boundary note), and
# this is a syntax-level fact about the annotation, not a reason to reach
# into icaros.llm for it.
_LLM_CALL_FUNCTOR = "llm_call"


def strip_call_annot(literal: Literal) -> Literal:
    """`literal`, or a copy with its llm_call(...) annotation gone.

    The call id and session inside it are pure correlation plumbing -- how a
    tool result finds its way back to the session that asked for it -- and
    mean nothing to a reader of the journal, model included. source(llm)
    stays: unlike the call id, "the model itself did this" is real
    provenance, the same kind of fact as source(bob) or source(percept) (see
    Journal.record_belief_change).
    """
    annot = literal.get_annot(_LLM_CALL_FUNCTOR)
    if annot is None:
        return literal
    stripped = literal.copy()
    stripped.del_annot(stripped.get_annot(_LLM_CALL_FUNCTOR))
    return stripped


def trigger_text(trigger: Trigger) -> str:
    """str(trigger), with its literal's llm_call(...) annotation gone -- see
    strip_call_annot. The text version, because every caller wants a string
    for the journal, not a term to keep working with."""
    stripped = strip_call_annot(trigger.literal)
    if stripped is trigger.literal:
        return str(trigger)
    clone = trigger.clone()
    clone.literal = stripped
    return str(clone)


@dataclass(slots=True, frozen=True)
class DeliberationRecord:
    """What the interpreter did when it chose a plan, recorded as it happened.

    ag: this is a record of the TRAJECTORY, not a reconstruction of the
    deliberation. The selection rule is deterministic and lives in the code, so
    it does not need to live in the log too -- what cannot be recovered later
    is which road the cycle took, what it was answering, and what it picked.
    Circumstance.reset_deliberate() wipes all of that at the top of the next
    cycle, and on the fast path relevant_plans/applicable_plans were never
    filled in the first place, which is why telemetry.inspect.deliberation()
    has to recompute and can only answer "what applies now".

    Every field is already a string. That is not laziness: an Option holds a
    Unifier that goes on being mutated after the choice is made, so a stored
    reference would render whatever the agent had reached by the time somebody
    asked, not what it chose.
    """

    path: str        # "fast" (FIND_OP) | "full" (RelPl->ApplPl->SelAppl) | "preattached"
    trigger: str
    # ag: what kind of trigger it was, recorded rather than left to be read
    # back out of the trigger string. It is what says whether an outcome of
    # "no plan" is a defect or a shrug: _handle_no_plan fails a goal with no
    # relevant plan and logs it, and does nothing at all for a belief update
    # nobody reacts to -- which is the common, entirely normal case, and must
    # not be shown as an error.
    trigger_kind: str  # "goal" | "belief"
    # "no_option" is not a missing plan: one was applicable and select_option
    # turned it down (TransitionSystem._select_applicable_plan)
    outcome: str     # "selected" | "no_relevant" | "no_applicable" | "no_option"
    plan_label: str | None = None
    source: str | None = None
    bindings: str | None = None
    candidates: int = 0
    chosen_index: int = -1
    # ag: two counters, and keeping them apart is the point of the whole
    # record. On the fast path the loop stops at the first applicable plan, so
    # the candidates BEFORE the winner were evaluated and their context failed,
    # while the ones AFTER it were never looked at. Merged into a single "3
    # alternatives" the log would let a model narrate a deliberation that never
    # happened -- "I weighed five options and chose the best" when the agent
    # took the first one that worked.
    context_failed: int = 0
    unexamined: int = 0
    # the trigger's own annotations, JSON-encoded -- see annots_text
    annots: str | None = None
    # ag: which Icaros session this event belongs to, when the model posted
    # it. Read off the llm_call annotation rather than left inside it: the
    # session is what says two events a dozen cycles apart are the same
    # conversation, and llm_generate already records it per round -- a
    # deliberate line that could not say it was the odd one out.
    session: str | None = None

    def as_detail(self) -> dict[str, str]:
        """Journal-shaped, all strings, Nones dropped."""
        detail = {
            "path": self.path,
            "trigger": self.trigger,
            "trigger_kind": self.trigger_kind,
            "annots": self.annots,
            "session": self.session,
            "outcome": self.outcome,
            "plan_label": self.plan_label,
            "source": self.source,
            "bindings": self.bindings,
            "candidates": str(self.candidates),
            "chosen_index": str(self.chosen_index),
            "context_failed": str(self.context_failed),
            "unexamined": str(self.unexamined),
        }
        return {k: v for k, v in detail.items() if v is not None}


def bindings_text(unifier: Unifier | None) -> str | None:
    """`{X -> bob}` for the journal. None when there is nothing bound, so the
    renderer can leave it out rather than print an empty brace."""
    if unifier is None:
        return None
    pairs = {str(var): str(unifier.get(var)) for var in unifier}
    return "{" + ", ".join(f"{k} -> {v}" for k, v in pairs.items()) + "}" if pairs else None


def annots_text(trigger: Trigger) -> str | None:
    """A trigger's annotations, as a JSON list of their own text.

    ag: captured here, from the terms, rather than read back out of the
    trigger string later. `+!greet("bob")[source(alice)]` ends in a balanced
    bracket, but so does `+!say("a]b")` -- splitting the rendered string is
    guessing, and this is the one place that still has the structure to ask.
    JSON for the same reason record_belief_change uses it: a list of texts
    that must survive as a list.

    None when there are none, so record() drops the key rather than storing
    an empty list nobody can tell from "not captured".
    """
    literal = getattr(trigger, "literal", None)
    if literal is None or not literal.has_annot():
        return None
    texts = [str(term) for term in literal.annots]
    return json.dumps(texts) if texts else None


def kind_of(trigger: Trigger) -> str:
    """"goal" for +!g and +?g, "belief" for +b/-b -- the same split
    TransitionSystem._handle_no_plan makes when it decides whether an event
    with no plan is a failure or a shrug."""
    return "goal" if trigger.is_goal() else "belief"


def is_generated_label(label) -> bool:
    """True for the `p__N` placeholder PlanLibrary.get_unique_label gives a
    plan written without @label -- a name that means nothing to a reader, so
    views show the plan itself instead."""
    return label is not None and label.functor.startswith("p__")


def _plan_text(plan) -> str | None:
    """What to show for the chosen plan: its label when the author wrote one,
    the plan itself (trigger, and context if any) when the label is generated."""
    if plan is None or plan.label is None:
        return None
    if not is_generated_label(plan.label):
        return str(plan.label)
    text = str(plan.trigger)
    return text if plan.context is None else f"{text} : {plan.context}"


def record_for(path: str, trigger: Trigger, option: Option | None, *,
               session: str | None = None,
               candidates: int = 0, chosen_index: int = -1,
               context_failed: int = 0, unexamined: int = 0) -> DeliberationRecord:
    plan = option.plan if option is not None else None
    src = getattr(plan, "src_info", None) if plan is not None else None
    return DeliberationRecord(
        path=path,
        trigger=trigger_text(trigger),
        trigger_kind=kind_of(trigger),
        annots=annots_text(trigger),
        session=session,
        outcome="selected",
        plan_label=_plan_text(plan),
        source=str(src) if src is not None else None,
        bindings=bindings_text(option.unifier) if option is not None else None,
        candidates=candidates,
        chosen_index=chosen_index,
        context_failed=context_failed,
        unexamined=unexamined,
    )
from __future__ import annotations

import itertools
import json
import threading
from collections import deque
from typing import Callable, Iterable, Sequence

from icaros.journal.deliberation import strip_call_annot
from icaros.journal.entry import (
    DELTA_KINDS,
    NARRATIVE_KINDS,
    Checkpoint,
    JournalEntry,
    JournalKind,
)
from icaros.journal.render import render_cycle_group

# ag: the agent's own memory of what it did, and the one thing an agent owns
# that a language model reads. It is deliberately NOT runtime/telemetry's
# EventRing, and the difference is not duplication for its own sake:
#
#   - the ring is MAS-wide, so an agent reasoning over it would see every other
#     agent's deliberations -- omniscience, which is not what a BDI agent is;
#   - the ring is attached by a frontend (cli.py, the web host), so the window
#     an agent saw would depend on whether anybody was watching, and how loud
#     the other agents were. A journal that feeds reasoning has to be always on
#     and independently bounded, or runs stop being reproducible;
#   - the ring is drained by sequence for many readers; this is folded and
#     filtered by cycle for one.
#
# Same capture policy though: everything is str()-ed on the calling thread,
# because an Option's unifier and an Intention's stack go on mutating after the
# call returns.

DEFAULT_CAPACITY = 1024
DEFAULT_DETAIL_CYCLES = 20
DEFAULT_CHECKPOINT_EVERY = 128
DEFAULT_CHECKPOINTS_KEPT = 4


class Journal:
    """Bounded, per-agent record of the reasoning cycle, in narrative order.

    Memory here fades rather than stops. A cycle is kept at full resolution
    while it is recent, and folded into a single entry once `detail_cycles`
    have passed, so old history costs one line per cycle instead of vanishing
    at a hard edge. `capacity` remains as a backstop, but it now evicts
    compacted cycles.

    Two things it must do that a plain log cannot:

    `beliefs_at(cycle)` reconstructs the belief base of a past cycle by folding
    +/- deltas onto a checkpoint. It returns None -- "I no longer know" --
    rather than a partial answer whenever eviction has taken a delta it would
    have needed. That refusal is the whole point: the consumer is a language
    model, and a belief base that is merely plausible produces an explanation
    that is confident, coherent and false.

    `recall(cycle)` joins the deliberation of a cycle with the model's own
    reasoning for that same cycle, which is what turns "I did X" into "I did X
    because".
    """

    def __init__(self, capacity: int = DEFAULT_CAPACITY,
                 detail_cycles: int = DEFAULT_DETAIL_CYCLES,
                 checkpoint_every: int = DEFAULT_CHECKPOINT_EVERY,
                 checkpoints_kept: int = DEFAULT_CHECKPOINTS_KEPT,
                 beliefs_source: Callable[[], Iterable] | None = None,
                 cycle_source: Callable[[], int] | None = None) -> None:
        self._capacity = capacity
        self._detail_cycles = detail_cycles
        self._entries: deque[JournalEntry] = deque(maxlen=capacity)
        self._checkpoints: deque[Checkpoint] = deque(maxlen=checkpoints_kept)
        # ag: capped against the buffer rather than trusted as given. A cadence
        # sparser than the buffer can hold means every retained anchor ends up
        # older than the oldest surviving delta, and then beliefs_at() has to
        # refuse even for the CURRENT cycle -- an agent that cannot say what it
        # believes right now. Tying the two together makes "recent history is
        # always answerable" hold by construction instead of by luck.
        self._checkpoint_every = max(1, min(checkpoint_every,
                                            capacity // (checkpoints_kept + 1)))
        self._beliefs_source = beliefs_source
        self._cycle_source = cycle_source
        self._lock = threading.Lock()
        self._next_seq = 0
        self._last_cycle = -1
        self._deltas_since_checkpoint = 0
        # highest seq of a delta-carrying entry that fell out of the deque. A
        # fold whose anchor is older than this is missing changes it cannot see.
        self._lost_delta_seq = -1
        self._observers: list[Callable[[JournalEntry], None]] = []

    # ---- writing -----------------------------------------------------------

    @property
    def capacity(self) -> int:
        return self._capacity

    def add_observer(self, observer: Callable[[JournalEntry], None]) -> None:
        """Every entry is also handed to `observer`. This is how telemetry
        mirrors an agent's journal into its MAS-wide ring without the agent
        needing to know a collector exists."""
        self._observers.append(observer)

    def remove_observer(self, observer: Callable[[JournalEntry], None]) -> None:
        if observer in self._observers:
            self._observers.remove(observer)

    def cycle(self) -> int:
        return self._cycle_source() if self._cycle_source is not None else -1

    def record(self, kind: JournalKind, /, **detail) -> JournalEntry:
        """Appends one entry. Runs on the agent's own thread; must stay short.

        ag: `kind` is positional-only so a detail key may be called "kind"
        without colliding with it. Every caller already passes it positionally,
        and the alternative -- finding out at runtime that a perfectly
        reasonable field name is reserved -- cost an afternoon once already.
        """
        # ag: the first entry anchors the fold. Doing it here rather than at
        # construction is what makes the anchor correct: an Agent is built
        # empty and the .mas2i loader pours the initial beliefs in afterwards
        # with bb.add(), which never passes brf -- a checkpoint taken in
        # __init__ would faithfully record that the agent believed nothing.
        if not self._checkpoints and kind is not JournalKind.BB_CHECKPOINT:
            self.checkpoint()
        cycle = self.cycle()
        if cycle != self._last_cycle:
            self._last_cycle = cycle
            self._compact(before_cycle=cycle - self._detail_cycles)
        entry = JournalEntry(seq=-1, cycle=cycle, kind=kind,
                             detail={k: str(v) for k, v in detail.items() if v is not None})
        with self._lock:
            entry.seq = self._next_seq
            self._next_seq += 1
            self._note_eviction_of_oldest()
            self._entries.append(entry)
        # observers run outside the lock: they take locks of their own (the
        # ring's), and holding two in a fixed order is a promise this class
        # cannot make about code it does not own
        for observer in self._observers:
            observer(entry)
        return entry

    def _note_eviction_of_oldest(self) -> None:
        """Called with the lock held, before an append that would overflow."""
        if len(self._entries) != self._entries.maxlen:
            return
        evicted = self._entries[0]
        if evicted.kind in DELTA_KINDS:
            self._lost_delta_seq = max(self._lost_delta_seq, evicted.seq)

    def record_belief_change(self, added: Sequence, deleted: Sequence) -> None:
        """The +/- of one belief revision, from Agent.revise().

        Literals are str()-ed WITH their annotations: `[source(bob)]` versus
        `[source(percept)]` versus `[source(self)]` is half of why the agent
        believed something, and the whole reason a journal beats a plain diff.
        The one annotation left out is llm_call(...) -- a correlation id and
        session hex meaningful to icaros.llm, not to a reader of the journal
        (see strip_call_annot).
        """
        if not added and not deleted:
            return
        self.record(JournalKind.BB_DELTA,
                    added=json.dumps([str(strip_call_annot(literal)) for literal in added]),
                    deleted=json.dumps([str(strip_call_annot(literal)) for literal in deleted]))
        self._deltas_since_checkpoint += 1
        if self._deltas_since_checkpoint >= self._checkpoint_every:
            self.checkpoint()

    def checkpoint(self) -> Checkpoint | None:
        """Anchors the fold with a full belief base.

        Taken before the first entry -- the initial beliefs arrive through
        bb.add() from the .mas2i loader and never pass brf, so without this
        there is nothing to fold onto -- and then every `checkpoint_every`
        deltas.
        """
        if self._beliefs_source is None:
            return None
        # ag: stripped the same way record_belief_change() strips a delta --
        # beliefs_at() diffs these two sources of text against each other by
        # exact match, so a belief carrying llm_call(...) here and stripped
        # there would never cancel out
        beliefs = tuple(sorted(str(strip_call_annot(belief)) for belief in self._beliefs_source()))
        with self._lock:
            mark = Checkpoint(seq=self._next_seq, cycle=self.cycle(), beliefs=beliefs)
            self._checkpoints.append(mark)
            self._deltas_since_checkpoint = 0
        self.record(JournalKind.BB_CHECKPOINT, beliefs=len(beliefs))
        return mark

    # ---- compaction --------------------------------------------------------

    def _compact(self, before_cycle: int) -> None:
        """Folds every cycle older than `before_cycle` into a single entry.

        ag: this is lossless for everything the journal actually promises, and
        the reason is the query granularity. `beliefs_at()` answers per cycle,
        so the intermediate belief states WITHIN a cycle were never observable
        -- merging that cycle's deltas into one net pair therefore cannot
        change any answer. The merge is also idempotent (the merged added and
        deleted sets are disjoint by construction), so a checkpoint that
        happens to sit mid-cycle stays consistent when the whole cycle's delta
        is applied on top of it.
        """
        with self._lock:
            if not self._entries or self._entries[0].cycle >= before_cycle:
                return
            compacted: deque[JournalEntry] = deque(maxlen=self._capacity)
            group: list[JournalEntry] = []
            for entry in self._entries:
                stale = entry.cycle < before_cycle and entry.kind is not JournalKind.CYCLE
                if group and (not stale or group[0].cycle != entry.cycle):
                    compacted.append(_fold_cycle(group))
                    group = []
                if stale:
                    group.append(entry)
                else:
                    compacted.append(entry)
            if group:
                compacted.append(_fold_cycle(group))
            self._entries = compacted

    # ---- reading -----------------------------------------------------------

    def window(self, n: int | None = None,
               kinds: Sequence[JournalKind] | None = None) -> list[JournalEntry]:
        """The last `n` entries of the given kinds, oldest first."""
        with self._lock:
            entries = list(self._entries)
        if kinds is not None:
            wanted = set(kinds)
            entries = [e for e in entries if e.kind in wanted]
        return entries if n is None else entries[-n:]

    def beliefs_at(self, cycle: int | None = None) -> list[str] | None:
        """The belief base as it stood at the end of `cycle`, or None when it
        can no longer be reconstructed.

        None is a real answer and callers must render it as one ("I no longer
        know what I believed then"), never fall back to the current beliefs.
        """
        cycle = self.cycle() if cycle is None else cycle
        with self._lock:
            checkpoints = list(self._checkpoints)
            entries = list(self._entries)
            lost = self._lost_delta_seq
        # the newest anchor that is both old enough to cover the question and
        # young enough that no delta after it has been evicted
        anchor = next((c for c in reversed(checkpoints)
                       if c.cycle <= cycle and c.seq > lost), None)
        if anchor is None:
            return None
        beliefs = list(anchor.beliefs)
        for entry in entries:
            if entry.kind not in DELTA_KINDS or entry.cycle > cycle:
                continue
            # ag: a compacted cycle is compared by cycle, not by seq. It keeps
            # the FIRST seq of the group it folded, so an anchor taken midway
            # through that cycle would look newer than the whole entry and skip
            # it -- losing the half of the cycle that came after the anchor.
            # Comparing by cycle re-applies the cycle's whole net delta on top
            # of that anchor instead, which lands on the same end-of-cycle
            # state because the merged delta is idempotent (its added and
            # deleted sets are disjoint by construction).
            if entry.kind is JournalKind.CYCLE:
                if entry.cycle < anchor.cycle:
                    continue
            elif entry.seq < anchor.seq:
                continue
            entry_added, entry_deleted = _delta_of(entry)
            for text in entry_deleted:
                if text in beliefs:
                    beliefs.remove(text)
            for text in entry_added:
                if text not in beliefs:
                    beliefs.append(text)
        return sorted(beliefs)

    def recall(self, cycle: int | None = None) -> dict:
        """Everything this agent can say about one cycle: what it deliberated,
        what the model thought if a model was involved, what it believed."""
        cycle = self.cycle() if cycle is None else cycle
        entries = [e for e in self.window() if e.cycle == cycle]
        return {
            "cycle": cycle,
            "deliberations": [e.detail for e in entries if e.kind is JournalKind.DELIBERATE],
            "llm_choices": [e.detail for e in entries if e.kind is JournalKind.LLM_CHOICE],
            "events": [{"kind": str(e.kind), **e.detail} for e in entries
                       if e.kind not in (JournalKind.DELIBERATE, JournalKind.LLM_CHOICE)],
            "beliefs": self.beliefs_at(cycle),
        }

    def render(self, n: int | None = 40, kinds: Sequence[JournalKind] | None = NARRATIVE_KINDS,
               budget_chars: int = 2000, beliefs: bool = True, history: bool = True,
               where: Callable[[JournalEntry], bool] | None = None,
               title: str = "What has happened so far") -> str:
        """The journal as prose, for a prompt: one paragraph per reasoning
        cycle, each starting "on cycle N: ...".

        `history` and `beliefs` switch the two halves independently, and with
        both off this renders nothing at all -- "" rather than a heading over
        an empty section, so prompts.session_system drops the part entirely.
        An agent can now be given its beliefs with no past (a model that
        should decide from the current state and not from how it got there) or
        its past with no beliefs (where a RAG grounding section says what is
        relevant instead of listing everything). Both were unsayable while the
        two travelled together.

        Truncation is always declared. A model handed a silently shortened
        history will reason as though it had the whole thing. `n` now bounds
        cycle-paragraphs, not raw entries -- grouping made the old per-entry
        count meaningless as a window size.

        `where`, when given, keeps only the entries it accepts. It exists for
        one caller -- a generation round hiding the turns of the OTHER
        conversations the agent has open, which read as questions nobody
        answered and get answered by the wrong session (see Agentic._preamble).
        Entries dropped this way are counted as not shown, like any other cut.

        `title` names the section. A parameter rather than a constant because
        the same method now serves two readers with different questions: a
        session asking "what has this agent been doing" and a conversation
        asking "what had been said before I started". Handing the second one a
        heading that promises everything, over a `kinds` filter that gives it
        five, would be the silent shortening the paragraph above rules out.
        """
        if not history and not beliefs:
            return ""

        available = [] if not history else self.window(n=None, kinds=kinds)
        if where is not None:
            available = [e for e in available if where(e)]

        # cycle numbers are monotonic and never split across a compaction
        # boundary (_compact folds a whole cycle into one CYCLE entry or
        # leaves it entirely raw), so one linear groupby pass is enough
        groups: list[tuple[int, str]] = []
        for cycle, group in itertools.groupby(available, key=lambda e: e.cycle):
            text = render_cycle_group(cycle, list(group))
            if text:
                groups.append((cycle, text))
        if n is not None:
            groups = groups[-n:]

        paragraphs: list[str] = []
        used = 0
        for cycle, text in reversed(groups):  # newest first, so the budget keeps the recent past
            if used + len(text) > budget_chars and paragraphs:
                break
            paragraphs.append(text)
            used += len(text)
        paragraphs.reverse()

        out: list[str] = []
        if history:
            out += [
                f"## {title}",
                f"We are at cycle {self.cycle()} now. Each paragraph below is one "
                f"earlier reasoning cycle, named \"on cycle N\".",
            ]
            # ag: two different things happen to old memories and only one is
            # loss. Compaction FADES a cycle -- folded into a paragraph, still
            # there, still foldable into beliefs_at(). Eviction FORGETS it.
            # Compaction keeps the first seq of the group it folds, so the
            # oldest surviving entry always carries the smallest seq it stands
            # for: seq 0 still present means nothing has been forgotten,
            # exactly, with nothing to keep count of.
            with self._lock:
                forgotten = bool(self._entries) and self._entries[0].seq > 0
            cut = len(groups) - len(paragraphs)
            if cut > 0:
                out.append(f"(... {cut} earlier cycle(s) not shown ...)")
            if forgotten:
                out.append("(... older history has been forgotten ...)")
            out.extend(paragraphs or ["(nothing yet)"])

        if beliefs:
            current = self.beliefs_at()
            if history:  # blank line only between two sections, not above one
                out.append("")
            out.append("## What I believe now")
            if current is None:
                out.append("(no longer reconstructable)")
            elif not current:
                out.append("(nothing)")
            else:
                out.extend(current)
        return "\n".join(out)


def _delta_of(entry: JournalEntry) -> tuple[list[str], list[str]]:
    """The (added, deleted) an entry carries, or two empty lists."""
    return (json.loads(entry.detail.get("added", "[]")),
            json.loads(entry.detail.get("deleted", "[]")))


def _fold_cycle(group: list[JournalEntry]) -> JournalEntry:
    """One cycle's entries as a single CYCLE entry: the lines rendered once and
    kept as text, and the belief changes merged into one net pair."""
    added: list[str] = []
    deleted: list[str] = []
    for entry in group:
        if entry.kind not in DELTA_KINDS:
            continue
        # order matters: a cycle that deleted then re-added a belief ends with
        # it present, and the reverse ends with it absent
        entry_added, entry_deleted = _delta_of(entry)
        for text in entry_deleted:
            if text in added:
                added.remove(text)
            if text not in deleted:
                deleted.append(text)
        for text in entry_added:
            if text in deleted:
                deleted.remove(text)
            if text not in added:
                added.append(text)
    # only the narrative kinds get rendered into the summary: a bookkeeping
    # entry like BB_CHECKPOINT is filtered out of a normal render and must not
    # sneak back in through a CYCLE, which IS narrative. Same composer as a
    # live cycle, so a folded old cycle and a fresh one read identically.
    narrative = [e for e in group if e.kind in NARRATIVE_KINDS]
    summary = render_cycle_group(group[0].cycle, narrative) if narrative else ""
    return JournalEntry(
        seq=group[0].seq, cycle=group[0].cycle, kind=JournalKind.CYCLE,
        detail={"summary": summary,
                "added": json.dumps(added), "deleted": json.dumps(deleted)},
    )

from __future__ import annotations

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.stdlib.registry import internal_action


@internal_action(min_args=2, max_args=2)
def eval(ts, un, args) -> bool:
    """.eval(Result, Query): Result unifies with the atom true/false
    depending on whether Query has at least one solution (no backtracking,
    no bindings from Query itself leak out)."""
    agent = ts.ag if ts is not None else None
    has_solution = next(args[1].logical_consequence(agent, un.clone()), None) is not None
    return un.unifies(args[0], Atom("true") if has_solution else Atom("false"))


@internal_action(min_args=2, max_args=2)
def count(ts, un, args) -> bool:
    """.count(Query, N): N unifies with the number of solutions of Query."""
    agent = ts.ag if ts is not None else None
    n = sum(1 for _ in args[0].logical_consequence(agent, un.clone()))
    return un.unifies(args[1], NumberTermImpl(n))


@internal_action(min_args=3, max_args=3)
def findall(ts, un, args) -> bool:
    """.findall(Template, Query, List): List collects Template resolved
    under every solution of Query, in solution order, keeping duplicates."""
    template, query, result_arg = args
    agent = ts.ag if ts is not None else None
    result = ListTerm()
    for candidate_un in query.logical_consequence(agent, un):
        result.append(template.resolve(candidate_un))
    return un.unifies(result_arg, result)


@internal_action(min_args=3, max_args=3)
def setof(ts, un, args) -> bool:
    """.setof(Template, Query, List): as .findall, but sorted and
    duplicate-free (Term's natural order) -- NOT Prolog's real setof/3
    (no existential-variable grouping), matching Jason's own simplification."""
    template, query, result_arg = args
    agent = ts.ag if ts is not None else None
    values = {template.resolve(candidate_un) for candidate_un in query.logical_consequence(agent, un)}
    result = ListTerm()
    result.extend(sorted(values))
    return un.unifies(result_arg, result)
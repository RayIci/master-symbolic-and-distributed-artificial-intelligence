from __future__ import annotations

import logging

from icaros.as_semantics.event import Event
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.string_term import StringTerm
from icaros.as_syntax.trigger import TEType, Trigger
from icaros.bb.belief_base import BeliefBase
from icaros.stdlib.internal_actions.console import _args_to_string
from icaros.stdlib.registry import internal_action

# ag: Jason's own version string is a constant baked in at build time
# (Config.getJasonVersion()), not a live read of anything -- same approach
# here. importlib.metadata.version("icaros") raises PackageNotFoundError
# in this dev checkout (not installed as a discoverable package), so a
# constant (kept in sync with pyproject.toml by hand) is the simplest
# faithful equivalent, not a workaround.
_VERSION = "icaros 0.1.0"


@internal_action(min_args=0, max_args=None)
def fail(ts, un, args) -> bool:
    """.fail / .fail(arg0, ...): fails the intention where it is run. With
    no arguments, a plain failure (routes through the existing generic IA-
    failure handling, which already turns a False/exception result into a
    goal-deletion event with error_annots("ia_failed", ...)).
    ag: Java's richer N-arg form pulls a message out of an error_msg(...)
    structure and attaches the other args as separate error annotations --
    simplified here to one combined message (same _args_to_string rule
    .println/.log already use) raised as a plain exception, which the
    existing generic path already wraps the same way; no new
    annotation-carrying exception type for this rare case."""
    if not args:
        return False
    raise ValueError(_args_to_string(args))


@internal_action(name="signal", min_args=1, max_args=2)
def signal(ts, un, args) -> bool:
    """.signal(Trigger[, type_signal]): adds Trigger straight into the event
    queue, e.g. .signal({+t}), .signal({+!t}) -- same Trigger.try_to_get_trigger
    parsing .wait/.at already use (raising ValueError on an unrecognised
    shape, improving on Jason's silent NPE there). With a 2nd argument equal
    to the atom `type_signal`, the trigger's type is forced to TEType.SIGNAL
    (already used elsewhere, e.g. incoming "signal" messages) and a `signal`
    annotation is added to its literal -- Java double-marks it the same way.
    The resulting event is never tied to any intention (Trigger.EmptyInt in
    Java), matching .at."""
    trigger = Trigger.try_to_get_trigger(args[0])
    if trigger is None:
        raise ValueError(".signal: first argument must be a trigger")

    if len(args) == 2 and args[1] == Atom("type_signal"):
        trigger.type = TEType.SIGNAL
        trigger.literal.add_annot(Atom("signal"))

    if not trigger.literal.has_source():
        trigger.literal.add_annot(BeliefBase.self_source_term)

    ts.circumstance.add_event(Event(trigger, None))
    return True


_LOG_LEVELS = {
    "severe": logging.ERROR,
    "warning": logging.WARNING,
    "fine": logging.DEBUG,
    "finer": logging.DEBUG,
    "finest": logging.DEBUG,
}


def _agent_logger(ts) -> logging.Logger:
    return logging.getLogger(f"icaros.agent.{ts.ag_arch.ag_name}")


@internal_action(name="log", min_args=1, max_args=None)
def log(ts, un, args) -> bool:
    """.log(level, arg0, ...): logs the concatenation of the remaining args
    (same rule .println/.printf use) at the given level. Unlike Jason
    (java.util.logging FINE/FINER/FINEST, no true INFO-vs-everything-else
    validation), any level atom other than severe/warning/fine/finer/finest
    -- including "info" itself, or a typo -- silently maps to INFO, a
    faithfully preserved quirk. Falls back to plain print() when there's no
    agent context (ts is None), same convention used elsewhere in stdlib."""
    level = _LOG_LEVELS.get(str(args[0]), logging.INFO)
    text = _args_to_string(args[1:])
    if ts is None:
        print(text)
        return True
    _agent_logger(ts).log(level, text)
    return True


_VERBOSE_LEVELS = {0: logging.WARNING, 1: logging.INFO, 2: logging.DEBUG}


@internal_action(name="verbose", min_args=1, max_args=1)
def verbose(ts, un, args) -> bool:
    """.verbose(N): sets this agent's own logger level (0=warning,
    1=info, 2=debug -- collapsing Java's 3-way FINE/FINER/FINEST onto
    Python's single DEBUG, since finer-grained sub-DEBUG levels don't
    exist here).
    ag: Java stores this on a per-agent Settings object (which also
    controls other things, e.g. verbosity of the console); icaros has no
    Settings class at all yet, so this sets the logger level directly
    rather than introducing one just for this."""
    n = int(args[0].solve())
    _agent_logger(ts).setLevel(_VERBOSE_LEVELS.get(n, logging.INFO))
    return True


@internal_action(name="version", min_args=1, max_args=1)
def version(ts, un, args) -> bool:
    """.version(V): unifies V with icaros's version string."""
    return un.unifies(args[0], StringTerm(_VERSION))
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_semantics.message import Message
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.var_term import VarTerm
from icaros.stdlib.internal_actions._scheduling import schedule
from icaros.stdlib.registry import InternalAction, internal_action

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term


@internal_action(name="broadcast", min_args=2, max_args=2, use_in_context=False)
def broadcast(ts, un, args) -> bool:
    """.broadcast(Performative, Content): sends a message with every other
    known agent as receiver (Runner.agent_names(), self excluded)."""
    ilf, content = args
    msg = Message(str(ilf), ts.ag_arch.ag_name, None, content)
    ts.ag_arch.broadcast(msg)
    return True


class Send(InternalAction):
    """.send(Receiver, Performative, Content[, Answer[, Timeout]]): sends a
    message to Receiver (an atom/string, or a list -- one Message per
    recipient, same msg id). "self" as receiver is replaced with the
    caller's own name.

    A class, not a plain function, because a synchronous ask (Performative
    is an ask AND a 4th argument is given) must suspend the calling
    intention until the reply arrives -- suspend_intention() has to report
    True only for that specific call, never for the other forms (plain
    send, or a tell/untell carrying a reply-to id as its 4th argument) --
    same per-call dynamic-flag need already solved for .suspend, safe here
    too thanks to the per-agent new_instance() isolation.

    Most of the reply-handling machinery this relies on already exists and
    is already wired into the reasoning cycle: TransitionSystem._process_ask_reply/
    resume_sync_ask_intention (transition_system.py) expect the call term
    itself to have exactly this shape (get_term(0)=Receiver, get_term(1)=
    Performative, get_term(3)=Answer) -- .send only has to build the
    Message and register the pending intention, not reimplement any of
    that."""

    name = ".send"

    def __init__(self):
        self._suspend_intention = False

    def prepare_arguments(self, body, un):
        return [t.resolve(un) for t in body.get_terms() or []]

    def execute(self, ts, un, args) -> bool:
        if not (3 <= len(args) <= 5):
            raise ValueError(f"internal action '.send' called with {len(args)} argument(s), expected 3 to 5")

        receiver, ilf_term, content = args[0], args[1], args[2]
        answer_var: Term | None = args[3] if len(args) >= 4 else None
        timeout: Term | None = args[4] if len(args) == 5 else None

        msg = Message(str(ilf_term), ts.ag_arch.ag_name, None, content)
        sync_ask = msg.is_ask() and answer_var is not None
        if sync_ask:
            msg.set_sync_ask_msg_id()
        elif answer_var is not None:
            # tell/untell/unknown performative: the 4th arg is a reply-to id,
            # not an answer var -- used to manually answer a received ask.
            msg.in_reply_to = str(answer_var)

        intention = ts.circumstance.selected_intention
        if sync_ask and intention is not None:
            ts.circumstance.add_pending_intention(msg.id, intention, Atom("waiting_ask"), suspend=False)

        receivers = receiver.get_as_list() if receiver.is_list() else [receiver]
        for r in receivers:
            msg.receiver = ts.ag_arch.ag_name if str(r) == "self" else str(r)
            ts.ag_arch.send_msg(msg)

        if sync_ask and timeout is not None and intention is not None:
            delay_ms = timeout.solve()
            msg_id = msg.id

            def on_timeout() -> None:
                # guard BEFORE touching intention state: if the real reply
                # already resumed it, the intention may already be finished
                # (empty stack) -- peek() would crash on a stale reference.
                if ts.circumstance.pending_intentions.get(msg_id) is not intention:
                    return
                answers_var = VarTerm(f"AnsList___{msg_id}")
                partial = intention.peek().unifier.get(answers_var)
                fallback = partial if partial is not None else Atom("timeout")
                ts.resume_sync_ask_intention(msg_id, answer_var, fallback)

            schedule(ts, delay_ms, on_timeout)

        self._suspend_intention = sync_ask
        return True

    def suspend_intention(self) -> bool:
        return self._suspend_intention

    def can_be_used_in_context(self) -> bool:
        return False

    def new_instance(self) -> Send:
        return Send()


send = Send()
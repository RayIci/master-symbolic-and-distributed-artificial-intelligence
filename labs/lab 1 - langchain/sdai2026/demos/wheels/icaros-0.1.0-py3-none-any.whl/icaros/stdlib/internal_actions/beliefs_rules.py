from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.list_term import ListTerm
from icaros.stdlib.internal_actions.console import _write
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.unifier import Unifier


@internal_action(min_args=1, max_args=1)
def belief(ts, un, args) -> Iterator[Unifier]:
    """.belief(Pattern): backtracks over every stored belief unifying with
    Pattern (facts only -- rules are skipped, except trivial "fact-like"
    rules whose body is literally `true`, matching Jason)."""
    pattern = args[0]
    candidates = ts.ag.bb.get_candidate_beliefs_for_literal(pattern, un)
    if candidates is None:
        return
    for candidate in candidates:
        if candidate.is_rule() and str(candidate.get_body()) != "true":
            continue
        c = un.clone()
        if c.unifies_no_undo(pattern, candidate):
            yield c


@internal_action(name="list_rules", min_args=0, max_args=0)
def list_rules(ts, un, args) -> bool:
    """.list_rules: prints every rule in the belief base."""
    for b in ts.ag.bb:
        if b.is_rule():
            _write(ts, str(b) + "\n")
    return True


@internal_action(name="relevant_rules", min_args=2, max_args=2)
def relevant_rules(ts, un, args) -> bool:
    """.relevant_rules(Pattern, Rules): Rules unifies with every rule (head
    :- body) whose head unifies with Pattern."""
    pattern = args[0]
    result = ListTerm()
    candidates = ts.ag.bb.get_candidate_beliefs_for_literal(pattern, un)
    if candidates is not None:
        for candidate in candidates:
            if candidate.is_rule() and un.clone().unifies_no_undo(pattern, candidate):
                copy = candidate.copy()
                copy.del_sources()
                result.append(copy)
    return un.unifies(args[1], result)
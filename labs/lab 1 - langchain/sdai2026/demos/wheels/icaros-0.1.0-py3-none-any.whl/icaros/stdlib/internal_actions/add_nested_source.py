from __future__ import annotations

from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.pred import Pred
from icaros.as_syntax.term import Term
from icaros.stdlib.registry import internal_action


def add_annot_to_list(term: Term, source: Term) -> Term:
    """Return a copy of term annotated with source(s) nested inside the new source.

    a                -> a[source(jomi)]
    [a1,a2]          -> [a1[source(jomi)], a2[source(jomi)]]
    a[source(bob)]   -> a[source(jomi)[source(bob)]] - i.e., the source for jomi was bob
    """
    if term.is_list():
        result = ListTerm()
        for t in term:
            result.append(add_annot_to_list(t, source))
        return result
    elif term.is_literal():
        lit = term.force_full_literal_impl().copy()

        # create the source annots
        ts = Pred.create_source(source).add_annots(*lit.get_annots_by_functor("source"))

        lit.del_sources()
        lit.add_annot(ts)
        return lit
    else:
        return term


@internal_action(min_args=3, max_args=3)
def add_nested_source(ts, un, args) -> bool:
    """.add_nested_source(T, Source, R): as .add_annot, but nests any
    existing source(...) annotation inside the new one instead of
    discarding it (a[source(bob)] + jomi -> a[source(jomi)[source(bob)]])."""
    return un.unifies(args[2], add_annot_to_list(args[0], args[1]))
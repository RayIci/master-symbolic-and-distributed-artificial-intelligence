from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import create_structure
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.as_syntax.string_term import StringTerm
from icaros.stdlib.registry import InternalAction, internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


@internal_action(min_args=2, max_args=2)
def copy_term(ts, un, args) -> bool:
    """.copy_term(T, R): R unifies with T, all free variables renamed fresh
    (consistently: repeated occurrences of the same variable get the same
    fresh name)."""
    if not args[0].is_literal():
        raise ValueError("internal action '.copy_term': first argument must be a literal")
    return un.unifies(args[1], args[0].make_vars_annon())


class RenameApart(InternalAction):
    """.rename_apart(T, R): as copy_term, but T's argument is NOT pre-resolved
    against the caller's unifier (raw term), matching Jason's override of
    prepareArguments -- needed to rename apart a term whose variables might
    otherwise clash with the caller's own before they're even looked up."""
    name = ".rename_apart"

    def prepare_arguments(self, body, un):
        return body.get_terms()

    def execute(self, ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> bool:
        term = args[0]
        if term.is_var():
            looked_up = un.get(term)
            if looked_up is not None:
                term = looked_up
        return un.unifies(args[1], term.make_vars_annon())

    def suspend_intention(self) -> bool:
        return False

    def can_be_used_in_context(self) -> bool:
        return False

    def new_instance(self) -> RenameApart:
        # no instance state (no __init__) -- safe to share across agents.
        return self


rename_apart = RenameApart()


@internal_action(min_args=2, max_args=2)
def get_src_info(ts, un, args) -> bool:
    """.get_src_info(T, R): R is T with code_src(File)/code_line(N)
    annotations added (from T's own source-position info, if any)."""
    term = args[0]
    if term.is_plan_body():
        term = term.body_term
    if term is None or not term.is_literal():
        return False
    literal = term.resolve(un)
    src_info = literal.src_info
    code_src = StringTerm(src_info.source) if src_info is not None and src_info.source else Atom("no_code")
    code_line = NumberTermImpl(src_info.begin_src_line) if src_info is not None else Atom("no_code")
    if literal.get_annot("code_src") is None:
        literal.add_annot(create_structure("code_src", code_src))
    if literal.get_annot("code_line") is None:
        literal.add_annot(create_structure("code_line", code_line))
    return un.unifies(args[1], literal)


def _remove_source(term: Term) -> Term:
    if term.is_list():
        result = ListTerm()
        result.extend(_remove_source(t) for t in term)
        return result
    if term.is_literal():
        copy = term.copy()
        copy.del_sources()  # mutates in place, returns None (pred.py:324-328)
        return copy
    return term


@internal_action(min_args=2, max_args=2)
def remove_source_annot(ts, un, args) -> bool:
    """.remove_source_annot(T, R): R is T (or every element, if T is a list)
    with all source(...) annotations stripped."""
    return un.unifies(args[1], _remove_source(args[0]))


def _add_annot(term: Term, annot: Term) -> Term:
    if term.is_list():
        result = ListTerm()
        result.extend(_add_annot(t, annot) for t in term)
        return result
    if term.is_literal():
        return term.copy().add_annots(annot)
    return term


@internal_action(min_args=3, max_args=3)
def add_annot(ts, un, args) -> bool:
    """.add_annot(T, Annot, R): R is T (or every element, if T is a list)
    with Annot added as an extra annotation."""
    return un.unifies(args[2], _add_annot(args[0], args[1]))
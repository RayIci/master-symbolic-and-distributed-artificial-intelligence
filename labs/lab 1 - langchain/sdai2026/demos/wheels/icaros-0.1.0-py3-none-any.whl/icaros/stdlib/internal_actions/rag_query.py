from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.string_term import StringTerm
from icaros.bb.rag.rag_belief_base import RagBeliefBase
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term

# ag: semantic retrieval only, same contract as journal_query.py -- an
# ordinary internal action, not a private channel for the model: an agent
# with no LLM calls it from a plan like any other, and a model reaching it
# through tool-calling goes through the very same execute(). It answers "what
# do I believe, by meaning" rather than journal's "what happened" -- a
# different question, so it stays its own family (ToolKind.RAG) instead of
# riding along with journal.

RAG_ACTIONS = frozenset({".rag_search"})

_DEFAULT_K = 5


def _text(term: Term) -> str:
    return term.string if term.is_string() else str(term)


def _int(term: Term, default: int) -> int:
    try:
        return int(float(str(term)))
    except (TypeError, ValueError):
        return default


@internal_action(name=".rag_search", min_args=2, max_args=3, llm_tool=True)
def rag_search(ts, un: Unifier, args: list[Term]) -> bool:
    """.rag_search(+Query, [+K,] -Beliefs): the beliefs closest in meaning to Query.

    Semantic search over this agent's own belief base, for a question that
    reaches beyond the journal's tools: not what happened, but what is
    believed, found by meaning rather than by predicate name. FAILS when this
    agent's belief base has no semantic index to search -- it was not built
    with `belief_base_class: RagBeliefBase` in the .mas2i.

    @when a question is about the CONTENT of what the agent believes and you
        do not know, or cannot guess, the predicate name to look for
    @param Query:string what to search for, in plain language
    @param K:number how many beliefs to return, most relevant first (default 5)
    @param Beliefs the matching beliefs, most relevant first, as a list of strings
    """
    bb = ts.ag.bb
    if not isinstance(bb, RagBeliefBase):
        return False
    k = _int(args[1], _DEFAULT_K) if len(args) == 3 else _DEFAULT_K
    hits = bb.retrieve(_text(args[0]), k)
    return un.unifies(args[-1], ListTerm([StringTerm(hit.text) for hit in hits]))
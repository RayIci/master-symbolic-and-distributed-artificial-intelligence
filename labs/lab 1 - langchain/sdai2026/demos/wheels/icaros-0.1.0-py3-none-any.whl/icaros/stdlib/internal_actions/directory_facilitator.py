from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.list_term import ListTerm
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_syntax.term import Term


def _service_str(term: Term) -> str:
    return term.string if term.is_string() else str(term)


def _require_runner(ts: TransitionSystem | None, ia_name: str):
    if ts is None or ts.ag_arch.runner is None:
        raise ValueError(f"internal action '{ia_name}': no MAS runner available")
    return ts.ag_arch.runner


@internal_action(name="df_register", min_args=1, max_args=2, use_in_context=False)
def df_register(ts, un, args) -> bool:
    """.df_register(Service[, Type]): registers the calling agent as a
    provider of Service. Type is accepted but ignored (see
    runtime/directory_facilitator.py)."""
    runner = _require_runner(ts, ".df_register")
    service_type = _service_str(args[1]) if len(args) == 2 else None
    runner.df.register(ts.ag_arch.ag_name, _service_str(args[0]), service_type)
    return True


@internal_action(name="df_deregister", min_args=1, max_args=2, use_in_context=False)
def df_deregister(ts, un, args) -> bool:
    """.df_deregister(Service[, Type]): true iff the calling agent was
    registered as a provider of Service (and is now removed).
    ag: Jason's df_deregister always returns true unconditionally -- the
    real result is used here instead, same deliberate improvement already
    made for .set.remove."""
    runner = _require_runner(ts, ".df_deregister")
    service_type = _service_str(args[1]) if len(args) == 2 else None
    return runner.df.deregister(ts.ag_arch.ag_name, _service_str(args[0]), service_type)


@internal_action(name="df_search", min_args=2, max_args=3)
def df_search(ts, un, args) -> bool:
    """.df_search(Service[, Type], L): L unifies with the (sorted) names of
    every agent currently registered as a provider of Service. Type
    accepted but ignored (see runtime/directory_facilitator.py)."""
    runner = _require_runner(ts, ".df_search")
    service_type = _service_str(args[1]) if len(args) == 3 else None
    providers = runner.df.search(_service_str(args[0]), service_type)
    result = ListTerm()
    result.extend(Atom(name) for name in providers)
    return un.unifies(args[-1], result)


@internal_action(name="df_subscribe", min_args=1, max_args=2, use_in_context=False)
def df_subscribe(ts, un, args) -> bool:
    """.df_subscribe(Service[, Type]): subscribes the calling agent to be
    told (via a provider(Provider,Service) belief, source(df)) about every
    current and future provider of Service. Type accepted but ignored."""
    runner = _require_runner(ts, ".df_subscribe")
    service_type = _service_str(args[1]) if len(args) == 2 else None
    runner.df.subscribe(ts.ag_arch.ag_name, _service_str(args[0]), service_type)
    return True
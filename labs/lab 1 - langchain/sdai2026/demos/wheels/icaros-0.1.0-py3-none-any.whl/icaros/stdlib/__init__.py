# The stdlib internal actions/arithmetic functions are not imported here:
# load_internal_actions/load_arith_functions discover every module of this
# package on first use. Modules defining actions/functions must import the
# decorators from icaros.stdlib.registry/arith_registry (not from this
# package) to stay importable during that discovery.
from icaros.stdlib.arith_registry import arith_function, load_arith_functions
from icaros.stdlib.registry import internal_action, load_internal_actions

__all__ = ["internal_action", "load_internal_actions", "arith_function", "load_arith_functions"]
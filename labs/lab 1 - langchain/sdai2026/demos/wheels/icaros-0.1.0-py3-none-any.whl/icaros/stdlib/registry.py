from __future__ import annotations

import importlib
import importlib.util
import pkgutil
import re
from pathlib import Path
from types import ModuleType
from typing import TYPE_CHECKING, Protocol, runtime_checkable
from uuid import uuid4

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator

    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.term import Term

    IAResult = "bool | Iterator[Unifier]"
    IAFunction = Callable[["TransitionSystem | None", "Unifier", "list[Term]"], "IAResult"]


@runtime_checkable
class InternalAction(Protocol):
    """The contract TransitionSystem and InternalActionLiteral call internal
    actions through (Java's InternalAction interface). Anything satisfying it
    can be registered: decorated functions (FunctionIA) cover the common
    stateless case; actions needing state or dynamic suspension (.wait,
    .fork, ...) can be full classes.

    new_instance() is what gives every agent its own instance, mirroring
    Java (each Agent has its own, never-shared internalActions map): Agent.get_ia
    calls it unconditionally when populating its per-agent cache, so a stateful
    action (e.g. .random) can't accidentally end up shared across agents just
    because its author forgot to opt in -- the Protocol requires it from
    everyone. For actions with no instance state, `return self` is correct
    and free (see FunctionIA below).
    """

    name: str

    # ag: opt-in marker for stdlib/ia_tools.py -- whether this action may be
    # offered to the LLM as a callable tool. Default False, and deliberately
    # so: the stdlib has ~200 actions, and dumping all of them into a tool
    # list would bury whatever the agent's own goals are trying to say. A
    # class-level default here means hand-written InternalAction classes
    # satisfy the protocol without every one of them having to declare it.
    llm_tool: bool = False

    def execute(self, ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> IAResult:
        """Runs the action. True/False = success/failure; an Iterator[Unifier]
        yields the alternative solutions (e.g. .member)."""
        ...

    def prepare_arguments(self, body: Literal, un: Unifier) -> list[Term]:
        """Terms of the call literal with the unifier applied (Java's capply)."""
        ...

    def suspend_intention(self) -> bool: ...

    def can_be_used_in_context(self) -> bool: ...

    def new_instance(self) -> InternalAction:
        """A copy of this action to hand to one particular agent (Agent.get_ia).
        Stateless actions just return self."""
        ...


class FunctionIA(InternalAction):
    """Adapts a plain function `fn(ts, un, args)` to the InternalAction protocol,
    adding arity validation. Built by the @internal_action decorator."""

    def __init__(self, fn: IAFunction, name: str, min_args: int = 0, max_args: int | None = None,
                 suspend_intention: bool = False, use_in_context: bool = True,
                 llm_tool: bool = False):
        self._fn = fn
        self.name = name
        self._min_args = min_args
        self._max_args = max_args
        self._suspend_intention = suspend_intention
        self._use_in_context = use_in_context
        self.llm_tool = llm_tool
        self.__doc__ = fn.__doc__

    # ag: read by stdlib/ia_tools.py to type the action's parameters -- the
    # docstring's signature line names them, these bound the count.
    @property
    def min_args(self) -> int:
        return self._min_args

    @property
    def max_args(self) -> int | None:
        return self._max_args

    def prepare_arguments(self, body: Literal, un: Unifier) -> list[Term]:
        return [t.resolve(un) for t in body.get_terms() or []]

    def execute(self, ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> IAResult:
        n = len(args)
        if n < self._min_args or (self._max_args is not None and n > self._max_args):
            if self._max_args is None:
                expected = f"at least {self._min_args}"
            elif self._min_args == self._max_args:
                expected = str(self._min_args)
            else:
                expected = f"{self._min_args} to {self._max_args}"
            raise ValueError(f"internal action '{self.name}' called with {n} argument(s), expected {expected}")
        return self._fn(ts, un, args)

    def suspend_intention(self) -> bool:
        return self._suspend_intention

    def can_be_used_in_context(self) -> bool:
        return self._use_in_context

    def new_instance(self) -> FunctionIA:
        # no instance state beyond what's fixed at construction (the wrapped
        # fn and arity bounds, never mutated afterwards) -- safe to share.
        return self

    def __repr__(self) -> str:
        return f"<internal action '{self.name}'>"


def internal_action(fn: IAFunction | None = None, *, name: str | None = None,
                    min_args: int = 0, max_args: int | None = None,
                    suspend_intention: bool = False, use_in_context: bool = True,
                    llm_tool: bool = False):
    """Turns a function `fn(ts, un, args) -> bool | Iterator[Unifier]` into an
    internal action. Pure: no registration happens here -- load_internal_actions
    collects the decorated objects from their modules.

    `name` defaults to the function name without trailing underscores
    (`print_` -> ".print"); the leading dot is added if missing, so registry
    keys match the parsed functor. Project-specific internal actions
    (written for a single .mas2i project, e.g. under examples/) get
    discovered and, if defined in a subfolder of the project, reprefixed
    with that folder's name instead of a leading dot -- see
    mas2i/loader.py's _discover_project_internal_actions, not this decorator.

    `llm_tool=True` opts the action into being offered to the LLM as a
    callable tool (stdlib/ia_tools.py). It is off by default so the tool list
    stays a short, deliberate menu rather than the whole stdlib; the agent-side
    flag (Agent(ia_llm_tools=...)) still has to be on for it to have any effect.
    """
    def wrap(f: IAFunction) -> FunctionIA:
        ia_name = name if name is not None else f.__name__.rstrip("_")
        if not ia_name.startswith("."):
            ia_name = "." + ia_name
        return FunctionIA(f, ia_name, min_args, max_args, suspend_intention, use_in_context,
                          llm_tool)

    return wrap(fn) if fn is not None else wrap


def collect_internal_actions(module: ModuleType) -> dict[str, InternalAction]:
    # isinstance against the (runtime_checkable) protocol, not just FunctionIA,
    # so hand-written classes are discovered too, not just decorated functions --
    # either because they need a custom prepare_arguments (.rename_apart) or
    # because they hold real per-agent state (.random).
    return {ia.name: ia for ia in vars(module).values() if isinstance(ia, InternalAction)}


# ag: shared by load_internal_actions below and arith_registry.py's
# load_arith_functions -- both walk icaros.stdlib the same way, differing
# only in which collect_* function picks decorated objects out of each
# module. arith_registry.py imports this (one direction only, to avoid a
# circular import between the two registries).
def _discover(collect: Callable[[ModuleType], dict], extra_skip: tuple[str, ...] = ()) -> dict:
    import icaros.stdlib as stdlib_pkg
    found: dict = {}
    skip = {"registry", "arith_registry", *extra_skip}
    for info in pkgutil.walk_packages(stdlib_pkg.__path__, prefix=f"{stdlib_pkg.__name__}."):
        leaf = info.name.rsplit(".", 1)[-1]
        if leaf in skip or leaf.startswith("_"):
            continue
        module = importlib.import_module(info.name)
        found.update(collect(module))
    return found


_stdlib_actions: dict[str, InternalAction] | None = None


def load_internal_actions(extra_paths: Iterable[str | Path] | None = None) -> dict[str, InternalAction]:
    """All the available internal actions, keyed by functor (".print", ...).

    By default returns the stdlib actions, discovered by scanning every module
    of the icaros.stdlib package, recursively (e.g. stdlib/internal_actions/*.py),
    cached after the first call. `extra_paths` is a list of Python files
    defining further actions with @internal_action; they are loaded and
    merged on top, so they win over builtins of the same name (per-agent
    override is intentional).
    """
    global _stdlib_actions
    if _stdlib_actions is None:
        _stdlib_actions = _discover(collect_internal_actions)

    actions = dict(_stdlib_actions)
    for raw_path in extra_paths or ():
        path = Path(raw_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(f"internal actions file not found: '{raw_path}'")
        actions.update(collect_internal_actions(_module_from_file(path)))
    return actions


def _module_from_file(path: Path) -> ModuleType:
    module_name = f"icaros_actions_{path.stem}_{abs(hash(str(path))):x}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load internal actions from '{path}'")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        raise ImportError(f"error loading internal actions from '{path}': {e}") from e
    return module


# a name that is both a legal Python identifier and a legal file stem -- which
# is the same check twice, and the second one is the one that matters: `name`
# reaches here from a model, and it is about to become a path.
_ACTION_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def actions_from_source(code: str, name: str, *,
                        directory: Path | None = None) -> dict[str, InternalAction]:
    """The internal actions the Python in `code` defines, ready to register.

    Written for the burn rung of the Icaros scale, where a model authors an
    action the agent does not have (Agentic._run_control). It asks for a normal
    module with normal @internal_action decorators, and collects it with the
    same collect_internal_actions() every other action goes through -- so the
    model writes what a person would write, and there is no second format to
    keep working.

    With `directory`, the source is written to <directory>/<name>.py and loaded
    FROM THAT FILE: what runs and what is on disk are then the same thing by
    construction, rather than two things that agree until they do not. Without
    one, the module is built in memory and goes away with the process.

    Raises with a message meant to be read by whoever wrote the code -- a model,
    which gets it back as its next round's question and can act on it.
    """
    if not _ACTION_NAME_RE.match(name or ""):
        raise ValueError(f"'{name}' is not a usable action name: letters, digits and "
                         f"underscores only, not starting with a digit")

    if directory is not None:
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{name}.py"
        path.write_text(code)
        module = _module_from_file(path)
    else:
        module_name = f"icaros_generated_{name}_{uuid4().hex[:8]}"
        module = ModuleType(module_name)
        module.__dict__["__name__"] = module_name
        exec(compile(code, f"<icaros:{name}>", "exec"), module.__dict__)  # noqa: S102

    found = collect_internal_actions(module)
    if not found:
        raise ValueError("the code defines no internal action: it needs a function "
                         "decorated with @internal_action from icaros.stdlib.registry")
    expected = f".{name}"
    if expected not in found:
        raise ValueError(f"the code was announced as '{name}' but defines "
                         f"{', '.join(sorted(found))} -- the names have to match")
    return found
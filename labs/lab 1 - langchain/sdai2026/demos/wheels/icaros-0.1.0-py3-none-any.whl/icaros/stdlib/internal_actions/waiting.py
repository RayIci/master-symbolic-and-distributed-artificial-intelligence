from __future__ import annotations

import re
import time
from typing import TYPE_CHECKING

from icaros.as_semantics.circumstance_listener import CircumstanceListener
from icaros.as_semantics.event import Event
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import create_atom, create_literal, create_string, create_structure
from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.as_syntax.trigger import Trigger
from icaros.stdlib.internal_actions._scheduling import schedule
from icaros.stdlib.registry import InternalAction, internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.intention import Intention
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


_AT_UNITS = {
    "s": 1000, "second": 1000, "seconds": 1000,
    "m": 60000, "minute": 60000, "minutes": 60000,
    "h": 3600000, "hour": 3600000, "hours": 3600000,
    "d": 86400000, "day": 86400000, "days": 86400000,
}
_AT_TIME_RE = re.compile(r"^now\s*\+\s*(\d+)\s*([a-zA-Z]*)$")


def _parse_at_time(term: Term) -> float:
    text = (term.string if term.is_string() else str(term)).strip()
    match = _AT_TIME_RE.match(text)
    if not match:
        raise ValueError(
            f"internal action '.at': time format '{text}' is not implemented "
            "(only 'now + N [unit]' is supported, matching Jason)")
    amount = int(match.group(1))
    unit = match.group(2).lower()
    if not unit or unit == "ms":
        return amount
    if unit not in _AT_UNITS:
        raise ValueError(f"internal action '.at': unknown time unit '{unit}'")
    return amount * _AT_UNITS[unit]


@internal_action(name="at", min_args=2, max_args=2)
def at(ts, un, args) -> bool:
    """.at(Time, Event): schedules Event to be added to the event queue at
    Time (only "now + N [unit]" is implemented, unit in s/m/h/d, default
    ms -- faithful to Jason, which doesn't implement absolute/cron-style
    times either despite the class doc mentioning the unix `at` command).
    The new event is not tied to any existing intention (Java's
    Intention.EmptyInt)."""
    delay_ms = _parse_at_time(args[0])
    te = Trigger.try_to_get_trigger(args[1])
    if te is None:
        raise ValueError(".at: second argument must be a trigger")
    schedule(ts, delay_ms, lambda: ts.circumstance.add_event(Event(te.clone(), None)))
    return True


def _pending_reason(intention: Intention, trigger: Trigger | None, formula: Term | None,
                     timeout_ms: float | None) -> Term:
    # ag: mirrors Java's wait.java pendingReason -- a wait(Id) literal
    # annotated with whatever is actually being waited on, which is what
    # .suspended/2 and circumstance_query.py report back for it.
    reason = create_literal("wait", create_string(str(intention.id)))
    if trigger is not None:
        reason.add_annot(trigger.literal)
    elif formula is not None and formula.is_literal():
        reason.add_annot(formula)
    elif timeout_ms is not None:
        reason.add_annot(create_structure("time", NumberTermImpl(timeout_ms)))
    return reason


def _finish_wait(ts: TransitionSystem, pending_id: str, intention: Intention,
                  failed: bool, elapsed_var: Term | None, start: float) -> None:
    # guard: whichever of {event/formula satisfied, timeout fired} runs
    # first wins -- the other finds nothing left under pending_id and no-ops.
    if ts.circumstance.remove_pending_intention(pending_id) is not intention:
        return

    if failed:
        # ag: lazy import to avoid a cycle (transition_system.py pulls in
        # stdlib.internal_actions at module load, which pulls in this file).
        from icaros.as_semantics.transition_system import error_annots
        ts._generate_goal_deletion(intention, error_annots("wait_timeout", "timeout in .wait"),
                                    create_atom("wait_timeout"))
        return

    intention.peek().remove_current_step()
    if elapsed_var is not None:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        intention.peek().unifier.unifies(elapsed_var, NumberTermImpl(elapsed_ms))
    ts.circumstance.resume_intention(intention, Atom("wait_ia"))


class _WaitEvent(CircumstanceListener):
    """Listens on the Circumstance for the event/formula a .wait(E[,T[,Elapsed]])
    call is waiting on, resuming the calling intention the instant a
    relevant change makes the condition true -- mirrors Java's wait.java
    WaitEvent, a CircumstanceListener registered for exactly this one wait.

    ag: only reacts to a NEW matching event, not to one already sitting
    unconsumed in the event queue at construction time -- faithful to
    Java, which only pre-checks the belief-condition shortcut (see
    Wait.execute) and never scans existing events for a trigger-based wait."""

    def __init__(self, ts: TransitionSystem, intention: Intention, trigger: Trigger | None,
                 formula: Term | None, un: Unifier, timeout_ms: float | None,
                 elapsed_var: Term | None, fail_on_timeout: bool) -> None:
        self._ts = ts
        self._circumstance = ts.circumstance
        self._intention = intention
        self._trigger = trigger
        self._formula = formula
        self._un = un
        self._elapsed_var = elapsed_var
        self._fail_on_timeout = fail_on_timeout
        self._start = time.monotonic()
        self._dropped = False
        self._pending_id = f"wait-{intention.id}"

        self._circumstance.add_event_listener(self)
        reason = _pending_reason(intention, trigger, formula, timeout_ms)
        self._circumstance.add_pending_intention(self._pending_id, intention, reason, suspend=False)

        if timeout_ms is not None:
            schedule(ts, timeout_ms, lambda: self.resume(by_timeout=True))

    def _condition_met(self) -> bool:
        consequences = self._formula.logical_consequence(self._ts.ag, self._un)
        return next(consequences, None) is not None

    def _test_resume_condition(self, event: Event | None) -> None:
        if event is not None and self._trigger is not None and self._un.unifies(self._trigger, event.trigger):
            self.resume(by_timeout=False)
        elif self._formula is not None and self._condition_met():
            self.resume(by_timeout=False)

    def event_added(self, event: Event) -> None:
        if self._dropped:
            return
        self._test_resume_condition(event)

    def intention_added(self, intention: Intention) -> None:
        self._test_resume_condition(None)

    def intention_suspended(self, trigger: Trigger | None, intention: Intention | None,
                             reason: Term | None) -> None:
        self._test_resume_condition(None)

    def intention_waiting(self, intention: Intention, reason: Term | None) -> None:
        self._test_resume_condition(None)

    def intention_resumed(self, intention: Intention, reason: Term | None) -> None:
        self._test_resume_condition(None)

    def intention_executing(self, intention: Intention, reason: Term | None) -> None:
        self._test_resume_condition(None)

    def intention_dropped(self, intention: Intention) -> None:
        if intention is self._intention:
            self._dropped = True
            self.resume(by_timeout=False)
        else:
            self._test_resume_condition(None)

    def resume(self, by_timeout: bool) -> None:
        # ag: deregister synchronously (so a listener still mid-notify-loop
        # elsewhere can't reach this again), then defer the actual
        # Circumstance/Intention mutation to the top of the next cycle --
        # matches Java's own comment ("invoke changes in C latter, so to
        # avoid concurrent changes in C"). For the timeout path this is a
        # second hop on top of schedule()'s own defer (one extra cycle of
        # latency); accepted for having a single resume path instead of
        # two.
        self._circumstance.remove_event_listener(self)
        failed = by_timeout and self._fail_on_timeout
        self._ts.run_at_begin_of_next_cycle(lambda: _finish_wait(
            self._ts, self._pending_id, self._intention,
            failed=failed, elapsed_var=self._elapsed_var, start=self._start))


class Wait(InternalAction):
    """.wait(T) / .wait(E) / .wait(E,T) / .wait(E,T,ElapsedTime): suspends
    the calling intention until T milliseconds elapse and/or E (a trigger
    like {+g}/{+!g}, or a belief-condition formula) becomes true.

    With only E (no T): waits forever for the event/formula, no timeout.
    With E and T (2 args): times out by FAILING the current goal. With
    ElapsedTime too (3 args): times out WITHOUT failing, just resumes and
    unifies the elapsed time.

    Resumption is event-driven, via a _WaitEvent CircumstanceListener --
    a matching event/formula is caught the instant it happens rather than
    on the next per-cycle recheck; the actual resumption still runs at the
    top of the following cycle (run_at_begin_of_next_cycle, to avoid
    mutating the Circumstance from inside its own notify loop). One
    consequence: a non-empty _tasks_for_begin_of_cycle used to keep the
    agent from ever sleeping while a .wait(E) was outstanding; now the
    agent CAN sleep, waking again within MAX_SLEEP (ag_arch.py) even if
    nothing else wakes it sooner -- so a percept-only condition (nothing
    calls wake_up_sense/act for it) can take up to MAX_SLEEP to be noticed.

    A class (not a plain function) because it always suspends the calling
    intention -- suspend_intention() must dynamically report True/False
    depending on whether a belief-condition already held immediately (no
    suspension needed at all in that case)."""

    name = ".wait"

    def __init__(self):
        self._suspend_intention = False

    def prepare_arguments(self, body, un):
        return [t.resolve(un) for t in body.get_terms() or []]

    def execute(self, ts, un, args) -> bool:
        if not (1 <= len(args) <= 3):
            raise ValueError(f"internal action '.wait' called with {len(args)} argument(s), expected 1 to 3")

        intention = ts.circumstance.selected_intention
        if intention is None:
            self._suspend_intention = False
            return True

        if len(args) == 1 and args[0].is_numeric():
            # ag: a pure time-based wait has nothing to listen for, so it
            # skips _WaitEvent entirely -- registering a CircumstanceListener
            # that would never fire is pure overhead on the notify hot path.
            self._suspend_intention = True
            timeout_ms = args[0].solve()
            pending_id = f"wait-{intention.id}"
            reason = _pending_reason(intention, None, None, timeout_ms)
            ts.circumstance.add_pending_intention(pending_id, intention, reason, suspend=False)
            schedule(ts, timeout_ms, lambda: _finish_wait(
                ts, pending_id, intention, failed=False, elapsed_var=None, start=time.monotonic()))
            return True

        event_or_formula = args[0]
        timeout_ms = args[1].solve() if len(args) >= 2 else None
        elapsed_var = args[2] if len(args) == 3 else None
        fail_on_timeout = len(args) == 2

        trigger = Trigger.try_to_get_trigger(event_or_formula)
        formula = None

        if trigger is None:
            formula = event_or_formula
            consequences = formula.logical_consequence(ts.ag, un)
            first = next(consequences, None) if consequences is not None else None
            if first is not None:
                # belief-condition already holds -- no suspension at all
                self._suspend_intention = False
                return True

        self._suspend_intention = True
        _WaitEvent(ts, intention, trigger, formula, un, timeout_ms, elapsed_var, fail_on_timeout)
        return True

    def suspend_intention(self) -> bool:
        return self._suspend_intention

    def can_be_used_in_context(self) -> bool:
        return False

    def new_instance(self) -> Wait:
        return Wait()


wait = Wait()
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


@internal_action(name="namespace_set_prop", min_args=3, max_args=3)
def namespace_set_prop(ts, un, args) -> bool:
    """.namespace_set_prop(NS, Key, Value): sets a property Key=Value on
    namespace NS (creating the property if new, overwriting it otherwise)."""
    if not args[0].is_atom():
        raise ValueError("internal action '.namespace_set_prop': first argument must be an atom (a namespace)")
    ts.ag.bb.set_namespace_prop(args[0], args[1], args[2])
    return True


@internal_action(name="namespace_get_prop", min_args=2, max_args=4)
def namespace_get_prop(ts, un, args) -> bool | Iterator[Unifier]:
    """.namespace_get_prop(NS, Key, Value[, Default]): with Key bound, Value
    unifies with the property stored under Key on namespace NS, or with
    Default if given and Key is unknown (false, with no Default, if Key is
    unknown). With Key a free var, backtracks over every known property of
    NS: .namespace_get_prop(NS, Key) over just the keys,
    .namespace_get_prop(NS, Key, Value) over key/value pairs.
    ag: Jason's namespace_get_prop.java falls through and succeeds without
    binding Value when Key is bound, unknown and no Default is given -- looks
    like a bug rather than an intended default, so here it's a plain False,
    matching the rest of the stdlib's "unknown key -> failure" convention."""
    if not args[0].is_atom():
        raise ValueError("internal action '.namespace_get_prop': first argument must be an atom (a namespace)")
    ns = args[0]

    if not args[1].is_var():
        if len(args) not in (3, 4):
            raise ValueError("internal action '.namespace_get_prop': Value argument required when Key is bound")
        value = ts.ag.bb.get_namespace_prop(ns, args[1])
        if value is not None:
            return un.unifies(args[2], value)
        if len(args) == 4:
            return un.unifies(args[2], args[3])
        return False

    if len(args) not in (2, 3):
        raise ValueError("internal action '.namespace_get_prop': incorrect argument shape (see documentation)")

    def solutions() -> Iterator[Unifier]:
        for key in ts.ag.bb.get_namespace_props(ns):
            candidate = un.clone()
            if not candidate.unifies_no_undo(args[1], key):
                continue
            if len(args) == 2:
                yield candidate
                continue
            value = ts.ag.bb.get_namespace_prop(ns, key)
            if candidate.unifies_no_undo(args[2], value):
                yield candidate

    return solutions()
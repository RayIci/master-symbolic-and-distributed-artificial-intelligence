from __future__ import annotations

import random as _random
from typing import TYPE_CHECKING

from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.stdlib.registry import InternalAction, internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.term import Term


class _Random(InternalAction):
    """.random(X)/.random(X,N): X unifies with a random float in [0,1), N times
    (default 1; 0 = unbounded, until the agent stops). .random(L,X)/.random(L,X,N):
    X unifies with a random element of list L, drawn (with repetition) N times.

    A class, not a plain @internal_action function, so each agent gets its own
    RNG: new_instance() (see registry.py/agent.py) is what Agent.get_ia calls to
    give this agent a private copy instead of the module-level default -- Jason
    gives each agent's own `.random` IA instance its own java.util.Random, and
    without this every agent would share one generator, with .set_random_seed
    reseeding everyone at once.
    """
    name = ".random"

    def __init__(self):
        self._rng = _random.Random()

    def prepare_arguments(self, body: Literal, un: Unifier) -> list[Term]:
        return [t.resolve(un) for t in body.get_terms() or []]

    def execute(self, ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> Iterator[Unifier]:
        as_list = args[0].is_list()
        if as_list:
            count_arg = args[2] if len(args) == 3 else None
        else:
            count_arg = args[1] if len(args) == 2 else None
        max_draws = int(count_arg.solve()) if count_arg is not None else 1

        if as_list and args[0].is_empty():
            return iter(())

        def solutions() -> Iterator[Unifier]:
            n = 0
            while (max_draws == 0 or n < max_draws) and (ts is None or ts.ag_arch.is_running()):
                n += 1
                candidate = un.clone()
                if as_list:
                    value = self._rng.choice(args[0].get_as_list())
                    ok = candidate.unifies_no_undo(args[1], value)
                else:
                    ok = candidate.unifies_no_undo(args[0], NumberTermImpl(self._rng.random()))
                if ok:
                    yield candidate

        return solutions()

    def suspend_intention(self) -> bool:
        return False

    def can_be_used_in_context(self) -> bool:
        return True

    def new_instance(self) -> _Random:
        return _Random()


random = _Random()


@internal_action(name="set_random_seed", min_args=1, max_args=1)
def set_random_seed(ts, un, args) -> bool:
    """.set_random_seed(N): seeds this agent's own .random generator (falls
    back to the shared module-level instance when called with ts=None,
    i.e. outside of any agent -- matches the ts-is-None convention used
    elsewhere, e.g. queries.py)."""
    target = ts.ag.get_ia(".random") if ts is not None else random
    target._rng.seed(int(args[0].solve()))
    return True


@internal_action(min_args=2, max_args=2)
def shuffle(ts, un, args) -> bool:
    """.shuffle(L, R): R is L with its elements in random order.
    ag: uses Python's own global `random` module state, NOT the `.random`/
    `set_random_seed` generator above -- faithfully replicates a Jason quirk
    (Collections.shuffle without an explicit Random is independent of the
    seeded generator random.java/set_random_seed controls)."""
    if not args[0].is_list():
        raise ValueError("internal action '.shuffle': first argument must be a list")
    import random as _global_random
    items = args[0].get_as_list()
    _global_random.shuffle(items)
    result = ListTerm()
    result.extend(items)
    return un.unifies(args[1], result)


@internal_action(min_args=3, max_args=4)
def range_(ts, un, args):
    """.range(X, Start, End, Step=1): X ranges inclusively from Start to End
    (backtracking) if a variable, or a ground membership check otherwise
    (Step is ignored in the ground-check case, matching Java)."""
    start = int(args[1].solve())
    end = int(args[2].solve())
    step = int(args[3].solve()) if len(args) == 4 else 1

    if not args[0].is_var():
        value = int(args[0].solve())
        return start <= value <= end

    def solutions() -> Iterator[Unifier]:
        value = start - step
        while (value + step <= end) if step > 0 else (value + step >= end):
            value += step
            candidate = un.clone()
            candidate.unifies_no_undo(args[0], NumberTermImpl(value))
            yield candidate

    return solutions()


def _extreme(ts, un, args, better) -> bool:
    if len(args) == 2:
        if not args[0].is_list():
            raise ValueError("internal action: first argument must be a list")
        items = args[0].get_as_list()
        if not items:
            return False
        result = items[0]
        for t in items[1:]:
            if better(t, result):
                result = t
        return un.unifies(args[1], result.clone())

    var, query, result_arg = args
    agent = ts.ag if ts is not None else None
    consequences = query.logical_consequence(agent, un)
    best = None
    for candidate_un in consequences:
        value = var.resolve(candidate_un)
        if best is None or better(value, best):
            best = value
    if best is None:
        return False
    return un.unifies(result_arg, best)


@internal_action(min_args=2, max_args=3)
def min_(ts, un, args) -> bool:
    """.min(L, R) or .min(X, Query, R): R is the smallest element/solution."""
    return _extreme(ts, un, args, lambda a, b: a < b)


@internal_action(min_args=2, max_args=3)
def max_(ts, un, args) -> bool:
    """.max(L, R) or .max(X, Query, R): R is the largest element/solution."""
    return _extreme(ts, un, args, lambda a, b: a > b)
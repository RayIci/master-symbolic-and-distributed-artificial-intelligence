from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_semantics.unifier import Unifier
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import parse_plan, parse_term
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.plan import Plan
from icaros.as_syntax.trigger import Trigger
from icaros.bb.belief_base import BeliefBase
from icaros.stdlib.internal_actions.console import _write
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.option import Option
    from icaros.as_syntax.term import Term


@internal_action(name="abolish", min_args=1, max_args=1)
def abolish(ts, un, args) -> bool:
    """.abolish(Pattern): removes every matching belief (any source, not
    just self -- Agent.abolish, already ported, is a faithful match of
    Java's own Agent.abolish and generates the usual -belief events)."""
    ts.ag.abolish(args[0], un)
    return True


def _assert_belief(ts, literal, add_end: bool, force_source: bool) -> bool:
    if force_source and not literal.has_source():
        literal.add_annot(BeliefBase.self_source_term)
    result = ts.ag.revise(literal, None, None, add_end=add_end)
    if result is not None:
        ts.update_belief_events(result, None)
    return True


@internal_action(name="asserta", min_args=1, max_args=1)
def asserta(ts, un, args) -> bool:
    """.asserta(Belief): adds Belief at the front of the belief base (Prolog-
    style assert), forcing source(self) if the belief has none."""
    return _assert_belief(ts, args[0], add_end=False, force_source=True)


@internal_action(name="assertz", min_args=1, max_args=1)
def assertz(ts, un, args) -> bool:
    """.assertz(Belief): as .asserta, but appends at the end.
    ag: unlike .asserta, Jason's own assertz does NOT force source(self) on
    a sourceless belief -- a real asymmetry in the Java source, not a typo
    here, preserved faithfully."""
    return _assert_belief(ts, args[0], add_end=True, force_source=False)


def _to_plan(term: Term) -> Plan:
    if isinstance(term, Plan):
        return term
    if term.is_string():
        # ag: Java's own "unescape" here is just deleting every backslash,
        # not a real escape-sequence decode -- preserved as-is.
        return parse_plan(term.string.replace("\\", ""))
    raise ValueError(".add_plan: each plan must be a plan term or a string")


def _plans_of(term: Term) -> list[Plan]:
    if term.is_list():
        return [_to_plan(t) for t in term.get_as_list()]
    return [_to_plan(term)]


@internal_action(name="add_plan", min_args=1, max_args=3)
def add_plan(ts, un, args) -> bool:
    """.add_plan(Plan(s) [, Source [, Position]]): adds plan(s) (a plan term,
    a string, or a list of either) to the plan library. Source defaults to
    self. Position: only the literal atom "begin" inserts at the front,
    anything else (including a typo) means the end -- fedele a Java. Note:
    with only 2 arguments, the second is always Source, never Position (no
    way to give Position without Source, same as Java)."""
    source = args[1] if len(args) >= 2 else BeliefBase.self_atom
    before = len(args) == 3 and str(args[2]) == "begin"
    for plan in _plans_of(args[0]):
        # ag: Java checks for the "l__" prefix, but PlanLibrary's own
        # auto-label prefix is "p__" -- a pre-existing Jason inconsistency,
        # preserved faithfully rather than "fixed" to match p__.
        if plan.label is not None and plan.label.functor.startswith("l__"):
            plan.del_label()
        ts.ag.pl.add(plan, source, before)
    return True


def _fix_label(term: Term) -> Term:
    if term.is_string() and term.string.startswith("@"):
        return parse_term(term.string[1:])
    return term


def _labels_of(term: Term) -> list[Term]:
    if isinstance(term, Plan):
        return [term.label]
    if term.is_list():
        result: list[Term] = []
        for t in term.get_as_list():
            result.extend(_labels_of(t))
        return result
    return [_fix_label(term)]


@internal_action(name="remove_plan", min_args=1, max_args=2)
def remove_plan(ts, un, args) -> bool:
    """.remove_plan(Label(s) [, Source]): removes plan(s) by label (an atom,
    a list of labels, or a Plan term -- uses its own label). A label given
    as a string starting with "@" is book-syntax convenience (e.g. "@l1"),
    stripped and reparsed as a term. Source defaults to self. Removal is
    reference-counted by source (PlanLibrary.remove, already ported) --
    never fails, even for a nonexistent label. No event is generated (plans
    aren't beliefs)."""
    source = args[1] if len(args) == 2 else BeliefBase.self_atom
    for label in _labels_of(args[0]):
        ts.ag.pl.remove(label, source)
    return True


def _as_plan_term(plan: Plan) -> Plan:
    p = plan.clone()
    p.is_plan_term = True
    p.make_vars_annon()
    return p


@internal_action(name="relevant_plan", min_args=2, max_args=2)
def relevant_plan(ts, un, args) -> bool | Iterator[Unifier]:
    """.relevant_plan(Trigger, PlanTerm): backtracking version of
    .relevant_plans -- yields one solution per plan in the library relevant
    to Trigger. Reverse mode: if Trigger is a free var and PlanTerm is
    already bound (a plan), just extracts and unifies its trigger directly,
    without consulting the plan library at all.
    ag: unlike .relevant_plans/.plan_label, the plan bound to PlanTerm here
    is the LIVE plan object, not a clone+anonymised copy -- verified as
    deliberate in Jason's own source (a commented-out anonymising line)."""
    trigger_arg, plan_arg = args
    if trigger_arg.is_var() and isinstance(plan_arg, Plan):
        return un.unifies(trigger_arg, plan_arg.trigger)

    te = Trigger.try_to_get_trigger(trigger_arg)
    if te is None:
        raise ValueError(".relevant_plan: first argument must be a trigger")
    candidates = ts.ag.pl.get_candidate_plans(te)
    if candidates is None:
        return False

    def solutions() -> Iterator[Unifier]:
        for plan in candidates:
            c = un.clone()
            if plan.is_relevant(te, c) is not None and c.unifies_no_undo(plan_arg, plan):
                yield c

    return solutions()


def _plans_and_labels(options: list[Option] | None) -> tuple[ListTerm, ListTerm]:
    plans = ListTerm()
    labels = ListTerm()
    for option in options or []:
        p = _as_plan_term(option.plan)
        plans.append(p)
        labels.append(p.label)
    return plans, labels


def _unify_plans_result(un: Unifier, args: list[Term], plans: ListTerm, labels: ListTerm) -> bool:
    result = un.unifies(args[1], plans)
    if result and len(args) == 3:
        result = un.unifies(args[2], labels)
    return result


@internal_action(name="relevant_plans", min_args=2, max_args=3)
def relevant_plans(ts, un, args) -> bool:
    """.relevant_plans(Trigger, -Plans [, -Labels]): Plans unifies with the
    list of every plan relevant to Trigger (cloned and with free vars
    anonymised, so they don't alias the caller's own unbound variables); if
    given, Labels unifies with the parallel list of their labels. A single
    deterministic result, not backtracking (unlike .relevant_plan)."""
    te = Trigger.try_to_get_trigger(args[0])
    if te is None:
        raise ValueError(".relevant_plans: first argument must be a trigger")
    plans, labels = _plans_and_labels(ts.ag.relevant_plans(te, None))
    return _unify_plans_result(un, args, plans, labels)


@internal_action(name="applicable_plans", min_args=2, max_args=3)
def applicable_plans(ts, un, args) -> bool:
    """.applicable_plans(Trigger, -Plans [, -Labels]): icaros-only
    extension, NOT present in Jason. Same shape as .relevant_plans, but
    filtered further down to plans whose context currently holds against
    the belief base -- reuses Agent.applicable_plans (already used
    internally by the reasoning cycle to go from relevant to applicable
    plans), so a caller can inspect "what could actually fire right now"
    without duplicating that filtering logic."""
    te = Trigger.try_to_get_trigger(args[0])
    if te is None:
        raise ValueError(".applicable_plans: first argument must be a trigger")
    plans, labels = _plans_and_labels(ts.ag.applicable_plans(ts.ag.relevant_plans(te, None)))
    return _unify_plans_result(un, args, plans, labels)


@internal_action(name="plan_label", min_args=2, max_args=2)
def plan_label(ts, un, args) -> bool | Iterator[Unifier]:
    """.plan_label(PlanTerm, Label): bidirectional. With PlanTerm a free var
    and Label bound, looks the plan up by label. With Label a free var and
    PlanTerm bound (a plan), just extracts its label directly (no library
    lookup, no cloning). Otherwise, backtracks over every plan in the
    library, unifying both Label and (a clone+anonymised) PlanTerm."""
    plan_arg, label_arg = args
    if plan_arg.is_var() and not label_arg.is_var():
        label = label_arg if label_arg.is_literal() else Atom(str(label_arg))
        plan = ts.ag.pl.get(label)
        if plan is None:
            return False
        return un.unifies(plan_arg, _as_plan_term(plan))

    if label_arg.is_var() and isinstance(plan_arg, Plan):
        return un.unifies(label_arg, plan_arg.label)

    def solutions() -> Iterator[Unifier]:
        for plan in list(ts.ag.pl.plans):
            c = un.clone()
            if c.unifies_no_undo(label_arg, plan.label) and c.unifies_no_undo(plan_arg, _as_plan_term(plan)):
                yield c

    return solutions()


@internal_action(name="list_plans", min_args=0, max_args=1)
def list_plans(ts, un, args) -> bool:
    """.list_plans / .list_plans(Trigger): prints the whole plan library, or
    (given an actual Trigger -- checked directly, not parsed/coerced,
    matching Java) only the plans whose trigger unifies with it."""
    if len(args) == 1 and isinstance(args[0], Trigger):
        te = args[0]
        for plan in ts.ag.pl:
            if Unifier().unifies(te, plan.trigger):
                _write(ts, str(plan) + "\n")
    else:
        _write(ts, ts.ag.pl.get_as_txt() + "\n")
    return True
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_semantics.goal_listener import GoalStates
from icaros.as_semantics.intended_means import IMCondition
from icaros.as_syntax.factory import create_atom
from icaros.as_syntax.plan_body import BodyType
from icaros.as_syntax.trigger import TEOperator, TEType, Trigger
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.circumstance import Circumstance
    from icaros.as_semantics.intention import Intention
    from icaros.as_syntax.term import Term


def _achieve_condition(goal: Term) -> IMCondition:
    return IMCondition(Trigger(TEOperator.ADD, TEType.ACHIEVE, goal))


def _finish_succeeded_intention(circumstance: Circumstance, intention: Intention) -> None:
    """Common tail for succeed_goal/done once drop_goal popped a frame: the
    CURRENT intention is left alone (the normal post-execute continuation
    handles it); any other intention is taken out of whatever bucket it was
    in and, if it still has work left, put back into running_intentions."""
    if intention is circumstance.selected_intention:
        return
    circumstance.drop_intention(intention)
    if not intention.is_finished():
        circumstance.add_running_intention(intention)


@internal_action(min_args=1, max_args=1)
def succeed_goal(ts, un, args) -> bool:
    """.succeed_goal(Goal): marks Goal as already achieved in every
    intention (running, waiting, or suspended) that has a +!Goal frame
    anywhere in its stack, dropping that frame and everything above it."""
    condition = _achieve_condition(args[0])
    circumstance = ts.circumstance
    for intention in list(circumstance.all_intentions()):
        im = intention.drop_goal(condition, un.clone())
        if im is not None:
            if ts.has_goal_listener():
                for gl in ts.goal_listeners:
                    gl.goal_finished(im.trigger, GoalStates.ACHIEVED)
            _finish_succeeded_intention(circumstance, intention)
    return True


@internal_action(min_args=1, max_args=1)
def fail_goal(ts, un, args) -> bool:
    """.fail_goal(Goal): as .succeed_goal, but raises a -!Goal failure event
    for each affected intention (if a recovery plan exists), or drops the
    intention outright if there's no recovery plan.

    Unlike succeed_goal, this does NOT drop_goal the target frame itself --
    it only pops its descendants (if any), leaving the target as the new
    top of stack, then hands its own (ADD/ACHIEVE) trigger to
    find_event_for_failure exactly as TransitionSystem._generate_goal_deletion
    does for a real plan-execution failure (im = intention.peek(); ...
    find_event_for_failure(trigger=im.trigger, ...)). find_event_for_failure
    builds the -!Goal trigger internally; passing it a pre-built DEL trigger
    instead breaks its "is this a nested failure-handling failure" check and
    crashes on a single-frame intention (verified by trial)."""
    condition = _achieve_condition(args[0])
    circumstance = ts.circumstance
    for intention in list(circumstance.all_intentions()):
        target = intention.get_intended_means(condition, un.clone())
        if target is None:
            continue
        if ts.has_goal_listener():
            for gl in ts.goal_listeners:
                gl.goal_failed(target.trigger, create_atom("drop_by_fail_goal"))
        while intention.peek() is not target:
            intention.pop()
        event, _ = intention.find_event_for_failure(target.trigger, ts.ag.pl, circumstance)
        if event is not None:
            circumstance.add_event(event)
        else:
            if ts.has_goal_listener():
                for gl in ts.goal_listeners:
                    gl.goal_finished(target.trigger, None)
            circumstance.drop_intention(intention)
    return True


@internal_action(min_args=0, max_args=1)
def done(ts, un, args) -> bool:
    """.done / .done(Goal): as .succeed_goal, but restricted to the
    currently-executing intention -- drop_goal already leaves
    intention.peek() on the parent frame, not-yet-advanced past the
    subgoal call, so the dispatcher's normal post-execute continuation
    does the right thing on its own."""
    intention = ts.circumstance.selected_intention
    if intention is None:
        return True
    goal = args[0] if len(args) == 1 else intention.peek().trigger.literal
    intention.drop_goal(_achieve_condition(goal), un)
    return True


@internal_action(name="drop_future_intention", min_args=1, max_args=1)
def drop_future_intention(ts, un, args) -> bool:
    """.drop_future_intention(Goal): drops (wholesale) every intention whose
    top-of-stack plan has a !Goal/!!Goal step unifying with Goal ANYWHERE in
    its body -- matches Java exactly: it scans the plan's whole original
    body (Plan.get_body()), not just the not-yet-executed remainder, despite
    the "future" name (a faithfully-replicated Jason quirk, not a bug we're
    introducing)."""
    goal = args[0]
    for intention in list(ts.circumstance.all_intentions()):
        body = intention.peek().plan.get_body()
        while body is not None:
            if body.body_type in (BodyType.ACHIEVE, BodyType.ACHIEVE_NF) and \
                    un.clone().unifies_no_undo(body.body_term, goal):
                ts.circumstance.drop_intention(intention)
                break
            body = body.body_next
    return True
from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING
from uuid import uuid4

from icaros.llm import IcarosSession, IcarosState, ToolKind
# ag: safe at module level, unlike the TransitionSystem import inside
# IcarosStep.execute -- message.py, atom.py, internal_action_literal.py,
# object_term.py, plan_body.py and structure.py all live in as_syntax and
# import nothing of icaros.as_semantics, so none of them close a cycle.
from icaros.as_semantics.message import Message
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import create_string
from icaros.as_syntax.internal_action_literal import InternalActionLiteral
from icaros.as_syntax.object_term import ObjectTerm
from icaros.as_syntax.plan_body import BodyType, PlanBody
from icaros.as_syntax.structure import Structure
from icaros.llm.decode import argument_problem
from icaros.journal import JournalKind, trigger_text
from icaros.stdlib.internal_actions.fork import AND, fork
from icaros.stdlib.registry import InternalAction, internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.intended_means import IntendedMeans
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


def _is_conversation(intention) -> bool:
    """Was this session opened in answer to somebody?

    True when the intention that called .talk/.run/... is ultimately serving a
    `+!kqml_received(_, chat, _, _)` -- a person typing in the dev UI, or
    another agent's `.send(Ag, chat, msg("..."))`, which is the same act seen
    from the other side.

    ag: read off intention.root(), the intended means at the BOTTOM of the
    stack, so it survives a chat plan that delegates to a subgoal before
    asking the model. peek() would answer "what is it doing right now", and
    right now it is always calling .talk -- which is the question that cannot
    tell the two uses of .talk apart.

    ag: inferred rather than declared, and that is a deliberate refusal to add
    syntax. There is nothing for a plan to say here that the trigger does not
    already say: an agent answering a chat is not choosing to be
    conversational, it IS in a conversation. A `.talk(P, A, conversation)`
    argument would be the same fact written twice, and the second copy would
    be the one that goes stale.
    """
    root = None if intention is None else intention.root()
    literal = None if root is None else getattr(root.trigger, "literal", None)
    if literal is None or literal.functor != Message.kqml_received_functor:
        return False
    # kqml_received(Sender, Performative, Content, MsgId): the performative is
    # the second term, and `chat` is the one that means somebody is waiting.
    return literal.get_arity() > 1 and str(literal.get_term(1)) == "chat"


_ICAROS_STEP = Structure(".icaros_step")
_ICAROS_CONSIDER = Structure(".icaros_consider_results")


def _step_node(ts: TransitionSystem, session: IcarosSession) -> PlanBody:
    literal = InternalActionLiteral(Structure(_ICAROS_STEP), ts.ag)
    literal.add_terms(ObjectTerm(session))
    return PlanBody(BodyType.INTERNAL_ACTION, literal)


def _consider_node(ts: TransitionSystem, session: IcarosSession) -> PlanBody:
    literal = InternalActionLiteral(Structure(_ICAROS_CONSIDER), ts.ag)
    literal.add_terms(ObjectTerm(session))
    return PlanBody(BodyType.INTERNAL_ACTION, literal)


def _journal_close(ts: TransitionSystem, session: IcarosSession, im: IntendedMeans | None,
                    *, failed: bool, summary: str | None) -> None:
    # ag: ported verbatim from the old _close_icaros_session -- the summary is
    # the session's product (for a talk session, its ONLY product), so it goes
    # on the journal regardless of how the session ended. `failed` here means
    # specifically "gave up after MAX_ROUNDS", not "the model's answer didn't
    # unify" -- that second kind of failure is a normal goal failure, reported
    # by _generate_goal_deletion's own JournalKind.GOAL_FAILED entry, and
    # muddying this one with it would make two entries say the same thing two
    # different ways.
    ts.ag.journal.record(
        JournalKind.LLM_GENERATE, level=str(session.level), session=session.id,
        round=str(session.rounds), concluded=summary or "",
        goal=trigger_text(im.trigger)[:200] if im is not None else None,
        error=f"gave up after {session.rounds} rounds" if failed else None)


def _allowed_tools(name: str, tools: Term) -> frozenset[str]:
    if not tools.is_list():
        raise ValueError(f"internal action '.{name}': the third argument must be a list of tool names")
    return frozenset(t.string if t.is_string() else str(t) for t in tools.get_as_list())


def _open(name: str, ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> bool:
    """Opens a session at the level `name` stands for, and splices a
    .icaros_step call into the calling intention's own body in place of this
    one -- the intention keeps running, its own selection carries the session
    forward from here.

    The optional second argument is where the answer goes. It is only a term
    to hold on to here: there is nothing to bind until the model closes the
    session, which happens rounds later in IcarosStep.execute.

    The optional third argument is the list of tool names the session may
    offer (atoms or strings). It narrows what llm_tools: and the level already
    allow, and never widens it.
    """
    if not args[0].is_string():
        raise ValueError(f"internal action '.{name}': the argument must be a string")
    allowed_tools = _allowed_tools(name, args[2]) if len(args) > 2 else None
    if ts is None:
        return False
    level = IcarosState[name.upper()]
    # the ceiling declared in the .mas2i. An agent asking to run above what it
    # was allowed fails here rather than quietly running at a lower level: the
    # plan asked for a capability, and it either has it or it does not.
    if ts.gen_limit < level:
        # TODO: should it instead raise an error?
        return False
    # a session with nobody to serve it would suspend the intention forever, so
    # an agent with no model refuses at the call site -- where it reads as the
    # configuration error it is -- instead of MAX_ROUNDS later.
    if ts.agentic is None or ts.agentic.provider is None:
        # TODO: should it instead raise an error?
        return False

    intention = ts.circumstance.selected_intention
    im = intention.peek() if intention is not None else None
    # ag: unique per session, NOT per intention: one intention can open several
    # sessions over its life, and a result arriving late from a session that
    # was already closed would then land in the next one, which is the same
    # accident goal_step's uuid4 exists to prevent one level down.
    session = IcarosSession(id=f"icaros-{uuid4().hex[:8]}", level=level,
                            inbox=deque([args[0].string]), intention=intention,
                            result_var=args[1] if len(args) > 1 else None,
                            opened_at_cycle=ts.cycle_count,
                            conversation=_is_conversation(intention),
                            max_rounds=ts.gen_max_rounds,
                            allowed_tools=allowed_tools)
    ts.circumstance.open_icaros_session(session)
    if im is not None:
        # captured once, the same way _exec_while/_exec_for capture what
        # follows a loop before splicing the reentrant step in -- this is
        # what .icaros_step falls through to once the session closes.
        session.continuation = im.current_step.body_next
        im.insert_as_next_step(_step_node(ts, session))
    return True


# ag: four actions and one body. They differ only in the rung they open at, and
# the rung is the whole meaning of the call -- what the model will be handed
# and what it will be told it may do (IcarosState.allowed_kinds/capabilities).
# Written out one by one rather than generated in a loop so that each one has
# its own docstring: stdlib/ia_tools.py reads the first line as the signature,
# and a reader greps for ".fly" and finds a definition, not a factory.
#
# None of the four suspend the calling intention any more: _open splices
# .icaros_step in as the very next step instead, and the outer dispatcher's
# own _continue_intention (triggered by suspend_intention()'s default False)
# is what advances onto it, in the same cycle.


@internal_action(min_args=1, max_args=3, use_in_context=False)
def talk(ts, un, args) -> bool:
    """.talk(Prompt[, -Answer[, Tools]]): asks the model Prompt, at the talk level -- it
    may read its own journal and answer, and cannot make the agent act.
    Suspends the calling intention until the model says it has finished, and
    binds Answer, if given, to what it answered."""
    return _open("talk", ts, un, args)


@internal_action(min_args=1, max_args=3, use_in_context=False)
def run(ts, un, args) -> bool:
    """.run(Prompt[, -Answer[, Tools]]): asks the model Prompt, at the run level -- as
    .talk, and it may also ask the agent to pursue goals it already has plans
    for. Suspends the calling intention until the model says it has finished,
    and binds Answer, if given, to what it answered."""
    return _open("run", ts, un, args)


@internal_action(min_args=1, max_args=3, use_in_context=False)
def fly(ts, un, args) -> bool:
    """.fly(Prompt[, -Answer[, Tools]]): asks the model Prompt, at the fly level --
    where it would also write new plans. Suspends the calling intention until
    the model says it has finished, and binds Answer, if given, to what it
    answered.

    ag: plan generation does not exist in the tree yet, so a fly session
    behaves exactly like a run one. The rung is accepted and enforced against
    the .mas2i ceiling; what it will eventually allow is not built."""
    return _open("fly", ts, un, args)


@internal_action(min_args=1, max_args=3, use_in_context=False)
def burn(ts, un, args) -> bool:
    """.burn(Prompt[, -Answer[, Tools]]): asks the model Prompt, at the burn level --
    where it would also write new internal actions. Suspends the calling
    intention until the model says it has finished, and binds Answer, if given,
    to what it answered.

    ag: like .fly, the capability the rung names is not built; a burn session
    behaves like a run one today."""
    return _open("burn", ts, un, args)


class IcarosStep(InternalAction):
    """.icaros_step(Session): advances one .talk/.run/.fly/.burn session by
    one LLM round trip. Injected by _open above, and re-injected by itself
    (a retry after a failed round trip, or the model answering in prose
    without committing to a tool) or by .icaros_consider_results (once a
    dispatched tool call's result is back) -- never written by hand, never
    offered to the model as a tool.

    A class, not a decorated function, for the same two reasons as .wait: it
    needs raw, unresolved arguments (the ObjectTerm(session) must arrive
    intact, not be re-resolved), and suspend_intention() must report
    dynamically -- True when something else will resume the intention (an
    internal-action frame pushed onto it finishing, or a fork's join), False
    when the intention simply carries on with its next step (a retry, a
    nudge, a `!goal` step the model asked for, or a session that just closed
    and fell through to its continuation).
    """

    name = ".icaros_step"

    def __init__(self):
        self._suspend_intention = False

    def prepare_arguments(self, body, un):
        # raw: the ObjectTerm carrying the session must arrive intact
        return list(body.get_terms() or [])

    def execute(self, ts: TransitionSystem, un: Unifier, args: list[Term]) -> bool:
        # ag: lazy import to avoid a cycle -- transition_system.py pulls in
        # stdlib.internal_actions at module load, which pulls in this file
        # (mirrors waiting.py's _finish_wait, same reason).
        from icaros.as_semantics.transition_system import error_annots

        session: IcarosSession = args[0].value
        intention = ts.circumstance.selected_intention
        if intention is None:
            # unreachable through the normal reasoning cycle -- EXEC_INT never
            # dispatches an internal action with no selected intention -- kept
            # only so a direct execute() call (a test) fails soft, as .wait does.
            self._suspend_intention = False
            return True
        im = intention.peek()

        session.rounds += 1
        try:
            done, summary, dispatchable = ts.agentic._round(session)
        except Exception:
            # ag: same stance as the old _generate() -- a model that cannot be
            # reached must not take the agent's cycle down with it, nor fail
            # the goal outright: the inbox is untouched by a failed round, so
            # retrying (below) is the same thing a retry after "no provider"
            # already does.
            ts.ag.logger.exception("Icaros session %s: the round trip failed", session.id)
            done, summary, dispatchable = False, None, []

        if done:
            ts.circumstance.close_icaros_session(session.id)
            _journal_close(ts, session, im, failed=False, summary=summary)
            answer = session.last_answer or summary or ""
            if session.result_var is not None and not im.unifier.unifies(
                    session.result_var, create_string(answer)):
                self._suspend_intention = True
                ts._generate_goal_deletion(
                    intention,
                    error_annots("icaros_failed",
                                f"the model's answer ('{answer}') does not unify with "
                                f"the second argument of the call ('{session.result_var}')"),
                    Atom("icaros_failed"))
                return True
            # the answer, handed back to the plan that asked -- .talk("p", A).
            # Bound above and not at the call, because at the call there was
            # nothing to bind yet; same shape as .wait's elapsed_var.
            im.insert_as_next_step(session.continuation)
            self._suspend_intention = False
            return True

        if session.rounds >= session.max_rounds:
            ts.circumstance.close_icaros_session(session.id)
            gave_up = f"the model did not finish within {session.max_rounds} rounds"
            _journal_close(ts, session, im, failed=True, summary=gave_up)
            self._suspend_intention = True
            ts._generate_goal_deletion(intention, error_annots("icaros_failed", gave_up),
                                       Atom("icaros_failed"))
            return True

        if not dispatchable:
            # a retry (no provider / a round that raised) or a prose-only
            # nudge -- either way, nothing to consider, ask again.
            im.insert_as_next_step(_step_node(ts, session))
            self._suspend_intention = False
            return True

        if len(dispatchable) == 1:
            name, arguments, provider_call_id = dispatchable[0]
            tool = ts.agentic._tool_named(name, session)
            if tool is None:
                # a tool this session was not offered: nothing would run, so
                # nothing would ever come back -- answer it and ask again.
                ts.agentic.refuse_tool_call(session, name, provider_call_id)
                im.insert_as_next_step(_step_node(ts, session))
                self._suspend_intention = False
                return True
            if argument_problem(tool, arguments) is not None:
                # arguments no call could be built from -- e.g. the model named
                # an input it was told it must supply and did not. json2terms
                # would truncate the term list instead, and the truncated goal
                # (one arity under the wrapper plan's) fails with no plan
                # relevant to it before the session gets an answer: the
                # reasoning cycle hangs. Refuse, and let the model retry or
                # move on, exactly as for a tool it was never offered.
                ts.agentic.refuse_tool_call(
                    session, name, provider_call_id,
                    argument_problem(tool, arguments))
                im.insert_as_next_step(_step_node(ts, session))
                self._suspend_intention = False
                return True
            if tool.kind is ToolKind.INTERNAL_ACTION:
                # splice .icaros_consider_results in as the continuation
                # BEFORE pushing, so the child frame add_tool_call pushes
                # returns to it once it finishes -- same ordering _open uses
                # for .icaros_step itself.
                im.insert_as_next_step(_consider_node(ts, session))
                if ts.agentic.add_tool_call(name, arguments, session, provider_call_id) is None:
                    # nothing was pushed, so nothing will ever resume this
                    # intention: answer the call and ask again instead.
                    ts.agentic.refuse_tool_call(
                        session, name, provider_call_id,
                        f"'{name}' could not be run with these arguments.")
                    im.insert_as_next_step(_step_node(ts, session))
                    self._suspend_intention = False
                    return True
                self._suspend_intention = True
                return True
            # ag: the Jason road. The model does not post an event: it says
            # which goal it would now like to achieve, and that becomes the
            # next step of this very intention --
            #   .icaros_step; !goal[source(llm), llm_call(..)]; .icaros_consider_results(S)
            # -- which goes back among the running ones. SelInt picks it when
            # its turn comes, and ExecInt's Rule Achieve posts the goal, the
            # same as for a `!goal` written in the plan. insert_as_next_step
            # REPLACES body_next (intended_means.py), so the chain is built
            # first; what really follows the session is on
            # session.continuation, not lost here.
            step = self._goal_step(ts, session, tool, name, arguments, provider_call_id)
            if step is None:
                im.insert_as_next_step(_step_node(ts, session))
                self._suspend_intention = False
                return True
            step.body_next = _consider_node(ts, session)
            im.insert_as_next_step(step)
            self._suspend_intention = False
            return True

        # more than one call in the same round: resolve every name the model
        # named, the same way the one-call road does. A name this session was
        # not offered is answered with a refusal and dropped -- and so is a
        # call whose arguments cannot be built into a goal (same hang risk
        # as the one-call road, right above).
        resolved = [(name, arguments, provider_call_id, ts.agentic._tool_named(name, session))
                   for name, arguments, provider_call_id in dispatchable]
        for name, arguments, provider_call_id, tool in resolved:
            if tool is None:
                ts.agentic.refuse_tool_call(session, name, provider_call_id)
            elif argument_problem(tool, arguments) is not None:
                ts.agentic.refuse_tool_call(
                    session, name, provider_call_id,
                    argument_problem(tool, arguments))
        resolved = [(name, arguments, provider_call_id, tool)
                   for name, arguments, provider_call_id, tool in resolved
                   if tool is not None and argument_problem(tool, arguments) is None]
        # TODO: an INTERNAL_ACTION-kind call has no trigger of its own to
        # carry inside a fork branch -- see Icaros.goal_step. Until it does,
        # one mixed into a multi-call batch is refused with a reason the model
        # can act on (call it again, alone), rather than failing the plan that
        # opened the session or running it un-correlated.
        for name, _, provider_call_id, tool in resolved:
            if tool.kind is ToolKind.INTERNAL_ACTION:
                ts.agentic.refuse_tool_call(
                    session, name, provider_call_id,
                    f"'{name}' was not run: call it on its own, in a round "
                    f"with no other tool calls.")
        branch_bodies = [b for b in (self._goal_step(ts, session, tool, name, arguments,
                                                     provider_call_id)
                                     for name, arguments, provider_call_id, tool in resolved
                                     if tool.kind is not ToolKind.INTERNAL_ACTION)
                        if b is not None]
        if not branch_bodies:
            # every call the model made was refused (never offered, bad
            # arguments, an internal action in a batch) -- nothing to fork,
            # ask again.
            im.insert_as_next_step(_step_node(ts, session))
            self._suspend_intention = False
            return True
        # .icaros_consider_results spliced in BEFORE forking: Fork.execute
        # clones im.current_step (whose body_next this now is) into every
        # branch's own .join continuation (fork.py), so each one lands here.
        im.insert_as_next_step(_consider_node(ts, session))
        self._suspend_intention = True
        fork.execute(ts, un, [AND, *branch_bodies])
        return True

    @staticmethod
    def _goal_step(ts: TransitionSystem, session: IcarosSession, tool, name: str,
                   arguments: dict, provider_call_id: str | None) -> PlanBody | None:
        """Icaros.goal_step, or None with the call already refused when the
        goal cannot be built -- a model's call that turns out unbuildable is
        an answer to give it, not a reason to fail the plan that asked."""
        try:
            return ts.agentic.goal_step(tool, arguments, session, provider_call_id)
        except Exception as e:
            ts.ag.logger.exception("Icaros session %s: could not build the call to '%s'",
                                   session.id, name)
            ts.agentic.refuse_tool_call(session, name, provider_call_id,
                                        f"'{name}' could not be called: {e}")
            return None

    def suspend_intention(self) -> bool:
        return self._suspend_intention

    def can_be_used_in_context(self) -> bool:
        return False

    def new_instance(self) -> IcarosStep:
        return IcarosStep()


class IcarosConsiderResults(InternalAction):
    """.icaros_consider_results(Session): drains whatever a dispatched tool
    call deposited for Session and hands it back to the model as the next
    round's question. Injected by .icaros_step right after dispatching
    exactly one tool call (or, once fork/join lands, after every branch of a
    concurrent round joins) -- never written by hand, never offered to the
    model as a tool.
    """

    name = ".icaros_consider_results"

    def prepare_arguments(self, body, un):
        return list(body.get_terms() or [])

    def execute(self, ts: TransitionSystem, un: Unifier, args: list[Term]) -> bool:
        session: IcarosSession = args[0].value
        intention = ts.circumstance.selected_intention
        if intention is None:
            return True
        # ag: MUST come before draining anything. After a fork/join round this
        # is a DIFFERENT Intention object than the one that opened the session
        # -- .fork abandons its caller (fork.py), and the branch that wins the
        # join is what carries on. Every later lookup keyed on
        # session.intention (drop_intention's cleanup, a future close) has to
        # follow the survivor, not the abandoned original.
        session.intention = intention
        # ag: role:"tool" turns, not session.inbox text -- see
        # IcarosSession.remember_tool_result and Icaros._round's own turn
        # right before this one. For a fork (N>1 calls in the round that
        # opened them) this is N calls in a row, one per result, answering
        # the N tool_calls the preceding assistant turn made.
        for result in ts.circumstance.take_llm_results_for(session.id):
            session.remember_tool_result(result.tool_name or "tool", result.as_text(),
                                         call_id=result.call_id)
        intention.peek().insert_as_next_step(_step_node(ts, session))
        return True

    def suspend_intention(self) -> bool:
        return False

    def can_be_used_in_context(self) -> bool:
        return False

    def new_instance(self) -> IcarosConsiderResults:
        return self


icaros_step = IcarosStep()
icaros_consider_results = IcarosConsiderResults()
from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

    from icaros.as_semantics.transition_system import TransitionSystem


def schedule(ts: TransitionSystem, delay_ms: float, callback: Callable[[], None]) -> threading.Timer:
    """Runs `callback` on ts's own reasoning thread, at the start of the
    cycle after delay_ms elapses -- never touches Circumstance/Intention
    state directly from the timer thread (unlike Jason, whose Circumstance
    collections are concurrent-safe by construction; icaros's plain
    dict/deque ones are not -- see .wait/.at/.send's porting notes)."""
    def on_timer() -> None:
        ts.run_at_begin_of_next_cycle(callback)
        ts.ag_arch.wake_up_act()

    timer = threading.Timer(max(delay_ms, 0) / 1000.0, on_timer)
    timer.daemon = True
    timer.start()
    return timer
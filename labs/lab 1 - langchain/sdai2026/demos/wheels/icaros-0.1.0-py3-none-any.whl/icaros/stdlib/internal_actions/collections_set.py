from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.set_term import SetTerm
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


def _get_or_create_set(un: Unifier, args: list[Term]) -> SetTerm:
    if args[0].is_set():
        return args[0]
    if args[0].is_var():
        s = SetTerm()
        un.unifies(args[0], s)
        return s
    raise ValueError("internal action '.set.*': first argument must be a set (or an unbound variable)")


def _check_collection(t: Term, ia_name: str) -> None:
    if not (t.is_list() or t.is_set()):
        raise ValueError(f"internal action '{ia_name}': second argument must be a list or a set")


@internal_action(name="set.create", min_args=1, max_args=1)
def set_create(ts, un, args) -> bool:
    """.set.create(S): S unifies with a new, empty set."""
    if not args[0].is_var():
        return False
    return un.unifies(args[0], SetTerm())


@internal_action(name="set.add", min_args=2, max_args=2)
def set_add(ts, un, args) -> bool:
    """.set.add(S, X): adds X to set S (creating S first if it's an unbound
    variable); always true, even if X was already a member."""
    _get_or_create_set(un, args).add(args[1])
    return True


@internal_action(name="set.add_all", min_args=2, max_args=2)
def set_add_all(ts, un, args) -> bool:
    """.set.add_all(S, L): adds every element of list L to set S."""
    if not args[1].is_list():
        raise ValueError("internal action '.set.add_all': second argument must be a list")
    s = _get_or_create_set(un, args)
    for t in args[1]:
        s.add(t)
    return True


@internal_action(name="set.remove", min_args=2, max_args=2)
def set_remove(ts, un, args) -> bool:
    """.set.remove(S, X): removes X from set S; true iff X was a member.
    ag: Jason's set/remove.java ignores java.util.Set.remove()'s return value
    and always succeeds -- looks like a bug rather than an intended "always
    true" semantics (unlike .set.add, which is genuinely idempotent-and-true
    by design). SetTerm.remove() already gives us the correct boolean for
    free, so we use it, matching the rest of the stdlib's "not found ->
    failure" convention instead of replicating the Java oversight."""
    return _get_or_create_set(un, args).remove(args[1])


@internal_action(name="set.clear", min_args=1, max_args=1)
def set_clear(ts, un, args) -> bool:
    """.set.clear(S): removes every element of set S."""
    _get_or_create_set(un, args).clear()
    return True


@internal_action(name="set.copy", min_args=2, max_args=2)
def set_copy(ts, un, args) -> bool:
    """.set.copy(S, R): R unifies with a deep copy of set S."""
    s = _get_or_create_set(un, args)
    return un.unifies(args[1], s.deep_clone())


@internal_action(name="set.to_list", min_args=2, max_args=2)
def set_to_list(ts, un, args) -> bool:
    """.set.to_list(S, L): L unifies with the elements of set S, sorted by
    the standard term order."""
    s = _get_or_create_set(un, args)
    return un.unifies(args[1], s.get_as_list_term())


@internal_action(name="set.union", min_args=2, max_args=2)
def set_union(ts, un, args) -> bool:
    """.set.union(S, L): adds every element of list/set L to set S, in
    place (unlike .union in lists.py, which is arity-3 and produces a new,
    separate result -- this one mutates S directly, matching Jason)."""
    _check_collection(args[1], ".set.union")
    _get_or_create_set(un, args).union(args[1])
    return True


@internal_action(name="set.intersection", min_args=2, max_args=2)
def set_intersection(ts, un, args) -> bool:
    """.set.intersection(S, L): keeps in set S only the elements also in
    list/set L, in place."""
    _check_collection(args[1], ".set.intersection")
    _get_or_create_set(un, args).intersection(args[1])
    return True


@internal_action(name="set.difference", min_args=2, max_args=2)
def set_difference(ts, un, args) -> bool:
    """.set.difference(S, L): removes from set S every element also in
    list/set L, in place."""
    _check_collection(args[1], ".set.difference")
    _get_or_create_set(un, args).difference(args[1])
    return True
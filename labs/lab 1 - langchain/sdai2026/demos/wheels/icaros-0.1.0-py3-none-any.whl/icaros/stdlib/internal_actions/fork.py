from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from icaros.as_semantics.intention import Intention
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.internal_action_literal import InternalActionLiteral
from icaros.as_syntax.object_term import ObjectTerm
from icaros.as_syntax.plan_body import BodyType, PlanBody
from icaros.as_syntax.structure import Structure
from icaros.stdlib.registry import InternalAction

if TYPE_CHECKING:
    from icaros.as_semantics.circumstance import Circumstance
    from icaros.as_semantics.event import Event
    from icaros.as_semantics.intended_means import IMCondition, IntendedMeans
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.term import Term
    from icaros.as_syntax.trigger import Trigger
    from icaros.pl.plan_library import PlanLibrary

_logger = logging.getLogger(__name__)

AND = Atom("and")
OR = Atom("or")

_JOIN = Structure(".join")


class ForkData:
    """The channel the branches of one .fork call coordinate through: which
    branches exist, how many have still to reach their .join, and whether the
    fork is an `and` or an `or`. Shared by reference -- every branch's injected
    .join(fd) call carries this same object as an ObjectTerm argument.

    ag: no lock. All the branches of a fork belong to the same agent and
    therefore run on that agent's single reasoning thread, free-threaded build
    included -- shared mutable state with a single owner, the same discipline
    the rest of Circumstance relies on.
    """

    def __init__(self, is_and: bool):
        self.is_and = is_and
        self.intentions: set[Intention] = set()
        self.to_finish = 0

    def add_intention(self, intention: Intention) -> None:
        self.intentions.add(intention)
        self.to_finish += 1

    # ag: Java gets this for free -- ObjectTermImpl.clone() looks for a PUBLIC
    # clone() method by reflection and, finding none on ForkData, returns the
    # same term, so every clone of a plan body keeps pointing at the one shared
    # ForkData. icaros's ObjectTerm.clone() deep-copies its content instead, so
    # without this the sharing breaks -- and it breaks silently, in exactly one
    # case: a fork nested inside another fork's branch WITHIN THE SAME plan body
    # (e.g. `(!a; (!c |&| !d)) |&| !b`). There the inner .fork clones a frame
    # whose remaining body still contains the outer `.join(fd)`, so each inner
    # branch would get a private copy of the OUTER ForkData, its to_finish would
    # never reach 0, and the outer and-join would hang forever.
    def __deepcopy__(self, memo: dict) -> ForkData:
        return self

    def __str__(self) -> str:
        kind = "and" if self.is_and else "or"
        ids = " ".join(str(i.id) for i in self.intentions)
        return f"fork data ({kind}) intentions = {{ {ids} }} waiting for {self.to_finish}"


class ForkIntention(Intention):
    """One branch of a fork. It carries the whole stack of the intention that
    called .fork (shared frames, see Intention.copy_to) plus its own top frame,
    and `fork_point` is where the fork happened: at or above it we are inside
    the branch's own work, below it we are in the caller's ancestors, shared
    with the siblings. The three overrides are the whole of fork's failure
    semantics -- TransitionSystem never mentions fork, it just calls these.
    """

    def __init__(self, parent: Intention, fork_data: ForkData):
        super().__init__()
        parent.copy_to(self)
        self._fork_point = parent.size()
        self._fork_data = fork_data

    @property
    def fork_point(self) -> int:
        """How many frames at the bottom of this branch's stack are shared
        ancestry -- `list(self)[:fork_point]`, in the order Intention
        iterates. Everything from there up is this branch's own work.

        ag: a read-only property rather than exposing `_fork_point` directly,
        so a reader (telemetry, mainly -- runtime/telemetry/inspect.py) can
        see where a branch forked without reaching past the underscore for
        something TransitionSystem itself never needed to."""
        return self._fork_point

    @property
    def fork_data(self) -> ForkData:
        """The channel this branch coordinates its join through, shared with
        every sibling still alive -- see ForkData."""
        return self._fork_data

    def drop_goal(self, condition: IMCondition, unifier: Unifier) -> IntendedMeans | None:
        im = super().drop_goal(condition, unifier)
        if im is not None and self.size() < self._fork_point:
            # the unwind went below the fork: an ancestor goal is being dropped
            # (.succeed_goal/.fail_goal). The first branch reached keeps the
            # popped frame and becomes the surviving continuation; every later
            # one empties itself and reports "nothing to do" so it just vanishes.
            if self._fork_data.to_finish > 0:
                self._fork_data.to_finish = 0
                return im
            self.clear_intended_means()
            return None
        return im

    def fail(self, circumstance: Circumstance) -> None:
        # reached only when no -!g handler exists anywhere: an and-fork whose
        # failure is at or above the fork point takes its siblings down with it.
        if self.size() >= self._fork_point and self._fork_data.is_and:
            for sibling in list(self._fork_data.intentions):
                circumstance.drop_intention(sibling)

    def find_event_for_failure(self, trigger: Trigger, plan_lib: PlanLibrary,
                               circumstance: Circumstance) -> tuple[Event | None, int]:
        event, pos_in_stack = super().find_event_for_failure(trigger, plan_lib, circumstance)
        if pos_in_stack <= self._fork_point:
            # no recovery plan inside the branch itself
            if self._fork_data.is_and:
                # and: the whole fork collapses and the failure goes on up to
                # the goal that spawned it, handled as usual from there
                self._fork_data.intentions.discard(self)
                for sibling in list(self._fork_data.intentions):
                    circumstance.drop_intention(sibling)
            else:
                # or: swallow it. This branch dies quietly and the siblings
                # keep trying -- do not look for a failure plan below the fork.
                return None, pos_in_stack
        return event, pos_in_stack


class Fork(InternalAction):
    """.fork(and|or, Body1, ..., BodyN): runs the bodies concurrently, as one
    intention each. Written `B1 |&| B2` (and) or `B1 ||| B2` (or) -- the parser
    desugars both into this call, and .join (injected below, never written by
    hand) is what puts the pieces back together.

    `and` continues after the fork once EVERY branch has finished; `or` once the
    FIRST one has, dropping the others.

    ag: this does not suspend-and-resume its own intention, it ABANDONS it --
    faithfully to Java, and it is the part worth knowing. suspend_intention() is
    True, so the dispatcher does not requeue the caller; the caller was already
    taken out of the running queue by SelInt, so nothing references it any more.
    Each branch instead carries its own private copy of whatever followed the
    fork, and whichever branch wins the join is the one that runs it. Consequence
    to expect when reading a trace: the intention that continues after a fork has
    a DIFFERENT id from the one that called it.

    A class rather than a decorated function because it needs raw, unresolved
    arguments (the branch bodies are PlanBody terms to clone, not terms to
    evaluate) and because it must suspend the calling intention.
    """

    name = ".fork"

    def prepare_arguments(self, body: Literal, un: Unifier) -> list[Term]:
        # raw, unresolved -- Java's body.getTermsArray()
        return list(body.get_terms() or [])

    def execute(self, ts: TransitionSystem, un: Unifier, args: list[Term]) -> bool:
        if len(args) < 2:
            raise ValueError(f"internal action '.fork' called with {len(args)} argument(s), "
                             "expected at least 2")
        if args[0] != AND and args[0] != OR:
            raise ValueError("internal action '.fork': first argument must be 'and' or 'or'")

        fork_data = ForkData(args[0] == AND)
        current = ts.circumstance.selected_intention
        if current is None:
            return False

        # ag: known limitation, inherited from Java rather than introduced here.
        # copy_to carries the atomic count over to every branch, and
        # add_running_intention parks any atomic intention in the single AI
        # slot -- so from the second branch on, each one silently overwrites
        # (and orphans) the previous. Logged rather than fixed: fixing it means
        # diverging from Jason's semantics for atomic plans.
        if current.is_atomic() and len(args) > 2:
            _logger.warning(
                ".fork with %d branches inside an atomic plan: only the last branch will run "
                "(the atomic slot holds one intention), and the join will never complete",
                len(args) - 1)

        for branch_body in args[1:]:
            branch = ForkIntention(current, fork_data)
            fork_data.add_intention(branch)
            branch.pop()  # the frame running .fork, replaced by the clone below
            im = current.peek().clone()

            # .join(fork_data), with the caller's continuation behind it: every
            # branch gets its own copy of what came after the fork
            join_literal = InternalActionLiteral(Structure(_JOIN), ts.ag)
            join_literal.add_terms(ObjectTerm(fork_data))
            join_step = PlanBody(BodyType.INTERNAL_ACTION, join_literal)
            join_step.body_next = im.current_step.body_next

            # the branch's own body, with the join appended
            body = branch_body.clone()
            body.add(join_step)
            body.is_body_term = False

            im.insert_as_next_step(body)
            im.remove_current_step()  # drop the .fork itself
            branch.push(im)
            ts.circumstance.add_running_intention(branch)

        return True

    def suspend_intention(self) -> bool:
        return True

    def can_be_used_in_context(self) -> bool:
        return False

    def new_instance(self) -> Fork:
        # no instance state: the per-call state lives in ForkData
        return self


class Join(InternalAction):
    """.join(ForkData): injected by .fork at the end of every branch, never
    written by hand. The intention running it is the BRANCH, not the intention
    that called .fork -- so the branch that satisfies the join is the one that
    goes on to run the continuation.

    ag: two known holes, both Jason's. A branch that is dropped without ever
    reaching its .join (e.g. by .drop_intention on a goal above the fork) never
    decrements to_finish, so an `and` join can wait forever; and
    .drop_intention(G) on an ancestor goal wipes out every branch at once,
    leaving nobody to resume the continuation -- unlike .succeed_goal/.fail_goal,
    which go through ForkIntention.drop_goal and keep one branch alive.
    """

    name = ".join"

    def prepare_arguments(self, body: Literal, un: Unifier) -> list[Term]:
        # raw: the ObjectTerm carrying the shared ForkData must arrive intact
        return list(body.get_terms() or [])

    def execute(self, ts: TransitionSystem, un: Unifier, args: list[Term]) -> bool:
        current = ts.circumstance.selected_intention
        if current is None:
            return False
        fork_data: ForkData = args[0].value
        fork_data.to_finish -= 1

        if fork_data.is_and:
            # everyone has to arrive; the last one carries on
            if fork_data.to_finish == 0:
                current.peek().remove_current_step()
                ts.circumstance.add_running_intention(current)
        else:
            # first one wins, the others are dropped
            fork_data.intentions.discard(current)
            for sibling in list(fork_data.intentions):
                ts.circumstance.drop_intention(sibling)
            current.peek().remove_current_step()
            ts.circumstance.add_running_intention(current)

        return True

    def suspend_intention(self) -> bool:
        return True

    def can_be_used_in_context(self) -> bool:
        return False

    def new_instance(self) -> Join:
        return self


fork = Fork()
join = Join()
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Mapping

from icaros.as_syntax.plan_doc import DEFAULT_TYPE, PlanDoc, parse_doc_comment
from icaros.llm import LlmTool, LlmToolParam, ToolKind, sanitize_tool_name

if TYPE_CHECKING:
    from icaros.stdlib.registry import InternalAction

# ag: the internal-action counterpart of pl/goal_tools.py. Kept in its own
# module, and out of registry.py, so the registry stays the pure dispatch
# mechanism -- and so the two tool families stay visibly separate, which is
# the point: goals are what the agent is *for*, internal actions are the
# primitives it is built from, and only the former are exposed by default.
#
# The doc source here is the Python docstring, which FunctionIA already keeps
# in __doc__. The stdlib convention is a signature line first:
#
#     .save_agent(File[, InitialGoals]): writes this agent's beliefs, ...
#
# so the signature names the parameters and marks the optional ones with
# brackets -- everything a tool schema needs, already written.

# ".foo(A, B[, C]): rest" / "my.plot(+Step,+Score) -- rest"
_SIGNATURE_RE = re.compile(r"^\s*(?P<name>[.\w][\w.]*)\s*\((?P<args>.*?)\)\s*(?::|--|—)?\s*")
# a mode prefix Jason-style docs use: "+Step" (in), "-X" (out), "?X".
# ag: the mode is captured, not just skipped over. "-X" means the action binds
# X rather than reading it, and a tool schema that asked a model to supply X
# would be asking for the answer it is about to be given.
_ARG_RE = re.compile(r"^(?P<mode>[+\-?]*)\s*(?P<name>[A-Za-z_]\w*)")


def tool_name_for(ia_name: str) -> str:
    """".print" -> "print"; "my.plot" -> "my_plot"."""
    return sanitize_tool_name(ia_name.lstrip("."))


def _split_signature(text: str) -> tuple[list[str], list[bool], list[bool], str]:
    """Pulls the leading signature line off a docstring.

    Returns (parameter names, per-parameter required flags, per-parameter
    output flags, the docstring with the signature removed). An empty name
    list means there was no signature to read, and the caller falls back to
    min_args/max_args.
    """
    # several actions document alternative call shapes on one line, e.g.
    # ".wait(T) / .wait(E) / .wait(E,T)". Read them all: each is parsed on its
    # own, then merged, so the schema describes the whole action rather than
    # just whichever form happens to be written first.
    shapes: list[list[tuple[str, bool, bool]]] = []
    rest = text
    while True:
        candidate = rest if not shapes else rest.lstrip()
        if shapes:
            if not candidate.startswith("/"):
                break
            candidate = candidate[1:].lstrip()
        m = _SIGNATURE_RE.match(candidate)
        if m is None:
            break
        shapes.append(_parse_arg_list(m.group("args")))
        rest = candidate[m.end():]

    if not shapes:
        return [], [], [], text

    # a parameter is required only where every shape that could be called
    # demands it: appearing in just some of the shapes, or inside brackets,
    # makes it optional.
    names: list[str] = []
    required: list[bool] = []
    outputs: list[bool] = []
    for shape in shapes:
        for name, mandatory, is_output in shape:
            if name not in names:
                names.append(name)
                # missing from an earlier shape => that call form works without it
                required.append(mandatory and shape is shapes[0])
                outputs.append(is_output)
            else:
                idx = names.index(name)
                required[idx] = required[idx] and mandatory
                # one shape writing to it is enough: the caller must be
                # prepared to receive it either way
                outputs[idx] = outputs[idx] or is_output
    for i, name in enumerate(names):
        if any(all(n != name for n, _, _ in shape) for shape in shapes):
            required[i] = False

    return names, required, outputs, rest


def _parse_arg_list(args: str) -> list[tuple[str, bool, bool]]:
    """One signature's arguments as (name, is_mandatory, is_output);
    "[...]" means optional, a leading "-" means output."""
    out: list[tuple[str, bool, bool]] = []
    depth = 0
    for chunk in re.split(r"([\[\],])", args):
        if chunk == "[":
            depth += 1
        elif chunk == "]":
            depth = max(0, depth - 1)
        elif chunk in (",", ""):
            continue
        else:
            arg = _ARG_RE.match(chunk.strip())
            if arg is not None:
                out.append((arg.group("name"), depth == 0, "-" in arg.group("mode")))
    return out


def ia_doc(ia: InternalAction) -> PlanDoc | None:
    """The action's docstring as a PlanDoc, signature line stripped."""
    raw = getattr(ia, "__doc__", None)
    if not raw:
        return None
    *_signature, body = _split_signature(raw)
    return parse_doc_comment(body)


def _params_for(ia: InternalAction, doc: PlanDoc | None) -> tuple[LlmToolParam, ...]:
    raw = getattr(ia, "__doc__", None) or ""
    names, required, outputs, _body = _split_signature(raw)

    min_args = getattr(ia, "min_args", 0) or 0
    max_args = getattr(ia, "max_args", None)

    variadic_tail = ""
    if not names:
        # no signature line to read: fall back to the declared arity bounds.
        upper = max_args if max_args is not None else min_args
        names = [f"arg{i}" for i in range(max(min_args, upper))]
        required = [i < min_args for i in range(len(names))]
        # arity bounds say nothing about direction, so everything is an input
        outputs = [False] * len(names)
        if max_args is None:
            # variadic: one array parameter stands for "any number of further
            # arguments", since a schema can't express an open-ended list of them.
            variadic_tail = "rest"
            names.append(variadic_tail)
            required.append(False)
            outputs.append(False)

    params: list[LlmToolParam] = []
    for i, name in enumerate(names):
        is_required = required[i] if i < len(required) else False
        param_type = "array" if name == variadic_tail else DEFAULT_TYPE
        description = ""
        documented = None if doc is None else doc.params.get(name)
        if documented is not None:
            param_type, description = documented.type, documented.description
        params.append(LlmToolParam(name=name, type=param_type, description=description,
                                   required=is_required,
                                   output=outputs[i] if i < len(outputs) else False))
    return tuple(params)


def ia_llm_tool(ia: InternalAction) -> LlmTool:
    """The packaged tool definition for one internal action.

    Does not consult the opt-in markers: callers that want the filtering want
    ia_llm_tools() below. This is the single-action view, useful for building
    a tool for an action you already decided to expose.
    """
    doc = ia_doc(ia)
    # first paragraph only: stdlib docstrings continue into porting notes and
    # implementation rationale ("A class, not a plain function, because ..."),
    # which is exactly the kind of text that wastes a model's attention. An
    # action written specifically to be a tool puts its user-facing summary
    # first, so this costs nothing there.
    description = "" if doc is None else doc.summary.split("\n\n", 1)[0].strip()
    if doc is not None and doc.when:
        description = f"{description}\n\nUse when {doc.when}".strip()
    return LlmTool(
        name=tool_name_for(ia.name),
        kind=ToolKind.INTERNAL_ACTION,
        description=description,
        params=_params_for(ia, doc),
        origin=ia,
    )


def ia_llm_tools(actions: Mapping[str, InternalAction], *, enabled: bool,
                 include_all: bool = False) -> list[LlmTool]:
    """The internal actions exposed as tools, in `actions` order.

    Gated twice, on purpose. `enabled` is the agent-level switch: off, this
    returns nothing at all, whatever the individual actions declare. Then each
    action must itself carry llm_tool=True, unless `include_all` overrides
    that -- an escape hatch for experimenting, not the normal path.
    """
    if not enabled:
        return []
    return [ia_llm_tool(ia) for ia in actions.values()
            if include_all or getattr(ia, "llm_tool", False)]

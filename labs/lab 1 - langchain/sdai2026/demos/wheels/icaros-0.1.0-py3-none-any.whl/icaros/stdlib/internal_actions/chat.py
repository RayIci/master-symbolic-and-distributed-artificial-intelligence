"""What an agent says to the person watching it.

ag: not console.py, and the difference is the audience rather than the
plumbing. .print is output -- a program telling a developer what it is doing,
which is why it lands in the dev UI's Log next to the environment's own lines
and the interpreter's warnings. .say is speech, addressed to somebody, and it
lands in the chat where that somebody is already talking back.

It goes on the journal rather than straight to telemetry because the journal
is the agent's own memory and is always on, while a collector is attached by
whichever frontend happens to be watching. "I said X" is something an agent
should still know about itself in a headless run, and the next generation
round reads it back in its preamble -- a model that answered a minute ago can
see that it did.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.journal import JournalKind
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


# ag: deliberately NOT llm_tool=True. The marker in this stdlib means "this
# action only reads" -- the three journal queries carry it and nothing else
# does, so that `llm_tools: - internal_actions` exposes nothing on its own
# (test_ia_tools.py::test_only_the_journal_actions_carry_the_marker pins it).
# Saying something is an act, so it stays unmarked and belongs to plans: the
# agent speaks because a plan of its own decided to, which is also the only
# reading of "on its own initiative" that a BDI agent has.
@internal_action(min_args=1, max_args=1, use_in_context=False)
def say(ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> bool:
    """.say(Text): says Text to the person watching, in the dev UI's chat.

    Nobody has to have asked: this is how an agent starts a conversation as
    well as how it answers one.
    """
    if not args[0].is_string():
        raise ValueError("internal action '.say': the argument must be a string")
    if ts is None:
        return False
    ts.ag.journal.record(JournalKind.SAY, text=args[0].string)
    return True
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.as_syntax.string_term import StringTerm
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


def _text_of(t: Term) -> str:
    return t.string if t.is_string() else str(t)


@internal_action(min_args=2, max_args=2)
def upper_case(ts, un, args) -> bool:
    """.upper_case(T, R): R is T's text, upper-cased."""
    return un.unifies(args[1], StringTerm(_text_of(args[0]).upper()))


@internal_action(min_args=2, max_args=2)
def lower_case(ts, un, args) -> bool:
    """.lower_case(T, R): R is T's text, lower-cased."""
    return un.unifies(args[1], StringTerm(_text_of(args[0]).lower()))


@internal_action(min_args=4, max_args=4)
def replace(ts, un, args) -> bool:
    """.replace(T, Pattern, Replacement, R): R is T with every regex match
    of Pattern replaced by Replacement (Java-compatible: Pattern is a regex)."""
    text = _text_of(args[0])
    pattern = args[1].string
    replacement = args[2].string
    return un.unifies(args[3], StringTerm(re.sub(pattern, replacement, text)))


@internal_action(min_args=2, max_args=4)
def substring(ts, un, args):
    """.substring(Sub, S): containment check. .substring(Sub, S, Start[, End]):
    extracts/binds Sub or S at a ground position, or backtracks over every
    occurrence of Sub in S when Start (and End) are variables."""
    if len(args) == 2:
        return args[1].string.find(args[0].string) >= 0

    if args[2].is_numeric() and args[0].is_var():
        s1 = args[1].string
        start = int(args[2].solve())
        end = int(args[3].solve()) if len(args) == 4 and args[3].is_numeric() else len(s1)
        return un.unifies(args[0], StringTerm(s1[start:end]))

    if args[2].is_numeric() and args[1].is_var():
        s0 = args[0].string
        start = int(args[2].solve())
        end = int(args[3].solve()) if len(args) == 4 and args[3].is_numeric() else len(s0)
        return un.unifies(args[1], StringTerm(s0[start:end]))

    s0, s1 = args[0].string, args[1].string

    def solutions() -> Iterator[Unifier]:
        pos = 0
        while True:
            found = s1.find(s0, pos)
            if found < 0:
                return
            candidate = un.clone()
            ok = candidate.unifies_no_undo(args[2], NumberTermImpl(found))
            if ok and len(args) == 4:
                ok = candidate.unifies_no_undo(args[3], NumberTermImpl(found + len(s0)))
            pos = found + 1
            if ok:
                yield candidate

    return solutions()


@internal_action(min_args=2, max_args=2)
def term2string(ts, un, args) -> bool:
    """.term2string(T, S): converts term T to its textual form S, or parses
    S back into a term when T is a variable."""
    if not args[0].is_var() and args[1].is_string():
        return str(args[0]) == args[1].string
    if not args[0].is_var():
        return un.unifies(args[1], StringTerm(str(args[0])))
    text = args[1].string if args[1].is_string() else str(args[1])
    try:
        from icaros.as_syntax.parser.entry_points import parse
        parsed = parse("term", text)
    except Exception:
        from icaros.as_syntax.atom import Atom
        parsed = Atom(text)
    return un.unifies(args[0], parsed)
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.unifier import Unifier


@internal_action(min_args=1, max_args=1)
def atom_(ts, un, args) -> bool:
    """.atom(X): true iff X is an atom (a 0-arity structure)."""
    return args[0].is_atom()


@internal_action(min_args=1, max_args=1)
def list_(ts, un, args) -> bool:
    """.list(X): true iff X is a list."""
    return args[0].is_list()


@internal_action(min_args=1, max_args=1)
def literal_(ts, un, args) -> bool:
    """.literal(X): true iff X is a literal (any structure, incl. annotated
    or negated ones -- unlike .atom, arity > 0 is fine)."""
    return args[0].is_literal()


@internal_action(min_args=1, max_args=1)
def number_(ts, un, args) -> bool:
    """.number(X): true iff X is a number."""
    return args[0].is_numeric()


@internal_action(min_args=1, max_args=1)
def string_(ts, un, args) -> bool:
    """.string(X): true iff X is a string."""
    return args[0].is_string()


@internal_action(min_args=1, max_args=1)
def structure_(ts, un, args) -> bool:
    """.structure(X): true iff X is a structure.
    ag: in Jason, a bare atom IS a structure (Atom extends Structure, arity 0
    included), so .structure("p") is true there. Here Structure(Atom) is a
    *subclass* of Atom (as_syntax's own pre-existing hierarchy, not touched by
    this batch), and Atom.is_structure() returns False -- so a bare atom is
    NOT considered a structure by this wrapper, a real behavioral divergence
    from Java inherited from as_syntax, out of scope to fix here."""
    return args[0].is_structure()


@internal_action(min_args=1, max_args=1)
def ground_(ts, un, args) -> bool:
    """.ground(X): true iff X has no free variables (numbers/strings/atoms
    are always ground; lists/structures are ground iff every element is)."""
    return args[0].is_ground()


@internal_action(name="internal_action", min_args=1, max_args=1)
def internal_action_(ts, un, args) -> bool:
    """.internal_action(X): true iff X is an internal action call, e.g. .print(a)."""
    return args[0].is_internal_action()


@internal_action(name="namespace", min_args=1, max_args=1)
def namespace_(ts, un, args) -> bool | Iterator[Unifier]:
    """.namespace(NS): with NS bound, true iff NS is a known namespace of the
    belief base. With NS a free var, backtracks over every known namespace."""
    if not args[0].is_var():
        return args[0] in ts.ag.bb.namespaces

    def solutions() -> Iterator[Unifier]:
        for ns in ts.ag.bb.namespaces:
            c = un.clone()
            if c.unifies_no_undo(args[0], ns):
                yield c

    return solutions()


@internal_action(name="type", min_args=2, max_args=2)
def type_(ts, un, args) -> bool | Iterator[Unifier]:
    """.type(X, T): with T bound, true iff T is one of X's types (a term can
    satisfy several at once, e.g. an atom is atom/literal/structure/ground).
    With T a free var, backtracks over every type X satisfies, in the same
    order Jason's own code checks them (not quite the order in Jason's own
    doc comment, which is imprecise -- the code is authoritative): number,
    atom, literal, string, list, set, map, queue, structure, rule, plan,
    ground, free."""
    x = args[0]
    checks = [
        ("number", x.is_numeric()), ("atom", x.is_atom()), ("literal", x.is_literal()),
        ("string", x.is_string()), ("list", x.is_list()), ("set", x.is_set()),
        ("map", x.is_map()), ("queue", x.is_queue()), ("structure", x.is_structure()),
        ("rule", x.is_rule()), ("plan", x.is_plan_body()), ("ground", x.is_ground()),
        ("free", x.is_var()),
    ]
    types = [Atom(name) for name, matched in checks if matched]

    if not args[1].is_var():
        return args[1] in types

    def solutions() -> Iterator[Unifier]:
        for t in types:
            c = un.clone()
            if c.unifies_no_undo(args[1], t):
                yield c

    return solutions()
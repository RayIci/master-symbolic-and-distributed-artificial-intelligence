# The arithmetic functions of this package live in functions.py, not here:
# load_arith_functions (icaros.stdlib.arith_registry) discovers every
# module of icaros.stdlib, recursively, on first use.
from __future__ import annotations

from datetime import datetime
from time import perf_counter_ns

from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.stdlib.registry import internal_action


@internal_action(min_args=3, max_args=3)
def date(ts, un, args) -> bool:
    """.date(Year, Month, Day): current local date."""
    now = datetime.now()
    return (un.unifies(args[0], NumberTermImpl(now.year))
            and un.unifies(args[1], NumberTermImpl(now.month))
            and un.unifies(args[2], NumberTermImpl(now.day)))


@internal_action(min_args=3, max_args=4)
def time(ts, un, args) -> bool:
    """.time(Hour, Minute, Second[, Millisecond]): current local time (24h)."""
    now = datetime.now()
    ok = (un.unifies(args[0], NumberTermImpl(now.hour))
          and un.unifies(args[1], NumberTermImpl(now.minute))
          and un.unifies(args[2], NumberTermImpl(now.second)))
    if len(args) == 4:
        ok = ok and un.unifies(args[3], NumberTermImpl(now.microsecond // 1000))
    return ok


@internal_action(min_args=1, max_args=1)
def nano_time(ts, un, args) -> bool:
    """.nano_time(T): a monotonic nanosecond counter (arbitrary origin, not
    wall-clock time -- for measuring elapsed time only)."""
    return un.unifies(args[0], NumberTermImpl(perf_counter_ns()))
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.map_term import MapTerm
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


def _get_or_create_map(un: Unifier, args: list[Term]) -> MapTerm:
    if args[0].is_map():
        return args[0]
    if args[0].is_var():
        m = MapTerm()
        un.unifies(args[0], m)
        return m
    raise ValueError("internal action '.map.*': first argument must be a map (or an unbound variable)")


@internal_action(name="map.create", min_args=1, max_args=1)
def map_create(ts, un, args) -> bool:
    """.map.create(M): M unifies with a new, empty map."""
    if not args[0].is_var():
        return False
    return un.unifies(args[0], MapTerm())


@internal_action(name="map.put", min_args=3, max_args=3)
def map_put(ts, un, args) -> bool:
    """.map.put(M, Key, Value): stores Value under Key in map M (creating M
    first if it's an unbound variable)."""
    _get_or_create_map(un, args).put(args[1], args[2])
    return True


@internal_action(name="map.get", min_args=3, max_args=4)
def map_get(ts, un, args) -> bool:
    """.map.get(M, Key, Value[, Default]): Value unifies with the value
    stored under Key in map M, or with Default if given and Key is unknown
    (false, with no Default, if Key is unknown)."""
    value = _get_or_create_map(un, args).get(args[1])
    if value is not None:
        return un.unifies(args[2], value)
    if len(args) == 4:
        return un.unifies(args[2], args[3])
    return False


@internal_action(name="map.key", min_args=2, max_args=2)
def map_key(ts, un, args) -> Iterator[Unifier]:
    """.map.key(M, Key): backtracks Key over every key of map M."""
    m = _get_or_create_map(un, args)

    def solutions() -> Iterator[Unifier]:
        for key in m.keys():
            candidate = un.clone()
            if candidate.unifies_no_undo(args[1], key):
                yield candidate

    return solutions()


@internal_action(name="map.value", min_args=2, max_args=2)
def map_value(ts, un, args) -> Iterator[Unifier]:
    """.map.value(M, Value): backtracks Value over every value of map M
    (values may repeat, unlike keys)."""
    m = _get_or_create_map(un, args)

    def solutions() -> Iterator[Unifier]:
        for value in m.values():
            candidate = un.clone()
            if candidate.unifies_no_undo(args[1], value):
                yield candidate

    return solutions()


@internal_action(name="map.remove", min_args=3, max_args=3)
def map_remove(ts, un, args) -> bool:
    """.map.remove(M, Key, Value): removes Key from map M, unifying Value
    with the value it held; false if Key was not present."""
    value = _get_or_create_map(un, args).remove(args[1])
    if value is None:
        return False
    return un.unifies(args[2], value)


@internal_action(name="map.clear", min_args=1, max_args=1)
def map_clear(ts, un, args) -> bool:
    """.map.clear(M): removes every entry of map M."""
    _get_or_create_map(un, args).clear()
    return True


@internal_action(name="map.copy", min_args=2, max_args=2)
def map_copy(ts, un, args) -> bool:
    """.map.copy(M, R): R unifies with a deep copy of map M."""
    m = _get_or_create_map(un, args)
    return un.unifies(args[1], m.deep_clone())
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from icaros.as_syntax.string_term import StringTerm
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


def _args_to_string(args: list[Term]) -> str:
    # mirrors Java println.argsToString: strings unquoted, unbound vars marked
    out = []
    for t in args:
        if t.is_string():
            out.append(t.string)
        elif t.is_var():
            out.append(f"{t}<no-value>")
        else:
            out.append(str(t))
    return "".join(out)


def _write(ts: TransitionSystem | None, text: str) -> None:
    # route through the agent architecture so a GUI can capture the output;
    # plain stdout when there is no arch (e.g. context evaluation in tests)
    if ts is not None and ts.ag_arch is not None:
        ts.ag_arch.print(text)
    else:
        print(text, end="")


@internal_action
def print_(ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> bool:
    """.print(arg0, ...): prints the concatenation of the args, no newline."""
    _write(ts, _args_to_string(args))
    return True


@internal_action
def println(ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> bool:
    """.println(arg0, ...): as .print, with a newline after the args."""
    _write(ts, _args_to_string(args) + "\n")
    return True


@internal_action(name="print_unifier", min_args=0, max_args=0)
def print_unifier(ts, un, args) -> bool:
    """.print_unifier: logs every variable binding in the current unifier."""
    for var, value in un.function.items():
        _write(ts, f"{var}={value}\n")
    _write(ts, "done\n")
    return True


@internal_action(min_args=1, max_args=None)
def printf(ts, un, args) -> bool:
    """.printf(Format, Arg, ...): Java/Python-compatible printf-style
    formatting (numbers are always floats, as in Jason -- prefer %f over %d)."""
    if not args[0].is_string():
        raise ValueError("internal action '.printf': first argument must be a string")
    fmt = args[0].string.replace("%n", "\n")
    values = tuple(a.solve() if a.is_numeric() else _args_to_string([a]) for a in args[1:])
    _write(ts, (fmt % values) + "\n")
    return True


_PUTS_RE = re.compile(r"#\{([A-Za-z0-9_]+)\}")


@internal_action(min_args=1, max_args=2)
def puts(ts, un, args) -> bool:
    """.puts(Format[, R]): like .println, but "#{expr}" placeholders are
    parsed as terms/expressions and evaluated against the current unifier
    (falling back to the literal placeholder text on a parse error).
    Binds R instead of printing when a second, variable argument is given.
    ag: Java's "#{_N}" (referencing an existing UnnamedVar by numeric id, for
    puts/make_vars_annon rename-apart coupling) is not ported -- see
    porting notes; any "#{expr}" is just parsed as a term/expression."""
    if not args[0].is_string():
        raise ValueError("internal action '.puts': first argument must be a string")

    def substitute(m: re.Match) -> str:
        name = m.group(1)
        try:
            from icaros.as_syntax.parser.entry_points import parse
            value = parse("term", name).resolve(un)
        except Exception:
            return m.group(0)
        return value.string if value.is_string() else str(value)

    text = _PUTS_RE.sub(substitute, args[0].string)
    if len(args) == 2 and args[1].is_var():
        return un.unifies(args[1], StringTerm(text))
    _write(ts, text + "\n")
    return True
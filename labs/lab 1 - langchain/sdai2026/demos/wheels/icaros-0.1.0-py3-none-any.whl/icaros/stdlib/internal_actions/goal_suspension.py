from __future__ import annotations

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import create_atom
from icaros.as_syntax.trigger import TEOperator, TEType, Trigger
from icaros.stdlib.registry import InternalAction, internal_action


class Suspend(InternalAction):
    """.suspend / .suspend(Goal): with no argument, suspends the calling
    intention itself. With Goal, suspends every intention with a +!Goal
    frame anywhere in its stack (running, waiting, or already suspended --
    all reachable via Circumstance.all_intentions), plus any *pure* event
    (no intention yet, e.g. a freshly perceived +!Goal) whose own trigger
    matches -- the one case all_intentions() doesn't cover, since it only
    yields events that already carry an intention.
    ag: Java re-scans 5 buckets by hand for the same effect (a comment there
    warns Pending Actions must be checked before Pending Intentions); here
    Circumstance.drop_intention (already ported) removes an intention from
    every bucket it could be in with one call, so bucket order doesn't
    matter -- same simplification already used by goal_lifecycle.py's
    succeed_goal/fail_goal.

    A class, not a plain @internal_action function, because the 0-arg form
    suspends the CALLING intention -- the dispatcher's generic continuation
    (TransitionSystem._execute_intention_step) would otherwise requeue it
    right after execute() returns (unlike .done/.drop_intention, this
    intention is NOT finished, so is_finished() doesn't save us here). This
    needs suspend_intention() to dynamically report True for that one call,
    but False for the Goal-arg form (which must NOT suspend its own caller,
    only the targeted intentions) -- a genuinely per-call dynamic flag, safe
    now that every agent gets its own IA instance (new_instance(), see
    registry.py/agent.py)."""

    name = ".suspend"

    def __init__(self):
        self._suspend_intention = False

    def prepare_arguments(self, body, un):
        return [t.resolve(un) for t in body.get_terms() or []]

    def execute(self, ts, un, args) -> bool:
        if len(args) > 1:
            raise ValueError(f"internal action '.suspend' called with {len(args)} argument(s), expected 0 to 1")

        if len(args) == 0:
            self._suspend_intention = True
            intention = ts.circumstance.selected_intention
            if intention is not None:
                intention.suspended = True
                ts.circumstance.add_pending_intention(
                    f"suspended-self-{intention.id}", intention, Atom("suspend_ia"))
            return True

        self._suspend_intention = False
        goal = args[0]
        trigger = Trigger(TEOperator.ADD, TEType.ACHIEVE, goal)

        for intention in list(ts.circumstance.all_intentions()):
            if not intention.has_trigger(trigger, un.clone()):
                continue
            ts.circumstance.drop_intention(intention, notify=False)
            intention.suspended = True
            ts.circumstance.add_pending_intention(
                f"suspended-{intention.id}", intention, Atom("suspend_ia"))

        for event in list(ts.circumstance.events_plus_atomic):
            if event.intention is not None:
                continue  # already handled above, via its intention
            if un.clone().unifies_no_undo(trigger, event.trigger):
                ts.circumstance.remove_event(event)
                ts.circumstance.add_pending_event(
                    f"suspended-event-{id(event)}", event, Atom("suspend_ia"))
        return True

    def suspend_intention(self) -> bool:
        return self._suspend_intention

    def can_be_used_in_context(self) -> bool:
        return True

    def new_instance(self) -> Suspend:
        return Suspend()


suspend = Suspend()


@internal_action(name="resume", min_args=1, max_args=1)
def resume(ts, un, args) -> bool:
    """.resume(Goal): undoes .suspend for every matching intention/event --
    resumes ALL matches found, not just the first."""
    goal = args[0]
    trigger = Trigger(TEOperator.ADD, TEType.ACHIEVE, goal)
    resume_reason = create_atom("resume_ia")

    for key, intention in list(ts.circumstance.pending_intentions.items()):
        if not intention.suspended or not intention.has_trigger(trigger, un.clone()):
            continue
        intention.suspended = False
        for listener in list(ts.circumstance.listeners):
            listener.intention_resumed(intention, resume_reason)
        ts.circumstance.remove_pending_intention(key)
        if key.startswith("suspended-self-"):
            # the .suspend call itself is still the unfinished current step
            intention.peek().remove_current_step()
        ts.circumstance.resume_intention(intention, resume_reason)

    for key, event in list(ts.circumstance.pending_events.items()):
        if not key.startswith("suspended-event-"):
            continue
        if un.clone().unifies_no_undo(trigger, event.trigger):
            ts.circumstance.remove_pending_event(key)
            ts.circumstance.add_event(event)
    return True


@internal_action(name="suspended", min_args=2, max_args=2)
def suspended(ts, un, args) -> bool:
    """.suspended(Goal, Reason): checks (does not mutate) whether Goal
    belongs to a suspended intention. Not backtracking -- stops at the
    first match, bool result. If the matching intention is parked waiting
    for an action's feedback, Reason is forced to the atom `act`; otherwise
    Reason unifies with the intention's own suspended_reason."""
    goal, reason = args
    trigger = Trigger(TEOperator.ADD, TEType.ACHIEVE, goal)

    for action in ts.circumstance.pending_actions.values():
        if action.intention.has_trigger(trigger, un.clone()):
            return un.unifies(reason, Atom("act"))

    for intention in ts.circumstance.pending_intentions.values():
        if intention.has_trigger(trigger, un.clone()):
            return un.unifies(reason, intention.suspended_reason)

    return False
from __future__ import annotations

import re
import threading
from pathlib import Path
from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.string_term import StringTerm
from icaros.bb.belief_base import BeliefBase
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term


def _as_str(t: Term) -> str:
    return t.string if t.is_string() else str(t)


@internal_action(name="create_agent", min_args=2, max_args=3)
def create_agent(ts, un, args) -> bool:
    """.create_agent(Name, Source[, Beliefs]): boots and starts a new agent
    from an .asl file, registered in the same Runner as the caller. With
    Name a free var, a base name is derived from the var's own name
    (first letter lowercased, matching Java) and deduplicated
    (name/name_1/name_2/...), then bound back into Name. With Name already
    bound, a collision with an existing agent fails the action (safer than
    Java's silent implicit rename, which only really applies to the
    var case anyway).
    ag: scope reduced from Java's create_agent -- no custom agentClass/
    beliefBaseClass/agentArchClass here (icaros has one un-chainable AgArch
    by design). That class-name-string resolution convention does exist
    elsewhere, for `.mas2i`'s agent_class/ag_arch_class/belief_base_class
    (mas2i/loader.py's _load_subclass), just not (yet) for this internal
    action; Source is mandatory here (Java can omit it, falling back to
    an empty default agent, not meaningful without custom classes)."""
    name_arg, source_arg = args[0], args[1]
    beliefs = args[2].get_as_list() if len(args) == 3 else None
    source = _as_str(source_arg)

    runner = ts.ag_arch.runner
    if runner is None:
        raise ValueError(".create_agent: no runner configured for this agent")

    if name_arg.is_var():
        base = str(name_arg)
        base = base[0].lower() + base[1:] if base else base
    else:
        base = _as_str(name_arg)

    ag_arch = runner.create_agent(base, source, beliefs)
    if not name_arg.is_var() and ag_arch.ag_name != base:
        # base name collided and got silently deduplicated -- not allowed
        # for an explicitly-bound name, roll back.
        runner.del_ag(ag_arch.ag_name)
        raise ValueError(f".create_agent: an agent named '{base}' already exists")

    ag_arch.start_thread()
    if name_arg.is_var():
        return un.unifies(name_arg, Atom(ag_arch.ag_name))
    return True


@internal_action(name="kill_agent", min_args=1, max_args=2)
def kill_agent(ts, un, args) -> bool:
    """.kill_agent(Name[, Deadline]): stops and unregisters the named agent
    asynchronously (fire-and-forget, like Java) -- any agent can kill any
    other, no permission check (same provisional/unsafe status Java's own
    doc flags it with)."""
    name = _as_str(args[0])
    deadline = args[1].solve() if len(args) == 2 else 0
    runner = ts.ag_arch.runner
    if runner is None:
        return False
    return runner.kill_agent(name, deadline)


@internal_action(name="clone", min_args=1, max_args=1)
def clone(ts, un, args) -> bool:
    """.clone(Name): clones the CALLING agent's own beliefs and plans into a
    freshly created, started agent named Name (deduplicated if taken)."""
    runner = ts.ag_arch.runner
    if runner is None:
        raise ValueError(".clone: no runner configured for this agent")
    ag_arch = runner.clone_agent(ts.ag, _as_str(args[0]))
    ag_arch.start_thread()
    return True


@internal_action(name="all_names", min_args=1, max_args=1)
def all_names(ts, un, args) -> bool:
    """.all_names(Result): Result unifies with the names of every agent
    currently registered in this MAS."""
    runner = ts.ag_arch.runner
    names = runner.agent_names() if runner is not None else [ts.ag_arch.ag_name]
    result = ListTerm()
    result.extend(Atom(n) for n in names)
    return un.unifies(args[0], result)


@internal_action(name="stopMAS", min_args=0, max_args=1, use_in_context=False)
def stop_mas(ts, un, args) -> bool:
    """.stopMAS[(Deadline)]: stops every agent registered in this MAS (and
    the environment, if any) after Deadline ms (default 0).
    ag: Java also supports stopping the whole JVM (System.exit) -- always
    omitted here, not just simplified: calling sys.exit() from inside a
    library internal action is inappropriate for an interpreter meant to be
    embeddable, not just run standalone. Always deferred to a background
    timer, even for Deadline=0 -- stopping the CALLING agent's own AgArch
    synchronously would deadlock (AgArch.stop_ag() joins its own thread)."""
    deadline = args[0].solve() if args else 0
    runner = ts.ag_arch.runner
    arches = runner.ag_list() if runner is not None else [ts.ag_arch]

    def do_stop() -> None:
        for arch in arches:
            arch.signal_stop()
        for arch in arches:
            arch.join_stopped()
        if runner is not None and runner.environment is not None:
            runner.environment.shutdown()

    timer = threading.Timer(max(deadline, 0) / 1000.0, do_stop)
    timer.daemon = True
    timer.start()
    return True


@internal_action(name="save_agent", min_args=1, max_args=2)
def save_agent(ts, un, args) -> bool:
    """.save_agent(File[, InitialGoals]): writes this agent's beliefs,
    rules, optional initial goals, and plans as AgentSpeak source text into
    File. Beliefs are written with their own source(self) annotation
    stripped (percept-/externally-sourced beliefs keep theirs)."""
    path = _as_str(args[0])
    goals = args[1].get_as_list() if len(args) == 2 else []

    lines = ["// beliefs and rules\n"]
    for b in ts.ag.bb:
        b = b.copy()
        b.del_source(BeliefBase.self_atom)
        lines.append(f"{b}.\n")

    lines.append("\n\n// initial goals\n")
    for g in goals:
        lines.append(f"!{g}.\n")

    lines.append("\n\n")
    lines.append(ts.ag.pl.get_as_txt())

    Path(path).write_text("".join(lines))
    return True


@internal_action(name="list_files", min_args=2, max_args=3)
def list_files(ts, un, args) -> bool:
    """.list_files(Path[, Pattern], Result): Result unifies with the full
    paths of every file (recursively) under Path whose bare filename
    matches Pattern (a regex, full-match; default ".*" when omitted).
    Directories are only ever walked into, never themselves returned."""
    base = Path(_as_str(args[0]))
    if len(args) == 3:
        pattern = _as_str(args[1])
        result_arg = args[2]
    else:
        pattern = ".*"
        result_arg = args[1]

    regex = re.compile(pattern)
    matches = ListTerm()
    for p in sorted(base.rglob("*")):
        if p.is_file() and regex.fullmatch(p.name):
            matches.append(StringTerm(str(p)))
    return un.unifies(result_arg, matches)


@internal_action(name="perceive", min_args=0, max_args=0)
def perceive(ts, un, args) -> bool:
    """.perceive: forces an immediate perception of the environment (the
    same Agent.buf() sense() already runs every cycle, triggered out of band
    instead of waiting for the next one)."""
    ts.ag.buf(ts.ag_arch.perceive())
    return True
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.map_term import MapTerm
from icaros.as_syntax.string_term import StringTerm
from icaros.journal import NARRATIVE_KINDS, JournalKind, render_entry
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term

# ag: retrieval only. These say WHAT HAPPENED -- the entries of a cycle or a
# range of cycles, optionally filtered by kind -- and stop there. Working out
# what it means is the caller's job, whether that caller is a plan or a model.
#
# There is deliberately no action that returns "the explanation" of a cycle:
# assembling one is a real inference, and something that merely concatenates
# log lines under that name would be handing back a confident-sounding account
# nobody actually derived.
#
# Ordinary internal actions, not a private channel for the model: an agent with
# no LLM calls them from a plan, and a model reaching them through tool-calling
# goes through the very same execute().

JOURNAL_ACTIONS = frozenset({".timeline", ".recall", ".beliefs_at"})


def _kinds(term: Term) -> tuple[JournalKind, ...] | None:
    """A list of kind names as JournalKinds. None if any name is unknown --
    a typo must fail the call, not quietly widen it to everything."""
    names = [str(k).strip('"') for k in term] if hasattr(term, "__iter__") else [str(term)]
    try:
        return tuple(JournalKind(name) for name in names)
    except ValueError:
        return None


def _int(term: Term, default: int) -> int:
    try:
        return int(float(str(term)))
    except (TypeError, ValueError):
        return default


@internal_action(name=".timeline", min_args=1, max_args=4, llm_tool=True)
def timeline(ts, un: Unifier, args: list[Term]) -> bool:
    """.timeline([+From, +To, [+Kinds,]] -Entries): what happened, oldest first.

    One entry per string. With no cycle range, the most recent entries; with
    one, only the cycles in [From, To].

    ag: one bracketed signature rather than three alternative shapes. The
    shapes get merged into a single parameter list, and the merge orders them
    by first appearance -- which for ".timeline(-Entries) / .timeline(+From,
    +To, -Entries)" is (Entries, From, To), an order no actual call uses. A
    caller building arguments positionally from that list, which is what the
    tool executor does, would pass them in the wrong slots.

    @when you need to know what has already happened, at a given cycle or over
        a range of them
    @param From:number first reasoning cycle to include
    @param To:number last reasoning cycle to include
    @param Kinds:array kind names to keep, e.g. ["deliberate", "bb_delta"]
    @param Entries the matching entries, as a list of strings
    """
    journal = ts.ag.journal
    # ag: the shapes are 1, 3 and 4 arguments; 2 is not one of them and is
    # refused rather than interpreted. It used to fall through to the
    # no-range branch, where From was silently dropped and the caller's To
    # became the output variable -- an answer to a question nobody asked,
    # handed back as if it were the right one.
    if len(args) == 2:
        return False
    kinds = NARRATIVE_KINDS
    if len(args) == 4:
        kinds = _kinds(args[2])
        if kinds is None:
            return False
    entries = journal.window(kinds=kinds)
    if len(args) >= 3:
        low, high = _int(args[0], 0), _int(args[1], ts.cycle_count)
        entries = [e for e in entries if low <= e.cycle <= high]
    else:
        entries = entries[-20:]
    return un.unifies(args[-1], ListTerm([StringTerm(render_entry(e)) for e in entries]))


@internal_action(name=".recall", min_args=2, max_args=2, llm_tool=True)
def recall(ts, un: Unifier, args: list[Term]) -> bool:
    """.recall(+Cycle, -Facts): one cycle, in parts rather than as prose.

    A map with `deliberations`, `llm_choices`, `events` and `beliefs`. Each
    entry keeps its own fields -- the plan label, the trigger, how many
    candidates had a false context -- so a plan can test them instead of
    parsing a sentence.

    @when you need to work with what happened at a cycle rather than read it,
        for instance to branch on which plan ran
    @param Cycle:number the reasoning cycle to look up
    @param Facts the cycle's entries and beliefs, as a map
    """
    memory = ts.ag.journal.recall(_int(args[0], ts.cycle_count))
    facts = MapTerm()
    for key in ("deliberations", "llm_choices", "events"):
        facts.put(Atom(key), ListTerm([_as_map(item) for item in memory[key]]))
    beliefs = memory["beliefs"]
    # ag: absent, not empty. An empty list would read as "believed nothing",
    # which is a different claim from "cannot reconstruct it".
    if beliefs is not None:
        facts.put(Atom("beliefs"), ListTerm([StringTerm(b) for b in beliefs]))
    return un.unifies(args[1], facts)


def _as_map(detail: dict[str, str]) -> MapTerm:
    out = MapTerm()
    for key, value in detail.items():
        out.put(Atom(key), StringTerm(value))
    return out


@internal_action(name=".beliefs_at", min_args=2, max_args=2, llm_tool=True)
def beliefs_at(ts, un: Unifier, args: list[Term]) -> bool:
    """.beliefs_at(+Cycle, -Beliefs): what I believed at the end of a cycle.

    FAILS when that far back can no longer be reconstructed, rather than
    answering with what I believe now.

    @when you need the belief base as it stood at a past cycle, which is
        rarely the one you have now
    @param Cycle:number the reasoning cycle to look up
    @param Beliefs the belief base of that cycle, as a list of strings
    """
    beliefs = ts.ag.journal.beliefs_at(_int(args[0], ts.cycle_count))
    # ag: the failure is the feature. beliefs_at() returns None for "I no
    # longer know", and turning that into an empty list -- or worse, into the
    # current beliefs -- would let a plan, or a model, build on a belief base
    # that was never real.
    if beliefs is None:
        return False
    return un.unifies(args[1], ListTerm([StringTerm(b) for b in beliefs]))
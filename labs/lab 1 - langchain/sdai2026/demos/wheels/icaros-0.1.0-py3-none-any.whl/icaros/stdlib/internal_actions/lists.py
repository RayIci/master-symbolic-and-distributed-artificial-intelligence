from __future__ import annotations

import re
from typing import TYPE_CHECKING

from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.number_term_impl import NumberTermImpl
from icaros.as_syntax.string_term import StringTerm
from icaros.stdlib.arith_registry import arith_function
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


def _size_of(term: Term) -> int | None:
    if term.is_list() or term.is_set() or term.is_map():
        return term.size()
    if term.is_string():
        return term.length()
    return None


@internal_action(min_args=2, max_args=2)
def length(ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> bool:
    """.length(L, X): unifies X with the size of the list/string/set/map L."""
    size = _size_of(args[0])
    if size is None:
        return False
    return un.unifies(args[1], NumberTermImpl(size))


# ag: an ARITHMETIC function (jason.functions.Length, which Java's
# FunctionRegister registers under the dotted name ".length"), not an internal
# action -- it lives here, next to the .length internal action it shares its
# name and its _size_of body with, rather than under stdlib/math/. The two
# never collide: the parser picks by name AND arity (transformer.arith_literal,
# Java's getArithFunction/checkArity), so `.length(L)` in an arithmetic
# position is this function and `.length(L, X)` is the internal action above.
# Jason's other dotted function, `.count(Query)`, is NOT ported: it queries the
# belief base, and an ArithFunction here gets no agent (see porting.md and
# as_semantics/arith_function.py) -- the `.count(Query, N)` internal action is
# unaffected.
@arith_function(name=".length", min_args=1, max_args=1)
def length_function(args: list[Term]) -> float:
    """.length(L): the size of the list/string/set/map L, usable inside an
    arithmetic expression (e.g. `.wait(.count(done, .length(G)))`)."""
    size = _size_of(args[0])
    if size is None:
        raise ValueError(f"function '.length': expected a list, string, set or map, got {args[0]}")
    return size


@internal_action(min_args=2, max_args=2)
def member(ts: TransitionSystem | None, un: Unifier, args: list[Term]) -> bool | Iterator[Unifier]:
    """.member(X, L): X unifies with a member of L; one solution per member."""
    target, collection = args
    if collection.is_set() and target.is_ground():
        return target in collection  # fast track, as Java member.java
    if not (collection.is_list() or collection.is_set()):
        raise ValueError(f"internal action '.member': second argument must be a list or a set, got {collection}")

    def solutions() -> Iterator[Unifier]:
        for t in collection:
            candidate = un.clone()
            if candidate.unifies_no_undo(target, t):
                yield candidate

    return solutions()


@internal_action(min_args=2, max_args=2)
def sort(ts, un, args) -> bool:
    """.sort(L, S): unifies S with L sorted by the standard term order."""
    if not args[0].is_list():
        raise ValueError("internal action '.sort': first argument must be a list")
    result = ListTerm()
    result.extend(sorted(args[0]))
    return un.unifies(args[1], result)


@internal_action(min_args=2, max_args=2)
def reverse(ts, un, args) -> bool:
    """.reverse(L, R): R is L (list or string) reversed."""
    if args[0].is_list():
        return un.unifies(args[1], args[0].reverse())
    if args[0].is_string():
        return un.unifies(args[1], StringTerm(args[0].string[::-1]))
    raise ValueError("internal action '.reverse': first argument must be a list or string")


def _concat_plain_value(t: Term) -> str:
    return t.string if t.is_string() else str(t)


@internal_action(min_args=2, max_args=4)
def concat(ts, un, args) -> bool:
    """.concat(A, B, ..., R): concatenates lists, or builds a string from
    the plain-text form of each argument (unquoted strings, no backtracking)."""
    if args[0].is_list():
        result = args[0].clone()
        for a in args[1:-1]:
            if not a.is_list():
                raise ValueError("internal action '.concat': all but the last argument must be lists")
            result.concat(a.clone())  # mutates result in place; return value (lt.get_last()) is irrelevant here
        return un.unifies(args[-1], result)
    text = "".join(_concat_plain_value(a) for a in args[:-1])
    last = args[-1]
    if not last.is_string() and not last.is_var():
        last = StringTerm(str(last))
    return un.unifies(StringTerm(text), last)


@internal_action(min_args=3, max_args=3)
def nth(ts, un, args):
    """.nth(N, L, X): N-th element of list/string L (0-based) unifies with X;
    if N is a variable, backtracks over every index whose element unifies with X."""
    collection = args[1]
    if collection.is_string():
        items = [StringTerm(c) for c in collection.string]
    elif collection.is_list():
        items = collection.get_as_list()
    else:
        raise ValueError("internal action '.nth': second argument must be a list or string")

    if args[0].is_numeric():
        index = int(args[0].solve())
        if index < 0 or index >= len(items):
            raise ValueError(f"internal action '.nth': index {index} is out of bounds ({len(items)})")
        return un.unifies(args[2], items[index])

    def solutions() -> Iterator[Unifier]:
        for i, item in enumerate(items):
            candidate = un.clone()
            if candidate.unifies_no_undo(args[2], item) and candidate.unifies_no_undo(args[0], NumberTermImpl(i)):
                yield candidate

    return solutions()


@internal_action(min_args=2, max_args=2)
def sublist(ts, un, args) -> Iterator[Unifier]:
    """.sublist(S, L): S unifies with a contiguous sublist of L; backtracks
    over every outer suffix's every prefix, longest-first, then the empty list."""
    if not args[1].is_list():
        raise ValueError("internal action '.sublist': second argument must be a list")

    def candidates() -> Iterator[list[Term]]:
        outer = args[1]
        while outer is not None and outer.is_list() and not outer.is_end():
            items = outer.get_as_list()
            while items:
                yield items
                items = items[:-1]
            outer = outer.get_next()
        yield []

    def solutions() -> Iterator[Unifier]:
        seen_empty = False
        for items in candidates():
            if not items:
                if seen_empty:
                    continue
                seen_empty = True
            candidate_term = ListTerm()
            candidate_term.extend(items)
            candidate_un = un.clone()
            if candidate_un.unifies_no_undo(args[0], candidate_term):
                yield candidate_un

    return solutions()


def _affix(un: Unifier, pattern: Term, whole: Term, suffix: bool) -> Iterator[Unifier]:
    if whole.is_list():
        items = whole.get_as_list()
        is_list = True
    elif whole.is_string():
        items = list(whole.string)
        is_list = False
    else:
        raise ValueError("internal action '.prefix'/'.suffix': second argument must be a list or string")

    def candidates() -> Iterator[list]:
        n = len(items)
        for i in range(n, -1, -1):
            yield items[n - i:] if suffix else items[:i]

    def solutions() -> Iterator[Unifier]:
        for chunk in candidates():
            if is_list:
                candidate_term = ListTerm()
                candidate_term.extend(chunk)
            else:
                candidate_term = StringTerm("".join(chunk))
            candidate_un = un.clone()
            if candidate_un.unifies_no_undo(pattern, candidate_term):
                yield candidate_un

    return solutions()


@internal_action(min_args=2, max_args=2)
def prefix(ts, un, args) -> Iterator[Unifier]:
    """.prefix(P, L): P unifies with a prefix of list/string L, longest first,
    down to the empty list/string."""
    return _affix(un, args[0], args[1], suffix=False)


@internal_action(min_args=2, max_args=2)
def suffix(ts, un, args) -> Iterator[Unifier]:
    """.suffix(S, L): S unifies with a suffix of list/string L, longest first,
    down to the empty list/string."""
    return _affix(un, args[0], args[1], suffix=True)


@internal_action(min_args=3, max_args=4)
def delete(ts, un, args) -> bool:
    """.delete(Start[, End], L, R) or .delete(Sub, S, R) or .delete(X, L, R):
    deletes an index range, a substring, or every occurrence of a term."""
    if args[0].is_numeric():
        start = int(args[0].solve())
        next_arg = 1
        end = start + 1
        if len(args) == 4 and args[1].is_numeric():
            next_arg = 2
            end = int(args[1].solve())
        target = args[next_arg]
        result_arg = args[next_arg + 1]
        if target.is_string():
            s = target.string
            return un.unifies(result_arg, StringTerm(s[:start] + s[end:] if 0 <= start <= end <= len(s) else s))
        if target.is_list():
            items = target.get_as_list()
            kept = [t for i, t in enumerate(items) if i < start or i >= end]
            result = ListTerm()
            result.extend(kept)
            return un.unifies(result_arg, result)
        raise ValueError("internal action '.delete': target must be a list or string")

    if args[0].is_string() and len(args) == 3:
        needle = args[0].string
        haystack = args[1].string if args[1].is_string() else str(args[1])
        return un.unifies(args[2], StringTerm(re.sub(needle, "", haystack)))

    if args[1].is_list() and len(args) == 3:
        items = args[1].get_as_list()
        kept = []
        for t in items:
            candidate = un.clone()
            if not candidate.unifies_no_undo(args[0], t):
                kept.append(t.clone())
        result = ListTerm()
        result.extend(kept)
        return un.unifies(args[2], result)

    raise ValueError("internal action '.delete': incorrect argument shape (see documentation)")


def _check_two_lists(args: list[Term]) -> None:
    if not args[0].is_list() or not args[1].is_list():
        raise ValueError("internal action: both arguments must be lists")


@internal_action(min_args=3, max_args=3)
def union(ts, un, args) -> bool:
    """.union(L1, L2, R): R is the sorted, duplicate-free union of L1 and L2."""
    _check_two_lists(args)
    return un.unifies(args[2], args[0].union(args[1]))


@internal_action(min_args=3, max_args=3)
def intersection(ts, un, args) -> bool:
    """.intersection(L1, L2, R): R is the sorted intersection of L1 and L2."""
    _check_two_lists(args)
    return un.unifies(args[2], args[0].intersection(args[1]))


@internal_action(min_args=3, max_args=3)
def difference(ts, un, args) -> bool:
    """.difference(L1, L2, R): R is L1 minus the elements also in L2, sorted."""
    _check_two_lists(args)
    return un.unifies(args[2], args[0].difference(args[1]))


@internal_action(min_args=1, max_args=1)
def empty(ts, un, args) -> bool:
    """.empty(X): true if X is an empty list/string/set/map."""
    t = args[0]
    if t.is_list():
        return t.is_empty()
    if t.is_string():
        return t.length() == 0
    size = _size_of(t)
    return size is not None and size == 0
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.atom import Atom
from icaros.as_syntax.factory import create_structure
from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.pred import Pred
from icaros.as_syntax.string_term import StringTerm
from icaros.as_syntax.trigger import TEOperator, TEType, Trigger
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from collections.abc import Iterator

    from icaros.as_semantics.circumstance import Circumstance
    from icaros.as_semantics.intention import Intention
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


@internal_action(min_args=1, max_args=1)
def my_name(ts, un, args) -> bool:
    """.my_name(Name): unifies Name with this agent's name in the society."""
    return un.unifies(args[0], Atom(ts.ag_arch.ag_name))


def _intention_ids_match(intention: Intention, un: Unifier, int_id: Term | None) -> Unifier | None:
    """Tries binding int_id to intention.id (as a StringTerm -- icaros uses
    UUIDs, not Jason's sequential ints); returns the resulting clone on
    success, None on failure. int_id=None always succeeds (id not requested)."""
    candidate = un.clone()
    if int_id is None:
        return candidate
    if candidate.unifies_no_undo(int_id, StringTerm(str(intention.id))):
        return candidate
    return None


def _matching_intentions(circumstance: Circumstance, goal: Term, un: Unifier,
                          int_id: Term | None, consider_suspended: bool) -> Iterator[Unifier]:
    """.intend/.desire's shared core: +!goal unifies with any IntendedMeans'
    trigger, in any frame, of any intention (optionally including suspended
    ones)."""
    trigger = Trigger(TEOperator.ADD, TEType.ACHIEVE, goal)
    for intention in circumstance.all_intentions():
        if not consider_suspended and intention.suspended:
            continue
        for im in intention:
            candidate = un.clone()
            if candidate.unifies_no_undo(trigger, im.trigger):
                result = _intention_ids_match(intention, candidate, int_id)
                if result is not None:
                    yield result


@internal_action(min_args=1, max_args=2)
def intend(ts, un, args) -> Iterator[Unifier]:
    """.intend(Goal[, IntId]): Goal (a bare achievement goal, no ! prefix)
    unifies with the triggering goal of any (non-suspended) intention."""
    int_id = args[1] if len(args) == 2 else None
    return _matching_intentions(ts.circumstance, args[0], un, int_id, consider_suspended=False)


def _matching_events(circumstance: Circumstance, goal: Term, un: Unifier,
                      int_id: Term | None) -> Iterator[Unifier]:
    trigger = Trigger(TEOperator.ADD, TEType.ACHIEVE, goal)

    def candidates():
        if circumstance.selected_event is not None:
            yield circumstance.selected_event
        yield from circumstance.events_plus_atomic
        yield from circumstance.pending_events.values()

    for event in candidates():
        cur_trigger = event.trigger
        if event.intention is not None and not event.intention.is_finished():
            cur_trigger = cur_trigger.resolve(event.intention.peek().unifier)
        candidate = un.clone()
        if candidate.unifies_no_undo(trigger, cur_trigger):
            result = (_intention_ids_match(event.intention, candidate, int_id)
                      if event.intention is not None else candidate)
            if result is not None:
                yield result


@internal_action(min_args=1, max_args=2)
def desire(ts, un, args) -> Iterator[Unifier]:
    """.desire(Goal[, IntId]): as .intend, but also matches Goal against
    pending/selected events (not yet turned into an intention), and
    considers suspended intentions too."""
    int_id = args[1] if len(args) == 2 else None
    circumstance = ts.circumstance
    yield from _matching_events(circumstance, args[0], un, int_id)
    yield from _matching_intentions(circumstance, args[0], un, int_id, consider_suspended=True)


def _current_intention(ts: TransitionSystem) -> Intention | None:
    circumstance = ts.circumstance
    if circumstance.selected_intention is not None:
        return circumstance.selected_intention
    if circumstance.selected_event is not None:
        return circumstance.selected_event.intention
    return None


@internal_action(name="current_intention", min_args=1, max_args=1)
def current_intention_(ts, un, args) -> bool:
    """.current_intention(I): I unifies with a simplified description of the
    currently-executing intention (id + list of its pending goals, one per
    stack frame, innermost first)."""
    intention = _current_intention(ts)
    if intention is None:
        return False
    stack = ListTerm()
    stack.extend(im.trigger.literal for im in intention)
    return un.unifies(args[0], create_structure("intention", StringTerm(str(intention.id)), stack))


def _place_of(circumstance: Circumstance, intention: Intention) -> str:
    # ag: Intention.place is never actually set anywhere in this port (dead
    # field), so the place has to be found by direct bucket membership, not
    # by reading intention.place.
    if circumstance.selected_intention is intention:
        return "selected_intention"
    if circumstance.selected_event is not None and circumstance.selected_event.intention is intention:
        return "selected_event"
    if any(e.intention is intention for e in circumstance.events_plus_atomic):
        return "event_queue"
    if any(e.intention is intention for e in circumstance.pending_events.values()):
        return "pending_events"
    if any(a.intention is intention for a in circumstance.pending_actions.values()):
        return "pending_actions"
    if intention in circumstance.pending_intentions.values():
        return "pending_intentions"
    if intention in circumstance.running_intentions_plus_atomic:
        return "running_intentions"
    return "none"


def _state_of(circumstance: Circumstance, intention: Intention) -> Term:
    place = _place_of(circumstance, intention)
    if place == "pending_actions":
        state = Pred("waiting")
        state.add_annot(create_structure("action", intention.suspended_reason))
        return state
    if place == "pending_intentions" and not intention.suspended:
        state = Pred("waiting")
        state.add_annot(create_structure("reason", intention.suspended_reason))
        return state
    if place in ("pending_events", "pending_intentions"):
        return Atom("suspended")
    if place in ("event_queue", "running_intentions", "selected_intention", "selected_event"):
        return Atom("running")
    return Atom("undefined")


@internal_action(min_args=2, max_args=3)
def intention(ts, un, args) -> Iterator[Unifier]:
    """.intention(Id, State[, Stack]): backtracks over every known intention
    (running, waiting, suspended -- everywhere in the circumstance), unifying
    Id (as a string) and a state atom (running/waiting/suspended/undefined,
    waiting/suspended annotated with reason(...)/action(...) where Jason
    does), and optionally its goal stack (innermost first)."""
    circumstance = ts.circumstance
    for candidate_int in circumstance.all_intentions():
        candidate = un.clone()
        if not candidate.unifies_no_undo(args[0], StringTerm(str(candidate_int.id))):
            continue
        if not candidate.unifies_no_undo(args[1], _state_of(circumstance, candidate_int)):
            continue
        if len(args) == 3:
            stack = ListTerm()
            stack.extend(im.trigger.literal for im in candidate_int)
            if not candidate.unifies_no_undo(args[2], stack):
                continue
        yield candidate
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_syntax.list_term import ListTerm
from icaros.as_syntax.queue_term import QueueTerm
from icaros.stdlib.registry import internal_action

if TYPE_CHECKING:
    from icaros.as_semantics.transition_system import TransitionSystem
    from icaros.as_semantics.unifier import Unifier
    from icaros.as_syntax.term import Term


def _require_queue(args: list[Term], ia_name: str) -> QueueTerm:
    # ag: unlike .map.*/.set.*, Jason's .queue.* IAs never auto-vivify --
    # only .queue.create produces a new queue, everything else needs one
    # already bound (put.java-style auto-vivification has no queue analogue).
    if not args[0].is_queue():
        raise ValueError(f"internal action '{ia_name}': first argument must be a queue created by .queue.create")
    return args[0]


@internal_action(name="queue.create", min_args=1, max_args=2)
def queue_create(ts, un, args) -> bool:
    """.queue.create(Q) or .queue.create(Q, priority): Q unifies with a new,
    empty queue (FIFO by default, or ordered by the standard term order if
    the atom `priority` is given)."""
    if not args[0].is_var():
        return False
    priority = False
    if len(args) == 2:
        if not (args[1].is_atom() and args[1].functor == "priority"):
            raise ValueError("internal action '.queue.create': second argument must be the atom 'priority'")
        priority = True
    return un.unifies(args[0], QueueTerm(priority=priority))


@internal_action(name="queue.add", min_args=2, max_args=2)
def queue_add(ts, un, args) -> bool:
    """.queue.add(Q, X): adds X to queue Q."""
    _require_queue(args, ".queue.add").add(args[1])
    return True


@internal_action(name="queue.add_all", min_args=2, max_args=2)
def queue_add_all(ts, un, args) -> bool:
    """.queue.add_all(Q, L): adds every element of list L to queue Q."""
    if not args[1].is_list():
        raise ValueError("internal action '.queue.add_all': second argument must be a list")
    q = _require_queue(args, ".queue.add_all")
    for t in args[1]:
        q.add(t)
    return True


@internal_action(name="queue.head", min_args=2, max_args=2)
def queue_head(ts, un, args) -> bool:
    """.queue.head(Q, X): X unifies with the head of queue Q, without
    removing it; false if Q is empty."""
    t = _require_queue(args, ".queue.head").head()
    if t is None:
        return False
    return un.unifies(args[1], t)


@internal_action(name="queue.remove", min_args=2, max_args=2)
def queue_remove(ts, un, args) -> bool:
    """.queue.remove(Q, X): removes the head of queue Q, unifying X with it;
    false if Q is empty."""
    t = _require_queue(args, ".queue.remove").poll()
    if t is None:
        return False
    return un.unifies(args[1], t)


@internal_action(name="queue.clear", min_args=1, max_args=1)
def queue_clear(ts, un, args) -> bool:
    """.queue.clear(Q): removes every element of queue Q."""
    _require_queue(args, ".queue.clear").clear()
    return True


@internal_action(name="queue.copy", min_args=2, max_args=2)
def queue_copy(ts, un, args) -> bool:
    """.queue.copy(Q, R): R unifies with a deep copy of queue Q (preserving
    its FIFO/priority mode)."""
    q = _require_queue(args, ".queue.copy")
    return un.unifies(args[1], q.deep_clone())


@internal_action(name="queue.to_list", min_args=2, max_args=2)
def queue_to_list(ts, un, args) -> bool:
    """.queue.to_list(Q, L): L unifies with the elements of queue Q in its
    internal order (insertion order for a FIFO queue; not guaranteed to be
    priority order for a priority queue, only head/remove guarantee that)."""
    q = _require_queue(args, ".queue.to_list")
    result = ListTerm()
    result.extend(t.clone() for t in q)
    return un.unifies(args[1], result)
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.as_semantics.arith_function import ArithFunction, FunctionArith
from icaros.stdlib.registry import _discover

if TYPE_CHECKING:
    from types import ModuleType

    from icaros.as_semantics.arith_function import ArithFn


def arith_function(fn: ArithFn | None = None, *, ns: str = "math", name: str | None = None,
                    min_args: int = 0, max_args: int | None = None, allow_unground: bool = False):
    """Turns a function `fn(args) -> float` into an arithmetic function.
    Pure: no registration happens here -- load_arith_functions collects the
    decorated objects from their modules, mirroring @internal_action.

    `name` defaults to `f"{ns}::{fn.__name__.rstrip('_')}"` (the trailing
    underscore trick handles names that collide with Python builtins/keywords,
    e.g. `max_`, `min_`, `round_`, `abs_`, `sum_`)."""
    def wrap(f: ArithFn) -> FunctionArith:
        af_name = name if name is not None else f"{ns}::{f.__name__.rstrip('_')}"
        return FunctionArith(f, af_name, min_args, max_args, allow_unground)

    return wrap(fn) if fn is not None else wrap


def collect_arith_functions(module: ModuleType) -> dict[str, ArithFunction]:
    return {af.get_name(): af for af in vars(module).values() if isinstance(af, ArithFunction)}


_stdlib_arith_functions: dict[str, ArithFunction] | None = None


def load_arith_functions() -> dict[str, ArithFunction]:
    """All the available arithmetic functions, keyed by qualified name
    ("math::sqrt", "system::time", ...), discovered by scanning every module
    of the icaros.stdlib package, recursively (e.g. stdlib/math/functions.py),
    cached after the first call -- same pkgutil-based discovery as
    load_internal_actions, walking into every subpackage so each file, no
    matter how deeply nested, is imported and scanned individually."""
    global _stdlib_arith_functions
    if _stdlib_arith_functions is None:
        _stdlib_arith_functions = _discover(collect_arith_functions)
    return _stdlib_arith_functions
from __future__ import annotations

# ag: `import math` here is NOT a self-import even though this module lives
# inside icaros.stdlib.math -- Python 3 uses absolute imports only, so this
# resolves to the standard library's math module.
import math
import time as _time
from typing import TYPE_CHECKING

from icaros.stdlib.arith_registry import arith_function
from icaros.stdlib.internal_actions.numbers import random as _random_ia

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term


def _numeric_values(list_term: Term, ia_name: str) -> list[float]:
    if not list_term.is_list():
        raise ValueError(f"internal action '{ia_name}': argument must be a list")
    return [t.solve() for t in list_term.get_as_list() if t.is_numeric()]


def _safe_div(a: float, b: float) -> float:
    return float("nan") if b == 0 else a / b


### trig / basic real functions (arity 1) ##########

@arith_function(min_args=1, max_args=1)
def sqrt(args) -> float:
    return math.sqrt(args[0].solve())


@arith_function(min_args=1, max_args=1)
def abs_(args) -> float:
    return abs(args[0].solve())


@arith_function(min_args=1, max_args=1)
def round_(args) -> float:
    """math::round(N): Java's Math.round is half-up, unlike Python's round()
    (banker's rounding) -- ported as floor(n + 0.5)."""
    return math.floor(args[0].solve() + 0.5)


@arith_function(min_args=1, max_args=1)
def ceil(args) -> float:
    return math.ceil(args[0].solve())


@arith_function(min_args=1, max_args=1)
def floor(args) -> float:
    return math.floor(args[0].solve())


@arith_function(min_args=1, max_args=1)
def log(args) -> float:
    return math.log(args[0].solve())


@arith_function(min_args=1, max_args=1)
def acos(args) -> float:
    return math.acos(args[0].solve())


@arith_function(min_args=1, max_args=1)
def asin(args) -> float:
    return math.asin(args[0].solve())


@arith_function(min_args=1, max_args=1)
def atan(args) -> float:
    return math.atan(args[0].solve())


@arith_function(min_args=1, max_args=1)
def cos(args) -> float:
    return math.cos(args[0].solve())


@arith_function(min_args=1, max_args=1)
def sin(args) -> float:
    return math.sin(args[0].solve())


@arith_function(min_args=1, max_args=1)
def tan(args) -> float:
    return math.tan(args[0].solve())


### constants (arity 0) ##########

@arith_function(min_args=0, max_args=0)
def pi(args) -> float:
    return math.pi


@arith_function(min_args=0, max_args=0)
def e(args) -> float:
    return math.e


### list-of-numbers aggregates ##########

@arith_function(min_args=1, max_args=2)
def max_(args) -> float:
    """math::max(N1,N2): the larger of two numbers. math::max(L): the
    largest numeric element of list L (non-numeric elements ignored);
    ValueError on an empty list (Jason returns Double.MIN_VALUE there --
    the smallest positive double, not -infinity -- an asymmetric quirk not
    replicated here, see the internal action .max in numbers.py, which
    already fails on an empty list rather than returning a sentinel)."""
    if len(args) == 2:
        return max(args[0].solve(), args[1].solve())
    values = _numeric_values(args[0], "math::max")
    if not values:
        raise ValueError("internal action 'math::max': list is empty")
    return max(values)


@arith_function(min_args=1, max_args=2)
def min_(args) -> float:
    """math::min(N1,N2) / math::min(L): symmetric to math::max."""
    if len(args) == 2:
        return min(args[0].solve(), args[1].solve())
    values = _numeric_values(args[0], "math::min")
    if not values:
        raise ValueError("internal action 'math::min': list is empty")
    return min(values)


@arith_function(min_args=1, max_args=1)
def sum_(args) -> float:
    """math::sum(L): sum of L's numeric elements (non-numeric ignored);
    0 for an empty list."""
    return float(sum(_numeric_values(args[0], "math::sum")))


@arith_function(min_args=1, max_args=1)
def average(args) -> float:
    """math::average(L): mean of L's numeric elements; NaN for an empty
    list (Jason's own division-by-zero-of-doubles behaviour, deliberately
    kept -- unlike math::mean below, which raises instead)."""
    values = _numeric_values(args[0], "math::average")
    return _safe_div(sum(values), len(values))


@arith_function(min_args=1, max_args=1)
def mean(args) -> float:
    """math::mean(L): like math::average, but raises on an empty list
    (matching Jason's own mean.java, which throws there unlike average.java)."""
    values = _numeric_values(args[0], "math::mean")
    if not values:
        raise ValueError("internal action 'math::mean': cannot compute the mean of an empty list")
    return sum(values) / len(values)


@arith_function(min_args=1, max_args=1)
def median(args) -> float:
    """math::median(L): raises if L is empty or has a non-numeric element
    (stricter than sum/average/max/min, which silently ignore/tolerate --
    matches Jason's median.java)."""
    if not args[0].is_list():
        raise ValueError("internal action 'math::median': argument must be a list")
    items = args[0].get_as_list()
    if not items:
        raise ValueError("internal action 'math::median': cannot compute the median of an empty list")
    if not all(t.is_numeric() for t in items):
        raise ValueError("internal action 'math::median': all list elements must be numeric")
    values = sorted(t.solve() for t in items)
    n = len(values)
    mid = n // 2
    if n % 2 == 0:
        return (values[mid - 1] + values[mid]) / 2
    return values[mid]


@arith_function(min_args=1, max_args=1)
def std_dev(args) -> float:
    """math::std_dev(L): sample standard deviation (n-1 denominator) of L's
    numeric elements. 0 for an empty list; NaN for a single-element list
    (denominator n-1 = 0), both matching Jason's std_dev.java."""
    values = _numeric_values(args[0], "math::std_dev")
    n = len(values)
    if n == 0:
        return 0.0
    m = sum(values) / n
    variance = _safe_div(sum((v - m) ** 2 for v in values), n - 1)
    return math.sqrt(variance)


### random / time ##########

@arith_function(min_args=0, max_args=1)
def random(args) -> float:
    """math::random / math::random(N): a random float in [0,1), or in [0,N)
    with an argument.
    ag: Jason's Random.java borrows the calling agent's own seeded RNG
    (shared with .random/.set_random_seed) via a TransitionSystem each
    ArithFunctionTerm binds to its owning Agent at construction time --
    decided against porting that binding (see porting.md/arith_function.py):
    the only beneficiary among all 23 ported functions is this one, for a
    narrow benefit (seed-consistency with .random), not worth the complexity
    (walking every belief/plan/goal after each parse, plus a known-unsound
    edge case under Runner.clone_agent, which shares Plan/Term objects by
    reference). math::random therefore always uses .random's module-level
    RNG below, independent of .set_random_seed."""
    value = _random_ia._rng.random()
    return value * args[0].solve() if args else value


@arith_function(name="system::time", min_args=0, max_args=0)
def time(args) -> float:
    """system::time: current epoch time in milliseconds (System.currentTimeMillis()
    equivalent). Does not collide with the .time internal action (datetime_actions.py)
    -- different namespace/registry."""
    return _time.time() * 1000.0
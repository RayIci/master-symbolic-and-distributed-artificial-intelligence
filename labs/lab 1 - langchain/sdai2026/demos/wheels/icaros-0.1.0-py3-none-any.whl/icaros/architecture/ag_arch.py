from __future__ import annotations

import logging
from copy import deepcopy
from threading import Thread, Condition, Event, Lock, current_thread
from collections import deque
from typing import ClassVar, TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable
    from icaros.as_syntax.literal import Literal
    from icaros.runtime.scheduler import AgentScheduler

from icaros.as_semantics.action_exec import ActionExec
from icaros.as_semantics.message import Message
from icaros.journal import JournalKind
from icaros.runtime.runner import Runner

from icaros.as_semantics.transition_system import TransitionSystem

logger = logging.getLogger(__name__)

MAX_SLEEP = 1.0  # seconds -- mirrors Java's LocalAgArch.MAX_SLEEP (1000ms)


class AgArch():
    """Merges Java's AgArch (the ts/perceive/act/mailbox contract) and LocalAgArch
    (the local, single-process implementation) into one class -- this port has no
    chain-of-responsibility of architecture layers, just this.

    Not ported: the chain of responsibility itself (insertAgArch/successor,
    custom archs), sync execution mode, MsgListener, the cycles* tuning knobs,
    getStatus()/DOM introspection.

    Pooled execution (`scheduler`, ported from Java's LocalAgArchForPool +
    the pool-creation half of RunLocalMAS.createThreadPool(), i.e. `.mas2i`'s
    `threads: N` -- see mas2i/loader.py) shares one AgentScheduler (runtime/
    scheduler.py -- a FIFO plus N daemon workers, not a ThreadPoolExecutor:
    no per-slice Future, no swallowed exceptions) across every agent in the
    MAS instead of giving each its own dedicated OS thread: see start_thread/
    wake/stop_ag/_run_batch below, each branching on whether `scheduler` is
    set. `scheduler` stays None (today's per-thread behavior, unchanged)
    unless a `.mas2i` sets `threads:`.
    """

    CYCLES_PER_BATCH: ClassVar[int] = 5  # Jason's RunLocalMAS default `cycles` for Local(pool,N)

    # ag: no `provider`/`model` parameters, and no Agentic of its own. An
    # agent's model reaches it as TransitionSystem's `agentic` (built by
    # mas2i/loader.py, handed through boot_agent), and every consumer reads it
    # as `ts.agentic` -- the arch was never on that road. Holding a second one
    # here would also have meant a 15 s Ollama warm-up on an object with no
    # `ts`, i.e. one unable to do anything: Agentic's every method opens on
    # `if self._ts is None: return`.
    #
    # `model` in particular must stay free for subclasses: an `ag_arch_class:`
    # is where a port keeps its world model (examples/gold-miners-II's
    # LocalMinerArch assigns `self.model` in __init__), and a read-only property
    # of that name here made the assignment raise.
    def __init__(self):
        self._environment = None
        self._exec_control = None
        self._runner: Runner | None = None
        self._ts: TransitionSystem | None = None
        self._ag_name = ""
        self._running = True
        self._mailbox: deque[Message] = deque()
        self._my_thread: Thread | None = None
        self._sleep_condition = Condition()
        self._sleep_time = 0.05
        self._sleeping: bool = False  # per-thread mode only
        self._scheduler: AgentScheduler | None = None
        self._batch_lock = Lock()  # guards _scheduled/_wake_pending in pooled mode only
        self._scheduled = False  # pooled mode only: queued for, or running, a slice
        self._wake_pending = False
        self._done = Event()
        self._done.set()  # not started yet -- trivially "done"
        self.on_cycle: Callable[[AgArch], None] | None = None
        self.on_print: Callable[[str], None] | None = None

    @property
    def runner(self):
        return self._runner

    @runner.setter
    def runner(self, runner: Runner):
        self._runner = runner

    @property
    def environment(self):
        return self._environment

    @environment.setter
    def environment(self, environment) -> None:
        self._environment = environment

    @property
    def ts(self) -> TransitionSystem | None:
        return self._ts

    @ts.setter
    def ts(self, ts: TransitionSystem) -> None:
        self._ts = ts

    @property
    def ag_name(self):
        return self._ag_name

    @ag_name.setter
    def ag_name(self, ag_name: str):
        if ag_name == "self" or ag_name == "percept":
            raise ValueError(f"an agent cannot be named '{ag_name}'")
        self._ag_name = ag_name

    @property
    def thread(self):
        return self._my_thread

    @thread.setter
    def thread(self, thread: Thread):
        self._my_thread = thread
        self._my_thread.name = self._ag_name

    @property
    def scheduler(self) -> AgentScheduler | None:
        return self._scheduler

    @scheduler.setter
    def scheduler(self, scheduler: AgentScheduler | None) -> None:
        self._scheduler = scheduler

    def start_thread(self) -> None:
        if self._scheduler is not None:
            self._done.clear()
            with self._batch_lock:
                self._schedule()
        elif self._my_thread is not None and not self._my_thread.is_alive():
            self._done.clear()
            self._my_thread.start()

    STOP_JOIN_TIMEOUT: ClassVar[float] = 5.0

    def signal_stop(self) -> None:
        """First half of stop_ag(): tells the agent to stop and wakes it, but
        does not wait. Lets a caller stopping many agents signal them all
        first and join once (see Runner.stop_all) instead of paying a full
        wake+join round trip per agent -- serial teardown at 10,000 agents is
        10,000 sequential context switches."""
        self._running = False
        # ag: wake() notifies _sleep_condition, which is NOT the condition a
        # paused agent waits on -- without this, stopping a MAS with anything
        # paused would sit until join_stopped's timeout expired
        if self._exec_control is not None:
            self._exec_control.release_all()
        self.wake()

    def join_stopped(self, timeout: float | None = None) -> None:
        """Second half of stop_ag(). No-op in pooled mode (no dedicated thread
        to join -- matches Jason's own LocalAgArch.stopAg(), which only
        interrupts myThread `if (myThread != null)`; use _done there, see
        below), and no-op when called from the agent's own thread, where
        joining yourself is a RuntimeError -- that is the whole reason
        .stopMAS and kill_agent defer to a Timer.

        _done (set by run()/run_slice/_run_batch once is_running() goes False,
        or by _schedule() if the scheduler is already shut down) is the
        non-polling way to wait for an in-flight pooled batch to finish:
        `ag.stop_ag(); ag._done.wait(timeout=...)`."""
        if self._scheduler is not None or self._my_thread is None:
            return
        if current_thread() is self._my_thread:
            return
        self._my_thread.join(self.STOP_JOIN_TIMEOUT if timeout is None else timeout)

    def stop_ag(self, timeout: float | None = None) -> None:
        self.signal_stop()
        self.join_stopped(timeout)

    def is_running(self) -> bool:
        return self._running

    @property
    def exec_control(self):
        """Jason's ExecutionControl slot -- icaros uses it for the dev UI's
        DebugController (runtime/debug_control.py). None means the agent runs
        unsupervised, which is every run without the UI attached."""
        return self._exec_control

    @exec_control.setter
    def exec_control(self, controller) -> None:
        self._exec_control = controller

    @property
    def is_sleeping(self) -> bool:
        if self._scheduler is not None:
            return not self._scheduled
        return self._sleeping

    def run(self) -> None:
        # ag: mirrors Java's LocalAgArch.run()/reasoningCycle() -- the loop
        # a per-agent thread runs, driving TransitionSystem.reasoning_cycle()
        # until stop_ag() clears _running. on_cycle fires here, synchronously
        # right after the cycle finishes -- state is consistent to read then.
        try:
            while self.is_running():
                if self._exec_control is not None:
                    # blocks while paused; only ever observed here, at the top
                    # of the loop, so no cycle is ever cut in half
                    self._exec_control.before_cycle(self)
                    if not self.is_running():
                        break
                self.ts.reasoning_cycle()
                if self.on_cycle is not None:
                    self.on_cycle(self)
                if self.ts.can_sleep():
                    self._sleeping = True
                    self.sleep()
                    self._sleeping = False
        except BaseException:
            # ag: same contract as run_slice() in pooled mode. Without this the
            # thread dies but _running stays True, so cli.run_headless's
            # `while any(a.is_running() ...)` never ends -- the process hangs
            # forever with no visible error.
            logger.exception("agent '%s' aborted its reasoning loop", self._ag_name)
            raise
        finally:
            self._running = False
            self._sleeping = False
            self._done.set()

    def _schedule(self) -> None:
        """Queues one slice unless one is already queued or running --
        caller holds _batch_lock. This is the entire "at most one pending
        slice per agent" invariant: without it, two start_thread()/wake()
        calls could put two _run_batch entries in flight, i.e. two workers
        reasoning over the same Circumstance at once."""
        if self._scheduled:
            return
        self._scheduled = self._scheduler.submit(self)
        if not self._scheduled:
            self._done.set()  # scheduler already shut down: no slice will run

    def run_slice(self) -> None:
        """Entry point AgentScheduler workers call (its `Slice` protocol)."""
        try:
            self._run_batch()
        except BaseException:
            # never leave _scheduled True on the way out -- a future wake()
            # would otherwise never re-queue this agent, exactly like the
            # exception a discarded ThreadPoolExecutor Future used to swallow
            self._running = False
            with self._batch_lock:
                self._scheduled = False
            self._done.set()
            raise  # the scheduler worker logs it

    def _run_batch(self) -> None:
        # ag: pooled-mode counterpart of run(), ported from Jason's
        # LocalAgArchForPool.run(): up to CYCLES_PER_BATCH reasoning
        # cycles, then either clear _scheduled and return (no worker
        # occupied while idle -- wake() resubmits later) or resubmit so
        # other agents sharing the scheduler get a turn.
        cycles = 0
        while self.is_running() and cycles < self.CYCLES_PER_BATCH:
            if self._exec_control is not None:
                # ag: never block here -- this thread belongs to a shared
                # pool, and parking it with `threads: 1` would freeze the
                # whole MAS. A paused agent de-schedules itself exactly the
                # way a sleeping one does below, and resume()'s wake()
                # re-queues it. The check and the clear MUST stay inside one
                # _batch_lock block: split them and a concurrent wake() can
                # set _wake_pending while _scheduled is still True, so the
                # wake is swallowed and the agent never runs again.
                with self._batch_lock:
                    if not self._exec_control.may_run(self):
                        self._scheduled = False
                        return
            self.ts.reasoning_cycle()
            cycles += 1
            if self.on_cycle is not None:
                self.on_cycle(self)
            with self._batch_lock:
                if self._wake_pending:
                    self._wake_pending = False
                elif self.ts.can_sleep():
                    self._scheduled = False
                    return
        if self.is_running():
            # end of batch, not a sleep decision: _scheduled is still True
            # from when this very slice was queued, so resubmit directly
            # (unconditionally) rather than through _schedule()'s guard --
            # this yields to other agents sharing the scheduler
            with self._batch_lock:
                self._scheduled = self._scheduler.submit(self)
            if not self._scheduled:
                self._done.set()  # scheduler shut down under us
        else:
            self._done.set()

    def can_sleep_on_mailbox(self) -> bool:
        # ag: renamed from mailbox_is_empty -- despite the name, it always
        # answered "empty AND still running" (every caller wants exactly
        # that combination, see transition_system.py's can_sleep* family),
        # so "empty" alone read as True for an empty mailbox on a stopped
        # agent when the actual answer was False.
        return not self._mailbox and self.is_running()

    ### sleep / wake -- Condition bundles Java's separate sleepLock + inSleep ##########

    def sleep(self) -> None:
        with self._sleep_condition:
            self._sleep_condition.wait(self._sleep_time)
            if self._sleep_time < MAX_SLEEP:
                self._sleep_time += 0.1

    def wake(self) -> None:
        if self._scheduler is not None:
            # ag: mirrors Java's LocalAgArchForPool.wake()'s `synchronized
            # (this)` block: the same lock guards this check-and-clear and
            # _run_batch's can_sleep()-check-and-set above, closing the
            # missed-wakeup window (a message arriving exactly as the
            # agent decides to sleep). _wake_pending is set unconditionally,
            # even if the agent isn't sleeping yet -- see _run_batch.
            with self._batch_lock:
                self._wake_pending = True
                self._schedule()
            return
        with self._sleep_condition:
            self._sleep_time = 0.05
            self._sleep_condition.notify_all()

    def wake_up_sense(self) -> None:
        self.wake()

    def wake_up_deliberate(self) -> None:
        self.wake()

    def wake_up_act(self) -> None:
        self.wake()

    ### perception ##########

    def perceive(self) -> list[Literal] | None:
        # ag: Java's default (Complete and Accurate sensing) delegates to the
        # environment: the full current perception, which Agent.buf() diffs
        # against the belief base. None means "nothing changed" (or no
        # environment configured) and leaves the belief base alone.
        if self._environment is None:
            return None
        return self._environment.get_percepts(self._ag_name)

    ### mail ##########

    def check_mail(self) -> None:
        while self._mailbox:
            self.ts.circumstance.add_msg(self._mailbox.popleft())

    def receive_msg(self, message: Message) -> None:
        self._mailbox.append(message)
        self.wake_up_sense()

    def send_msg(self, message: Message) -> None:
        if message.sender is None:
            message.sender = self._ag_name
        if self._runner is None:
            return
        # ag_name (the registry key) is a plain str, but message.receiver may be
        # an Atom (message content is AgentSpeak terms) -- normalise before lookup.
        receiver = self._runner.get_ag(str(message.receiver))
        if receiver is None:
            if self.is_running():
                raise ValueError(f"Receiver '{message.receiver}' does not exist! Could not send {message}")
            return
        self._journal_record(JournalKind.MSG_OUT, receiver=message.receiver,
                             performative=message.il_force, content=message.content)
        receiver.receive_msg(deepcopy(message))
        self._runner.notify_msg_sent(message)

    def broadcast(self, message: Message) -> None:
        # ag: N sequential unicast sends, not a real transport-level
        # broadcast primitive -- matches Jason's own LocalAgArch.broadcast.
        # Resolved here rather than through send_msg: an agent can be
        # deregistered (kill_agent's Timer thread) between the name snapshot
        # and the send, and for a broadcast that is normal churn to skip, not
        # the ValueError send_msg raises for an explicit .send to a name that
        # does not exist.
        if self._runner is None:
            return
        if message.sender is None:
            message.sender = self._ag_name
        # one entry for the broadcast, not one per recipient: the agent did a
        # single thing, and N identical lines would crowd out its own history
        self._journal_record(JournalKind.MSG_OUT, receiver="everyone",
                             performative=message.il_force, content=message.content)
        for name in self._runner.agent_names():
            if name == self._ag_name:
                continue
            receiver = self._runner.get_ag(name)
            if receiver is None:
                continue
            # ag: set receiver on the copy, not on the shared `message` --
            # mutating message.receiver in place used to leave the caller's
            # own Message holding whichever receiver got the last send
            outgoing = deepcopy(message)
            outgoing.receiver = name
            receiver.receive_msg(outgoing)
            self._runner.notify_msg_sent(outgoing)

    ### actions ##########

    def act(self, action: ActionExec) -> None:
        if not self.is_running():
            return
        if self._environment is not None:
            self._environment.act(self, action)
        else:
            action.result = False
            action.failure_reason = "noenv"
            action.failure_msg = "no environment configured!"
            self.action_executed(action)

    def action_executed(self, action: ActionExec) -> None:
        self.ts.circumstance.add_feedback_action(action)
        self.wake_up_act()

    ### console ##########

    def print(self, text: str) -> None:
        # output channel of .print/.println; text is written verbatim (no added
        # newline). Called from the agent's thread, so on_print consumers must
        # be thread-safe (same contract as on_cycle).
        #
        # ag: exactly one destination, never both. on_print set means a UI is
        # showing this agent's console, and echoing to the terminal underneath
        # it just duplicates every line into a window the developer is not
        # reading. Unset (headless) the terminal IS the console -- flushed
        # because redirected to a file or a pipe stdout is block-buffered, so
        # a quiet MAS would otherwise show nothing until ~8KB piled up.
        # the journal is not a third destination competing with those two: it
        # is the record, and it gets the line either way
        self._journal_record(JournalKind.PRINT, line=text)
        if self.on_print is not None:
            self.on_print(text)
        else:
            print(text, end="", flush=True)

    def _journal_record(self, kind: JournalKind, **detail) -> None:
        """Records on this agent's journal, if it has been wired to a
        TransitionSystem yet -- AgArch outlives that wiring at both ends."""
        if self._ts is not None:
            self._ts.ag.journal.record(kind, **detail)

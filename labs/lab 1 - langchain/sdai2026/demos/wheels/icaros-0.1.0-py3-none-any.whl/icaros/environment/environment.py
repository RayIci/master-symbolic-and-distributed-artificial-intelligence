from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Callable, ClassVar, Iterable

if TYPE_CHECKING:
    from icaros.architecture.ag_arch import AgArch
    from icaros.as_semantics.action_exec import ActionExec
    from icaros.as_syntax.literal import Literal
    from icaros.runtime.runner import Runner


def env_action(fn: Callable | None = None, *, name: str | None = None, ag_name: str | None = None):
    """Marks a method as callable from AgentSpeak plans as a plain action
    (no leading dot, unlike internal actions): `prendi(X)` in a plan body
    resolves to the `prendi` @env_action method on the agent's Environment.
    `name` defaults to the method name -- override it if the AgentSpeak
    action name can't be a valid Python identifier.

    `ag_name`, if given, names a keyword argument that execute_action()
    injects with the name of the agent whose action this is -- invisible on
    the AgentSpeak side (the plan's own term arguments are unaffected and
    keep their order), matched by keyword so it doesn't need to sit in any
    particular position in the method's signature. Actions that don't pass
    `ag_name` get no extra argument at all.
    """
    def wrap(f: Callable) -> Callable:
        f._env_action_name = name or f.__name__
        f._env_action_ag_param = ag_name
        return f
    return wrap(fn) if fn is not None else wrap


class Environment:
    """Base class for a MAS's shared environment: percepts (facts the agents
    read on their next sense() and turn into `belief[source(percept)]` via
    Agent.buf() -- see add_percept/remove_percept/get_percepts) and actions
    (Python methods marked with @env_action, invoked when an agent's plan
    runs a matching plain action). Subclass this and add @env_action methods;
    no UI is provided -- that's the developer's concern.

    `act()` is the framework's dispatch entrypoint (called by AgArch.act());
    it is not meant to be overridden -- register actions via @env_action.
    """

    ACTION_THREADS: ClassVar[int] = 4  # matches Jason's `new Environment()` default pool size
    # functor -> (method attr name, keyword arg name to inject the acting
    # agent's name into, or None)
    _env_actions_map: ClassVar[dict[str, tuple[str, str | None]]] = {}

    def __init_subclass__(cls, **kwargs) -> None:
        super().__init_subclass__(**kwargs)
        actions: dict[str, tuple[str, str | None]] = {}
        for klass in reversed(type.mro(cls)):
            for attr_name, member in vars(klass).items():
                action_name = getattr(member, "_env_action_name", None)
                if not isinstance(action_name, str):
                    continue
                actions[action_name] = (attr_name, getattr(member, "_env_action_ag_param", None))
        cls._env_actions_map = actions

    def __init__(self, *, action_threads: int | None = None) -> None:
        # guards the percept structures only -- never held while an
        # @env_action runs, or a blocking action would stall every agent's
        # perception (see act()).
        self._percepts_lock = threading.RLock()
        # ag: per-instance override of the ACTION_THREADS default -- a single
        # blocking @env_action holds one of these for its whole duration, so
        # an environment whose actions do real I/O wants more than 4. Passed
        # through the cooperative **kwargs chain by TimeSteppedEnvironment /
        # GridEnvironment, so a subclass sets it in its own super().__init__.
        self._executor = ThreadPoolExecutor(
            max_workers=action_threads or type(self).ACTION_THREADS,
            thread_name_prefix="env-action")
        # ag: percepts are a live snapshot of the world, exactly like Jason's
        # own Environment.percepts/agPercepts fields -- add_percept/
        # remove_percept/clear_percepts just mutate this snapshot; nothing is
        # delivered to any agent until its own next sense() calls
        # get_percepts(), which hands over the whole current snapshot (global
        # | own). Working out what changed is the agent's job, not the
        # environment's: Agent.buf() diffs that snapshot against the
        # [source(percept)] beliefs actually in the agent's belief base, as
        # in Jason. Global percepts (agent_name=None) are seen by every
        # agent, including one created after they were added.
        self._global_percepts: set[Literal] = set()
        self._agent_percepts: dict[str, set[Literal]] = {}
        # ag: Jason's own uptodateAgs -- the set of agents whose last
        # get_percepts() already reflects the current snapshot. Any
        # add_percept/remove_percept/clear_percepts (global or per-agent)
        # clears it, exactly like Java's uptodateAgs.clear(): nothing tracks
        # *what* changed, so the next get_percepts() from any agent returns
        # the full snapshot again and re-adds itself here.
        self._uptodate_agents: set[str] = set()
        # wired by the runtime (telemetry's MasCollector.attach) when a UI is
        # showing this MAS; None (headless) means log() only prints.
        self._log_sink: Callable[[str], None] | None = None
        # set by Runner.environment's setter -- the agent registry
        # inform_ags_environment_changed() below wakes through
        self._runner: Runner | None = None

    ### logging ##########

    @property
    def log_sink(self) -> Callable[[str], None] | None:
        return self._log_sink

    @log_sink.setter
    def log_sink(self, sink: Callable[[str], None]) -> None:
        self._log_sink = sink

    def log(self, message: str) -> None:
        """Prints `message` prefixed with the environment's class name, e.g.
        `[TreasureEnv] oggetto preso!`. Same convention as AgArch.print(): the
        terminal always gets it, and it's also forwarded to the running TUI's
        console (every agent tab plus the combined one) when there is one --
        no extra wiring needed in the environment itself."""
        line = f"[{type(self).__name__}] {message}"
        # one destination, never both -- same rule as AgArch.print: a sink
        # means a UI is showing this, and echoing underneath it only
        # duplicates. Headless, the terminal is the log, flushed because
        # stdout is block-buffered when redirected to a file or a pipe.
        if self._log_sink is not None:
            self._log_sink(line)
        else:
            print(line, flush=True)

    ### percepts ##########

    @property
    def runner(self) -> Runner | None:
        return self._runner

    @runner.setter
    def runner(self, runner: Runner) -> None:
        self._runner = runner

    # ag: adding/removing a percept deliberately does NOT wake anybody, same
    # as Jason -- its addPercept/removePercept/clearPercepts only mutate the
    # percept collections and clear uptodateAgs. Percepts are pull, not
    # push: an agent notices them on its next sense(), because get_percepts()
    # then has something to hand it. Cutting the wait short is a separate,
    # opt-in latency optimisation the environment asks for explicitly, via
    # inform_ags_environment_changed() below (Jason's MarsEnv calls it after
    # every action; its HouseEnv never calls it at all and just relies on the
    # agents' own polling).

    def add_percept(self, percept: Literal, agent_name: str | None = None) -> None:
        with self._percepts_lock:
            self._target_set(agent_name).add(percept)
            self._uptodate_agents.clear()

    def remove_percept(self, percept: Literal, agent_name: str | None = None) -> None:
        """Removes a percept from the environment's current snapshot -- a
        no-op if it wasn't there (matches Jason's own removePercept). Once
        the target agent next senses, get_percepts() no longer includes it
        and it drops out of that agent's belief base."""
        with self._percepts_lock:
            self._target_set(agent_name).discard(percept)
            self._uptodate_agents.clear()

    def set_percepts(self, literals: Iterable[Literal], agent_name: str | None = None) -> None:
        """Atomically replaces agent_name's (or the global/broadcast, if
        None) current percept set with `literals` -- the idiomatic Jason
        clearPercepts()+addPercept() refresh, done as one critical section so
        a concurrent get_percepts() can never observe the torn intermediate
        state. Jason has no single call for this (environment authors just
        call clearPercepts()+addPercept() back to back); named set_percepts
        to read as the natural counterpart of get_percepts in this port's
        add/remove/clear/get/set family."""
        with self._percepts_lock:
            self.clear_percepts(agent_name)
            for literal in literals:
                self.add_percept(literal, agent_name)

    def inform_ags_environment_changed(self, *agent_names: str) -> None:
        """Java's Environment.informAgsEnvironmentChanged: wakes the named
        agents so they re-sense now instead of on their next poll, or every
        agent in the MAS when called with no names.

        Worth calling after a batch of percept updates. It matters most for
        agents that don't poll at all: a pooled agent (see ag_arch.py's
        scheduler mode) parks itself with no timer, unlike the per-thread
        default which re-polls on a <=1s backoff, so nothing else would ever
        bring it back."""
        if not agent_names:
            self._wake_all_agents()
            return
        for name in agent_names:
            self._wake_agent(name)

    def _wake_all_agents(self) -> None:
        if self._runner is None:
            return
        # ag_list(), not ags: this runs at every step boundary and only needs
        # to iterate -- `ags` would rebuild a 10,000-entry dict each time
        for ag_arch in self._runner.ag_list():
            ag_arch.wake_up_sense()

    def _wake_agent(self, agent_name: str) -> None:
        if self._runner is None:
            return
        ag_arch = self._runner.get_ag(agent_name)
        if ag_arch is not None:
            ag_arch.wake_up_sense()

    def clear_percepts(self, agent_name: str | None = None) -> None:
        with self._percepts_lock:
            self._target_set(agent_name).clear()
            self._uptodate_agents.clear()

    def get_percepts(self, ag_name: str) -> list[Literal] | None:
        """Jason's Environment.getPercepts(): every percept this agent can
        currently see (global | its own), or None when nothing has changed
        since its last call (uptodateAgs already contains it) -- Agent.buf()
        treats None as "leave the belief base alone", while an empty list
        means "the agent perceives nothing, drop every percept".

        ag: returns a fresh list, never the live sets, so the caller can
        iterate it outside the lock. The literals themselves are the stored
        objects and must not be mutated -- Agent.buf() copies each one before
        annotating it with source(percept), as Jason's does."""
        with self._percepts_lock:
            if ag_name in self._uptodate_agents:
                return None
            self._uptodate_agents.add(ag_name)
            return list(self._global_percepts | self._agent_percepts.get(ag_name, set()))

    def _target_set(self, agent_name: str | None) -> set[Literal]:
        if agent_name is None:
            return self._global_percepts
        return self._agent_percepts.setdefault(agent_name, set())

    ### actions ##########

    def act(self, ag_arch: AgArch, action: ActionExec) -> None:
        """Jason's Environment.scheduleAction: queues the action on the pool
        and returns at once, so the agent keeps reasoning while it runs."""
        try:
            self._executor.submit(self.execute_action, ag_arch, action)
        except RuntimeError:  # pool already shut down: MAS is stopping
            action.result = False
            action.failure_reason = "env_stopped"
            action.failure_msg = "environment is shutting down"
            ag_arch.action_executed(action)

    def execute_action(self, ag_arch: AgArch, action: ActionExec) -> None:
        self._invoke_action(ag_arch, action)
        ag_arch.action_executed(action)

    def _invoke_action(self, ag_arch: AgArch, action: ActionExec) -> None:
        """Runs the matching @env_action and records the outcome on `action`,
        without telling the agent -- Java keeps these two apart too
        (executeAction returns a boolean; actionExecuted is called
        separately). Split out so TimeSteppedEnvironment can run every action
        of a step, refresh the percepts, and only then deliver the feedback."""
        term = action.action_term
        entry = type(self)._env_actions_map.get(term.functor)
        if entry is None:
            action.result = False
            action.failure_reason = "unknown_action"
            action.failure_msg = f"no such environment action: '{term.functor}'"
            return
        attr_name, ag_param = entry
        method = getattr(self, attr_name)
        args = term.get_terms() or []
        kwargs = {ag_param: ag_arch.ag_name} if ag_param else {}
        try:
            result = method(*args, **kwargs)
        except Exception as e:
            action.result = False
            action.failure_reason = "env_action_error"
            action.failure_msg = str(e)
        else:
            action.result = result is not False
            if not action.result:
                action.failure_reason = "env_action_failed"
                action.failure_msg = f"action '{term.functor}' returned False"

    def shutdown(self) -> None:
        """Framework teardown: closes the action pool, then runs the user's
        stop() hook. Kept separate from stop() because subclasses override
        stop() without calling super(), which would silently skip this."""
        self._executor.shutdown(wait=False, cancel_futures=True)
        self.stop()

    def stop(self) -> None:
        """Optional override point for releasing resources (closing a
        socket, a simulator connection, ...) when the MAS shuts down
        (.stopMAS calls this if a runner has an environment configured).
        No-op by default."""

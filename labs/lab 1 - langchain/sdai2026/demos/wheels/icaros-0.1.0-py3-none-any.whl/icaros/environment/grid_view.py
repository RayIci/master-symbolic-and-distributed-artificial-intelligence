"""Generic Tk viewer for GridEnvironment-based examples (see
grid_environment.py). Runs as its own OS *process*, not a thread -- see
examples/blocks-world/blocks_gui.py's docstring for why: on macOS, Tk must
run on the process's own main thread, and GridEnvironment's caller (the
.mas2i runner) has that thread busy running the agents' reasoning cycles.

Protocol: the first line on stdin is a one-time config JSON
  {"title": str, "width": int, "height": int, "cell_size": int}
every following line is a state snapshot JSON
  {"agents": [{"pos": [x,y], "color": "#rrggbb", "label": str}, ...],
   "objects": [{"pos": [x,y], "shape": "square"|"circle"|"diamond",
                "color": "#rrggbb", "label": str}, ...]}
No domain knowledge lives here (e.g. nothing "garbage"-specific) -- object
appearance is entirely decided by whoever calls push_gui_update().

Redraw is incremental for agents: each agent index gets one persistent
canvas item, updated in place (coords/fill/text) only when something about
it actually changed, instead of the whole canvas being torn down and
rebuilt every frame. At thousands of agents (examples/game-of-life) that is
the difference between the canvas keeping up and it falling permanently
behind -- see poll()'s queue-draining below for the other half of that.
Objects (comparatively few, in every existing example) stay a simpler
delete-and-recreate-on-change, since their identity isn't stable across
frames (see push_gui_update: they come from a Python set, whose iteration
order can shift whenever an object is added/removed).
"""
import json
import queue
import sys
import threading
import tkinter as tk

_SHUTDOWN = object()  # sentinel: distinct from "no new snapshot yet" (None)


def _read_stdin(out_queue: "queue.Queue") -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            out_queue.put(json.loads(line))
        except json.JSONDecodeError:
            continue
    # stdin hit EOF: the parent process closed the pipe or died. Ask the Tk
    # loop to shut down too, so this viewer doesn't linger as an orphan.
    out_queue.put(_SHUTDOWN)


def _draw_shape(canvas: tk.Canvas, shape: str, x0: float, y0: float,
                x1: float, y1: float, color: str, label: str) -> list[int]:
    if shape == "circle":
        ids = [canvas.create_oval(x0, y0, x1, y1, fill=color, outline="")]
    elif shape == "diamond":
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        ids = [canvas.create_polygon(cx, y0, x1, cy, cx, y1, x0, cy, fill=color, outline="")]
    else:
        ids = [canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="")]
    if label:
        ids.append(canvas.create_text((x0 + x1) / 2, (y0 + y1) / 2, text=label,
                                       fill="white", font=("Helvetica", 12, "bold")))
    return ids


class _AgentSlot:
    """One persistent (shape, optional label) pair of canvas items for a
    single agent index -- created once, then updated in place. Agents are
    always drawn as circles (unlike objects), so unlike objects there's no
    shape-type change to handle here, only coords/color/label."""
    __slots__ = ("shape_id", "text_id", "key")

    def __init__(self) -> None:
        self.shape_id: int | None = None
        self.text_id: int | None = None
        self.key: tuple | None = None


def _sync_agent_slot(canvas: tk.Canvas, slot: _AgentSlot,
                      x0: float, y0: float, x1: float, y1: float,
                      color: str, label: str) -> None:
    key = (x0, y0, x1, y1, color, label)
    if slot.key == key:
        return  # nothing about this agent changed since the last frame

    prev = slot.key
    coords_changed = prev is None or (x0, y0, x1, y1) != prev[:4]
    color_changed = prev is None or color != prev[4]

    if slot.shape_id is None:
        slot.shape_id = canvas.create_oval(x0, y0, x1, y1, fill=color, outline="")
    else:
        if coords_changed:
            canvas.coords(slot.shape_id, x0, y0, x1, y1)
        if color_changed:
            canvas.itemconfig(slot.shape_id, fill=color)

    if label:
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        if slot.text_id is None:
            slot.text_id = canvas.create_text(cx, cy, text=label, fill="white",
                                               font=("Helvetica", 12, "bold"))
        else:
            if coords_changed:
                canvas.coords(slot.text_id, cx, cy)
            if prev is None or label != prev[5]:
                canvas.itemconfig(slot.text_id, text=label)
    elif slot.text_id is not None:
        canvas.delete(slot.text_id)
        slot.text_id = None

    slot.key = key


def _clear_agent_slot(canvas: tk.Canvas, slot: _AgentSlot) -> None:
    if slot.shape_id is not None:
        canvas.delete(slot.shape_id)
    if slot.text_id is not None:
        canvas.delete(slot.text_id)


def main() -> None:
    config = json.loads(sys.stdin.readline())
    width, height = config["width"], config["height"]
    cell = config.get("cell_size", 60)

    root = tk.Tk()
    root.title(config.get("title", "Grid World"))
    canvas = tk.Canvas(root, width=width * cell, height=height * cell,
                        bg="#eaf6ff", highlightthickness=0)
    canvas.pack()

    in_queue: "queue.Queue" = queue.Queue()
    threading.Thread(target=_read_stdin, args=(in_queue,), daemon=True).start()

    pad = max(1, cell // 12)  # degenerates to an inverted/invisible rect below ~cell=48px at pad=4

    # grid lines: drawn once, W+H+2 lines instead of the W*H per-cell
    # rectangles the old always-redraw version created every frame; skipped
    # below a cell size where they'd be pure noise (game-of-life's 7px)
    if cell >= 12:
        for gx in range(width + 1):
            x = gx * cell
            canvas.create_line(x, 0, x, height * cell, fill="#cccccc")
        for gy in range(height + 1):
            y = gy * cell
            canvas.create_line(0, y, width * cell, y, fill="#cccccc")

    agent_slots: list[_AgentSlot] = []
    object_ids: list[int] = []
    prev_objects_raw = None

    def sync_agents(agents: list[dict]) -> None:
        while len(agent_slots) < len(agents):
            agent_slots.append(_AgentSlot())
        for extra in agent_slots[len(agents):]:
            _clear_agent_slot(canvas, extra)
        del agent_slots[len(agents):]

        for i, ag in enumerate(agents):
            x, y = ag["pos"]
            _sync_agent_slot(canvas, agent_slots[i],
                              x * cell + pad, y * cell + pad,
                              (x + 1) * cell - pad, (y + 1) * cell - pad,
                              ag.get("color", "#3498db"), ag.get("label", ""))

    def sync_objects(objects: list[dict]) -> None:
        nonlocal prev_objects_raw
        if objects == prev_objects_raw:
            return  # unchanged since the last frame -- skip entirely
        prev_objects_raw = objects
        for item_id in object_ids:
            canvas.delete(item_id)
        object_ids.clear()
        for obj in objects:
            x, y = obj["pos"]
            object_ids.extend(_draw_shape(
                canvas, obj.get("shape", "square"),
                x * cell + pad, y * cell + pad, (x + 1) * cell - pad, (y + 1) * cell - pad,
                obj.get("color", "#e74c3c"), obj.get("label", "")))

    def draw(state: dict) -> None:
        sync_objects(state.get("objects", []))
        sync_agents(state.get("agents", []))

    def poll() -> None:
        # drain to the latest queued frame: a burst of frames the producer
        # wrote faster than this loop's 50ms tick collapses into one redraw
        # instead of a growing backlog (the producer already coalesces to
        # one pending frame itself -- see grid_environment.py -- this is
        # belt-and-braces for whatever the OS pipe buffered in the meantime)
        latest = None
        while True:
            try:
                item = in_queue.get_nowait()
            except queue.Empty:
                break
            if item is _SHUTDOWN:
                root.destroy()
                return
            latest = item
        if latest is not None:
            draw(latest)
        root.after(50, poll)

    root.after(50, poll)
    root.mainloop()


if __name__ == "__main__":
    main()
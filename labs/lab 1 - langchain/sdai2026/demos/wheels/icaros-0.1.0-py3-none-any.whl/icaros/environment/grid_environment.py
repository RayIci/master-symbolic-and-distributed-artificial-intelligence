"""Reusable base for Jason's grid-world examples (gold-miners,
cleaning-robots, domestic-robot, mining-robots, ...): a WxH grid, N agents
each with exactly one position (Jason's setAgPos/getAgPos), and an
arbitrary number of typed, placeable objects (Jason's
add/remove/hasObject) -- multiple instances of the same type can share the
grid, one type can have zero or many instances anywhere.

Rendering is an optional Tk viewer (grid_view.py) running in its own OS
*process*, never a thread -- see grid_view.py's docstring for why (macOS
requires Tk on the process's own main thread, which here is always busy
running the .mas2i runner). Pass gui=False to skip it entirely. The viewer
is deliberately wired in rather than pluggable: this is the batteries-
included grid. An environment that wants a different world or a different
UI extends Environment or TimeSteppedEnvironment directly instead.

Sits on top of TimeSteppedEnvironment rather than beside it, so a grid can
also be round-based without multiple inheritance: pass stepped=True (plus
step_timeout / over_actions_policy) straight to the constructor and they
travel on down. Left alone, stepping stays off and this behaves exactly
like a plain Environment with a grid.
"""
from __future__ import annotations

import json
import subprocess
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from icaros.environment.time_stepped_environment import TimeSteppedEnvironment

if TYPE_CHECKING:
    from icaros.as_syntax.literal import Literal

_GUI_SCRIPT = Path(__file__).with_name("grid_view.py")

SQUARE = "square"
CIRCLE = "circle"
DIAMOND = "diamond"


@dataclass(frozen=True)
class ObjectStyle:
    shape: str = SQUARE
    color: str = "#e74c3c"
    label: str = ""


@dataclass(frozen=True)
class AgentStyle:
    color: str = "#3498db"
    label: str = ""


class GridEnvironment(TimeSteppedEnvironment):

    def __init__(self, width: int, height: int, num_agents: int, *,
                 title: str = "Grid World", cell_size: int = 60,
                 object_styles: dict[str, ObjectStyle] | None = None,
                 agent_styles: list[AgentStyle] | None = None,
                 gui: bool = True, **kwargs):
        # **kwargs carries TimeSteppedEnvironment's own arguments (stepped,
        # step_timeout, step_sleep, over_actions_policy) through untouched,
        # so a subclass configures both layers in one super() call
        super().__init__(**kwargs)
        self.width = width
        self.height = height
        self._agent_pos: list[tuple[int, int]] = [(0, 0)] * num_agents
        self._objects: dict[str, set[tuple[int, int]]] = {}
        self._object_styles = object_styles or {}
        self._agent_styles = agent_styles or [AgentStyle() for _ in range(num_agents)]
        self._grid_lock = threading.RLock()

        self._gui_proc: subprocess.Popen | None = None
        self._gui_cond = threading.Condition()
        self._gui_pending_line: str | None = None
        self._gui_writer_stop = False
        self._gui_writer: threading.Thread | None = None
        if gui:
            self._gui_proc = subprocess.Popen(
                [sys.executable, str(_GUI_SCRIPT)], stdin=subprocess.PIPE, text=True)
            self._write_gui_line_direct(json.dumps(
                {"title": title, "width": width, "height": height, "cell_size": cell_size}))
            self._gui_writer = threading.Thread(
                target=self._gui_writer_loop, name="grid-gui-writer", daemon=True)
            self._gui_writer.start()

    ### agents ##########

    def set_agent_pos(self, agent_id: int, x: int, y: int) -> None:
        with self._grid_lock:
            self._agent_pos[agent_id] = (x, y)

    def get_agent_pos(self, agent_id: int) -> tuple[int, int]:
        with self._grid_lock:
            return self._agent_pos[agent_id]

    ### objects ##########

    def add_object(self, type_name: str, x: int, y: int) -> None:
        with self._grid_lock:
            self._objects.setdefault(type_name, set()).add((x, y))

    def remove_object(self, type_name: str, x: int, y: int) -> None:
        with self._grid_lock:
            self._objects.get(type_name, set()).discard((x, y))

    def has_object(self, type_name: str, x: int, y: int) -> bool:
        with self._grid_lock:
            return (x, y) in self._objects.get(type_name, ())

    ### percepts ##########

    def sync_percepts(self, literals: set[Literal], agent_name: str | None = None) -> None:
        """Convenience wrapper around Environment.set_percepts() for when the
        caller already has the full "wanted" set as one value (as every grid
        example here does, built from a scan of the surrounding cells) --
        just forwards to it. Each agent's Agent.buf() diffs this against the
        percepts in its own belief base, so plain
        clear_percepts()+add_percept() would work here too; this only saves
        each call site from turning its `wanted` set into a loop of
        add_percept() calls itself.

        Queues only: like Jason's own addPercept/removePercept this wakes
        nobody, so a caller syncing many agents pays no per-agent wake. Call
        inform_ags_environment_changed() once when the whole update is in."""
        self.set_percepts(literals, agent_name)

    ### rendering (Tk, in the grid_view.py subprocess) ##########

    def push_gui_update(self, agent_overrides: dict[int, dict] | None = None,
                        object_overrides: dict[str, dict] | None = None) -> None:
        if self._gui_proc is None:
            return
        agent_ov = agent_overrides or {}
        object_ov = object_overrides or {}
        # only the snapshot is taken under _grid_lock: building the dicts,
        # json.dumps, and the pipe write all happen after release, so a
        # 10,000-agent frame can never make die/live/add_object/etc. wait
        # on it (this used to run entirely under _grid_lock).
        with self._grid_lock:
            agent_pos = list(self._agent_pos)
            objects_snapshot = {t: list(p) for t, p in self._objects.items()}

        agents = []
        for i, pos in enumerate(agent_pos):
            style = self._agent_styles[i]
            override = agent_ov.get(i, {})
            agents.append({
                "pos": list(pos),
                "color": override.get("color", style.color),
                "label": override.get("label", style.label),
            })
        objects = []
        for type_name, positions in objects_snapshot.items():
            style = self._object_styles.get(type_name, ObjectStyle())
            override = object_ov.get(type_name, {})
            for pos in positions:
                objects.append({
                    "pos": list(pos), "shape": style.shape,
                    "color": override.get("color", style.color),
                    "label": override.get("label", style.label),
                })
        self._queue_gui_frame(json.dumps({"agents": agents, "objects": objects}))

    def _queue_gui_frame(self, line: str) -> None:
        with self._gui_cond:
            self._gui_pending_line = line  # latest-wins: overwrites any undelivered frame
            self._gui_cond.notify()

    def _gui_writer_loop(self) -> None:
        while True:
            with self._gui_cond:
                while self._gui_pending_line is None and not self._gui_writer_stop:
                    self._gui_cond.wait()
                if self._gui_pending_line is None:  # stopped, nothing left to write
                    return
                line = self._gui_pending_line
                self._gui_pending_line = None
            if not self._write_gui_line_direct(line):
                return  # pipe is gone: no point looping any further

    def _write_gui_line_direct(self, line: str) -> bool:
        stdin = self._gui_proc.stdin if self._gui_proc is not None else None
        if stdin is None or stdin.closed:
            return False
        try:
            stdin.write(line + "\n")
            stdin.flush()
        except (BrokenPipeError, ValueError):
            return False  # viewer window was closed / process already gone
        return True

    def stop(self) -> None:
        if self._gui_writer is not None:
            with self._gui_cond:
                self._gui_writer_stop = True
                self._gui_cond.notify()
            self._gui_writer.join(timeout=2.0)
        if self._gui_proc is not None and self._gui_proc.poll() is None:
            self._gui_proc.terminate()

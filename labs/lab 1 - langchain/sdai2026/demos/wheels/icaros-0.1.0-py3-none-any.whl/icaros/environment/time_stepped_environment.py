"""Port of Jason's TimeSteppedEnvironment: an Environment whose actions are
*buffered* rather than executed on arrival, and applied together at a step
boundary, so every agent perceives the same, fully-settled world each round.

The layering is deliberate. `Environment` is the actions+percepts contract
and dispatches an action as soon as it arrives; this class overrides only
`act()` -- Jason's `scheduleAction` -- to collect actions instead, and
`GridEnvironment` then adds grid state and a viewer on top of it. Three
layers, single inheritance, so an environment author always extends exactly
one class.

Stepping is OFF by default (`stepped=False`), in which case `act()` falls
straight through to `Environment.act()` and this class is inert -- that is
why `GridEnvironment` can sit under it without turning every grid example
into a round-based simulation.

One round, all under `_requests_lock` (which `get_percepts` also takes, so
nobody can perceive a half-applied world):

  1. step += 1
  2. run every action whose `remain_steps` reaches 0 -- but tell nobody yet
  3. update_ags_percept()
  4. only now, deliver each of those actions' feedback
  5. promote queued over-requests into this round
  6. if that already completes the round, recurse
  7. inform_ags_environment_changed()
  8. step_started(step)

Steps 2 and 4 being separate is the whole point: an agent must never see its
action's result before the round's percepts reflect every other agent's
action too.
"""
from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Collection

from icaros.environment.environment import Environment

if TYPE_CHECKING:
    from icaros.architecture.ag_arch import AgArch
    from icaros.as_semantics.action_exec import ActionExec
    from icaros.as_syntax.literal import Literal

logger = logging.getLogger(__name__)


class OverActionsPolicy(Enum):
    """What to do when an agent asks for a second action in a step it has
    already acted in (Jason's OverActionsPolicy)."""
    QUEUE = "queue"                  # hold it for a later step
    FAIL_SECOND = "fail_second"      # fail it now
    IGNORE_SECOND = "ignore_second"  # report success now, but do nothing


@dataclass
class _ActRequest:
    ag_arch: AgArch
    action: ActionExec
    remain_steps: int  # steps still to wait before the action actually runs


class TimeSteppedEnvironment(Environment):

    def __init__(self, *args, stepped: bool = False, step_timeout: float = 0.0,
                 step_sleep: float = 0.0,
                 over_actions_policy: OverActionsPolicy = OverActionsPolicy.FAIL_SECOND,
                 **kwargs) -> None:
        # cooperative: everything not ours goes on down the chain, so a
        # subclass passes its own arguments and ours in one super() call
        super().__init__(*args, **kwargs)
        self._stepped = stepped
        # seconds to wait for the stragglers before starting the next step
        # anyway; 0 means a pure barrier that waits forever (Jason's default)
        self._step_timeout = step_timeout
        self._step_sleep = step_sleep  # Jason's setSleep: pause between rounds
        self._over_actions_policy = over_actions_policy

        self._step = 0
        self._nb_ags = -1
        self._requests: dict[str, _ActRequest] = {}
        self._over_requests: deque[_ActRequest] = deque()
        # RLock: an @env_action running under _invoke_action may call back
        # into get_action_in_schedule(), which takes this lock again
        self._requests_lock = threading.RLock()
        self._running = True

        self._timeout_thread: threading.Thread | None = None
        self._timeout_cond = threading.Condition()
        self._all_finished = False

    ### configuration ##########

    @property
    def stepped(self) -> bool:
        return self._stepped

    @property
    def step(self) -> int:
        return self._step

    @property
    def nb_ags(self) -> int:
        """How many agents a round waits for. Recomputed on every read (Java
        resolves it once and caches): icaros can create and kill agents at
        runtime, and since test_end_cycle compares with >=, a stale count
        that is too high would hang the barrier permanently."""
        self.update_number_of_agents()
        return self._nb_ags

    def set_nb_ags(self, n: int) -> None:
        self._nb_ags = n

    def update_number_of_agents(self) -> None:
        """How many agents act on this environment -- by default every agent
        in the MAS. Override (calling set_nb_ags) when only a subset acts."""
        if self._runner is not None:
            self.set_nb_ags(self._runner.nb_agents)

    def set_over_actions_policy(self, policy: OverActionsPolicy) -> None:
        self._over_actions_policy = policy

    ### hooks for subclasses ##########

    def update_ags_percept(self) -> None:
        """Called once per step, after every action of the step has been
        applied and before any agent is told its action finished -- the one
        place to refresh percepts so the whole MAS sees a settled world.

        clear_percepts()+add_percept() (Jason's own clearPercepts()+
        addPercept() refresh idiom), set_percepts(), sync_percepts()
        (GridEnvironment) or plain add_percept()/remove_percept() all work
        here -- each agent's Agent.buf() diffs the current snapshot against
        the percepts in its own belief base, so any of them correctly
        retracts a percept that's no longer true."""

    def step_started(self, step: int) -> None:
        """Called at the end of _start_new_step, once the new round is open."""

    def step_finished(self, step: int, elapsed: float, by_timeout: bool) -> None:
        """Called when a round closes. `by_timeout` is True when the round
        ended because step_timeout elapsed rather than because every agent
        acted. Only ever called when there is a timeout thread, i.e. when
        step_timeout > 0 -- same as Jason."""

    def required_steps_for_action(self, ag_name: str, action: Literal) -> int:
        """How many steps this action takes. Anything above 1 makes the agent
        wait that many rounds for its feedback, while still counting as
        having acted in each of them."""
        return 1

    def test_end_cycle(self, finished_ags: Collection[str]) -> bool:
        """True when the round can close. Override for a custom barrier.

        Called once per action, so it has to stay O(1) in the number of
        agents -- hence Collection (len()) rather than Iterable: counting by
        walking the names would make a round quadratic (10,000 actions each
        counting up to 10,000 names)."""
        return len(finished_ags) >= self.nb_ags

    ### action buffering (Jason's scheduleAction) ##########

    def get_action_in_schedule(self, ag_name: str) -> ActionExec | None:
        """The action `ag_name` has pending in the current step, if any --
        how an environment can tell what an agent is busy doing."""
        with self._requests_lock:
            request = self._requests.get(ag_name)
            return request.action if request is not None else None

    def act(self, ag_arch: AgArch, action: ActionExec) -> None:
        if not self._stepped:
            super().act(ag_arch, action)
            return
        if not self._running:
            # ag: match Environment.act's own env_stopped handling -- this
            # used to just drop the action with no action_executed() call,
            # leaving the intention's pending action unresolved forever (a
            # hang) instead of failing it cleanly.
            action.result = False
            action.failure_reason = "env_stopped"
            action.failure_msg = "environment is shutting down"
            ag_arch.action_executed(action)
            return

        ag_name = ag_arch.ag_name
        new_request = _ActRequest(
            ag_arch, action, self.required_steps_for_action(ag_name, action.action_term))
        start_new = False

        with self._requests_lock:
            self._ensure_timeout_thread()
            if ag_name in self._requests:
                self._handle_over_action(ag_arch, action, new_request)
            else:
                self._requests[ag_name] = new_request
                start_new = self.test_end_cycle(self._requests.keys())

        if start_new:
            # outside the lock: sleeping here used to stall every other
            # agent's act() and get_percepts() for the whole pause, and
            # _start_new_step takes the lock again anyway (_all_ag_finished
            # hands over to the timeout thread instead)
            if self._step_sleep > 0:
                time.sleep(self._step_sleep)
            if self._timeout_thread is not None:
                self._all_ag_finished()
            else:
                self._start_new_step()

    def _handle_over_action(self, ag_arch: AgArch, action: ActionExec,
                             request: _ActRequest) -> None:
        # caller holds _requests_lock
        policy = self._over_actions_policy
        logger.debug("agent '%s' asked for '%s' in a step it already acted in; policy: %s",
                     ag_arch.ag_name, action.action_term, policy.value)
        if policy is OverActionsPolicy.QUEUE:
            self._over_requests.append(request)
            return
        action.result = policy is OverActionsPolicy.IGNORE_SECOND
        if not action.result:
            action.failure_reason = "over_action"
            action.failure_msg = (f"'{action.action_term}' arrived in a step "
                                  f"'{ag_arch.ag_name}' had already acted in")
        ag_arch.action_executed(action)

    ### the step boundary (Jason's startNewStep) ##########

    def _start_new_step(self) -> None:
        # ag: a loop, not the self-call Java uses. Promoted over-requests can
        # complete one round after another, and each nesting level was a real
        # Python stack frame -- a RecursionError silently swallowed by the
        # except below. The loop also runs step_started() exactly once per
        # step, with that step's own number (the recursive version ran it once
        # per nesting level, all with the final number).
        while self._running:
            with self._requests_lock:
                self._step += 1
                step_now = self._step
                try:
                    # 1. run the actions that come due -- feedback comes later
                    for request in self._requests.values():
                        request.remain_steps -= 1
                        if request.remain_steps == 0:
                            self._invoke_action(request.ag_arch, request.action)

                    # 2. now the world is settled, refresh what everyone perceives
                    self.update_ags_percept()
                except Exception:
                    # ag: narrowed to the two calls that run user code. It used
                    # to wrap the bookkeeping below too, so a failure here left
                    # requests undelivered and hung the barrier in silence.
                    if self._running:
                        logger.exception("error while running step %d", step_now)

                # 3. collect the agents whose action actually ran; the feedback
                # itself is delivered below, OUTSIDE the lock -- what a round
                # guarantees is the ORDER (percepts refreshed before anyone is
                # told its action finished), not that delivery happens under
                # _requests_lock. Delivering under it meant taking every
                # agent's _feedback_actions_lock and _batch_lock, one at a
                # time, while every other agent's act()/get_percepts() waited.
                done_names = [n for n, r in self._requests.items() if r.remain_steps == 0]
                done = [self._requests.pop(n) for n in done_names]

                # note: requests is NOT cleared wholesale -- entries still
                # waiting out a multi-step action stay, and keep counting as
                # "this agent has acted" in test_end_cycle below

                # 4. pull in second actions that were queued during the round
                still_over: deque[_ActRequest] = deque()
                for request in self._over_requests:
                    name = request.ag_arch.ag_name
                    if name in self._requests:
                        still_over.append(request)
                    else:
                        self._requests[name] = request
                self._over_requests = still_over

                # those promotions may already complete the next round
                again = self.nb_ags > 0 and self.test_end_cycle(self._requests.keys())

            # --- outside the lock from here: each of these reaches into every
            # agent's own locks, and step_started is user code
            for request in done:
                request.ag_arch.action_executed(request.action)
            self.inform_ags_environment_changed()
            self.step_started(step_now)
            if not again:
                return

    ### timeout thread ##########

    def _ensure_timeout_thread(self) -> None:
        """Started on the first action rather than in __init__ (where Jason
        starts it): a subclass has not finished building its world yet when
        our __init__ runs, and a step firing into a half-built environment is
        a race Jason only survives because its timeouts are seconds long."""
        if self._timeout_thread is not None or self._step_timeout <= 0:
            return
        self._timeout_thread = threading.Thread(
            target=self._timeout_loop, name="env-step-timeout", daemon=True)
        self._timeout_thread.start()

    def _all_ag_finished(self) -> None:
        with self._timeout_cond:
            self._all_finished = True
            self._timeout_cond.notify()

    def _timeout_loop(self) -> None:
        while self._running:
            with self._timeout_cond:
                started = time.monotonic()
                by_timeout = False
                if not self._all_finished:
                    # False means the wait timed out rather than being
                    # signalled, i.e. some agents never acted
                    by_timeout = not self._timeout_cond.wait(self._step_timeout)
                self._all_finished = False
                elapsed = time.monotonic() - started
            if not self._running:
                return
            # outside the condition: both are user code and _start_new_step
            # takes a different lock
            try:
                self.step_finished(self._step, elapsed, by_timeout)
            except Exception:
                logger.exception("error in step_finished for step %d", self._step)
            self._start_new_step()

    ### percepts / teardown ##########

    def get_percepts(self, ag_name: str) -> list[Literal] | None:
        if not self._stepped:
            return super().get_percepts(ag_name)
        # same lock the step boundary holds: perception is frozen while a
        # round is being applied, so nobody sees a half-updated world
        with self._requests_lock:
            return super().get_percepts(ag_name)

    def stop(self) -> None:
        self._running = False
        self._all_ag_finished()  # unblock the timeout thread so it can exit
        super().stop()
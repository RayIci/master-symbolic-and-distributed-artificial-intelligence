from __future__ import annotations

import logging
from pathlib import Path

from lark import Lark, Transformer
from lark.exceptions import UnexpectedInput, VisitError

from icaros.as_syntax.parser.entry_points import parse as parse_as
from icaros.as_syntax.parser.errors import ASParseError
from icaros.llm.providers import reserved_params
from icaros.mas2i.model import AgentSpec, EnvironmentSpec, MASConfig
from icaros.parse_diagnostics import format_syntax_error


class MAS2IParseError(Exception):
    pass


class _LocatedError(MAS2IParseError):
    """A transformer-stage failure that knows where in the .mas2i file it
    happened. Only parse_mas() knows the file's *name*, so the message is
    finished there (with_source) -- to come out in the same
    "file:line:col: what" shape a syntax error does."""

    def __init__(self, line: int, column: int, message: str):
        super().__init__(f"line {line}, column {column}: {message}")
        self.line, self.column, self.message = line, column, message

    def with_source(self, source: str) -> MAS2IParseError:
        return MAS2IParseError(f"{source}:{self.line}:{self.column}: {self.message}")


_GRAMMAR = (Path(__file__).resolve().parent / "mas2i.lark").read_text()
_parser = Lark(_GRAMMAR, parser="lalr", start="mas", maybe_placeholders=True)

# regex-defined terminals with no fixed spelling -- every other terminal in
# this grammar is a keyword/punctuation literal, picked up automatically by
# format_syntax_error() from the grammar itself.
_OVERRIDES = {
    "NAME": "a name",
    "PATH": "a .asl file path",
    "PY_PATH": "a .py file path",
    "DIR_PATH": "a directory path",
    "INT": "a number",
    "BOOL": "'true' or 'false'",
    "BELIEF_LINE": "a belief literal",
    "OPTION_LINE": "a 'key=value' option",
    "MODEL_NAME": "a model name",
    "LLM_SELECTION_NAME": "one of: event, message, option, intention, action",
    "GEN_LIMIT_NAME": "one of: still, talk, run, fly, burn",
    "UI_NAME": "one of: web, none",
    "LLM_TOOL_FAMILY": "one of: plans, internal_actions, journal, rag",
    "TOOL_SELECTOR": "'all', a goal indicator (book_flight/2), a plan label, "
                     "or an internal action (.print)",
    "PARAM_VALUE": "a value: true, false, a number, or a word",
    "PROMPT_KEY": "one of: history, beliefs, rag_grounding",
    "PROMPT_SETTING": "'on', 'off' or a number",
}

# the wildcard inside an llm_tools family: `- plans / - all`
ALL_TOOLS = "all"

# providers supported by icaros.llm.providers; extend as new providers land
_SUPPORTED_PROVIDERS = ("ollama", "openai", "anthropic", "openai_compatible")

# what each `prompt:` key accepts. "size" takes a number, `on` (the default
# size, spelled out) or `off`; "switch" takes only on/off. Written here rather
# than in the grammar because one terminal covering both keeps the lexer out
# of a choice it cannot make -- and because the error a reader wants names the
# key, which the grammar cannot do.
_PROMPT_KEYS = {"history": "size", "beliefs": "switch", "rag_grounding": "size"}


class _MASTransformer(Transformer):
    def source_prop(self, children):
        (path,) = children
        return ("source", Path(str(path)))

    def instances_prop(self, children):
        (n,) = children
        return ("instances", int(n))

    def belief_item(self, children):
        (tok,) = children
        text = str(tok).strip()
        try:
            return parse_as("literal", text)
        except ASParseError as e:
            # e.explanation, not str(e): the latter carries the belief's own
            # line/column, which are the snippet's, not this file's
            raise _LocatedError(tok.line, tok.column,
                                f"invalid belief '{text}': {e.explanation}") from e

    def beliefs_prop(self, children):
        return ("beliefs", list(children))

    def agent_class_prop(self, children):
        (path,) = children
        return ("agent_class", Path(str(path)))

    def ag_arch_class_prop(self, children):
        (path,) = children
        return ("ag_arch_class", Path(str(path)))

    def belief_base_class_prop(self, children):
        (path,) = children
        return ("belief_base_class", Path(str(path)))

    def rag_prop(self, children):
        (flag,) = children
        return ("rag", str(flag).lower() == "true")

    def embed_model_prop(self, children):
        (tok,) = children
        return ("embed_model", str(tok))

    def option_item(self, children):
        (tok,) = children
        raw = str(tok).strip()
        if "=" not in raw:
            raise _LocatedError(tok.line, tok.column,
                                f"malformed option '{raw}' (expected key=value)")
        key, _, value = raw.partition("=")
        return (key.strip(), value.strip())

    def options_prop(self, children):
        return ("options", dict(children))

    def agentic_prop(self, children):
        # the section's presence is the switch; what is inside it is the
        # config. dict() so a repeated property is last-one-wins, the same
        # permissive rule agent_decl uses for everything else.
        return ("agentic", dict(children))

    # ag: the superseded spellings. They parse (see the grammar's own note)
    # so that this is where a reader lands, with the new shape spelled out,
    # instead of at a bare "expected '{'". Located on the offending token,
    # because unlike the old agentic/provider cross-check the fix goes exactly
    # where the error is.
    def _moved(self, tok, what: str, into: str) -> None:
        raise _LocatedError(tok.line, tok.column,
                            f"'{what}' is no longer a property on its own; it goes inside "
                            f"{into}, e.g.\n"
                            f"    agentic {{\n"
                            f"        provider: ollama\n"
                            f"        model:    qwen3.5\n"
                            f"    }}")

    def agentic_legacy(self, children):
        (tok,) = children
        if str(tok).lower() == "false":
            raise _LocatedError(tok.line, tok.column,
                                "'agentic: false' is now written by leaving the agent's "
                                "'agentic { }' section out altogether")
        raise _LocatedError(tok.line, tok.column,
                            "'agentic: true' is now a section: write 'agentic { ... }' "
                            "with this agent's provider, model and the rest of its LLM "
                            "config inside it (an empty 'agentic { }' takes everything "
                            "from 'default_agentic { }')")

    def provider_legacy(self, children):
        self._moved(children[0], "provider", "the agent's 'agentic { }' section")

    def model_legacy(self, children):
        self._moved(children[0], "model", "the agent's 'agentic { }' section")

    def default_provider_legacy(self, children):
        self._moved(children[0], "default_provider", "'default_agentic { }'")

    def default_model_legacy(self, children):
        self._moved(children[0], "default_model", "'default_agentic { }'")

    def param_value(self, children):
        """One `name: value` inside params { }, typed.

        ag: the .lark hands over one PARAM_VALUE terminal for every scalar and
        the type is decided here, because a grammar that tried would need
        three terminals competing over `256` and `0.2` -- and because "0.2 is
        not a number" is a sentence only Python is in a position to write.
        Anything that is not a bool and not a number stays a string: that is
        `reasoning_effort: low` and every enum-shaped parameter after it.
        """
        name, raw = children
        text = str(raw)
        lowered = text.lower()
        if lowered in ("true", "false"):
            value = lowered == "true"
        else:
            try:
                value = int(text)
            except ValueError:
                try:
                    value = float(text)
                except ValueError:
                    value = text
        return (str(name), value)

    def param_group(self, children):
        """A nested `name { ... }`, for a parameter whose value is an object.

        Anthropic's `thinking { type: enabled  budget_tokens: 256 }` is the
        case this exists for. One rule instead of a special case per provider,
        which is the whole stance of params: icaros does not know what these
        mean and does not need to.
        """
        name, *entries = children
        return (str(name), dict(entries))

    def chat_stream_prop(self, children):
        (flag,) = children
        return ("chat_stream", str(flag).lower() == "true")

    def params_prop(self, children):
        return ("params", dict(children))

    def prompt_entry(self, children):
        key, setting = children
        name, raw = str(key), str(setting).lower()
        kind = _PROMPT_KEYS[name]
        if raw in ("on", "off"):
            return (name, raw == "on")
        if kind == "switch":
            raise _LocatedError(
                setting.line, setting.column,
                f"'{name}' is a section, not a size: write 'on' or 'off', not '{raw}'")
        return (name, int(raw))

    def prompt_prop(self, children):
        return ("prompt", dict(children))

    def provider_prop(self, children):
        (tok,) = children
        provider = str(tok)
        if provider not in _SUPPORTED_PROVIDERS:
            supported = ", ".join(_SUPPORTED_PROVIDERS)
            raise _LocatedError(tok.line, tok.column,
                                f"unknown provider '{provider}' (supported: {supported})")
        return ("provider", provider)

    def model_prop(self, children):
        (tok,) = children
        return ("model", str(tok))

    def gen_limit_prop(self, children):
        (tok,) = children
        return ("gen_limit", str(tok))

    def gen_path_prop(self, children):
        (tok,) = children
        return ("gen_path", Path(str(tok)))

    def gen_max_rounds_prop(self, children):
        (tok,) = children
        return ("gen_max_rounds", int(str(tok)))

    def llm_selection_item(self, children):
        (tok,) = children
        return str(tok)

    def llm_selections_prop(self, children):
        return ("llm_selections", set(children))

    def llm_tool_entry(self, children):
        (tok,) = children
        return tok

    def llm_tools_prop(self, children):
        """Regroups the flat entry list: a family name opens a group, every
        selector after it belongs to that group."""
        groups: dict[str, set[str] | None] = {}
        current: str | None = None
        for tok in children:
            text = str(tok)
            if tok.type == "LLM_TOOL_FAMILY":
                # a family named twice: the second occurrence reopens it,
                # same permissive last-one-wins the rest of this file uses
                current = text
                groups[current] = set()
                continue
            if current is None:
                # the commonest way to land here is the pre-rename spelling,
                # `- goals`, which now lexes as an ordinary selector
                raise _LocatedError(
                    tok.line, tok.column,
                    f"'{text}' is not under a family; list it below "
                    f"'- plans', '- internal_actions', '- journal' or '- rag'")
            if groups[current] is not None:
                groups[current].add(text)
        # None means the whole family: nothing was listed under it, or "all" was
        return ("llm_tools", {
            family: None if not members or ALL_TOOLS in members else frozenset(members)
            for family, members in groups.items()})

    def agent_decl(self, children):
        name, *props = children
        values = dict(props)  # a repeated property key: last one wins (not specially validated)
        # ag: `agentic { }` is a section, so its absence -- not a boolean
        # inside it -- is what makes an agent non-agentic, and every LLM
        # property lives inside it. That is why there is no check here for
        # "provider written without agentic": there is nowhere to write it.
        # This method used to carry one, over a list of four property names
        # that had to be kept in step with the grammar by hand.
        llm = values.get("agentic")
        agentic = llm is not None
        llm = llm or {}
        selections = llm.get("llm_selections", set())
        rag = values.get("rag", False)
        if rag and "belief_base_class" in values:
            raise _LocatedError(
                name.line, name.column,
                f"agent '{name}' sets both 'rag' and 'belief_base_class'; "
                f"'rag: true' IS belief_base_class: RagBeliefBase, so drop one of them")
        embed_model = values.get("embed_model")
        if rag and not embed_model:
            raise _LocatedError(
                name.line, name.column,
                f"agent '{name}' sets 'rag: true' but no 'embed_model'; "
                f"add 'embed_model: <name>' to it")
        if embed_model and not rag:
            raise _LocatedError(
                name.line, name.column,
                f"agent '{name}' sets 'embed_model' but not 'rag'; "
                f"add 'rag: true' to it, or drop 'embed_model'")
        return AgentSpec(
            name=str(name),
            agentic=agentic,
            line=name.line,
            column=name.column,
            source=values.get("source", Path(f"{name}.asl")),
            instances=values.get("instances", 1),
            beliefs=values.get("beliefs", []),
            agent_class=values.get("agent_class"),
            ag_arch_class=values.get("ag_arch_class"),
            belief_base_class=values.get("belief_base_class"),
            rag=rag,
            embed_model=embed_model,
            options=values.get("options", {}),
            provider=llm.get("provider"),
            model=llm.get("model"),
            params=llm.get("params"),
            chat_stream=llm.get("chat_stream", True),
            prompt=llm.get("prompt"),
            llm_select_event="event" in selections,
            llm_select_message="message" in selections,
            llm_select_option="option" in selections,
            llm_select_intention="intention" in selections,
            llm_select_action="action" in selections,
            llm_tools=llm.get("llm_tools"),
            gen_limit=values.get("gen_limit", "still"),
            gen_path=values.get("gen_path"),
            gen_max_rounds=values.get("gen_max_rounds", 12),
        )

    def environment_decl(self, children):
        (path,) = children
        return EnvironmentSpec(source=Path(str(path)))

    def path_item(self, children):
        (p,) = children
        return Path(str(p))

    def asl_source_path_decl(self, children):
        return ("asl_source_path", list(children))

    def threads_decl(self, children):
        (n,) = children
        return ("threads", int(n))

    def ui_decl(self, children):
        (name,) = children
        return ("ui", str(name))

    def tui_decl(self, children):
        (flag,) = children
        # deprecated alias for `ui:`, kept one release so existing .mas2i
        # files keep working -- the warning is what tells their authors
        logging.getLogger(__name__).warning(
            "mas2i: `tui:` is deprecated, use `ui: %s` instead",
            "web" if str(flag).lower() == "true" else "none")
        return ("ui", "web" if str(flag).lower() == "true" else "none")

    def default_agentic_decl(self, children):
        return ("default_agentic", dict(children))

    @staticmethod
    def _resolve_llm_config(agents: list[AgentSpec], defaults: dict) -> None:
        """Folds default_agentic into every agentic AgentSpec, then validates.

        ag: the merge lives here, not in mas2i/loader.py where it used to, for
        two reasons. The checks below need the RESOLVED values, so they would
        otherwise have to exist in both places; and an AgentSpec read by
        anything other than the loader used to show provider=None for an agent
        that in fact inherits the MAS default. Field-wise, not pair-wise: an
        agent naming only `model:` still inherits the default provider.
        `params` merges one key at a time for the same reason -- a MAS-wide
        `num_ctx` should survive an agent that only wanted its own
        temperature. Non-agentic agents are skipped: declaring a default is
        not the same as asking for one, so it never quietly makes an agent
        LLM-backed.

        Two things are rejected here rather than earlier, both because they
        need the resolved provider: an agentic agent with nothing to connect
        to, and a params key icaros builds itself.
        """
        for spec in agents:
            if not spec.agentic:
                continue
            if spec.provider is None:
                spec.provider = defaults.get("provider")
            if spec.model is None:
                spec.model = defaults.get("model")
            shared = defaults.get("params")
            if shared:
                spec.params = {**shared, **(spec.params or {})}
            missing = [n for n in ("provider", "model") if getattr(spec, n) is None]
            if missing:
                names = " and ".join(missing)
                raise _LocatedError(
                    spec.line, spec.column,
                    f"agent '{spec.name}' is agentic but has no {names}; "
                    f"set {' and '.join(f'{n}:' for n in missing)} inside its "
                    f"'agentic {{ }}', or in 'default_agentic {{ }}' for the whole MAS")
            taken = reserved_params(spec.provider, spec.params)
            if taken:
                raise _LocatedError(
                    spec.line, spec.column,
                    f"agent '{spec.name}' sets {', '.join(taken)} in params, but icaros "
                    f"builds {'those' if len(taken) > 1 else 'that'} itself; "
                    f"drop {'them' if len(taken) > 1 else 'it'}")

    def mas(self, children):
        name, *items = children
        agents = [i for i in items if isinstance(i, AgentSpec)]
        environments = [i for i in items if isinstance(i, EnvironmentSpec)]
        asl_path_blocks = [i[1] for i in items if isinstance(i, tuple) and i[0] == "asl_source_path"]
        threads_values = [i[1] for i in items if isinstance(i, tuple) and i[0] == "threads"]
        ui_values = [i[1] for i in items if isinstance(i, tuple) and i[0] == "ui"]
        default_agentic_values = [i[1] for i in items
                                  if isinstance(i, tuple) and i[0] == "default_agentic"]
        # repeated `environment:`/`asl_source_path:`/`threads:`/`ui:`/
        # `default_agentic { }` blocks: last one wins, same permissive style
        # already used for repeated properties inside agent_decl
        environment = environments[-1] if environments else None
        asl_source_path = asl_path_blocks[-1] if asl_path_blocks else []
        threads = threads_values[-1] if threads_values else None
        ui = ui_values[-1] if ui_values else "web"
        default_agentic = default_agentic_values[-1] if default_agentic_values else None
        self._resolve_llm_config(agents, default_agentic or {})
        return MASConfig(name=str(name), agents=agents, environment=environment,
                          asl_source_path=asl_source_path, threads=threads, ui=ui,
                          default_agentic=default_agentic)


_transformer = _MASTransformer()


def parse_mas(text: str, *, source: str | None = None) -> MASConfig:
    try:
        tree = _parser.parse(text)
    except UnexpectedInput as e:
        raise MAS2IParseError(format_syntax_error(e, text, _parser, source=source,
                                                  overrides=_OVERRIDES)) from e
    try:
        return _transformer.transform(tree)
    except VisitError as e:
        # ag: same unwrap trick as as_syntax.parser.entry_points.parse -- a
        # raise inside a Transformer method arrives wrapped in VisitError.
        if isinstance(e.orig_exc, _LocatedError) and source is not None:
            raise e.orig_exc.with_source(source) from e
        if isinstance(e.orig_exc, MAS2IParseError):
            raise e.orig_exc from e
        raise
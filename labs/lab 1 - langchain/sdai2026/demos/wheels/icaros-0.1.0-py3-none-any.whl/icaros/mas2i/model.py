from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from icaros.as_syntax.literal import Literal


@dataclass
class AgentSpec:
    name: str
    source: Path  # as written in the mas2i; resolved later against the file's dir
    instances: int = 1
    beliefs: list[Literal] = field(default_factory=list)
    agent_class: Path | None = None       # .py file defining a single Agent subclass
    ag_arch_class: Path | None = None     # .py file defining a single AgArch subclass
    belief_base_class: Path | None = None  # .py file defining a single BeliefBase subclass
    # `rag: true` -- shorthand for belief_base_class pointing at icaros.bb.rag
    # .rag_belief_base.RagBeliefBase, the one built-in BeliefBase subclass
    # (semantic retrieval over this agent's own beliefs). Mutually exclusive
    # with belief_base_class: the parser rejects both being set (see
    # _MASTransformer.agent_decl) rather than picking a winner.
    rag: bool = False
    # which Ollama model backs rag:'s embedder (OllamaEmbedder's model=).
    # Required exactly when rag is True -- the parser rejects either one
    # without the other (see _MASTransformer.agent_decl).
    embed_model: str | None = None
    options: dict[str, str] = field(default_factory=dict)
    # New Icaros features
    # whether the .mas2i gave this agent an `agentic { }` section at all.
    # False means loader.py boots it with agentic=None. Every field below
    # comes from inside that section, so they are None/empty exactly when this
    # is False -- there is nowhere else to write them.
    agentic: bool = False
    # the EFFECTIVE provider/model after parsing, not just what this agent's
    # own section wrote: parse_mas folds in default_agentic for agentic
    # agents. Non-None exactly when agentic is True.
    provider: str | None = None
    model: str | None = None
    # `params { }` -- the provider's OWN request parameters, untranslated and
    # not interpreted here (icaros.llm.providers decides where each one lands
    # in the request). Values are scalars or, for a composite parameter, a
    # nested dict. Merged key-wise over default_agentic's own params by
    # parse_mas. None means the section was not written.
    params: dict | None = None
    # `chat_stream:` -- whether a chat answer is streamed to a watching UI as
    # it is written. True by default, and only ever consulted for a
    # conversation session. Not to be confused with the provider's own
    # `stream` request parameter, which is a reserved params key: this is
    # icaros's decision about what it can read back, not a value passed on.
    chat_stream: bool = True
    # `prompt:` -- which sections of a session's system message get built and
    # how big, as the raw {key: int|bool} the parser validated.
    # icaros.llm.prompts.PromptConfig.from_mas2i turns it into the object
    # Icaros reads, and owns the defaults. None means "as before", which here
    # is a real answer and not an absence: unlike llm_tools this block prunes
    # rather than permits, so nothing written means nothing pruned.
    prompt: dict | None = None
    llm_select_event: bool = False
    llm_select_message: bool = False
    llm_select_option: bool = False
    llm_select_intention: bool = False
    llm_select_action: bool = False
    # `llm_tools:` (inside `agentic { }`) -- family name to the members of it
    # exposed as LLM tools, where None as a value means the whole family. None
    # for the whole field means the property was not declared, and an agent
    # that does not declare it offers its model no tools at all: this is a
    # limit on what an LLM may reach for, so nothing is the default. See
    # Agent.llm_tools().
    llm_tools: dict[str, frozenset[str] | None] | None = None
    # how far up the generation scale this agent may go, as an ordered ladder:
    # still < talk < run < fly < burn. "still" is the bottom rung and the
    # default, so the ladder is opt-in -- keep it in sync with the default in
    # the parser's agent_decl()
    gen_limit: str = "still"
    # where a "burn" agent's generated internal actions are written, relative
    # to the .mas2i (resolved by the loader, like environment: and
    # asl_source_path:). None means the model's Python is compiled in memory
    # and never reaches the disk -- declaring a directory is what makes
    # generation persistent, and is the only thing that permits the write.
    gen_path: Path | None = None
    # per-agent override of icaros.llm.session.MAX_ROUNDS (the ceiling on
    # round trips a single .talk/.run/.fly/.burn session may take). 12 written
    # out rather than imported, same reasoning as gen_limit's own default
    # above -- keep it in sync with MAX_ROUNDS if that ever changes.
    gen_max_rounds: int = 12
    # where this agent's name token sits in the .mas2i, for diagnostics raised
    # after agent_decl() has already returned (the agentic/provider/model
    # cross-check in mas(), which needs the MAS-wide defaults to be known).
    # None when the spec wasn't built by the parser.
    line: int | None = None
    column: int | None = None


@dataclass
class EnvironmentSpec:
    source: Path  # .py file defining a single Environment subclass


@dataclass
class MASConfig:
    name: str
    agents: list[AgentSpec] = field(default_factory=list)
    environment: EnvironmentSpec | None = None
    asl_source_path: list[Path] = field(default_factory=list)
    # if set, every agent in this MAS shares one bounded thread pool of this
    # size instead of getting its own dedicated OS thread (Jason's
    # `infrastructure: Local(pool,N)`)
    threads: int | None = None
    # which frontend the runner opens: "web" (the developer UI, in its own
    # window) or "none" (terminal logs only). "none" is the right choice past
    # a few hundred agents -- the UI keeps per-agent state and is built for
    # tens. `tui: false`/`tui: true` in a .mas2i still map onto this.
    ui: str = "web"
    # `default_agentic { }` -- MAS-wide connection defaults (provider, model,
    # params), already folded into every agentic AgentSpec by parse_mas. Kept
    # here for a reader of the config rather than for the loader, which only
    # ever needs the resolved per-agent values. It deliberately cannot carry
    # llm_tools/llm_selections/prompt: those are per-agent questions, and the
    # grammar refuses them here rather than leaving it to a convention.
    default_agentic: dict | None = None
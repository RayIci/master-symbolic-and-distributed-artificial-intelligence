from __future__ import annotations

import importlib.util
from copy import deepcopy
from pathlib import Path
from typing import TYPE_CHECKING

from icaros.architecture.ag_arch import AgArch
from icaros.as_semantics.agent import Agent
from icaros.as_semantics.icaros import Icaros
from icaros.as_syntax.factory import parse_agent
from icaros.bb.belief_base import BeliefBase
from icaros.bb.rag.embedder import OllamaEmbedder
from icaros.bb.rag.index import BeliefIndex
from icaros.bb.rag.rag_belief_base import RagBeliefBase
from icaros.environment.environment import Environment
from icaros.llm.prompts import PromptConfig
from icaros.mas2i.model import AgentSpec, EnvironmentSpec
from icaros.mas2i.parser.parser import parse_mas
from icaros.mas2i.progress import BootProgress, _Reporter
from icaros.runtime.boot import boot_agent
from icaros.runtime.runner import Runner
from icaros.runtime.scheduler import AgentScheduler
from icaros.stdlib.registry import collect_internal_actions

if TYPE_CHECKING:
    from types import ModuleType

    from icaros.stdlib.registry import InternalAction


def _expand_names(spec: AgentSpec) -> list[str]:
    if spec.instances == 1:
        return [spec.name]
    return [f"{spec.name}{i}" for i in range(1, spec.instances + 1)]


def _import_module(source: Path, label: str) -> ModuleType:
    # ag: same dynamic-file-loading idiom as stdlib/registry.py's extra_paths
    # for internal actions (importlib.util.spec_from_file_location +
    # module_from_spec + exec_module); duplicated rather than shared since
    # mas2i and stdlib are otherwise unrelated modules. `label` only shows up
    # in the synthetic module name and load-failure message.
    module_name = f"icaros_mas2i_{label}_{source.stem}_{abs(hash(str(source))):x}"
    mod_spec = importlib.util.spec_from_file_location(module_name, source)
    if mod_spec is None or mod_spec.loader is None:
        raise ImportError(f"cannot load {label} from '{source}'")
    module = importlib.util.module_from_spec(mod_spec)
    mod_spec.loader.exec_module(module)
    return module


def _load_subclass(base: Path, py_path: Path, base_class: type, label: str) -> type:
    # `label` is the .mas2i property name (e.g. "environment", "agent_class"),
    # used only in the not-found/load-failure messages; the no/multiple-
    # subclass messages use base_class.__name__ (e.g. "Environment", "Agent")
    # since that's the class actually being extended.
    source = (base / py_path).resolve()
    if not source.is_file():
        raise FileNotFoundError(f"{label} source not found: '{source}'")
    module = _import_module(source, label)

    candidates = [obj for obj in vars(module).values()
                  if isinstance(obj, type) and issubclass(obj, base_class) and obj is not base_class
                  and obj.__module__ == module.__name__]
    if not candidates:
        raise ValueError(f"no {base_class.__name__} subclass found in '{source}'")
    if len(candidates) > 1:
        names = ", ".join(c.__name__ for c in candidates)
        raise ValueError(f"multiple {base_class.__name__} subclasses found in '{source}': {names}")
    return candidates[0]


def _load_environment(base: Path, spec: EnvironmentSpec) -> Environment:
    return _load_subclass(base, spec.source, Environment, "environment")()


def _discover_project_internal_actions(
        project_dir: Path, exclude: frozenset[Path] = frozenset()) -> dict[str, InternalAction]:
    """Every @internal_action-decorated object defined in any .py file under
    project_dir (recursively) -- the pythonic, auto-discovered equivalent of
    Jason's `package.ClassName extends DefaultInternalAction` user actions.
    A file directly in project_dir keeps whatever name its decorator gave it
    (the stdlib's own default: a leading dot, e.g. ".myAction"). A file in a
    subfolder gets reprefixed to f"{folder_name}.{leaf}" (leading dot
    stripped) -- the folder stands in for Jason's package.

    `exclude` skips files already imported elsewhere under their own synthetic
    module name (namely the environment source, loaded by _load_environment
    before this runs) -- without it, that file's module-level code ran twice,
    once per synthetic name, and its class existed as two unrelated objects."""
    found: dict[str, InternalAction] = {}
    for py_file in sorted(project_dir.rglob("*.py")):
        if py_file.resolve() in exclude:
            continue
        module = _import_module(py_file, "internal_action")
        for ia in collect_internal_actions(module).values():
            if py_file.parent != project_dir:
                ia.name = f"{py_file.parent.name}.{ia.name.lstrip('.')}"
            found[ia.name] = ia
    return found


def _resolve_asl_source(base: Path, spec: AgentSpec, search_path: list[Path]) -> Path:
    # local-to-the-mas2i-file resolution (today's only behavior) always wins;
    # asl_source_path is only a fallback for sources shared across projects.
    primary = (base / spec.source).resolve()
    if primary.is_file():
        return primary
    for directory in search_path:
        candidate = (base / directory / spec.source).resolve()
        if candidate.is_file():
            return candidate
    # naming the agent matters more than usual now that `source:` is
    # optional: with it left out, the .asl being looked for is one the
    # .mas2i file never actually mentions (it defaults to "<name>.asl")
    searched = ", ".join(str(base / d) for d in [Path(".")] + list(search_path))
    raise FileNotFoundError(
        f"agent '{spec.name}': source not found: {spec.source} (searched: {searched})")


def load_mas(mas2i_path: str | Path, progress: BootProgress | None = None, *,
             llm_client_factory=None) -> Runner:
    """Boots a whole MAS. `progress`, when given, is called as each step
    completes -- see mas2i/progress.py. It is called on this thread, so a UI
    consumer must not block in it.

    `llm_client_factory`, when given, replaces LlmClient for every Icaros this
    boots -- the injection seam a test needs, since load_mas is what actually
    constructs each agentic agent's Icaros and hands the caller no other way
    in. Everywhere else in icaros, `LlmClient(chat=...)`/`Icaros(chat=...)` is
    the seam; this is the one place that builds the client several layers
    down from the caller, so the factory is threaded through instead.
    """
    reporter = _Reporter(progress)
    path = Path(mas2i_path)
    reporter.at("parse", f"reading {path.name}")
    config = parse_mas(path.read_text(), source=str(path))
    base = path.parent  # agent sources are relative to the mas2i file, not cwd
    # only countable now: 1 parse + 1 environment + one .asl parse per agent
    # block + one boot per instance
    reporter.set_total(2 + len(config.agents) + sum(s.instances for s in config.agents))
    reporter.step("parse", f"{config.name}: {len(config.agents)} agent block(s)")

    runner = Runner()
    runner.ui = config.ui
    env_source = (base / config.environment.source).resolve() if config.environment is not None else None
    if config.environment is not None:
        reporter.at("environment", f"loading {config.environment.source.name}")
        runner.environment = _load_environment(base, config.environment)
    reporter.step("environment", "environment ready" if env_source else "no environment")
    if config.threads is not None:
        runner.scheduler = AgentScheduler(config.threads, name_prefix=f"{config.name}-ag")

    exclude = frozenset({env_source}) if env_source is not None else frozenset()
    project_actions = _discover_project_internal_actions(base, exclude=exclude)

    for spec in config.agents:
        source = _resolve_asl_source(base, spec, config.asl_source_path)
        runner.agent_groups.append((spec.name, spec.instances))
        reporter.at("asl", f"parsing {source.name}")
        # parsed once per `agent` block, then cloned per instance by
        # boot_agent/load_parsed_asl -- same pattern as boot.py's KQML
        # plans, now also covering `instances: N` (was N full re-parses)
        parsed_source = parse_agent(source.read_text(), base_dir=source.parent, source_name=str(source))
        reporter.step("asl", f"{source.name} parsed")

        agent_cls = (_load_subclass(base, spec.agent_class, Agent, "agent_class")
                     if spec.agent_class else Agent)
        ag_arch_cls = (_load_subclass(base, spec.ag_arch_class, AgArch, "ag_arch_class")
                       if spec.ag_arch_class else AgArch)
        if spec.belief_base_class:
            bb_cls = _load_subclass(base, spec.belief_base_class, BeliefBase, "belief_base_class")
        elif spec.rag:
            # spec.embed_model is never None here -- the parser rejects
            # rag: true without embed_model: (see _MASTransformer.agent_decl)
            bb_cls = lambda: RagBeliefBase(index=BeliefIndex(embedder=OllamaEmbedder(model=spec.embed_model)))
        else:
            bb_cls = None

        for name in _expand_names(spec):
            bb = bb_cls() if bb_cls is not None else None
            agent = agent_cls(bb=bb, options=dict(spec.options),
                               se_llm=spec.llm_select_event, sm_llm=spec.llm_select_message,
                               so_llm=spec.llm_select_option, si_llm=spec.llm_select_intention,
                               sa_llm=spec.llm_select_action,
                               llm_tools=spec.llm_tools)
            # Icaros: creating the agentic faculty -- only for an agent whose
            # .mas2i had an `agentic { }` section. Everyone else boots with None,
            # the same state boot_agent() defaults to; nothing here has to resolve
            # provider/model/params any more (parse_mas already folded in the
            # MAS-wide defaults) nor check them, since an agentic spec cannot
            # reach this point with provider or model unset.
            agentic = None
            if spec.agentic:
                # ag: announced BEFORE the call, not after. Agentic.__init__ makes
                # a blocking round trip that loads the model into the
                # provider's memory -- measured at 15.2 s of a 15.2 s boot for
                # examples/llm-tools. Reporting it afterwards would leave the
                # progress bar frozen for exactly as long as the one step a
                # user most needs explained.
                reporter.at("llm", f"{name}: connecting to {spec.provider}/{spec.model}")
                agentic = Icaros(spec.provider, spec.model, params=spec.params,
                                 prompt=PromptConfig.from_mas2i(spec.prompt),
                                 chat_stream=spec.chat_stream,
                                 client_factory=llm_client_factory)
            if project_actions:
                agent.register_internal_actions(project_actions)
            # resolved against the .mas2i's own directory, like environment:
            # and asl_source_path: -- a generated action belongs to the project
            # the file describes, not to wherever `uv run icaros` was typed
            gen_path = (base / spec.gen_path).resolve() if spec.gen_path is not None else None
            ag_arch: AgArch = boot_agent(source, ag_arch=ag_arch_cls(), agent=agent, agentic=agentic, name=name,
                                         parsed=parsed_source, gen_limit=spec.gen_limit,
                                         gen_path=gen_path, gen_max_rounds=spec.gen_max_rounds)
            if runner.scheduler is not None:
                ag_arch.scheduler = runner.scheduler
            for belief in spec.beliefs:
                ag_arch.ts.ag.bb.add(deepcopy(belief))
            runner.add_ag(ag_arch)
            reporter.step("agent", f"{name} ready")
    reporter.at("ready", f"{runner.nb_agents} agent(s) booted")
    return runner
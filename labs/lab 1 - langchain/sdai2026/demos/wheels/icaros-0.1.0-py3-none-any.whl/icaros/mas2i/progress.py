from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass(slots=True)
class BootStep:
    """One reported step of load_mas().

    ag: `total` is only known after the .mas2i has been parsed, so the very
    first steps report total=0 and a UI must treat that as indeterminate
    rather than as "already finished".
    """

    done: int
    total: int
    phase: str  # short, stable: "parse", "environment", "asl", "llm", "agent", "ready"
    detail: str  # human-readable, e.g. 'connecting to ollama/lfm2.5-thinking'

    @property
    def fraction(self) -> float | None:
        """0.0-1.0, or None while the total is still unknown."""
        if self.total <= 0:
            return None
        return min(1.0, self.done / self.total)


# a callback, not a queue or a listener list: load_mas is single-threaded and
# has exactly one consumer, the frontend that asked for the load
BootProgress = Callable[[BootStep], None]


class _Reporter:
    """Counts steps so load_mas doesn't have to thread a counter through."""

    __slots__ = ("_callback", "_done", "_total")

    def __init__(self, callback: BootProgress | None) -> None:
        self._callback = callback
        self._done = 0
        self._total = 0

    def set_total(self, total: int) -> None:
        self._total = total

    def step(self, phase: str, detail: str = "") -> None:
        self._done += 1
        self.at(phase, detail)

    def at(self, phase: str, detail: str = "") -> None:
        """Reports without advancing -- for announcing a slow thing before
        starting it, which is the whole point when it takes 15 seconds."""
        if self._callback is not None:
            self._callback(BootStep(done=self._done, total=self._total,
                                    phase=phase, detail=detail))

from __future__ import annotations

import hashlib
import json
import math
import os
import time
import urllib.error
import urllib.request
from typing import Protocol, runtime_checkable

DEFAULT_HOST = "http://localhost:11434"

EMBED_TRACE_ENV = "ICAROS_EMBED_TRACE"


class EmbeddingError(Exception):
    """The embedding backend could not produce vectors."""


@runtime_checkable
class Embedder(Protocol):
    """What BeliefIndex needs from an embedding backend.

    embed() takes a list even though a single add() only ever has one text to
    embed: batching is what makes the initial load of a belief base (and any
    bulk_note) affordable -- one round trip instead of one per belief.
    """

    @property
    def model_id(self) -> str:
        """Identifies the model, so vectors from different models are never mixed."""
        ...

    def embed(self, texts: list[str]) -> list[list[float]]:
        """One L2-normalised vector per input text, in the same order."""
        ...


def normalize(vector: list[float]) -> list[float]:
    """L2-normalises in place of the caller, so scoring is a plain dot product."""
    norm = math.sqrt(sum(v * v for v in vector))
    if norm == 0.0:
        return list(vector)
    return [v / norm for v in vector]


class OllamaEmbedder(Embedder):
    """Embeddings from a local Ollama server (POST /api/embed).

    No baked-in default model: `model` (or ICAROS_EMBED_MODEL) must say which
    one to load, so a belief base never quietly runs on whatever model
    happened to be installed. The host defaults to localhost, overridable per
    instance or through ICAROS_OLLAMA_HOST. Uses urllib rather than a
    third-party HTTP client to keep this module's own dependencies at lark alone --
    unaffected by icaros/llm/providers.py's `ollama` extra, since this talks to
    Ollama's REST API directly rather than through the `ollama` package.
    """

    def __init__(self, model: str | None = None, host: str | None = None, timeout: float = 60.0):
        self._model = model or os.environ.get("ICAROS_EMBED_MODEL")
        if not self._model:
            raise ValueError(
                "OllamaEmbedder needs a model: pass model=, or set ICAROS_EMBED_MODEL")
        self._host = (host or os.environ.get("ICAROS_OLLAMA_HOST", DEFAULT_HOST)).rstrip("/")
        self._timeout = timeout

    @property
    def model_id(self) -> str:
        return f"ollama:{self._model}"

    @property
    def host(self) -> str:
        return self._host

    def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        payload = json.dumps({"model": self._model, "input": list(texts)}).encode()
        request = urllib.request.Request(
            f"{self._host}/api/embed", data=payload, headers={"Content-Type": "application/json"})
        started = time.perf_counter()
        try:
            with urllib.request.urlopen(request, timeout=self._timeout) as response:
                body = json.load(response)
        except (urllib.error.URLError, OSError, ValueError) as e:
            raise EmbeddingError(
                f"ollama embed failed ({self._host}, model '{self._model}'): {e}") from e
        self._trace_roundtrip((time.perf_counter() - started) * 1000.0, len(texts))

        vectors = body.get("embeddings")
        if not isinstance(vectors, list) or len(vectors) != len(texts):
            raise EmbeddingError(
                f"ollama returned {len(vectors) if isinstance(vectors, list) else 'no'} "
                f"embedding(s) for {len(texts)} input(s)")
        return [normalize(v) for v in vectors]

    def _trace_roundtrip(self, duration_ms: float, n_texts: int) -> None:
        """Append one {ts, model_id, n_texts, duration_ms} line when told to.

        ag: embedding round trips do not go through LlmClient, so --llm-trace
        never sees them and a timing study would silently under-count the LLM
        work of an agent with rag: true. Rather than thread the trace writer
        down into the belief base, the embedder appends to its own file when
        ICAROS_EMBED_TRACE names one -- epoch timestamps on both sides
        correlate it with the main trace. Best effort: a trace outage must
        never cost a game its embeddings.
        """
        path = os.environ.get(EMBED_TRACE_ENV)
        if not path:
            return
        try:
            with open(path, "a") as f:
                f.write(json.dumps({
                    "ts": time.time(),
                    "model_id": self.model_id,
                    "n_texts": n_texts,
                    "duration_ms": duration_ms,
                }) + "\n")
        except OSError:
            pass

    def is_available(self) -> bool:
        """Whether the server answers at all -- for skipping integration tests."""
        try:
            with urllib.request.urlopen(f"{self._host}/api/version", timeout=2.0):
                return True
        except (urllib.error.URLError, OSError):
            return False

    def __repr__(self) -> str:
        return f"<OllamaEmbedder {self._model} at {self._host}>"


class HashingEmbedder(Embedder):
    """Offline, deterministic embedder (the hashing trick over whitespace tokens).

    No network and no model, so tests can exercise the whole indexing path
    without Ollama. blake2b rather than hash() because str hashing is salted
    per process, and the vectors have to be stable across runs.
    """

    def __init__(self, dim: int = 64):
        self._dim = dim

    @property
    def model_id(self) -> str:
        return f"hashing:{self._dim}"

    @property
    def dim(self) -> int:
        return self._dim

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._embed_one(text) for text in texts]

    def _embed_one(self, text: str) -> list[float]:
        vector = [0.0] * self._dim
        for token in text.split():
            digest = hashlib.blake2b(token.lower().encode(), digest_size=8).digest()
            index = int.from_bytes(digest[:4], "big") % self._dim
            vector[index] += 1.0 if digest[4] & 1 else -1.0
        return normalize(vector)

    def __repr__(self) -> str:
        return f"<HashingEmbedder dim={self._dim}>"
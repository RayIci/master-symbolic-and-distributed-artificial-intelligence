from __future__ import annotations

import heapq
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from icaros.bb.rag.embedder import EmbeddingError, OllamaEmbedder
from icaros.bb.rag.store import shared_store
from icaros.bb.rag.verbalizer import belief_to_text

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable

    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.literal import Literal
    from icaros.bb.rag.embedder import Embedder
    from icaros.bb.rag.store import VectorStore

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RetrievalHit:
    literal: Literal
    score: float
    text: str

    def __str__(self) -> str:
        return f"{self.score:.3f}  {self.literal}"


@dataclass
class _IndexEntry:
    literal: Literal
    text: str
    vector: list[float] | None  # None only while an embedding failure is outstanding


class BeliefIndex:
    """Semantic index over the literals of one belief base.

    Kept in step with the belief base synchronously: note() embeds there and
    then, so a belief is retrievable the instant add() returns. The cost is
    paid once per distinct text thanks to the VectorStore -- a re-added belief,
    or the same belief in another agent, is free.

    Owned by one agent thread. The only shared state is the VectorStore, which
    carries its own lock.
    """

    def __init__(self, embedder: Embedder | None = None,
                 verbalizer: Callable[[Literal], str] = belief_to_text,
                 store: VectorStore | None = None, strict: bool = False):
        self._embedder = embedder if embedder is not None else OllamaEmbedder()
        self._verbalizer = verbalizer
        self._store = store if store is not None else shared_store()
        self._strict = strict
        # keyed on id() of the literal actually held by the belief base. Safe
        # because the entry keeps a strong reference to it, so the id cannot be
        # recycled while the entry lives -- and it makes forget() O(1).
        self._entries: dict[int, _IndexEntry] = {}
        self._degraded = False

    @property
    def embedder(self) -> Embedder:
        return self._embedder

    @property
    def store(self) -> VectorStore:
        return self._store

    ### keeping the index in step ##########

    def note(self, literal: Literal | None) -> None:
        """Indexes (or re-indexes) one belief. Synchronous."""
        if literal is None:
            return
        text = self._verbalizer(literal)
        entry = self._entries.get(id(literal))
        if entry is not None and entry.text == text and entry.vector is not None:
            return  # unchanged since last time: nothing to recompute
        vectors = self._embed([text])
        self._entries[id(literal)] = _IndexEntry(literal, text, vectors[0] if vectors else None)

    def bulk_note(self, literals: Iterable[Literal]) -> None:
        """As note(), for many beliefs in a single round trip to the backend.

        Worth using whenever beliefs arrive in a batch (the initial load of an
        agent): 32 texts in one call cost ~137ms against ~960ms one at a time.
        """
        pending = [(lit, self._verbalizer(lit)) for lit in literals if lit is not None]
        stale = [(lit, text) for lit, text in pending if self._is_stale(lit, text)]
        if not stale:
            return
        vectors = self._embed([text for _, text in stale])
        for i, (literal, text) in enumerate(stale):
            self._entries[id(literal)] = _IndexEntry(literal, text, vectors[i] if vectors else None)

    def forget(self, literal: Literal) -> None:
        self._entries.pop(id(literal), None)

    def forget_all(self, literals: Iterable[Literal]) -> None:
        for literal in literals:
            self.forget(literal)

    def clear(self) -> None:
        self._entries.clear()

    def _is_stale(self, literal: Literal, text: str) -> bool:
        entry = self._entries.get(id(literal))
        return entry is None or entry.text != text or entry.vector is None

    ### retrieval ##########

    def retrieve(self, query: str, k: int = 5, *, include_rules: bool = False,
                 namespace: Atom | None = None, min_score: float | None = None,
                 refresh: bool = True) -> list[RetrievalHit]:
        """The k beliefs closest to `query`, most similar first.

        Rules are left out unless asked for, matching what .belief does in
        stdlib/internal_actions/beliefs_rules.py.

        `refresh` re-verbalises the indexed literals and re-embeds any whose
        text has drifted. It costs string work proportional to the size of the
        belief base and (thanks to the cache) usually no embedding at all, and
        it buys immunity to beliefs mutated behind the belief base's back --
        Agent.brf deletes annotations straight on the stored literal
        (agent.py:168) without going through remove().
        """
        if k <= 0 or not self._entries:
            return []

        candidates = [entry for entry in self._entries.values()
                      if (include_rules or not entry.literal.is_rule())
                      and (namespace is None or entry.literal.ns == namespace)]
        if not candidates:
            return []

        if refresh:
            self._refresh(candidates)
        self._retry_unindexed(candidates)

        query_vectors = self._embed([query])
        if not query_vectors:
            return []
        query_vector = query_vectors[0]

        scored = ((self._similarity(query_vector, entry.vector), entry) for entry in candidates)
        ranked = ((score, entry) for score, entry in scored if score is not None)
        if min_score is not None:
            ranked = ((score, entry) for score, entry in ranked if score >= min_score)
        # key= so ties never fall through to comparing the entries, which aren't ordered
        best = heapq.nlargest(k, ranked, key=lambda pair: pair[0])
        return [RetrievalHit(entry.literal, score, entry.text) for score, entry in best]

    def _refresh(self, candidates: list[_IndexEntry]) -> None:
        drifted = [(entry, self._verbalizer(entry.literal)) for entry in candidates]
        drifted = [(entry, text) for entry, text in drifted if entry.text != text]
        if not drifted:
            return
        vectors = self._embed([text for _, text in drifted])
        for i, (entry, text) in enumerate(drifted):
            entry.text = text
            entry.vector = vectors[i] if vectors else None

    def _retry_unindexed(self, candidates: list[_IndexEntry]) -> None:
        pending = [entry for entry in candidates if entry.vector is None]
        if not pending:
            return
        vectors = self._embed([entry.text for entry in pending])
        if vectors is None:
            return
        for entry, vector in zip(pending, vectors, strict=True):
            entry.vector = vector

    @staticmethod
    def _similarity(query_vector: list[float], vector: list[float] | None) -> float | None:
        # vectors are L2-normalised by the embedder, so the dot product *is* the
        # cosine. A length mismatch means the entry predates a model change --
        # skip it rather than crash; the next refresh re-embeds it.
        if vector is None or len(vector) != len(query_vector):
            return None
        return sum(a * b for a, b in zip(query_vector, vector, strict=True))

    ### backend access ##########

    def _embed(self, texts: list[str]) -> list[list[float]] | None:
        """Vectors for `texts`, or None if the backend is unreachable.

        Swallowing the failure is the default because note() is reached from
        Agent.brf inside the reasoning cycle: an Ollama that is down must slow
        the agent, not kill it. The belief still enters the symbolic belief
        base, and the next retrieve() retries the embedding.
        """
        try:
            vectors = self._store.get_or_compute(texts, self._embedder)
        except EmbeddingError as e:
            if self._strict:
                raise
            # first failure is worth a warning; repeating it every reasoning
            # cycle for as long as Ollama stays down is not
            level = logging.DEBUG if self._degraded else logging.WARNING
            logger.log(level, "belief index degraded, %d belief(s) unindexed: %s", len(texts), e)
            self._degraded = True
            return None
        self._degraded = False
        return vectors

    def __len__(self) -> int:
        return len(self._entries)

    def __repr__(self) -> str:
        return f"<BeliefIndex {len(self._entries)} beliefs, {self._embedder.model_id}>"
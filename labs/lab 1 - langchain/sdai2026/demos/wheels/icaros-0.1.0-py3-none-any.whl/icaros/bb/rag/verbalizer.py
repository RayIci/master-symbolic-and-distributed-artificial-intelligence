from __future__ import annotations

import re
from typing import TYPE_CHECKING

from icaros.as_syntax.literal import Literal

if TYPE_CHECKING:
    from icaros.as_syntax.term import Term

# annotations that carry no meaning for a reader and would poison the vector
# cache: add_source_info_as_annots() stamps the source file and line onto a
# literal, which would make every belief's text unique and every lookup a miss.
_IGNORED_ANNOTS = frozenset({"code_src", "code_line", "code"})

# LogExpr / RelExpr / ArithExpr keep the operator in the functor slot (" & ",
# " > ", "+", ...). Spelling them out is worth real accuracy: an embedding model
# has plenty to say about "greater than" and nothing about ">".
_OPERATOR_WORDS = {
    "&": "and", "|": "or", "not": "not",
    ">": "greater than", ">=": "at least", "<": "less than", "<=": "at most",
    "==": "equals", "\\==": "differs from", "=": "is", "=..": "destructured as",
    "+": "plus", "-": "minus", "*": "times", "/": "divided by",
    "**": "to the power of", "div": "divided by", "mod": "modulo",
}

# compiled once: belief_to_text runs on every add(), cache hits included
_CAMEL = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")
_SEPARATORS = re.compile(r"[_\-.]+")
_WHITESPACE = re.compile(r"\s+")
_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def split_identifier(name: str) -> str:
    """`nearLeastVisited` / `near_least_visited` -> `near least visited`.

    Embedding models are trained on prose, so an identifier they see as one
    unknown token is worth much more once it is split into real words. Lowered
    because the split leaves mid-word capitals that read as proper nouns, and
    because it folds `Pos`/`pos` onto a single cache entry.
    """
    return _WHITESPACE.sub(" ", _CAMEL.sub(" ", _SEPARATORS.sub(" ", name))).strip().lower()


def belief_to_text(literal: Literal) -> str:
    """Renders a belief as the text that gets embedded.

    `at(robot,pos(3,4))[source(percept)]` -> `at robot pos 3 4 from percept`.
    Rules become `head if body`. The result doubles as the cache key, so it has
    to be a pure function of the literal: nothing positional, nothing timed.
    """
    core = _literal_text(literal)
    if literal.is_rule():
        core = f"{core} if {_render(literal.get_body())}"
    annots = _annots_text(literal)
    return f"{core} {annots}".strip() if annots else core


def _literal_text(literal: Literal) -> str:
    prefix: list[str] = []
    ns = literal.ns
    if ns is not None and ns != Literal.default_ns:
        prefix.append(split_identifier(ns.functor))
    if literal.negated():
        prefix.append("not")
    return " ".join([*prefix, _structure_text(literal)]).strip()


def _structure_text(term: Term) -> str:
    """functor + arguments, with operator functors rendered infix."""
    functor = getattr(term, "functor", None)
    if functor is None:
        return _operators_as_words(str(term))
    # get_terms() is None, not [], on a Structure built without terms
    terms = term.get_terms() or ()
    operator = _operator_word(functor)
    if operator is not None:
        if len(terms) == 2:
            return f"{_render(terms[0])} {operator} {_render(terms[1])}".strip()
        if len(terms) == 1:
            return f"{operator} {_render(terms[0])}".strip()
    parts = [split_identifier(functor), *(_render(t) for t in terms)]
    return " ".join(p for p in parts if p)


def _operator_word(functor: str) -> str | None:
    """The word for an operator functor, or None if this is a real predicate name.

    The identifier test is what keeps a user predicate called `not/1` or `mod/2`
    out of the operator table -- LogExpr's own functors are padded (`" & "`,
    `"not "`), so they never look like identifiers.
    """
    if _IDENTIFIER.match(functor):
        return None
    symbol = functor.strip()
    return _OPERATOR_WORDS.get(symbol) or symbol or None


def _annots_text(literal: Literal) -> str:
    if not literal.has_annot():
        return ""
    parts: list[str] = []
    for annot in literal.annots:
        if isinstance(annot, Literal) and annot.functor in _IGNORED_ANNOTS:
            continue
        # source(percept) reads better -- and embeds better -- as "from percept",
        # and telling percept from self from another agent's name is exactly the
        # kind of thing a retrieval query asks about
        if isinstance(annot, Literal) and annot.functor == "source" and annot.get_arity() == 1:
            parts.append(f"from {_render(annot.get_term(0))}")
        else:
            parts.append(_render(annot))
    return " ".join(p for p in parts if p)


def _render(term: Term | None) -> str:
    if term is None:
        return ""
    if term.is_string():
        return term.string or ""
    # before is_numeric: an ArithExpr answers True to both. A ground one is just
    # a number written as an expression (`-2.5` parses as a unary minus) and
    # should read as its value; an unground one (a rule body's `X + 1`) cannot
    # be solved and has to be spelled out.
    if term.is_arith_expr():
        if term.is_ground():
            try:
                return _number_text(term.solve())
            except ArithmeticError:
                pass
        return _structure_text(term)
    if term.is_numeric():
        return _number_text(term.solve())
    if term.is_list() or term.is_set() or term.is_queue():
        return " ".join(_render(t) for t in term)
    if isinstance(term, Literal):
        return _literal_text(term)
    if term.is_structure():
        return _structure_text(term)
    # map terms, plan bodies, cyclic terms: no structural walk worth writing
    return _operators_as_words(str(term))


def _number_text(value: float) -> str:
    # 3.0 is written `3` in the source and should embed as `3`, not `3.0`
    return str(int(value)) if value == int(value) else str(value)


def _operators_as_words(text: str) -> str:
    for symbol, word in ((" & ", " and "), (" | ", " or ")):
        text = text.replace(symbol, word)
    return _WHITESPACE.sub(" ", text).strip()
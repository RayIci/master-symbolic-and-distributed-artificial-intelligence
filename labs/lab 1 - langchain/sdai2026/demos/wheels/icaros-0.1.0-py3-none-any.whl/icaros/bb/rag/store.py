from __future__ import annotations

import os
import threading
from collections import OrderedDict
from typing import TYPE_CHECKING

from icaros.bb.rag.embedder import EmbeddingError

if TYPE_CHECKING:
    from collections.abc import Sequence

    from icaros.bb.rag.embedder import Embedder

DEFAULT_MAX_ENTRIES = 50_000


class VectorStore:
    """Cache of text -> vector, so a belief text is embedded at most once.

    Keyed on the verbalised text rather than on the Literal, for two reasons.
    A text always maps to the same vector for a given model, so the cache never
    needs invalidating: a percept that enters and leaves the belief base every
    reasoning cycle is embedded once for the life of the process. And literals
    are mutable *and* hashable at the same time (the hazard BeliefBucket works
    around by indexing hashes into lists instead of using literals as keys), so
    they make poor cache keys.

    One instance is shared by every agent by default (see shared_store): agents
    running the same .asl overwhelmingly share belief texts, so the first
    instance pays for the embedding and the rest hit the cache. That makes this
    the one object in the RAG layer touched by more than one agent thread,
    hence the lock -- under free-threaded CPython a dict gives no guarantee for
    a read concurrent with a write.
    """

    def __init__(self, max_entries: int = DEFAULT_MAX_ENTRIES):
        self._vectors: OrderedDict[str, list[float]] = OrderedDict()
        self._lock = threading.Lock()
        self._max_entries = max_entries
        self._hits = 0
        self._misses = 0

    def get_or_compute(self, texts: Sequence[str], embedder: Embedder) -> list[list[float]]:
        """Vectors for `texts`, in order, embedding only the ones not cached.

        Raises EmbeddingError if the backend fails; nothing is cached in that case.
        """
        wanted: list[str] = []
        seen: set[str] = set()
        for text in texts:
            if text not in seen:
                seen.add(text)
                wanted.append(text)

        found: dict[str, list[float]] = {}
        missing: list[str] = []
        with self._lock:
            for text in wanted:
                vector = self._vectors.get(text)
                if vector is None:
                    missing.append(text)
                else:
                    self._vectors.move_to_end(text)
                    found[text] = vector
            self._hits += len(found)
            self._misses += len(missing)

        if missing:
            # deliberately outside the lock: this is a ~30ms round trip to Ollama,
            # and holding the lock across it would serialise every other agent
            # behind it. Two threads racing on the same missing text just compute
            # it twice and store the same answer -- wasteful, never wrong.
            computed = embedder.embed(missing)
            if len(computed) != len(missing):
                raise EmbeddingError(
                    f"embedder returned {len(computed)} vectors for {len(missing)} texts")
            with self._lock:
                for text, vector in zip(missing, computed, strict=True):
                    self._vectors[text] = vector
                    self._vectors.move_to_end(text)
                    found[text] = vector
                while len(self._vectors) > self._max_entries:
                    self._vectors.popitem(last=False)

        return [found[text] for text in texts]

    def peek(self, text: str) -> list[float] | None:
        """The cached vector, without computing anything (and without LRU touch)."""
        with self._lock:
            return self._vectors.get(text)

    def clear(self) -> None:
        with self._lock:
            self._vectors.clear()
            self._hits = 0
            self._misses = 0

    @property
    def stats(self) -> tuple[int, int]:
        """(hits, misses) since the last clear -- how much the cache is earning."""
        with self._lock:
            return self._hits, self._misses

    def __len__(self) -> int:
        with self._lock:
            return len(self._vectors)

    def __repr__(self) -> str:
        hits, misses = self.stats
        return f"<VectorStore {len(self)}/{self._max_entries} entries, {hits} hits, {misses} misses>"


_shared_store: VectorStore | None = None
_shared_store_lock = threading.Lock()


def shared_store() -> VectorStore:
    """The process-wide cache every BeliefIndex uses unless given its own."""
    global _shared_store
    with _shared_store_lock:
        if _shared_store is None:
            max_entries = int(os.environ.get("ICAROS_RAG_CACHE_SIZE", DEFAULT_MAX_ENTRIES))
            _shared_store = VectorStore(max_entries)
        return _shared_store
from __future__ import annotations

from typing import TYPE_CHECKING

from icaros.bb.belief_base import BeliefBase
from icaros.bb.rag.index import BeliefIndex

if TYPE_CHECKING:
    from icaros.as_syntax.atom import Atom
    from icaros.as_syntax.literal import Literal
    from icaros.as_syntax.predicate_indicator import PredicateIndicator
    from icaros.bb.rag.index import RetrievalHit


class RagBeliefBase(BeliefBase):
    """A belief base that also answers "which beliefs are about X?".

    The symbolic side is inherited untouched -- unification, logical
    consequence, annotation merging and source bookkeeping all behave exactly
    as in BeliefBase. The overrides below exist only to tell the semantic index
    what changed, and they do it synchronously: when add() returns, the belief
    is retrievable.

    Enable it for a project with `rag: true` in the .mas2i (shorthand for
    `belief_base_class:` pointing at this class -- see mas2i/loader.py), or
    build one directly for the LLM layer.
    """

    def __init__(self, index: BeliefIndex | None = None, **index_options):
        super().__init__()
        # the signature must stay callable with no arguments: mas2i/loader.py
        # instantiates the class named by `belief_base_class:` as bb_cls().
        # Calling it that way still raises, though, unless ICAROS_EMBED_MODEL
        # is set -- OllamaEmbedder() has no default model to fall back on
        # (see embedder.py). `rag: true` in the .mas2i always passes one
        # explicitly (embed_model:, required alongside it), so this path is
        # only reachable via a custom belief_base_class: or direct Python use.
        self._index = index if index is not None else BeliefIndex(**index_options)

    @property
    def index(self) -> BeliefIndex:
        return self._index

    ### semantic retrieval ##########

    def retrieve(self, query: str, k: int = 5, **options) -> list[RetrievalHit]:
        """The k beliefs closest in meaning to `query`. See BeliefIndex.retrieve."""
        return self._index.retrieve(query, k, **options)

    def reindex(self) -> None:
        """Re-embeds the whole belief base in one batch.

        Worth calling once after the initial beliefs are loaded, where dozens
        arrive back to back and one batched round trip beats one call each.
        """
        self._index.bulk_note(list(self))

    ### keeping the index in step with the belief base ##########

    def add(self, literal: Literal, add_in_end: bool = False) -> bool:
        added = super().add(literal, add_in_end)
        if added:
            # index the object that actually went into the bucket, not the
            # caller's: add() either stores literal.copy() or merges the new
            # annotations into the literal already there (belief_base.py:79-88)
            self._index.note(self.find(literal))
        return added

    def remove(self, literal: Literal) -> bool:
        # captured first: if the belief is physically removed there is no way
        # to reach the stored object afterwards, and that object is the index key
        stored = self.find(literal)
        removed = super().remove(literal)
        if removed and stored is not None:
            if self.find(literal) is None:
                self._index.forget(stored)
            else:
                # survived with fewer annotations (belief_base.py:91-99), and
                # annotations are part of the verbalised text
                self._index.note(stored)
        return removed

    def abolish(self, namespace: Atom, pi: PredicateIndicator) -> bool:
        doomed = list(self.get_candidate_beliefs(pi) or ())
        abolished = super().abolish(namespace, pi)
        if abolished:
            self._index.forget_all(doomed)
        return abolished

    def clear(self) -> None:
        super().clear()
        self._index.clear()

    def __repr__(self) -> str:
        return f"<RagBeliefBase {self.size} beliefs, {self._index!r}>"
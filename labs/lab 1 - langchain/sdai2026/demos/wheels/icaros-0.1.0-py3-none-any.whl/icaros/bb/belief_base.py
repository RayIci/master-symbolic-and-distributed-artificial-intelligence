from __future__ import annotations

from typing import Set, Dict, Deque, Iterator

from collections import deque

from icaros.as_semantics.unifier import Unifier
from icaros.as_syntax.atom import Atom
from icaros.as_syntax.pred import Pred
from icaros.as_syntax.predicate_indicator import PredicateIndicator
from icaros.as_syntax.literal import Literal
from icaros.as_syntax.term import Term


class BeliefBase:

    self_atom = Atom("self")
    percept_atom = Atom("percept")

    self_source_term = Pred.create_source(self_atom)
    percept_source_term = Pred.create_source(percept_atom)

    def __init__(self):
        self._beliefs_default_namespace: Dict[PredicateIndicator, BeliefBucket] = dict()
        self._namespaces: Dict[Atom, Dict[PredicateIndicator, BeliefBucket]] = dict()
        self._namespace_props: Dict[Atom, Dict[Atom, Term]] = dict()
        self._size: int = 0
        self._has_select_option : bool = False
        # ag: Jason's DefaultBeliefBase.percepts, the index Agent.buf() diffs
        # against. Keyed by id() of the stored object, not by the literal:
        # a perceived belief grows extra annots through import_annots() (say,
        # it is also told by another agent), and a plain set of literals then
        # stops __eq__-matching it (hash still matched, __eq__ didn't) --
        # set.remove() raised KeyError and killed the agent thread. Identity
        # cannot drift like that. Entries leave only when the object leaves
        # the belief base (remove_from_entry/abolish/clear); losing just the
        # source(percept) annot -- which Agent.brf can do straight on the
        # stored literal -- is filtered out when reading, see get_percepts().
        self._percepts: Dict[int, Literal] = dict()

        self._namespaces[Literal.default_ns] = self._beliefs_default_namespace

    @property
    def namespaces(self) -> Set[Atom]:
        return set(self._namespaces.keys())

    def set_namespace_prop(self, namespace: Atom, key: Atom, value: Term) -> None:
        if namespace not in self._namespace_props:
            self._namespace_props[namespace] = dict()
        self._namespace_props[namespace][key] = value

    def get_namespace_prop(self, namespace: Atom, key: Atom) -> Term | None:
        return self._namespace_props.get(namespace, {}).get(key)

    def get_namespace_props(self, namespace: Atom) -> Set[Atom]:
        if namespace not in self._namespace_props:
            return set()
        return set(self._namespace_props[namespace].keys())

    @property
    def size(self) -> int:
        return self._size

    @property
    def percepts(self) -> Set[Literal]:
        return set(self.get_percepts())

    def get_percepts(self) -> list[Literal]:
        """Jason's getPercepts(): the stored beliefs that currently carry
        source(percept) -- the objects themselves, so do not mutate them;
        remove one through remove() with a source(percept) literal, which
        keeps its other sources (and subclasses' own indexes) intact.

        ag: a snapshot list rather than Jason's live iterator with remove(),
        so the caller can modify the belief base while walking it."""
        return [b for b in self._percepts.values() if b.has_source(self.percept_atom)]

    def clear(self) -> None:
        self._size = 0
        self._percepts.clear()
        self._beliefs_default_namespace.clear()
        self._namespaces.clear()
        self._namespaces[Literal.default_ns] = self._beliefs_default_namespace

    def add(self, literal: Literal, add_in_end: bool = False) -> bool:
        if not literal.can_be_added_in_bb():
            raise Exception(f"Literal {literal} cannot be added in bb")
        if literal.ns.is_var():
            raise Exception(f"Literal {literal} cannot be placed in an unground namespace {literal.ns}")

        belief: Literal = self.find(literal)
        if belief is not None and not belief.is_rule():
            if belief.import_annots( literal ):
                self._note_percept(belief)
                return True
        else:
            belief = literal.copy()
            entry: BeliefBucket = self.provide_belief_entry(belief)
            entry.add(belief, add_in_end)
            self._size += 1
            self._note_percept(belief)
            return True
        return False

    def _note_percept(self, belief: Literal) -> None:
        if belief.has_source(self.percept_atom):
            self._percepts[id(belief)] = belief

    def remove(self, literal: Literal) -> bool:
        belief: Literal = self.find(literal)
        if belief is not None:
            if literal.has_subset_annot(belief):
                # ag: literal.annots is None for an annotation-less literal -- del_annots(None)
                # would call the no-arg "delete everything" overload instead of "nothing to delete"
                result: bool = belief.del_annots(literal.annots) if literal.annots is not None else False
                return self.remove_from_entry(belief) | result
        return False

    def remove_from_entry(self, literal: Literal) -> bool:
        if literal.has_source():
           return False
        beliefs_map = self._beliefs_default_namespace if literal.ns == Literal.default_ns else self._namespaces.get(literal.ns)
        key: PredicateIndicator = literal.get_predicate_indicator()
        entry: BeliefBucket = beliefs_map[key]
        entry.remove(literal)
        if entry.is_empty():
            del beliefs_map[key]
        self._size -= 1
        self._percepts.pop(id(literal), None)
        return True

    def abolish(self, namespace: Atom, pi: PredicateIndicator) -> bool:
        beliefs_map = self._namespaces.get(namespace)
        if beliefs_map is None:
            return False
        entry: BeliefBucket | None = beliefs_map.pop(pi, None)
        if entry is not None:
            self._size -= entry.size()
            for belief in entry:
                self._percepts.pop(id(belief), None)
            return True
        return False

    def find(self, literal: Literal) -> Literal | None:
        beliefs_map = self._beliefs_default_namespace if literal.ns == Literal.default_ns else self._namespaces.get(literal.ns)
        if beliefs_map is None:
            return None
        entry: BeliefBucket | None = beliefs_map.get(literal.get_predicate_indicator())
        if entry is None:
            return None
        return entry.find(literal)

    # ag: Java overloads getCandidateBeliefs by parameter type (PredicateIndicator vs
    # Literal,Unifier) -- Python can't dispatch on that, so the two got distinct names
    # (same treatment as get_annots_by_functor, see porting.md).
    def get_candidate_beliefs(self, pi: PredicateIndicator) -> Iterator[Literal] | None:
        pi2entry = self._namespaces.get(pi.ns)
        if pi2entry is None:
            return None
        entry: BeliefBucket | None = pi2entry.get(pi)
        if entry is not None:
            return iter(entry)
        return None

    def get_candidate_beliefs_for_literal(self, literal: Literal, unifier: Unifier) -> Iterator[Literal] | None:
        if literal.is_var():
            return iter(self)
        beliefs_map = self._beliefs_default_namespace
        if literal.ns != Literal.default_ns:
            ns: Atom = literal.ns
            if ns.is_var():
                literal = literal.resolve(unifier)
                ns = literal.ns
            if ns.is_var():
                return iter(self)
            beliefs_map = self._namespaces.get(ns)
        if beliefs_map is None:
            return None
        entry: BeliefBucket | None = beliefs_map.get(literal.get_predicate_indicator())
        if entry is not None:
            return iter(entry)
        return None

    def __str__(self) -> str:
        return str(self._namespaces)


    @property
    def has_select_option(self) -> bool:
        return self._has_select_option

    def provide_belief_entry(self, literal: Literal) -> BeliefBucket:
        beliefs_map = self._beliefs_default_namespace
        if literal.ns != Literal.default_ns:
            beliefs_map = self._namespaces.get(literal.ns)
            if beliefs_map is None:
                beliefs_map = dict()
                self._namespaces[literal.ns] = beliefs_map
        entry: BeliefBucket | None = beliefs_map.get(literal.get_predicate_indicator())
        if entry is None:
            entry = BeliefBucket()
            beliefs_map[literal.get_predicate_indicator()] = entry
        return entry

    def __iter__(self) -> Iterator[Literal]:
        for beliefs_map in self._namespaces.values():
            for entry in beliefs_map.values():
                yield from entry

class BeliefBucket():
    """
    A BeliefBucket puts together all the beliefs with the same predicate indicator.
    """

    def __init__(self):
        self._list: Deque[Literal] = deque()
        # ag: hash-bucketed index restoring the O(1)-amortized find()/add()
        # Jason's DefaultBeliefBase gets from its own structural map. Keyed by
        # hash(literal) rather than a dedicated wrapper type: Structure's own
        # calc_hash_code()/__hash__ (what hash() already calls) hashes exactly
        # functor+namespace+terms -- the same fields equals_as_structure()
        # compares, both deliberately ignoring annotations -- so it's already
        # the right "structural" hash for this index. _list stays the source
        # of truth for ordering/iteration; this only accelerates lookups.
        self._map: Dict[int, list[Literal]] = {}

    def add(self, literal: Literal, add_in_end: bool) -> None:
        if add_in_end:
            self._list.append(literal)
        else:
            self._list.appendleft(literal)
        self._map.setdefault(hash(literal), []).append(literal)

    def remove(self, literal: Literal) -> None:
        self._list.remove(literal)
        bucket = self._map.get(hash(literal))
        if bucket is not None:
            for i, cur in enumerate(bucket):
                if cur is literal or cur.equals_as_structure(literal):
                    del bucket[i]
                    break
            if not bucket:
                del self._map[hash(literal)]

    def size(self) -> int:
        return len(self._list)

    def is_empty(self) -> bool:
        return len(self._list) == 0

    def find(self, literal: Literal) -> Literal | None:
        bucket = self._map.get(hash(literal))
        if bucket is None:
            return None
        return next((belief for belief in bucket if belief.equals_as_structure(literal)), None)

    def __contains__(self, literal: Literal):
        bucket = self._map.get(hash(literal))
        return bucket is not None and any(belief.equals_as_structure(literal) for belief in bucket)

    def __str__(self) -> str:
        string = ""
        for literal in self._list:
            string += str(literal) + ":" + str(hash(literal)) + ","
        return string

    def __iter__(self) -> Iterator[Literal]:
        return iter(self._list)